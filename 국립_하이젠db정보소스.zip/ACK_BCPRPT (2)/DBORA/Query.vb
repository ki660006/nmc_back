﻿Imports DBORA.DbProvider
Public Class Query
    Public Shared Function BarcordScan_patinfo(ByVal rsbcno As String) As DataTable
        Dim sFn As String = "Function fnget_Allreg_patinfo()  As DataTable"
        Dim sSql As String = ""
        'rsbcno = ""
        Try
            Dim sBCNO As String = Trim(rsbcno)
            Dim err As String = ""
            'sBCNO = sBCNO.Replace("-", "").Trim()

            '< add freety 2005/09/14 : -가 포함된 검체번호 입력도 허용
            sBCNO = sBCNO.Replace("-", "")
            '>

            If Len(sBCNO) = 11 Or Len(sBCNO) = 12 Then
                sBCNO = GetBCPrtToView(Mid(sBCNO, 1, 11))
            End If

            If sBCNO = "" Then
                Throw New Exception("검체번호가 없음")
            End If
            If sBCNO.Length = 14 Then sBCNO += "0"
            If sBCNO.Length < 15 Then Throw New Exception("검체번호가 형식이 맞지않음")

            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT R.bcno, J.regno, R.TESTCD  , f6.tnmd, R.spccd, f3.spcnm,  R.viewrst " + vbCrLf
            sSql += "            , SUBSTR(J.Orddt,1,8)   ORDDT  , SUBSTR(J.Orddt,9,6)   ORDTIME   , SUBSTR(J.BCPRTDT,1,8) BCPRPTDT    , SUBSTR(J.BCPRTDT,9,6) BCPRPTTIME " + vbCrLf
            sSql += "            , SUBSTR(J1.colldt,1,8) colldt , SUBSTR(J1.colldt,9,6) collTIME  , SUBSTR(J1.tkdt,1,8)   tkdt        , SUBSTR(J1.tkdt,9,6)   tktime" + vbCrLf
            sSql += "            , SUBSTR(r.regdt,1,8)   regdt  , SUBSTR(r.regdt,9,6)   regtime   , SUBSTR(r.fndt,1,8)    rstdt       , SUBSTR(r.fndt,9,6)    rstime" + vbCrLf
            sSql += "            FROM LR010M R " + vbCrLf
            sSql += "            INNER JOIN LJ010M J" + vbCrLf
            sSql += "                ON R.BCNO = J.BCNO" + vbCrLf
            sSql += "            INNER JOIN LJ011M J1" + vbCrLf
            sSql += "                ON R.BCNO = J1.BCNO " + vbCrLf
            sSql += "                AND R.TCLSCD = J1.TCLSCD " + vbCrLf
            sSql += "            inner join lf060m f6" + vbCrLf
            sSql += "                on r.testcd =  f6.testcd" + vbCrLf
            sSql += "                and j1.tkdt >= f6.usdt" + vbCrLf
            sSql += "                and j1.tkdt <= f6.uedt" + vbCrLf
            sSql += "            inner join lf030m f3 " + vbCrLf
            sSql += "                on r.spccd = f3.spccd " + vbCrLf
            sSql += "                and j1.tkdt >= f3.usdt" + vbCrLf
            sSql += "                and j1.tkdt <= f3.uedt" + vbCrLf
            sSql += "            WHERE R.BCNO = '" + sBCNO + "'" + vbCrLf

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            CommFN.COMMON_FN.log("query :", Err)
        End Try

    End Function
    Public Shared Function GetBCPrtToView(ByVal rsBcNo As String) As String
        Dim sFn As String = "Function GetBCPrtToView(String) As String"

        Try

            If Not rsBcNo.Length.Equals(11) Then Return ""

            Dim sSql As String = ""
            Dim dt As New DataTable

            sSql = "SELECT fn_ack_get_bcno_normal(?) FROM DUAL"

            Dim al As New ArrayList

            al.Add(New OleDb.OleDbParameter("@prtbcno", rsBcNo))

            DbCommand()
            dt = DbExecuteQuery(sSql, al)

            If dt.Rows.Count > 0 Then
                Return dt.Rows(0).Item(0).ToString
            Else
                Return ""
            End If

        Catch ex As Exception
            CommFN.COMMON_FN.log(sFn, Err)
            Return ""

        End Try

    End Function
End Class
