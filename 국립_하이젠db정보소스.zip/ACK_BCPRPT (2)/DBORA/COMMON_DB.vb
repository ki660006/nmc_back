﻿Namespace CommDb
    Public Class STU_CONNSTR
        Public USEDP As String = ""
        Public PROVIDER As String = ""
        Public CATEGORY As String = ""
        Public DATASOURCE As String = ""
        Public USERID As String = ""
        Public PASSWORD As String = ""
        Public DESCRIPTION As String = ""

        Public Sub New()
            MyBase.New()
        End Sub
    End Class
    Public Class Info
        Private Const sFile As String = "File : CGCOMMON_DB.vb, Class : CommDb.Info" & vbTab


        Public Function GetConnStr() As STU_CONNSTR
            Dim sFn As String = "Private Function GetConnStr() As clsCONN_STR"

            Dim o_stu As New STU_CONNSTR
            Try
                o_stu.USEDP = "2"
                o_stu.PROVIDER = "OraOLEDB.Oracle"
                o_stu.CATEGORY = ""
                o_stu.DATASOURCE = "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST = 10.95.21.144)(PORT=1521))(ADDRESS=(PROTOCOL=TCP)(HOST=10.95.21.143)(PORT=1521))(LOAD_BALANCE=NO)(CONNECT_DATA=(SERVER= DEDICATED)(SERVICE_NAME=EMRDB)(FAILOVER_MODE=(TYPE=SELECT)(METHOD=BASIC)(RETRIES=180)(DELAY=5))))"
                o_stu.USERID = "lisif"
                o_stu.PASSWORD = "lisif"

            Catch ex As Exception
                CommFN.COMMON_FN.log(sFile + sFn, Err)

                o_stu.USEDP = "2"
                o_stu.PROVIDER = "OraOLEDB.Oracle"
                o_stu.CATEGORY = ""
                o_stu.DATASOURCE = "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST = 10.95.21.144)(PORT=1521))(ADDRESS=(PROTOCOL=TCP)(HOST=10.95.21.143)(PORT=1521))(LOAD_BALANCE=NO)(CONNECT_DATA=(SERVER= DEDICATED)(SERVICE_NAME=EMRDB)(FAILOVER_MODE=(TYPE=SELECT)(METHOD=BASIC)(RETRIES=180)(DELAY=5))))"
                o_stu.USERID = "lisif"
                o_stu.PASSWORD = "lisif"

            Finally
                GetConnStr = o_stu

            End Try

        End Function


    End Class
End Namespace

