﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' 어셈블리의 일반 정보는 다음 특성 집합을 통해 제어됩니다.
' 어셈블리와 관련된 정보를 수정하려면
' 이 특성 값을 변경하십시오.

' 어셈블리 특성 값을 검토합니다.

<Assembly: AssemblyTitle("BCPRT01")> 
<Assembly: AssemblyDescription("MEDI@CK.NET LIS 프로그램")> 
<Assembly: AssemblyCompany("ACK Co.,Ltd.")> 
<Assembly: AssemblyProduct("MEDI@CK .Net v3")> 
<Assembly: AssemblyCopyright("Copyrightⓒ 2010 ACK Co.,Ltd. All rights reserved")> 
<Assembly: AssemblyTrademark("MEDI@CK")> 
<Assembly: ComVisible(False)> 

'이 프로젝트가 COM에 노출되는 경우 다음 GUID는 typelib의 ID를 나타냅니다.
<Assembly: Guid("7148cab7-c374-4409-83b9-991494e43100")> 
'<Assembly: AssemblyFileVersion("1.0.0.0")> 

' 어셈블리의 버전 정보는 다음 네 가지 값으로 구성됩니다.
'
'      주 버전
'      부 버전
'      빌드 번호
'      수정 버전
'
' 모든 값을 지정하거나 아래와 같이 '*'를 사용하여 빌드 번호 및 수정 버전이 자동으로
' 지정되도록 할 수 있습니다.
'Version 3.1.10.100 --> 2011/01/01 : 3.1.10.100으로 초기 셋팅
'Version 3.1.10.187 --> 2012/12/17 : 혈액바코드 3차부적합판정 수정
'Version 3.1.10.451 --> 2015/07/15 : 슬라이드라벨 출력
'Version 3.1.10.452 --> 2018/08/29 : 혈액은행 라벨 출력
'Version 3.1.10.489 --> 2017/08/16 : 혈액은행 2D QR 바코드 추가 ,BarCodePrtOut_Blood 함수에 BIXOLON 조건 추가
'Version 3.1.10.490 --> 2017/08/16 : 혈액은행 bixlon 혈액백 여러개일때 오류 수정 , 채혈실 citizon portclose 추가 , bixlon 슬라이드 오류 수정 
'Version 3.1.10.491 --> 2017/08/17 : 혈액은행 외래환자의 경우 환자정보 누락 오류 수정 
'Version 3.1.10.492 --> 2017/08/18 : 바코드 재출력 오류 관련 소스 RollBack
'Version 3.1.10.493 --> 2017/08/18 : 바코드 재출력 오류 관련 소스 RollBack
'Version 3.1.10.495 --> 2019/10/21 : Worklist조회 및 출력 Slide Label 출력 시 라벨에 검사항목명 추가
'Version 3.1.10.496 --> 2019/11/26 : 출고 확인바코드 출력 추가
'Version 3.1.10.497 --> 2019/11/26 : 출고 확인바코드 출력 추가
'Version 3.1.10.498 --> 2019/12/20 : ris bixlon 추가해줌
<Assembly: AssemblyVersion("3.1.10.498")> 