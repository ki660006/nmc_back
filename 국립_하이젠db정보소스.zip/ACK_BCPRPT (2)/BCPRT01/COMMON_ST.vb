﻿
Public Class STU_BCPRTINFO
    Public COLLSEQNO As String = ""     '-- 채혈 대기순번
    Public BCNOPRT As String = ""       '-- 출력용 바코드번호
    Public BCNO As String = ""          '-- 바코드 FULL 번호
    Public REGNO As String = ""         '-- 등록번호
    Public PATNM As String = ""         '-- 환자명
    Public SEXAGE As String = ""        '-- 성별/나이
    Public BCCLSCD As String = ""       '-- 검체구분
    Public DEPTWARD As String = ""      '-- 진료과/병동
    Public IOGBN As String = ""         '-- 입외구분
    Public SPCNM As String = ""         '-- 검체명
    Public TUBECD As String = ""        '-- Tube code
    Public TUBENM As String = ""        '-- Tube name
    Public TESTNMS As String = ""       '-- 검사명
    Public EMER As String = ""          '-- 응급여부(Y)
    Public INFINFO As String = ""       '-- 감염정보
    Public TGRPNM As String = ""        '-- 검사그룹
    Public XMATCH As String = ""        '-- Cross Matching 여부(A)
    Public REMARK As String = ""        '-- 의사 Remark
    Public BCCNT As String = ""
    ' Public BCCNT As Integer = ""         '-- 출력매수
    Public BCTYPE As String = ""        '-- 출력양식
    Public HREGNO As String = ""        '-- 
    Public BCNO_MB As String = ""       '-- 미생물인 경우
    Public OBFTSYN As String = ""       '-- 외래전 검사 여부
    Public METHODCD As String = ""
    Public URGENT As String = ""
    Public BIRTH_DATE As String = ""    '-- 생년월일
    Public INIINFO_FULL As String = ""  '-- 감염정보 full
    Public RS As String = ""            '-- 동의서, 의뢰서
    Public SPCOMMENT As String = ""     '-- 특이사항
    Public COLLWARN As String = ""      '-- 채혈시 주의사항
    Public REMARK_FULL As String = ""   '-- 의사 remark
    Public SEQTYN As String = ""        '-- 연속검사 여부
    Public WKGRPCD As String = ""       '-- 작업그룹

    Public COMNM As String = ""
    Public DRNM As String = ""
    Public PAT_ABORH As String = ""
    Public TKDT As String = ""
    Public ORDDT As String = ""
    Public TKID As String = ""
    Public TESTCD As String = ""
    Public BLDNO As String = ""
    Public FORM As String = ""
End Class
Public Class COMMON_ST

End Class
