﻿Imports System.Windows.Forms
Imports System.IO

Namespace CommFN
    Public Class COMMON_FN
        Public Shared Sub log(ByVal sLog As String)
            Dim sFile As String
            Dim sDir As String

            sDir = Application.StartupPath & "\ErrLog"

            If Dir(sDir, FileAttribute.Directory) = "" Then MkDir(sDir)

            sFile = sDir & "\Err" & Format(Now, "yyyy-MM-dd") & ".txt"
            Dim sw As New StreamWriter(sFile, True, System.Text.Encoding.UTF8)

            sw.WriteLine(Now())
            sw.WriteLine(vbTab & sLog)
            sw.Close()

        End Sub
        Public Shared Sub log(ByVal sLog As String, ByVal e As ErrObject)
            Dim sFile As String
            Dim sDir As String

            sDir = Application.StartupPath & "\ErrLog"

            If Dir(sDir, FileAttribute.Directory) = "" Then MkDir(sDir)

            sFile = sDir & "\Err" & Format(Now, "yyyy-MM-dd") & ".txt"
            Dim sw As New StreamWriter(sFile, True, System.Text.Encoding.UTF8)

            sw.WriteLine(Now())

            sw.WriteLine(sLog)

            sw.WriteLine(vbTab & "Err Number : " & e.Number)
            sw.WriteLine(vbTab & "Err Description : " & e.Description)

            sw.Close()

        End Sub
    End Class
End Namespace

