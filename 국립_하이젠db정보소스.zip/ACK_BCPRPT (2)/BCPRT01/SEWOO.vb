Imports COMMON.SVar
Imports COMMON.CommFN
Imports COMMON.CommFN.Fn
Imports COMMON.CommLogin.LOGIN
Imports COMMON.CommPrint

Public Class SEWOO


    ' Line Pen Type
    Public Const PS_SOLID As Integer = 0
    Public Const PS_DASH As Integer = 1
    Public Const PS_DOT As Integer = 2
    Public Const PS_DASHDOT As Integer = 3
    Public Const PS_DASHDOTDOT As Integer = 4

    Public Declare Function LK_OpenPrinter Lib "LKBSDK.dll" (ByVal PrinterName As String) As Integer
    Public Declare Function LK_ClosePrinter Lib "LKBSDK.dll" () As Integer
    Public Declare Function LK_StartPage Lib "LKBSDK.dll" () As Integer
    Public Declare Function LK_EndPage Lib "LKBSDK.dll" () As Integer
    Public Declare Function LK_SetupPrinter Lib "LKBSDK.dll" (ByVal LabelWidth As String, ByVal LabelLength As String, ByVal MediaType As Integer, ByVal GapHeight As String, ByVal Offset As String, ByVal Density As Integer, ByVal Speed As Integer, ByVal Copies As Integer) As Integer
    Public Declare Function LK_PrintWindowsFont Lib "LKBSDK.dll" (ByVal PosX As Integer, ByVal PosY As Integer, ByVal Degree As Integer, ByVal Height As Integer, ByVal Weight As Integer, ByVal Italic As Integer, ByVal Underline As Integer, ByVal TypeFace As String, ByVal Data As String) As Integer
    Public Declare Function LK_PrintBMP Lib "LKBSDK.dll" (ByVal PosX As Integer, ByVal PosY As Integer, ByVal FileName As String) As Integer
    Public Declare Function LK_PrintPCX Lib "LKBSDK.dll" (ByVal PosX As Integer, ByVal PosY As Integer, ByVal FileName As String) As Integer
    Public Declare Function LK_PrintDeviceFont Lib "LKBSDK.dll" (ByVal PosX As Integer, ByVal PosY As Integer, ByVal Rotation As Integer, ByVal FontNumber As Integer, ByVal HorExpand As Integer, ByVal VerExpand As Integer, ByVal Reverse As Integer, ByVal Data As String) As Integer
    Public Declare Function LK_PrintBarCode Lib "LKBSDK.dll" (ByVal PosX As Integer, ByVal PosY As Integer, ByVal Rotation As Integer, ByVal BarCode As String, ByVal NarrowWidth As Integer, ByVal WideWidth As Integer, ByVal BarHeight As Integer, ByVal Readable As Integer, ByVal Data As String) As Integer
    Public Declare Function LK_PrintLine Lib "LKBSDK.dll" (ByVal PosX As Integer, ByVal PosY As Integer, ByVal HoriSize As Integer, ByVal VertSize As Integer) As Integer
    Public Declare Function LK_PrintDiagonalLine Lib "LKBSDK.dll" (ByVal StartX As Integer, ByVal StartY As Integer, ByVal EndX As Integer, ByVal EndY As Integer, ByVal Thick As Integer) As Integer
    Public Declare Function LK_PrintBox Lib "LKBSDK.dll" (ByVal StartX As Integer, ByVal StartY As Integer, ByVal EndX As Integer, ByVal EndY As Integer, ByVal Thick As Integer) As Integer
    Public Declare Function LK_PrintDate Lib "LKBSDK.dll" (ByVal PosX As Integer, ByVal PosY As Integer, ByVal Degree As Integer, ByVal Height As Integer, ByVal Weight As Integer, ByVal Italic As Integer, ByVal Underline As Integer, ByVal TypeFace As String, ByVal DateFormat As Integer) As Integer
    Public Declare Function LK_PrintTime Lib "LKBSDK.dll" (ByVal PosX As Integer, ByVal PosY As Integer, ByVal Degree As Integer, ByVal Height As Integer, ByVal Weight As Integer, ByVal Italic As Integer, ByVal Underline As Integer, ByVal TypeFace As String, ByVal TimeFormat As Integer) As Integer
    Public Declare Function LK_SetupPrinterCutter Lib "LKBSDK.dll" (ByVal LabelWidth As String, ByVal LabelLength As String, ByVal MediaType As Integer, ByVal GapHeight As String, ByVal Offset As String, ByVal Density As Integer, ByVal Speed As Integer, ByVal Copies As Integer, ByVal Rotation As Integer, ByVal Cutting As Integer, ByVal CutMethod As Integer, ByVal CutPageInterval As Integer, ByVal FeedAfterCut As String) As Integer
    Public Declare Function LK_DrawLine Lib "LKBSDK.dll" (ByVal LineType As Integer, ByVal sx As Integer, ByVal sy As Integer, ByVal ex As Integer, ByVal ey As Integer, ByVal Thick As Integer) As Integer
    Public Declare Function LK_Rectangle Lib "LKBSDK.dll" (ByVal LineType As Integer, ByVal sx As Integer, ByVal sy As Integer, ByVal ex As Integer, ByVal ey As Integer, ByVal Thick As Integer) As Integer
    Public Declare Function LK_Ellipse Lib "LKBSDK.dll" (ByVal LineType As Integer, ByVal sx As Integer, ByVal sy As Integer, ByVal ex As Integer, ByVal ey As Integer, ByVal Thick As Integer) As Integer
    Public Declare Function LK_PrintWindowsFontAlign Lib "LKBSDK.dll" (ByVal Alignment As Integer, ByVal PosY As Integer, ByVal Degree As Integer, ByVal Height As Integer, ByVal Weight As Integer, ByVal Italic As Integer, ByVal Underline As Integer, ByVal TypeFace As String, ByVal Data As String) As Integer
    Public Declare Function LK_PrintWindowsFontPitch Lib "LKBSDK.dll" (ByVal PosX As Integer, ByVal PosY As Integer, ByVal Degree As Integer, ByVal Height As Integer, ByVal Width As Integer, ByVal Weight As Integer, ByVal Italic As Integer, ByVal Underline As Integer, ByVal TypeFace As String, ByVal Data As String) As Integer

    Private Const msFile As String = "File : SEWOO.vb, Class : SEWOO" + vbTab


    Public Overridable Function BarCodePrtOut(ByVal ra_PrtData As ArrayList, _
                                              ByVal rsPrintPort As String, ByVal rsSocketIP As String, ByVal rbFirst As Boolean, _
                                              Optional ByVal riLeftPos As Integer = 0, _
                                              Optional ByVal riTopPos As Integer = 0, _
                                              Optional ByVal rsBarType As String = "CODABAR", _
                                              Optional ByVal rbLabelGbn As Boolean = False) As Boolean
        Dim sFn As String = "BarCodePrtOut"
        Dim bReturn As Boolean = False
        Dim iFileNo As Integer = 0

        Try
            'If LK_OpenPrinter(rsPrintPort) Then
            '    LK_SetupPrinter("55.0", "30.0", 0, "4.0", "0", 8, 6, 1)
            '    LK_ClosePrinter()
            'End If

            For ix1 As Integer = 0 To ra_PrtData.Count - 1

                If CType(ra_PrtData(ix1), STU_BCPRTINFO).REGNO <> "" Then


                    Dim iPrtCnt As Integer = 1


                    If CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT = "A" Then
                        iPrtCnt = 2
                    ElseIf CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT = "B" Then
                        '< CrossMatching ��ü
                        iPrtCnt = 3
                    ElseIf IsNumeric(CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT) Then
                        iPrtCnt = Convert.ToInt32(CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT)
                    End If



                    For ix2 As Integer = 1 To iPrtCnt

                        If LK_OpenPrinter(rsPrintPort) = 0 Then
                            If CType(ra_PrtData(ix1), STU_BCPRTINFO).BCNO = "" And rbLabelGbn = True Then
                                Dim sPrtMsg = fnMakePrtMsg(CType(ra_PrtData(ix1), STU_BCPRTINFO), rbFirst, riLeftPos, riTopPos, rsBarType)
                            ElseIf rbFirst = True And CType(ra_PrtData(ix1), STU_BCPRTINFO).BCNO = "" Then
                                Dim sPrtMsg = fnMakePrtMsg_PATINFO(CType(ra_PrtData(ix1), STU_BCPRTINFO), rbFirst, riLeftPos, riTopPos, rsBarType)
                            Else
                                Dim sPrtMsg = fnMakePrtMsg(CType(ra_PrtData(ix1), STU_BCPRTINFO), rbFirst, riLeftPos, riTopPos, rsBarType)
                            End If

                            LK_ClosePrinter()
                        End If

                        Threading.Thread.Sleep(1000)
                    Next
                End If
            Next

            Return True
        Catch ex As AccessViolationException
            MsgBox("������ ���� ���� �߻�")
            Return False
        Catch ex As Exception
            LK_ClosePrinter()
            Fn.log(msFile + sFn, Err)
            MsgBox(msFile + sFn + vbCrLf + ex.Message, MsgBoxStyle.Information)
            Return False
        Finally
            FileClose(iFileNo)

        End Try
    End Function

    Public Overridable Function BarCodePrtOut_BLD(ByVal roSndMsg As ArrayList, _
                                                  ByVal riPrtCnt As Integer, ByVal rsPrintPort As String, ByVal rsSocketIP As String, _
                                                  Optional ByVal riLeftPos As Integer = 0, _
                                                  Optional ByVal riTopPos As Integer = 0, _
                                                  Optional ByVal rsBarType As String = "CODABAR") As Boolean
        Dim sFn As String = "BarCodePrtOut_BLD"
        Dim bReturn As Boolean = False
        Dim iFileNo As Integer = 0

        Try

            If roSndMsg Is Nothing Then
            Else
                'riPrtCnt = 10
                For ix1 As Integer = 0 To roSndMsg.Count - 1

                    For ix2 As Integer = 1 To riPrtCnt
                        If LK_OpenPrinter(rsPrintPort) = 0 And CType(roSndMsg(ix1), STU_BLDLABEL).BCTYPE <> "D" Then
                            Dim sPrtMsg = fnMakePrtMsg_BLD(CType(roSndMsg(ix1), STU_BLDLABEL), riLeftPos, riTopPos)
                        Else
                            Dim sPrtMsg = fnMakePrtMsg_DON(CType(roSndMsg(ix1), STU_BLDLABEL), riLeftPos, riTopPos, ix2)
                        End If
                        LK_ClosePrinter()
                    Next

                    Threading.Thread.Sleep(1000)
                    LK_ClosePrinter()
                Next
            End If


            Return True
        Catch ioex As System.IO.IOException
            ''������ �ٸ� ���μ������� ��� ���̹Ƿ� ���μ������� �׼����� �� �����ϴ�.
            'If Err.Number = 75 Then
            '    'Recursive Call
            '    BarCodePrtOut(asSndMsg, aiPrtCnt, asIP, aiPort)
            'End If
        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            MsgBox(msFile + sFn + vbCrLf + ex.Message)
            Return False
        Finally
            FileClose(iFileNo)

        End Try
    End Function

    Public Overridable Function BarCodePrtOut_PIS(ByVal ra_PrtData As ArrayList, _
                                                  ByVal rsPrintPort As String, ByVal rsSocketIP As String, ByVal rbFirst As Boolean, _
                                                  Optional ByVal riLeftPos As Integer = 0, _
                                                  Optional ByVal riTopPos As Integer = 0, _
                                                   Optional ByVal rsBarType As String = "CODABAR") As Boolean
        Dim sFn As String = "BarCodePrtOut"
        Dim bReturn As Boolean = False
        Dim iFileNo As Integer = 0

        Try
            'If LK_OpenPrinter(rsPrintPort) Then
            '    LK_SetupPrinter("55.0", "30.0", 0, "4.0", "0", 8, 6, 1)
            '    LK_ClosePrinter()
            'End If

            For ix1 As Integer = 0 To ra_PrtData.Count - 1
                If CType(ra_PrtData(ix1), STU_BCPRTINFO).REGNO <> "" Then
                    Dim iPrtCnt As Integer = Convert.ToInt32(CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT)

                    For ix2 As Integer = 1 To iPrtCnt
                        '-- ��ü����(������ ���)
                        CType(ra_PrtData(ix1), STU_BCPRTINFO).REMARK = ix2.ToString + "/" + CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT

                        If LK_OpenPrinter(rsPrintPort) = 0 Then
                            Dim sPrtMsg = fnMakePrtMsg_PIS(CType(ra_PrtData(ix1), STU_BCPRTINFO), rbFirst, riLeftPos, riTopPos, rsBarType)
                            LK_ClosePrinter()
                        End If

                        Threading.Thread.Sleep(1000)
                    Next
                End If
            Next

            Return True
        Catch ex As Exception
            LK_ClosePrinter()
            Fn.log(msFile + sFn, Err)
            MsgBox(msFile + sFn + vbCrLf + ex.Message)
            Return False
        Finally
            FileClose(iFileNo) 
        End Try
    End Function
    Protected Overridable Function fnMakePrtMsg_PATINFO(ByVal ro_Data As STU_BCPRTINFO, _
                                                        ByVal rbFirst As Boolean, _
                                                        ByVal riLeftPos As Integer, ByVal riTopPos As Integer, _
                                                        ByVal rsBarType As String) As String
        Dim sFn As String = "fnMakePrtMsg"

        Try

            Dim iTop As Integer = riTopPos - 30



            Dim lgRtn As Integer = 0


            lgRtn = LK_SetupPrinter("50", "30.0", 0, "3.1", "0", 8, 6, 1)
            If lgRtn <> 0 Then Return ""

            '< ���� ����  
            LK_StartPage()

            If ro_Data.BCTYPE = "B" Then
                '< ȯ�ڸ�
                Dim sPatNm As String = ro_Data.PATNM
                LK_PrintWindowsFont(5, 15, 0, 35, 2, 0, 0, "����ü", sPatNm)

                '< ������
                'ro_Data.PAT_ABORH = "Cis-AB+"
                LK_PrintDeviceFont(180, 25, 0, 3, 1, 1, 0, ro_Data.PAT_ABORH)

                '< ��Ϲ�ȣ
                LK_PrintDeviceFont(5, 60, 0, 4, 1, 1, 0, ro_Data.REGNO)

                '< ����/����
                Dim sSexAge As String = ro_Data.SEXAGE
                LK_PrintDeviceFont(180, 60, 0, 3, 1, 1, 0, sSexAge)

                '< ���ڵ�
                Dim sDptWard As String = ro_Data.DEPTWARD
                LK_PrintDeviceFont(270, 60, 0, 3, 1, 1, 0, sDptWard)

                '< ����������
                LK_PrintDeviceFont(5, 110, 0, 4, 1, 1, 0, ro_Data.COMNM)

                '< ó����
                Dim sOrddt As String = ro_Data.ORDDT.Substring(0, 10)
                LK_PrintWindowsFont(5, 155, 0, 25, 0, 0, 0, "����ü", "ó����:")
                LK_PrintDeviceFont(100, 155, 0, 2, 1, 1, 0, sOrddt)

                '< ó����
                Dim sDrnm As String = ro_Data.DRNM
                LK_PrintWindowsFont(230, 155, 0, 25, 0, 0, 0, "����ü", "ó����:")
                LK_PrintWindowsFont(320, 155, 0, 25, 0, 0, 0, "����ü", sDrnm)

                '< ������
                Dim sTkdt As String = ro_Data.TKDT.Substring(0, 16)
                LK_PrintWindowsFont(5, 185, 0, 25, 0, 0, 0, "����ü", "������:")
                LK_PrintDeviceFont(100, 185, 0, 2, 1, 1, 0, ro_Data.TKDT)

                '< ������
                'ro_Data.TKID = "�ڼ���"
                Dim sTkid As String = ro_Data.TKID
                LK_PrintWindowsFont(5, 215, 0, 25, 0, 0, 0, "����ü", "������:")
                LK_PrintWindowsFont(100, 215, 0, 25, 0, 0, 0, "����ü", sTkid)
            Else

                ''< ��Ϲ�ȣ sPID 
                'LK_PrintWindowsFont(100, 80, 0, 40, 1, 0, CType(IIf(ro_Data.BCCLSCD.Substring(0, 1).Trim() = "R", "1", "0"), Integer), "����ü", ro_Data.REGNO)
                LK_PrintWindowsFont(270, 170, 180, 40, 1, 0, CType(IIf(ro_Data.BCCLSCD.Substring(0, 1).Trim() = "R", "1", "0"), Integer), "����ü", ro_Data.REGNO)
                ''< �����/����/����  
                'Dim sDptWard As String = ro_Data.DEPTWARD
                'LK_PrintDeviceFont(300, 160, 0, 3, 1, 1, 0, sDptWard)

                ''< ����/���� 
                'Dim sSexAge As String = ro_Data.SEXAGE
                'LK_PrintDeviceFont(340, 140, 0, 3, 1, 1, 0, sSexAge)

                '< ȯ�ڸ� 
                Dim sPatNm As String = ro_Data.PATNM
                'LK_PrintWindowsFont(150, 160, 0, 30, 0, 0, 0, "����ü", sPatNm)
                LK_PrintWindowsFont(250, 90, 180, 30, 0, 0, 0, "����ü", sPatNm)

                ''< sRemark 
                'LK_PrintDeviceFont(370, 50, 0, 4, 1, 1, 0, IIf(ro_Data.REMARK <> "", "C", "").ToString)

            End If



            '
            '< ���� ������ 
            LK_EndPage()

            Return ""

        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            Throw (New Exception(ex.Message, ex))

            Return ""

        End Try

    End Function

    Protected Overridable Function fnMakePrtMsg(ByVal ro_Data As STU_BCPRTINFO, _
                                                ByVal rbFirst As Boolean, _
                                                ByVal riLeftPos As Integer, ByVal riTopPos As Integer, _
                                                ByVal rsBarType As String) As String
        Dim sFn As String = "fnMakePrtMsg"

        Try

            Dim sTestNms As String = ro_Data.TESTNMS
            Dim iTop As Integer = riTopPos - 30


            Dim sLine1 As String = ""
            Dim sLine2 As String = ""

            If ro_Data.TESTNMS.Length < 31 Then
                sLine1 = sTestNms

            Else
                sLine1 = sTestNms.Substring(0, 30)

                'If ro_Data.TESTNMS.Length > 50 Then

                '    sLine2 = sTestNms.Substring(30, 23) + "..."
                'Else
                '    sLine2 = sTestNms.Substring(30, ro_Data.TESTNMS.Length - 30)
                'End If

            End If

            Dim lgRtn As Integer = 0

            If ro_Data.BCTYPE = "M" Then
                lgRtn = LK_SetupPrinter("43", "20", 0, "3.1", "0", 8, 6, 1)
            Else
                lgRtn = LK_SetupPrinter("50", "30.0", 0, "3.1", "0", 8, 6, 1)
            End If

            If lgRtn <> 0 Then Return ""

            '< ���� ����  
            LK_StartPage()

            Dim sSpcNm As String = ro_Data.SPCNM
            Dim sTubeNm As String = ro_Data.TUBENM
            Dim sTGrpNm As String = ro_Data.TGRPNM

            'ro_Data.OBFTSYN = "Y"
            If ro_Data.OBFTSYN = "Y" Then
                LK_PrintLine(399, 0, 2 * 1, 31 * 8)
            End If

            If ro_Data.BCCLSCD = PRG_CONST.BCCLS_BldCrossMatch Or ro_Data.BCCNT = "B" Then
                '< ȯ�ڸ�
                Dim sPatNm As String = ro_Data.PATNM
                LK_PrintWindowsFont(170, 160, 0, 30, 0, 0, 0, "����ü", sPatNm)
                '< ������
                LK_PrintDeviceFont(25, 160, 0, 4, 1, 1, 0, ro_Data.PAT_ABORH)
                '< ��Ϲ�ȣ
                LK_PrintDeviceFont(25, 160, 0, 4, 1, 1, 0, ro_Data.REGNO)
                '< ����/����
                Dim sSexAge As String = ro_Data.SEXAGE
                LK_PrintWindowsFont(320, 25, 0, 15, 0, 0, 0, "����ü", sSexAge)
                '< ���ڵ�
                Dim sDptWard As String = ro_Data.DEPTWARD
                LK_PrintDeviceFont(220, 135, 0, 2, 1, 1, 0, sDptWard)
                '< ó����
                LK_PrintWindowsFont(145, 195, 0, 20, 0, 0, 0, "����ü", "ó����")
                LK_PrintDeviceFont(220, 135, 0, 2, 1, 1, 0, ro_Data.ORDDT)
                '< ó����
                LK_PrintWindowsFont(145, 195, 0, 20, 0, 0, 0, "����ü", "ó����")
                LK_PrintDeviceFont(220, 135, 0, 2, 1, 1, 0, ro_Data.DRNM)
                '< ������
                LK_PrintWindowsFont(145, 195, 0, 20, 0, 0, 0, "����ü", "������")
                LK_PrintDeviceFont(220, 135, 0, 2, 1, 1, 0, ro_Data.TKDT)
                '< ������
                LK_PrintWindowsFont(145, 195, 0, 20, 0, 0, 0, "����ü", "������")
                LK_PrintDeviceFont(220, 135, 0, 2, 1, 1, 0, ro_Data.TKID)
            Else
                If ro_Data.BCTYPE = "M" Then
                    '< �۾� �׷��� �˸°� ������ �Ǿ����� Ȯ�� 
                    If ro_Data.WKGRPCD = "" Then
                        Throw (New Exception("�۾��׷��� �����Ǿ����� Ȯ���ϼ���."))
                    End If

                    '< �۾���ȣ
                    Dim sWkno As String = ro_Data.BCNO_MB.Substring(8, 2) + "-" + ro_Data.BCNO_MB.Substring(10)
                    LK_PrintWindowsFont(310, 140, 180, 29, 1, 0, 0, "����ü", sWkno)
                    '< ��ü��ȣ 
                    LK_PrintWindowsFont(310, 105, 180, 20, 0, 0, 0, "����ü", ro_Data.BCNO)

                    ''< ȯ�ڸ�
                    'ro_Data.OBFTSYN = "Y"
                    Dim temp As String = ro_Data.PATNM
                    LK_PrintWindowsFont(150, 140, 180, 27, 1, 0, 0, "����ü", temp)

                    '< ����/���� 
                    Dim sSexAge As String = ro_Data.SEXAGE
                    LK_PrintWindowsFont(150, 105, 180, 20, 0, 0, 0, "����ü", sSexAge)

                    '< ���ڵ�
                    LK_PrintBarCode(300, 80, 180, "3", 1, 3, 40, 0, ro_Data.BCNOPRT)

                    '< ��ü��  
                    LK_PrintWindowsFont(310, 30, 180, 25, 1, 0, 0, "����ü", sSpcNm)
                    '< ������
                    'ro_Data.TGRPNM = "aq"
                    Dim temp1 As String = ro_Data.TGRPNM
                    LK_PrintWindowsFont(150, 30, 180, 25, 1, 0, 0, "����ü", temp1)
                Else

                    '< ��ü�� 
                    'LK_PrintWindowsFont(145, 190, 0, 22, 0, 0, 0, "����ü", sSpcNm)
                    LK_PrintWindowsFont(165, 65, 180, 22, 0, 0, 0, "����ü", sSpcNm.Trim)

                    '< ����  
                    'LK_PrintWindowsFont(25, 190, 0, 22, 0, 0, 0, "����ü", ro_Data.TUBENM)
                    LK_PrintWindowsFont(375, 65, 180, 22, 0, 0, 0, "����ü", ro_Data.TUBENM.Trim)

                    '< �˻�׷� sComment2 -> sLine2 ��ġ�� ������
                    'LK_PrintDeviceFont(350, 190, 0, 8, 2, 1, 0, ro_Data.TGRPNM)
                    'ro_Data.TGRPNM = "aq"
                    'LK_PrintDeviceFont(65, 235, 0, 2, 1, 1, 0, ro_Data.TGRPNM)
                    'ro_Data.TGRPNM = "C0"
                    LK_PrintDeviceFont(330, 20, 180, 2, 1, 1, 0, ro_Data.TGRPNM)

                    '< ���ް� ������ ���� sEmer 
                    'ro_Data.URGENT = "Y"
                    'ro_Data.EMER = "Y"
                    If ro_Data.URGENT.Equals("Y") Then
                        Dim sE As String = ro_Data.URGENT
                        If sE = "Y" Then
                            sE = "E"
                        End If

                        LK_PrintDeviceFont(395, 180, 180, 3, 1, 1, 1, sE)

                    ElseIf ro_Data.EMER.Equals("Y") Or ro_Data.EMER.Equals("E") Then
                        Dim sE As String = ro_Data.EMER
                        If sE = "Y" Then
                            sE = "E"
                        End If

                        LK_PrintDeviceFont(395, 180, 180, 3, 1, 1, 0, sE)
                    End If
                    '< ���� sEmer 



                    '< �˻��׸�� 
                    'LK_PrintDeviceFont(65, 215, 0, 2, 1, 1, 0, sLine1)
                    LK_PrintDeviceFont(330, 38, 180, 2, 1, 1, 0, sLine1)
                    '�˻��׸�� 2������ ���� �ʱ����
                    If sLine2 <> "" Then
                        'LK_PrintDeviceFont(65, 235, 0, 2, 1, 1, 0, sLine2)
                    End If



                    '< �� sKind
                    'LK_PrintDeviceFont(25, 215, 0, 4, 1, 1, 0, ro_Data.BCCLSCD)
                    LK_PrintDeviceFont(375, 38, 180, 4, 1, 1, 0, ro_Data.BCCLSCD)

                    '< ��ü��ȣ 
                    'LK_PrintDeviceFont(25, 0, 0, 3, 1, 1, 0, ro_Data.BCNO)
                    LK_PrintDeviceFont(375, 250, 180, 3, 1, 1, 0, ro_Data.BCNO)
                    '< �˻���
                    LK_PrintDeviceFont(105, 250, 180, 3, 1, 1, 0, ro_Data.METHODCD)

                    ''< ���ڵ� ���� �Ͻ�  233
                    'rbFirst = True
                    'LK_PrintDeviceFont(340, 0, 0, 2, 1, 1, CType(IIf(rbFirst, "0", "1"), Integer), Fn.GetServerDateTime.ToString("HH:mm"))
                    LK_PrintDeviceFont(65, 250, 180, 2, 1, 1, CType(IIf(rbFirst, "0", "1"), Integer), Fn.GetServerDateTime.ToString("HH:mm"))
                    '< ��������  
                    Dim a_sInfInfo As String() = ro_Data.INFINFO.Split("/"c)
                    'Dim a_sInfInfo As String() = "H/C+".Split("/"c)
                    For iCnt As Integer = 0 To a_sInfInfo.Length - 1
                        If iCnt > 2 Then Exit For

                        LK_PrintDeviceFont(15, 195 + (iCnt * 30), 180, 2, 1, 1, 0, a_sInfInfo(iCnt).ToString())
                    Next


                    '< ���ڵ�  
                    If ro_Data.BCNOPRT <> "" Then
                        ' Codabar 
                        '---> 3of9

                        If ro_Data.BCTYPE = "M" Then
                            'LK_PrintBarCode(40, 30, 0, "3", 2, 3, 100, 0, ro_Data.BCNOPRT)
                            LK_PrintBarCode(365, 220, 180, "3", 2, 4, 100, 0, ro_Data.BCNOPRT)
                        Else
                            'LK_PrintBarCode(40, 30, 0, "3", 2, 4, 100, 0, ro_Data.BCNOPRT)
                            LK_PrintBarCode(365, 222, 180, "3", 2, 4, 100, 0, ro_Data.BCNOPRT)
                        End If

                        '<<<

                        '->>>>>>>>>>>>>>>   2of5
                        'LK_PrintBarCode(60, 30, 0, "2", 2, 6, 85, 0, ro_Data.BCNOPRT)

                        'LKBPrint.LK_PrintBarCode(x, y, 0, "1", 2, 0, BarHeight, 1, code_128a);
                        '<<<<<<<<<<<<<<<
                        '' code 128
                        'LK_PrintBarCode(60 + riLeftPos, 30, 0, "1A", 2, 4, 90, 0, ro_Data.BCNOPRT)

                        '< ���ڵ� ��ȣ
                        Dim sBcnoPrt As String = ro_Data.BCNOPRT
                        'LK_PrintWindowsFont(40, 135, 0, 18, 1, 0, 0, "����ü", sBcnoPrt)
                        LK_PrintWindowsFont(367, 119, 180, 18, 1, 0, 0, "����ü", sBcnoPrt)
                    Else
                        '< �̼��� ���ڵ� 
                        LK_PrintWindowsFont(360, 180, 180, 50, 1, 0, 0, "����ü", "��ä�����ڵ�")
                        '>  
                    End If

                    ''< ��Ϲ�ȣ sPID
                    'ro_Data.OBFTSYN = "Y"
                    'LK_PrintDeviceFont(25, 160, 0, 4, 1, 1, CType(IIf(ro_Data.OBFTSYN = "Y", "1", "0"), Integer), ro_Data.REGNO)
                    LK_PrintDeviceFont(375, 97, 180, 4, 1, 1, CType(IIf(ro_Data.OBFTSYN = "Y", "1", "0"), Integer), ro_Data.REGNO)

                    '< ����/���� 
                    Dim sSexAge As String = ro_Data.SEXAGE
                    'LK_PrintDeviceFont(310, 160, 0, 3, 1, 1, 0, sSexAge)
                    LK_PrintDeviceFont(90, 95, 180, 3, 1, 1, 0, sSexAge)

                    '< �����/����/����  
                    Dim sDptWard As String = ro_Data.DEPTWARD
                    'LK_PrintDeviceFont(220, 135, 0, 2, 1, 1, 0, sDptWard)
                    LK_PrintDeviceFont(180, 119, 180, 2, 1, 1, 0, sDptWard)

                    '< ȯ�ڸ� 
                    Dim sPatNm As String = ro_Data.PATNM
                    'LK_PrintWindowsFont(170, 160, 0, 30, 0, 0, 0, "����ü", sPatNm)
                    LK_PrintWindowsFont(233, 99, 180, 30, 0, 0, 0, "����ü", sPatNm)

                    '< sRemark 
                    'ro_Data.REMARK = "C"
                    LK_PrintDeviceFont(395, 210, 180, 3, 1, 1, 0, IIf(ro_Data.REMARK <> "", "C", "").ToString)

                End If
            End If
            '
            '< ���� ������ 
            LK_EndPage()

            Return ""

        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            Throw (New Exception(ex.Message, ex))

            Return ""

        End Try

    End Function
    Protected Overridable Function fnMakePrtMsg_BLD(ByVal ro_Data As STU_BLDLABEL, ByVal riLeftPos As Integer, ByVal riTopPos As Integer) As String
        Dim sFn As String = "fnMakePrtMsg_BLD"

        Try
            Dim lgRtn As Integer = 0
            Dim iTop As Integer = riTopPos
            Dim sDept As String = ""
            Dim sWard As String = ""

            lgRtn = LK_SetupPrinter("88.0", "76.0", 0, "3.0", "0", 8, 6, 1)
            If lgRtn <> 0 Then Return ""

            '< ���� ����  
            LK_StartPage()

            '< 1. ��Ϲ�ȣ 
            'LK_PrintWindowsFont(590 + riLeftPos, 540 + iTop, 180, 45, 3, 0, 0, "HY�߰���", ro_Data.REGNO)
            LK_PrintWindowsFont(590 + riLeftPos, 530 + iTop, 180, 45, 3, 0, 0, "HY�߰���", ro_Data.REGNO)

            '< 2. ȯ�ڸ�
            Dim sPatNm As String = ro_Data.PATNM
            LK_PrintWindowsFont(250 + riLeftPos, 530 + iTop, 180, 45, 3, 0, 0, "HY�߰���", sPatNm)

            ''< 3. �ܷ�-�����,  ����-�����/����/����
            If ro_Data.IOGBN.Trim.Equals("O") Then
                sDept = ro_Data.DEPTWARD.Trim                                                         '�ܷ�ȯ��
                sWard = ""
            Else
                If InStr(ro_Data.DEPTWARD.Trim, "/") = 0 Then
                    sDept = ro_Data.DEPTWARD.Trim
                    sWard = ""
                Else
                    sDept = ro_Data.DEPTWARD.Trim.Substring(0, InStr(ro_Data.DEPTWARD.Trim, "/") - 1) '����ȯ��
                    sWard = ro_Data.DEPTWARD.Trim.Substring(InStr(ro_Data.DEPTWARD.Trim, "/") - 1)
                End If
            End If

            ' LK_PrintWindowsFont(590 + riLeftPos, 400 + iTop, 180, 45, 3, 0, 0, "HY�߰���", ro_Data.DEPTWARD)

            LK_PrintWindowsFont(560 + riLeftPos, 420 + iTop, 180, 45, 3, 0, 0, "HY�߰���", sDept)
            LK_PrintWindowsFont(560 + riLeftPos, 370 + iTop, 180, 45, 3, 0, 0, "HY�߰���", sWard)

            ''< 4. ����/����
            LK_PrintWindowsFont(230 + riLeftPos, 390 + iTop, 180, 45, 3, 0, 0, "HY�߰���", ro_Data.SEXAGE)

            ''< 5. ȯ��������
            If ro_Data.PAT_ABORH.Length < 4 Then
                LK_PrintWindowsFont(590 + riLeftPos, 270 + iTop, 180, 90, 3, 0, 0, "HY�߰���", ro_Data.PAT_ABORH)
            ElseIf ro_Data.PAT_ABORH.Length > 4 Then
                LK_PrintWindowsFont(590 + riLeftPos, 270 + iTop, 180, 80, 3, 0, 0, "HY�߰���", ro_Data.PAT_ABORH)
            End If

            ''< 6. ���������
            If ro_Data.PAT_ABORH.Length < 4 Then
                LK_PrintWindowsFont(250 + riLeftPos, 270 + iTop, 180, 90, 3, 0, 0, "HY�߰���", ro_Data.BLD_ABORH)
            ElseIf ro_Data.PAT_ABORH.Length > 4 Then
                LK_PrintWindowsFont(250 + riLeftPos, 270 + iTop, 180, 80, 3, 0, 0, "HY�߰���", ro_Data.BLD_ABORH)
            End If

            ''< 7. ���׹�ȣ
            If ro_Data.BLDNO.Count = 1 Then
                LK_PrintDeviceFont(580 + riLeftPos, 150 + iTop, 180, 3, 1, 2, 0, ro_Data.BLDNO(0))
            Else
                For ix As Integer = 0 To ro_Data.BLDNO.Count - 1
                    LK_PrintDeviceFont(580 + riLeftPos, 150 + iTop + 30 * ix, 180, 3, 1, 2, 0, ro_Data.BLDNO(ix))
                Next
            End If

            ''< 8. ��������(����������)
            Dim sComNm As String = ro_Data.COMNM
            LK_PrintDeviceFont(240 + riLeftPos, 150 + iTop, 180, 3, 1, 2, 0, sComNm)

            ''< 9. ���׹�ȣ/���� - ���׹�ȣ + '/' + COMORDCD(ó���ڵ�)
            Dim sBldNoComOrdCd As String = ro_Data.BLDNO(0).ToString.Trim.Replace("-", "") + "/" + ro_Data.COMCD.Trim
            'LK_PrintBarCode(530 + riLeftPos, 95 + iTop, 180, "3", 2, 4, 32, 0, sBldNoComOrdCd)
            'LK_PrintBarCode(510 + riLeftPos, 95 + iTop, 180, "3", 2, 4, 32, 0, sBldNoComOrdCd)
            LK_PrintBarCode(540 + riLeftPos, 95 + iTop, 180, "3", 2, 4, 32, 0, sBldNoComOrdCd)

            ''< 10. �˻��Ͻ�
            LK_PrintDeviceFont(580 + riLeftPos, 50 + iTop, 180, 2, 1, 2, 0, ro_Data.TESTDT)

            ''< 11. �������� ���
            If (ro_Data.XMATCH1.Trim.Equals("����") Or ro_Data.XMATCH4.Trim.Equals("����")) Then
                LK_PrintDeviceFont(180 + riLeftPos, 50 + iTop, 180, 2, 1, 2, 0, "��������  ����")
            End If

            '< ���� ������ 
            LK_EndPage()

            Return ""

        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            Throw (New Exception(ex.Message, ex))

            Return ""

        End Try
    End Function

    Protected Overridable Function fnMakePrtMsg_BLD_20160713_OLD(ByVal ro_Data As STU_BLDLABEL, ByVal riLeftPos As Integer, ByVal riTopPos As Integer) As String
        Dim sFn As String = "fnMakePrtMsg_BLD"

        Try

            Dim lgRtn As Integer = 0
            Dim iTop As Integer = riTopPos

            lgRtn = LK_SetupPrinter("88.0", "76.0", 0, "3.0", "0", 8, 6, 1)
            If lgRtn <> 0 Then Return ""

            '< ���� ����  
            LK_StartPage()

            '< 1. ��Ϲ�ȣ 
            LK_PrintDeviceFont(490 + riLeftPos, 583 + iTop, 180, 2, 1, 2, 0, ro_Data.REGNO)

            '< 2. �����/����/����  
            LK_PrintDeviceFont(473 + riLeftPos, 533 + iTop, 180, 2, 1, 2, 0, ro_Data.DEPTWARD)

            '< 3. ȯ��������
            'If ro_Data.PAT_ABORH = "" Then ro_Data.PAT_ABORH = ro_Data.BLD_ABORH
            If ro_Data.PAT_ABORH.Length < 4 Then
                LK_PrintDeviceFont(465 + riLeftPos, 470 + iTop, 180, 4, 2, 2, 0, ro_Data.PAT_ABORH)
            ElseIf ro_Data.PAT_ABORH.Length > 4 Then
                LK_PrintDeviceFont(540 + riLeftPos, 470 + iTop, 180, 3, 2, 2, 0, ro_Data.PAT_ABORH)
            End If

            '< 4. ����������
            Dim sComNm As String = ro_Data.COMNM
            LK_PrintWindowsFont(520 + riLeftPos, 390 + iTop, 180, 30, 1, 0, 0, "����ü", sComNm)

            '< 5. Hb �����
            Dim sHb_rst As String = ro_Data.Hb_RST
            LK_PrintWindowsFont(165 + riLeftPos, 210 + iTop, 0, 30, 1, 0, 0, "����ü", sHb_rst)

            '< 6. ���պ�����
            'If ro_Data.
            Dim sXMatch As String = ""

            If ro_Data.XMATCH1.Trim <> "" Then
                sXMatch += ro_Data.XMATCH1.Substring(0, 1) + "/"
            End If
            If ro_Data.XMATCH2.Trim <> "" Then
                sXMatch += ro_Data.XMATCH2.Substring(0, 1) + "/"
            End If
            If ro_Data.XMATCH3.Trim <> "" Then
                sXMatch += ro_Data.XMATCH3.Substring(0, 1)
            End If
            LK_PrintWindowsFont(483 + riLeftPos, 240 + iTop, 180, 25, 1, 0, 0, "����ü", sXMatch)

            '< 7. Filter/IR
            If ro_Data.IR = "" Then
                ro_Data.IR = "N"
            ElseIf ro_Data.IR <> "" Then
                ro_Data.IR = "Y"
            End If

            If ro_Data.FITER = "" Then
                ro_Data.FITER = "N"
            ElseIf ro_Data.FITER <> "" Then
                ro_Data.FITER = "Y"
            End If

            Dim sFiterIr As String = ro_Data.IR + "/" + ro_Data.FITER
            LK_PrintDeviceFont(463 + riLeftPos, 293 + iTop, 180, 2, 1, 2, 0, sFiterIr)

            '< 8. �˻���
            Dim sTestNm As String = ro_Data.TESTNM
            LK_PrintWindowsFont(480 + riLeftPos, 195 + iTop, 180, 25, 1, 0, 0, "����ü", sTestNm)

            '< 9. �����
            Dim sOutNm As String = ro_Data.OUTNM
            LK_PrintWindowsFont(480 + riLeftPos, 145 + iTop, 180, 25, 1, 0, 0, "����ü", sOutNm)

            '< ���� ��ȿ�Ͻ� 
            Dim sAvildt As String = ""
            If ro_Data.AVILDT <> "" Then
                sAvildt = ro_Data.AVILDT.Substring(0, 10)
            End If
            LK_PrintWindowsFont(670 + riLeftPos, 143 + iTop, 180, 30, 1, 0, 0, "����ü", "��ȿ����")
            LK_PrintDeviceFont(500 + riLeftPos, 145 + iTop, 180, 2, 1, 2, 0, sAvildt)

            '< 10.tnsjusno 
            '�����ڸ� ����ؼ� tnsjusno������
            'Dim sRecNm As String = ro_Data.RECNM
            'LK_PrintWindowsFont(150 + riLeftPos, 95 + iTop, 180, 25, 1, 0, 0, "����ü", sRecNm)
            Dim sTnsNo As String = ro_Data.TNSNO.Substring(0, 8) + "-" + ro_Data.TNSNO.Substring(8, 1) + "-" + ro_Data.TNSNO.Substring(9)
            LK_PrintDeviceFont(195 + riLeftPos, 145 + iTop, 180, 2, 1, 2, 0, sTnsNo)
            LK_PrintWindowsFont(340 + riLeftPos, 143 + iTop, 180, 30, 1, 0, 0, "����ü", "������ȣ")
            'LK_PrintDeviceFont(185 + riLeftPos, 145 + iTop, 180, 1, 1, 2, 0, ro_Data.OUTDT)

            '<��û�ڶ��� ���������� ������
            'Dim sComNm As String = ro_Data.COMNM
            LK_PrintWindowsFont(670 + riLeftPos, 95 + iTop, 180, 30, 1, 0, 0, "����ü", "��������")
            LK_PrintBarCode(540 + riLeftPos, 95 + iTop, 180, "3", 2, 4, 30, 0, ro_Data.COMCD)


            '< 1. ȯ�ڸ�
            Dim sPatNm As String = ro_Data.PATNM
            LK_PrintWindowsFont(155 + riLeftPos, 580 + iTop, 180, 30, 1, 0, 0, "����ü", sPatNm)

            '< 2. ����/����
            LK_PrintDeviceFont(129 + riLeftPos, 535 + iTop, 180, 2, 1, 2, 0, ro_Data.SEXAGE)

            '< 3. ���������
            If ro_Data.BLD_ABORH.Length < 4 Then
                LK_PrintDeviceFont(125 + riLeftPos, 470 + iTop, 180, 4, 2, 2, 0, ro_Data.BLD_ABORH)
            ElseIf ro_Data.BLD_ABORH.Length > 4 Then
                LK_PrintDeviceFont(205 + riLeftPos, 470 + iTop, 180, 3, 2, 2, 0, ro_Data.BLD_ABORH)
            End If

            '< 4. ���׹�ȣ
            If ro_Data.BLDNO.Count = 1 Then
                LK_PrintDeviceFont(520 + riLeftPos, 340 + iTop, 180, 2, 1, 2, 0, ro_Data.BLDNO(0))
                LK_PrintBarCode(360 + riLeftPos, 385 + iTop, 180, "3", 2, 4, 70, 0, ro_Data.BLDNO(0).ToString.Replace("-"c, ""))
            Else
                For ix As Integer = 0 To ro_Data.BLDNO.Count - 1
                    LK_PrintDeviceFont(400 + riLeftPos, 170 + iTop + 30 * ix, 180, 2, 1, 2, 0, ro_Data.BLDNO(ix))
                Next
            End If

            '< 7. ���׹�Ȯ��
            LK_PrintDeviceFont(125 + riLeftPos, 295 + iTop, 180, 2, 2, 2, 0, "Y")

            '< 8. �˻��Ͻ�
            LK_PrintDeviceFont(185 + riLeftPos, 195 + iTop, 180, 1, 1, 2, 0, ro_Data.TESTDT)

            '< 9. ����Ͻ�
            LK_PrintDeviceFont(185 + riLeftPos, 145 + iTop, 180, 1, 1, 2, 0, ro_Data.OUTDT)


            '< ���� ������ 
            LK_EndPage()

            Return ""

        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            Throw (New Exception(ex.Message, ex))

            Return ""

        End Try
    End Function

    Protected Overridable Function fnMakePrtMsg_DON(ByVal ro_Data As STU_BLDLABEL, ByVal riLeftPos As Integer, ByVal riTopPos As Integer, ByVal riIndex As Integer) As String
        Dim sFn As String = "fnMakePrtMsg_DON"

        Try
            Dim lgRtn As Integer = 0
            Dim iTop As Integer = riTopPos

            lgRtn = LK_SetupPrinter("50", "40.0", 0, "3.1", "0", 8, 6, 1)
            If lgRtn <> 0 Then Return ""

            '< ���� ����  
            LK_StartPage()

            If riIndex = 1 Then
                '�������ڵ� ���ڵ�
                LK_PrintBarCode(365, 235, 180, "3", 2, 4, 80, 0, ro_Data.BLDCD)
                LK_PrintDeviceFont(350, 155, 180, 1, 1, 2, 0, ro_Data.BLDCD)
                LK_PrintDeviceFont(120, 200, 180, 3, 1, 2, 0, ro_Data.BLD_ABORH)

                LK_PrintBarCode(365, 120, 180, "3", 2, 4, 80, 0, ro_Data.COMCD)
                LK_PrintDeviceFont(350, 40, 180, 1, 1, 2, 0, ro_Data.COMCD)
                LK_PrintDeviceFont(120, 100, 180, 3, 1, 2, 0, ro_Data.COMNM)

            ElseIf riIndex = 2 Then
                '���׹�ȣ ���ڵ�

                '���׹�ȣ
                'ro_Data.BLOODNO = "2013083101"
                LK_PrintBarCode(365, 210, 180, "3", 2, 4, 80, 0, ro_Data.BLOODNO)
                Dim sFlBldNo As String = ro_Data.BLOODNO.Substring(0, 2) + "-" + ro_Data.BLOODNO.Substring(2, 2) + "-" + ro_Data.BLOODNO.Substring(4)
                'Dim sFlBldNo As String = "20-13-083102"
                LK_PrintWindowsFont(375, 250, 180, 25, 1, 0, 0, "����ü", sFlBldNo)

                '��������
                Dim sDongbn As String = ro_Data.DONGBN
                'Dim sDongbn As String = "����"
                LK_PrintWindowsFont(400, 120, 180, 25, 1, 0, 0, "����ü", sDongbn)

                '������
                Dim sRcvNm As String = ro_Data.RCVNM
                'Dim sRcvNm As String = "��ξ�"
                LK_PrintWindowsFont(270, 120, 180, 25, 1, 0, 0, "����ü", "������:")
                LK_PrintWindowsFont(170, 120, 180, 25, 1, 0, 0, "����ü", sRcvNm)

                '��Ϲ�ȣ
                LK_PrintWindowsFont(400, 90, 180, 25, 1, 0, 0, "����ü", ro_Data.REGNO)


                '�����ڸ�
                Dim sDonNm As String = ro_Data.PATNM
                'Dim sDonNm As String = "��ξ�"
                LK_PrintWindowsFont(270, 90, 180, 25, 1, 0, 0, "����ü", "������:")
                LK_PrintWindowsFont(170, 90, 180, 25, 1, 0, 0, "����ü", sDonNm)

                '������ ����/����
                LK_PrintWindowsFont(70, 90, 180, 25, 1, 0, 0, "����ü", ro_Data.SEXAGE)

                '�����Ͻ�
                LK_PrintWindowsFont(400, 60, 180, 25, 1, 0, 0, "����ü", "�����Ͻ�:")
                LK_PrintWindowsFont(275, 60, 180, 25, 1, 0, 0, "����ü", ro_Data.DONDT)

                '��ȿ�Ͻ�
                LK_PrintWindowsFont(400, 30, 180, 25, 1, 0, 0, "����ü", "��ȿ�Ͻ�:")
                LK_PrintWindowsFont(275, 30, 180, 25, 1, 0, 0, "����ü", ro_Data.AVILDT)




            Else
                '���׹�ȣ ���ڵ�
                'ro_Data.BLOODNO = "2013083101"
                'LK_PrintBarCode(365, 200, 180, "3", 2, 4, 100, 0, ro_Data.BLOODNO)
                ''Dim sFlBldNo As String = ro_Data.BLOODNO.Substring(0, 2) + "-" + ro_Data.BLOODNO.Substring(2, 2) + "-" + ro_Data.BLOODNO.Substring(4)
                'Dim sFlBldNo As String = "20-13-083102"
                'LK_PrintDeviceFont(375, 240, 180, 1, 1, 2, 0, sFlBldNo)

                ''Dim sDongbn As String = ro_Data.DONGBN
                'Dim sDongbn As String = "����"
                'LK_PrintWindowsFont(350, 90, 180, 27, 1, 0, 0, "����ü", sDongbn)

                ''Dim sRcvNm As String = ro_Data.RCVNM
                'Dim sRcvNm As String = "��ξ�"
                'LK_PrintWindowsFont(260, 90, 180, 25, 1, 0, 0, "����ü", "������ : ")
                'LK_PrintWindowsFont(140, 90, 180, 25, 1, 0, 0, "����ü", sRcvNm)




                '���׹�ȣ ���ڵ�
                ro_Data.BLOODNO = "2013083101"
                LK_PrintBarCode(365, 225, 180, "3", 2, 4, 40, 0, ro_Data.BLOODNO)
                'Dim sFlBldNo As String = ro_Data.BLOODNO.Substring(0, 2) + "-" + ro_Data.BLOODNO.Substring(2, 2) + "-" + ro_Data.BLOODNO.Substring(4)
                Dim sFlBldNo As String = "20-13-083102"
                LK_PrintWindowsFont(375, 250, 180, 18, 1, 0, 0, "����ü", sFlBldNo)

                'Dim sDongbn As String = ro_Data.DONGBN
                Dim sDongbn As String = "����"
                LK_PrintWindowsFont(350, 180, 180, 20, 1, 0, 0, "����ü", sDongbn)

                'Dim sRcvNm As String = ro_Data.RCVNM
                Dim sRcvNm As String = "��ξ�"
                LK_PrintWindowsFont(240, 180, 180, 20, 1, 0, 0, "����ü", "������ : ")
                LK_PrintWindowsFont(140, 180, 180, 20, 1, 0, 0, "����ü", sRcvNm)

                '�������ڵ� ���ڵ�
                LK_PrintBarCode(365, 150, 180, "3", 2, 4, 40, 0, ro_Data.BLDCD)
                LK_PrintWindowsFont(350, 105, 180, 20, 1, 0, 0, "����ü", ro_Data.BLDCD)
                LK_PrintDeviceFont(140, 150, 180, 3, 1, 2, 0, ro_Data.BLD_ABORH)

                '���������ڵ� ���ڵ�
                LK_PrintBarCode(365, 80, 180, "3", 2, 4, 40, 0, ro_Data.COMCD)
                LK_PrintWindowsFont(350, 35, 180, 20, 1, 0, 0, "����ü", ro_Data.COMCD)
                LK_PrintDeviceFont(140, 80, 180, 3, 1, 2, 0, ro_Data.COMNM)
            End If

        Catch ex As Exception

        End Try
    End Function

    Protected Overridable Function fnMakePrtMsg_BLD_(ByVal ro_Data As STU_BLDLABEL, ByVal riLeftPos As Integer, ByVal riTopPos As Integer) As String
        Dim sFn As String = "fnMakePrtMsg"

        Try
            Dim sPrtBuf As String = ""
            Dim sCrLf As String = Chr(13) + Chr(10)

            Dim iMaxLen As Integer = 33

            '< �⺻���� 
            sPrtBuf = ""
            'sPrtBuf = sPrtBuf + "I8,1,001" + vbCrLf
            'sPrtBuf = sPrtBuf + "D" + vbCrLf        '-- ���� = OD, ���� = D
            'sPrtBuf = sPrtBuf + "Q464,24" + vbCrLf  '-- Label Length, Gap Length
            'sPrtBuf = sPrtBuf + "q696" + vbCrLf     '-- Label(Width)
            'sPrtBuf = sPrtBuf + "S4" + vbCrLf       '-- speed
            'sPrtBuf = sPrtBuf + "D8" + vbCrLf       '-- ��
            'sPrtBuf = sPrtBuf + "ZT" + vbCrLf
            'sPrtBuf = sPrtBuf + "JF" + vbCrLf       '-- FB
            sPrtBuf = sPrtBuf & "N" + vbCrLf

            '< ��Ϲ�ȣ
            sPrtBuf = sPrtBuf + "A170,20,0,3,1,2,N," + Chr(34) + ro_Data.REGNO + Chr(34) + vbCrLf

            '< ȯ�ڸ�  
            sPrtBuf = sPrtBuf + "A500,25,0,8,2,1,N," + Chr(34) + ro_Data.PATNM + Chr(34) + vbCrLf

            '< �����/����/����  
            sPrtBuf = sPrtBuf + "A180,68,0,3,1,1,N," + Chr(34) + ro_Data.DEPTWARD + Chr(34) + vbCrLf

            '< ����/���� 
            sPrtBuf = sPrtBuf + "A530,68,0,3,1,1,N," + Chr(34) + ro_Data.SEXAGE + Chr(34) + vbCrLf

            '< ȯ�� ������ 
            sPrtBuf = sPrtBuf + "A220,95,0,3,1,2,N," + Chr(34) + ro_Data.PAT_ABORH + Chr(34) + vbCrLf

            '< ��� ������ 
            sPrtBuf = sPrtBuf + "A550,95,0,3,1,2,N," + Chr(34) + ro_Data.BLD_ABORH + Chr(34) + vbCrLf

            ''< �������� 
            Dim bHangul As Boolean = False
            For iLen As Integer = 0 To ro_Data.COMNM.Length - 1
                If Char.GetUnicodeCategory(ro_Data.COMNM.Substring(iLen, 1)) = Globalization.UnicodeCategory.OtherLetter Then
                    bHangul = True
                    Exit For
                End If
            Next

            If bHangul Then
                sPrtBuf = sPrtBuf + "A170,143,0,8,1,1,N," + Chr(34) + ro_Data.COMNM + Chr(34) + vbCrLf
            Else
                sPrtBuf = sPrtBuf + "A170,143,0,2,1,1,N," + Chr(34) + ro_Data.COMNM + Chr(34) + vbCrLf
            End If


            '< ���պ�����
            If ro_Data.XMATCH1 = "-" Then ro_Data.XMATCH1 = "����"
            If ro_Data.XMATCH1 = "+" Then ro_Data.XMATCH1 = "������"

            If ro_Data.XMATCH2 = "-" Then ro_Data.XMATCH2 = "����"
            If ro_Data.XMATCH2 = "+" Then ro_Data.XMATCH2 = "������"

            'sPrtBuf = sPrtBuf + "A190,185,0,8,1,1,N," + Chr(34) + sRst1 + Chr(34) + vbCrLf
            sPrtBuf = sPrtBuf + "A190,215,0,8,1,1,N," + Chr(34) + ro_Data.XMATCH2 + Chr(34) + vbCrLf

            '-- ���׹�ȣ
            If ro_Data.BLDNO.Count = 1 Then
                sPrtBuf = sPrtBuf + "A500,180,0,3,1,1,N," + Chr(34) + ro_Data.BLDNO(0) + Chr(34) + vbCrLf
            Else
                For ix As Integer = 0 To ro_Data.BLDNO.Count - 1
                    sPrtBuf = sPrtBuf + "A500," + (150 + (ix * 30)).ToString + ",0,3,1,1,N," + Chr(34) + ro_Data.BLDNO(ix) + Chr(34) + vbCrLf
                Next
            End If

            '< IR
            'sIR = "1" : sFilter_in = "1"
            sPrtBuf = sPrtBuf + "A190,263,0,3,1,1,N," + Chr(34) + IIf(ro_Data.IR = "1", "Y", "").ToString().PadLeft(1, " "c) + "/" + IIf(ro_Data.FITER = "1", "F", "").ToString + Chr(34) + vbCrLf
            '>

            '< Ȯ��
            sPrtBuf = sPrtBuf + "A450,263,0,3,1,1,N," + Chr(34) + "OK" + Chr(34) + vbCrLf
            '>


            '< �˻���
            sPrtBuf = sPrtBuf + "A180,303,0,8,1,1,N," + Chr(34) + ro_Data.BEFOUTNM + Chr(34) + vbCrLf

            '< �˻�����
            sPrtBuf = sPrtBuf + "A500,303,0,2,1,1,N," + Chr(34) + ro_Data.BEFOUTDT + Chr(34) + vbCrLf

            '< �����
            sPrtBuf = sPrtBuf + "A180,343,0,8,1,1,N," + Chr(34) + ro_Data.OUTNM + Chr(34) + vbCrLf

            '< �������
            sPrtBuf = sPrtBuf + "A500,343,0,2,1,1,N," + Chr(34) + ro_Data.OUTDT + Chr(34) + vbCrLf

            '< ������
            sPrtBuf = sPrtBuf + "A180,383,0,8,1,1,N," + Chr(34) + ro_Data.RECNM + Chr(34) + vbCrLf


            '< ���� ������ 
            sPrtBuf = sPrtBuf & "P1" + vbCrLf
            '>  

            Return sPrtBuf

        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            MsgBox(msFile + sFn + vbCrLf + ex.Message)

            Return ""

        End Try
    End Function

    Protected Overridable Function fnMakePrtMsg_PIS(ByVal ro_Data As STU_BCPRTINFO, _
                                                    ByVal rbFirst As Boolean, _
                                                    ByVal riLeftPos As Integer, ByVal riTopPos As Integer, _
                                                    ByVal rsBarType As String) As String
        Dim sFn As String = "fnMakePrtMsgfnMakePrtMsg_PIS"

        Try

            Dim sTestNms As String = ro_Data.TESTNMS
            Dim iTop As Integer = riTopPos - 30

            If ro_Data.TESTNMS.Length > 20 Then
                sTestNms = sTestNms.Substring(0, 19) & "..."
            End If

            If sTestNms.IndexOf("...") > -1 Then
                If sTestNms.Substring(0, sTestNms.IndexOf("...")).Length > 20 Then
                    sTestNms = sTestNms.Substring(0, 19) & "..."
                End If
            End If

            Dim lgRtn As Integer = 0

            lgRtn = LK_SetupPrinter("55.0", "30.0", 0, "3.1", "0", 8, 6, 1)
            If lgRtn <> 0 Then Return ""

            '< ���� ����  
            LK_StartPage()

            '< sRemark
            LK_PrintWindowsFont(15 + riLeftPos, 200 + iTop, 0, 25, 3, 0, 0, "����ü", ro_Data.REMARK)

            '< ��ü��
            Dim sSpcNm As String = ro_Data.SPCNM
            LK_PrintWindowsFont(110 + riLeftPos, 200 + iTop, 0, 20, 1, 0, 0, "����ü", sSpcNm)

            '< �˻��׸�� 
            LK_PrintWindowsFont(45 + riLeftPos, 250 + iTop, 0, 20, 1, 0, 0, "����ü", sTestNms)

            ''< ��ó���
            'LK_PrintDeviceFont(65 + riLeftPos, 230 + iTop, 0, 8, 1, 1, 0, ro_Data.TGRPNM)

            '< �� sKind
            LK_PrintDeviceFont(15 + riLeftPos, 230 + iTop, 0, 3, 2, 2, 0, "P")

            '< ��ü��ȣ 
            LK_PrintDeviceFont(6 + riLeftPos, 45 + iTop, 0, 2, 1, 1, 0, ro_Data.BCNO)

            '< ���ڵ� ���� �Ͻ�  233
            LK_PrintDeviceFont(260 + riLeftPos, 45 + iTop, 0, 1, 1, 1, CType(IIf(rbFirst, "0", "1"), Integer), Fn.GetServerDateTime.ToString("yyyy-MM-dd HH:mm"))

            '< ��������  
            Dim a_sInfInfo As String() = ro_Data.INFINFO.Split("/"c)
            For iCnt As Integer = 0 To a_sInfInfo.Length - 1
                If iCnt > 1 Then Exit For
                LK_PrintDeviceFont(6 + riLeftPos, 80 + (iCnt * 30) + iTop, 0, 3, 1, 1, 0, a_sInfInfo(iCnt).ToString())
            Next

            '< ���ڵ�  
            If ro_Data.BCNOPRT <> "" Then
                ' Codabar 
                LK_PrintBarCode(100 + riLeftPos, 65 + iTop, 0, "K", 2, 4, 80, 0, "A" + ro_Data.BCNOPRT + "A")

                '' code 128
                'LK_PrintBarCode(75 + riLeftPos, 61, 0, "1A", 2, 4, 90, 0, ro_Data.BCNOPRT)

                '< ���ڵ� ��ȣ
                Dim sBcnoPrt As String = ro_Data.BCNOPRT
                LK_PrintWindowsFont(170 + riLeftPos, 147 + iTop, 0, 15, 1, 0, 0, "����ü", sBcnoPrt)
            Else
                '< �̼��� ���ڵ� 
                LK_PrintWindowsFont(90 + riLeftPos, 100 + iTop, 0, 35, 1, 0, 0, "����ü", "��ä�����ڵ�")
                '>  
            End If

            '< ��Ϲ�ȣ sPID
            LK_PrintDeviceFont(9 + riLeftPos, 145 + iTop, 0, 3, 1, 2, CType(IIf(ro_Data.BCCLSCD.Substring(0, 1).Trim() = "R", "1", "0"), Integer), ro_Data.REGNO)

            '< �����/����/����  
            Dim sDptWard As String = ro_Data.DEPTWARD
            LK_PrintWindowsFont(310 + riLeftPos, 165 + iTop, 0, 20, 1, 0, 0, "����ü", sDptWard)

            '< ����/���� 
            Dim sSexAge As String = ro_Data.SEXAGE
            LK_PrintWindowsFont(380 + riLeftPos, 175 + iTop, 0, 15, 0, 0, 0, "����ü", sSexAge)

            '< ȯ�ڸ�
            Dim sPatNm As String = ro_Data.PATNM
            LK_PrintWindowsFont(160 + riLeftPos, 165 + iTop, 0, 25, 0, 0, 0, "����ü", sPatNm)

            '< ���� ������ 
            LK_EndPage()

            Return ""

        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            Throw (New Exception(ex.Message, ex))

            Return ""

        End Try

    End Function

    Protected Overridable Function fnMakePrtMsg_RIS(ByVal ro_Data As STU_BCPRTINFO, _
                                                    ByVal rbFirst As Boolean, _
                                                    ByVal riLeftPos As Integer, ByVal riTopPos As Integer, _
                                                    ByVal rsBarType As String) As String
        Dim sFn As String = "fnMakePrtMsg"

        Try

            'Dim sTestNms As String = ro_Data.TESTNMS
            'Dim iTop As Integer = riTopPos - 5

            'riLeftPos += 20

            'If ro_Data.TESTNMS.Length > 20 Then
            '    sTestNms = sTestNms.Substring(0, 19) & "..."
            'End If

            'If sTestNms.IndexOf("...") > -1 Then
            '    If sTestNms.Substring(0, sTestNms.IndexOf("...")).Length > 20 Then
            '        sTestNms = sTestNms.Substring(0, 19) & "..."
            '    End If
            'End If

            'Dim lgRtn As Integer = 0

            'lgRtn = LK_SetupPrinter("53.0", "35.0", 1, "3.0", "1", 8, 6, 1)
            'If lgRtn <> 0 Then Return ""

            ''< ���� ����  
            'LK_StartPage()

            'Dim sSpcNm As String = ro_Data.SPCNM
            'Dim sTubeNm As String = ro_Data.TUBENM
            'Dim sTGrpNm As String = ro_Data.TGRPNM

            ''< ���ڵ�  
            '' Codabar 
            'LK_PrintBarCode(80 + riLeftPos, 30 + iTop, 0, "K", 2, 4, 75, 0, "A" + ro_Data.BCNOPRT + "A")

            ''' code 128
            ''LK_PrintBarCode(75 + riLeftPos, 61, 0, "1A", 2, 4, 90, 0, ro_Data.BCNOPRT)

            ''< ���ڵ� ��ȣ
            'Dim sBcnoPrt As String = ro_Data.BCNOPRT
            'LK_PrintWindowsFont(160 + riLeftPos, 107 + iTop, 0, 15, 1, 0, 0, "����", sBcnoPrt)

            ''< ��Ϲ�ȣ sPID
            'LK_PrintDeviceFont(12 + riLeftPos, 130 + iTop, 0, 3, 1, 2, CType(IIf(ro_Data.BCCLSCD.Substring(0, 1).Trim() = "R", "1", "0"), Integer), ro_Data.REGNO)

            ''< �����/����/����  
            'Dim sDptWard As String = ro_Data.DEPTWARD
            'LK_PrintWindowsFont(270 + riLeftPos, 170 + iTop, 0, 20, 1, 0, 0, "����", sDptWard)

            ''< ����/���� 
            'Dim sSexAge As String = ro_Data.SEXAGE
            'LK_PrintWindowsFont(320 + riLeftPos, 140 + iTop, 0, 18, 0, 0, 0, "����", sSexAge)

            ''< ȯ�ڸ� 
            'Dim sPatNm As String = ro_Data.PATNM
            'LK_PrintWindowsFont(150 + riLeftPos, 135 + iTop, 0, 35, 1, 0, 0, "����", sPatNm)

            ''< ��ü��
            'LK_PrintWindowsFont(12 + riLeftPos, 180 + iTop, 0, 25, 1, 0, 0, "����", sSpcNm)

            ''< ���� 
            'LK_PrintWindowsFont(12 + riLeftPos, 215 + iTop, 0, 25, 1, 0, 0, "����", sTubeNm.Substring(0, 8) + "-")

            ''< ���� 
            'LK_PrintDeviceFont(145 + riLeftPos, 205 + iTop, 0, 2, 2, 2, 0, sTubeNm.Substring(8))


            ''< �˻��׸�� 
            'LK_PrintDeviceFont(12 + riLeftPos, 250 + iTop, 0, 2, 1, 1, 0, sTestNms)

            ''< ���� ������ 
            'LK_EndPage()

            'Return ""

            '############ �̻� ���� ���� ���� ���ڵ�

            'Dim sTestNms As String = ro_Data.TESTNMS
            Dim sTestCds As String = ro_Data.TESTCD
            Dim iTop As Integer = riTopPos - 5
            Dim sLine1 As String = ""
            Dim sLine2 As String = ""
            Dim sLine3 As String = ""

            riLeftPos += 20

            'If ro_Data.TESTNMS.Length > 20 Then
            '    sTestNms = sTestNms.Substring(0, 19) & "..."
            'End If

            'If sTestNms.IndexOf("...") > -1 Then
            'If sTestNms.Substring(0, sTestNms).Length > 20 Then
            '    sTestNms = sTestNms.Substring(0, 19)
            'End If
            'End If

            'If sTestCds.Length > 30 Then
            '    Line1 = sTestCds.Substring(0, 30)
            'ElseIf sTestCds.Length > 40 Then
            '    Line2 = sTestCds.Substring(31, sTestCds.Length)
            'ElseIf sTestCds.Length > 50 Then
            '    Line3 = sTestCds.Substring(61, sTestCds.Length)
            'End If
            
            Select Case ro_Data.TESTCD.Length
                Case Is < 24
                    sLine1 = sTestCds.Substring(0, sTestCds.Length)
                Case Is < 48
                    sLine1 = sTestCds.Substring(0, 24)
                    sLine2 = sTestCds.Substring(24, sTestCds.Length - 24)
                Case Is < 72
                    sLine1 = sTestCds.Substring(0, 24)
                    sLine2 = sTestCds.Substring(24, 24)
                    sLine3 = sTestCds.Substring(48, sTestCds.Length - 48)
                Case Else
                    sLine1 = sTestCds.Substring(0, 24)
                    sLine2 = sTestCds.Substring(24, 24)
                    sLine3 = sTestCds.Substring(48, sTestCds.Length - 72) + ", ..."
            End Select

            'If ro_Data.TESTCD.Length < 30 Then
            '    sLine1 = sTestCds
            'ElseIf ro_Data.TESTCD.Length > 30 Then
            '    sLine1 = sTestCds.Substring(0, 30)
            '    If sLine1 <> "" And ro_Data.TESTCD.Length > 40 Then
            '        sLine2 = sTestCds.Substring(30)
            '        If sLine1 <> "" And sLine2 <> "" And ro_Data.TESTCD.Length > 50 Then
            '            sLine3 = sTestCds.Substring(60)
            '        End If
            '    End If
            'End If

            Dim lgRtn As Integer = 0

            lgRtn = LK_SetupPrinter("53.0", "35.0", 0, "3.0", "0", 8, 6, 1)
            If lgRtn <> 0 Then Return ""

            '< ���� ����  
            LK_StartPage()

            Dim sSpcNm As String = ro_Data.SPCNM
            Dim sTubeNm As String = ro_Data.TUBENM
            Dim sTGrpNm As String = ro_Data.TGRPNM

            '< ���ڵ�  
            ' Codabar 
            'LK_PrintBarCode(80 + riLeftPos, 30 + iTop, 0, "K", 2, 4, 75, 0, "A" + ro_Data.BCNOPRT + "A")

            '' code 128
            'LK_PrintBarCode(75 + riLeftPos, 61, 0, "1A", 2, 4, 90, 0, ro_Data.BCNOPRT)

            '< ���ڵ� ��ȣ
            'Dim sBcnoPrt As String = ro_Data.BCNOPRT
            'LK_PrintWindowsFont(160 + riLeftPos, 107 + iTop, 0, 15, 1, 0, 0, "����", sBcnoPrt)

            '< ��Ϲ�ȣ sPID
            LK_PrintDeviceFont(370 + riLeftPos, 230 + iTop, 180, 3, 1, 2, 0, ro_Data.REGNO)

            '< �����/����/����  
            Dim sDptWard As String = ro_Data.DEPTWARD
            LK_PrintWindowsFont(100 + riLeftPos, 190 + iTop, 180, 20, 1, 0, 0, "����", sDptWard)

            '< ����/���� 
            Dim sSexAge As String = ro_Data.SEXAGE
            LK_PrintWindowsFont(60 + riLeftPos, 220 + iTop, 180, 18, 0, 0, 0, "����", sSexAge)

            '< ȯ�ڸ� 
            Dim sPatNm As String = ro_Data.PATNM
            LK_PrintWindowsFont(230 + riLeftPos, 230 + iTop, 180, 35, 1, 0, 0, "����", sPatNm)

            '< ��ü��
            LK_PrintWindowsFont(370 + riLeftPos, 180 + iTop, 180, 20, 1, 0, 0, "����", sSpcNm)

            '< ���� 
            LK_PrintWindowsFont(360 + riLeftPos, 150 + iTop, 180, 25, 1, 0, 0, "����", sTubeNm.Substring(0, 8) + "-")

            '< ���� 
            'LK_PrintDeviceFont(145 + riLeftPos, 105 + iTop, 0, 2, 2, 2, 0, sTubeNm.Substring(8))
            LK_PrintWindowsFont(220 + riLeftPos, 155 + iTop, 180, 40, 1, 0, 0, "����", sTubeNm.Substring(8))

            '< ó�泯¥
            Dim sOrdDt As String = ro_Data.ORDDT
            'LK_PrintDeviceFont(12 + riLeftPos, 150 + iTop, 0, 15, 1, 1, 0, sOrdDt)
            LK_PrintWindowsFont(360 + riLeftPos, 110 + iTop, 180, 20, 1, 0, 0, "����", "ó������ : " + sOrdDt)

            If sLine1 <> "" Then
                'LK_PrintDeviceFont(12 + riLeftPos, 180 + iTop, 0, 15, 1, 1, 0, sLine1)
                LK_PrintWindowsFont(360 + riLeftPos, 80 + iTop, 180, 20, 1, 0, 0, "����", sLine1)
                If sLine2 <> "" Then
                    'LK_PrintDeviceFont(12 + riLeftPos, 200 + iTop, 0, 15, 1, 1, 0, sLine2)
                    LK_PrintWindowsFont(360 + riLeftPos, 60 + iTop, 180, 20, 1, 0, 0, "����", sLine2)
                    If sLine3 <> "" Then
                        'LK_PrintDeviceFont(12 + riLeftPos, 220 + iTop, 0, 15, 1, 1, 0, sLine3)
                        LK_PrintWindowsFont(360 + riLeftPos, 40 + iTop, 180, 20, 1, 0, 0, "����", sLine3)
                    End If
                End If
            End If

            '< ���� ������ 
            LK_EndPage()

            Return ""

        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            Throw (New Exception(ex.Message, ex))

            Return ""

        End Try

    End Function

    Public Overridable Function BarCodePrtOut_RIS(ByVal ra_PrtData As ArrayList, _
                                              ByVal rsPrintPort As String, ByVal rsSocketIP As String, ByVal rbFirst As Boolean, _
                                              Optional ByVal riLeftPos As Integer = 0, _
                                              Optional ByVal riTopPos As Integer = 0, _
                                              Optional ByVal rsBarType As String = "CODABAR") As Boolean
        Dim sFn As String = "BarCodePrtOut"
        Dim bReturn As Boolean = False
        Dim iFileNo As Integer = 0
        Dim sWkNo As String = ""

        Try
            'If LK_OpenPrinter(rsPrintPort) Then
            '    LK_SetupPrinter("55.0", "30.0", 0, "4.0", "0", 8, 6, 1)
            '    LK_ClosePrinter()
            'End If

            For ix1 As Integer = 0 To ra_PrtData.Count - 1

                If sWkNo <> CType(ra_PrtData(ix1), STU_BCPRTINFO).TUBENM Then    '���� �۾���ȣ(�۾��׷�)�� 1ȸ�� ����Ѵ�.
                    sWkNo = CType(ra_PrtData(ix1), STU_BCPRTINFO).TUBENM
                Else
                    Continue For
                End If

                If CType(ra_PrtData(ix1), STU_BCPRTINFO).REGNO <> "" Then
                    Dim iPrtCnt As Integer = 1

                    If CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT = "A" Then
                        iPrtCnt = 2
                    ElseIf CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT = "B" Then
                        '< CrossMatching ��ü
                        iPrtCnt = 3
                    ElseIf IsNumeric(CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT) Then
                        iPrtCnt = Convert.ToInt32(CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT)
                    End If

                    For ix2 As Integer = 1 To iPrtCnt

                        If LK_OpenPrinter(rsPrintPort) = 0 Then
                            If rbFirst = True And CType(ra_PrtData(ix1), STU_BCPRTINFO).BCNO = "" Then
                                Dim sPrtMsg = fnMakePrtMsg_PATINFO(CType(ra_PrtData(ix1), STU_BCPRTINFO), rbFirst, riLeftPos, riTopPos, rsBarType)
                            Else

                                Dim sPrtMsg = fnMakePrtMsg_RIS(CType(ra_PrtData(ix1), STU_BCPRTINFO), rbFirst, riLeftPos, riTopPos, rsBarType)
                            End If

                            LK_ClosePrinter()
                        End If

                        Threading.Thread.Sleep(1000)
                    Next
                End If
            Next

            Return True
        Catch ex As Exception
            LK_ClosePrinter()
            Fn.log(msFile + sFn, Err)
            MsgBox(msFile + sFn + vbCrLf + ex.Message)
            Return False
        Finally
            FileClose(iFileNo)

        End Try
    End Function

End Class

