﻿Imports COMMON.SVar
Imports COMMON.CommFN
Imports COMMON.CommFN.Fn
Imports COMMON.CommPrint
Imports System.Text

Public Class BIXOLON
#Region " Constant variables "

    '  Constant List

    '	Rotation
    Public Const ROTATE_0 As Integer = 0
    Public Const ROTATE_90 As Integer = 1
    Public Const ROTATE_180 As Integer = 2
    Public Const ROTATE_270 As Integer = 3

    '	Bar-code Type
    Public Const CODE39 As Integer = 0
    Public Const CODE128 As Integer = 1
    Public Const I2OF5 As Integer = 2
    Public Const CODEBAR As Integer = 3
    Public Const CODE93 As Integer = 4
    Public Const UPC_A As Integer = 5
    Public Const UPC_E As Integer = 6
    Public Const EAN13 As Integer = 7
    Public Const EAN8 As Integer = 8
    Public Const UCC_EAN128 As Integer = 9

    '	Device Fonts
    Public Const ENG_9X15 As Integer = 0   '	9 x 15
    Public Const ENG_12X20 As Integer = 1  '	12 x 20
    Public Const ENG_16X25 As Integer = 2  '	16 x 25
    Public Const ENG_19X30 As Integer = 3  '	19 x 30
    Public Const ENG_24X38 As Integer = 4  '	24 x 38
    Public Const ENG_32X50 As Integer = 5  '	32 x 50
    Public Const ENG_48X76 As Integer = 6  '	48 x 76
    Public Const ENG_22X34 As Integer = 7    '  22 x 34
    Public Const ENG_28X44 As Integer = 8    '  28 x 44
    Public Const ENG_37X58 As Integer = 9    '  37 x 58

    Public Const KOR_16X16 As Integer = 97  '0x61	'	16 x 16
    Public Const KOR_24X24 As Integer = 98  '0x62	'	24 x 24	
    Public Const KOR_20X20 As Integer = 99  '0x63 '  20 x 20
    Public Const KOR_26X26 As Integer = 100    '0x64 '  26 x 26
    Public Const KOR_20X26 As Integer = 101    '0x65 '  20 x 26
    Public Const KOR_38X38 As Integer = 102    '0x66 '  38 x 38

    Public Const CHN_GB2312 As Integer = 96 '0x6D
    Public Const CHN_BIG5 As Integer = 110  '0x6E

    '	Speed
    Public Const SPEED_25 As Integer = 0
    Public Const SPEED_30 As Integer = 1
    Public Const SPEED_40 As Integer = 2
    Public Const SPEED_50 As Integer = 3
    Public Const SPEED_60 As Integer = 4
    Public Const SPEED_70 As Integer = 5

    '	Orientation
    Public Const ORIENTATION_TOP As Integer = 0
    Public Const ORIENTATION_BOTTOM As Integer = 1

    '	Media Type
    Public Const GAP = 0
    Public Const CONTINUOUS = 1
    Public Const BLACKMARK = 2

    '	Block Option
    Public Const LINE_OVER_WRITING = 0
    Public Const LINE_EXCLUSIVE_OR = 1
    Public Const LINE_DELETE = 2
    Public Const SLOPE = 3
    Public Const BOX = 4

    ' Font Selection
    Public Const ASCII As String = "U"
    Public Const KS5601 As String = "K"
    Public Const BIG5 As String = "B"
    Public Const GB2312 As String = "G"
    Public Const ShiftJIS As String = "J"


    ' Font Alignment
    Public Const LEFTALIGN As String = "L"
    Public Const RIGHTALIGN As String = "R"
    Public Const CENTERALIGN As String = "C"

    ' Font Direction
    Public Const LEFTTORIGHT As Integer = 0
    Public Const RIGHTTOLEFT As Integer = 1

    ' QRCode MODEL
    Public Const QRMODEL_1 As Integer = 1
    Public Const QRMODEL_2 As Integer = 2

    ' QRCode ECC Level
    Public Const QRECCLEVEL_L As Integer = 1   ' 7%
    Public Const QRECCLEVEL_M As Integer = 2   ' 15%
    Public Const QRECCLEVEL_Q As Integer = 3   ' 25%
    Public Const QRECCLEVEL_H As Integer = 4   ' 30%

    ' QRCode size
    Public Const QRSIZE_1 As Integer = 1
    Public Const QRSIZE_2 As Integer = 2
    Public Const QRSIZE_3 As Integer = 3
    Public Const QRSIZE_4 As Integer = 4

    ' Dither option 
    Public Const DITHER_NONE As Integer = -1
    Public Const DITHER_1 As Integer = 0
    Public Const DITHER_2 As Integer = 1
    Public Const DITHER_3 As Integer = 6
    Public Const DITHER_4 As Integer = 7

    '	Alignment
    Public Const ALIGN_LEFT = 0
    Public Const ALIGN_CENTER = 1
    Public Const ALIGN_RIGHT = 2
    Public Const ALIGN_BOTH_SIDE = 3

#End Region

#Region " DLL API Function "

    Public Declare Function ConnectPrinter Lib "BXLLIB.dll" (ByVal szPrinterName As String) As Boolean

    Public Declare Function DisconnectPrinter Lib "BXLLIB.dll" () As Boolean


    Public Declare Function GetBIXOLON_PrinterList Lib "BXLLIB.dll" (ByVal strInstalledPrinter As System.Text.StringBuilder) As Integer

    Public Declare Function GetDllVersion Lib "BXLLIB.dll" (ByVal strBxlPrtList As System.Text.StringBuilder) As Boolean
    ''


    Public Declare Function GetPrinterResolution Lib "BXLLIB.dll" () As Integer


    Public Declare Function Print1DBarcode Lib "BXLLIB.dll" (ByVal nHorizontalPos As Integer, _
                                                 ByVal nVerticalPos As Integer, _
                                                 ByVal nBarcodeType As Integer, _
                                                 ByVal nNarrowBarWidth As Integer, _
                                                 ByVal nWideBarWidth As Integer, _
                                                 ByVal nBarcodeHeight As Integer, _
                                                 ByVal nRotation As Integer, _
                                                 ByVal bHRI As Boolean, _
                                                 ByVal pData As String) _
                                                 As Boolean


    Public Declare Function PrintDeviceFont Lib "BXLLIB.dll" (ByVal nHorizontalPos As Integer, _
                                                  ByVal nVerticalPos As Integer, _
                                                  ByVal nFontName As Integer, _
                                                  ByVal nHorizontalMulti As Integer, _
                                                  ByVal nVerticalMulti As Integer, _
                                                  ByVal nRotation As Integer, _
                                                  ByVal bBold As Boolean, _
                                                  ByVal szText As String) _
                                                  As Boolean


    Public Declare Function SetConfigOfPrinter Lib "BXLLIB.dll" (ByVal nSpeed As Integer, _
                                                     ByVal nDensity As Integer, _
                                                     ByVal nOrientation As Integer, _
                                                     ByVal bAutoCut As Integer, _
                                                     ByVal nCuttingPeriod As Integer, _
                                                     ByVal bBackFeeding As Boolean) _
                                                     As Boolean


    Public Declare Function Prints Lib "BXLLIB.dll" (ByVal nLabelSet As Integer, _
                                         ByVal nCopiesOfEachLabel As Integer) _
                                         As Boolean


    Public Declare Function SetPaper Lib "BXLLIB.dll" (ByVal nHorizontalMagin As Integer, _
                                           ByVal nVerticalMargin As Integer, _
                                           ByVal nPaperWidth As Integer, _
                                           ByVal nPaperLength As Integer, _
                                           ByVal nMediaType As Integer, _
                                           ByVal nOffSet As Integer, _
                                           ByVal nGapLengthORThicknessOfBlackLine As Integer) _
                                           As Boolean


    Public Declare Function ClearBuffer Lib "BXLLIB.dll" () As Boolean


    Public Declare Function PrintBlock Lib "BXLLIB.dll" (ByVal nHorizontalStartPos As Integer, _
                                             ByVal nVerticalStartPos As Integer, _
                                             ByVal nHorizontalEndPos As Integer, _
                                             ByVal nVerticalEndPos As Integer, _
                                             ByVal nOption As Integer, _
                                             ByVal nThickness As Integer) _
                                             As Boolean

    '/******************************************************************************/
    ' Circle draw 
    ' int nHorizontalStartPos	: X position
    ' int nVerticalStartPos	    : Y position
    ' int nDiameter			    : 원 Size Lib "BXLLIB.dll" (반지름) 1~6
    ' int nMulti				: 확대 Lib "BXLLIB.dll" (1~4)
    '/******************************************************************************/

    Public Declare Function PrintCircle Lib "BXLLIB.dll" (ByVal nHorizontalStartPos As Integer, _
                                             ByVal nVerticalStartPos As Integer, _
                                             ByVal nDiameter As Integer, _
                                             ByVal nMulti As Integer) _
                                             As Boolean


    Public Declare Function PrintDirect Lib "BXLLIB.dll" (ByVal pDirectData As String) As Integer


    Public Declare Function StartLabel Lib "BXLLIB.dll" () As Boolean


    Public Declare Sub EndLabel Lib "BXLLIB.dll" ()


    Public Declare Function PrintTrueFontLib Lib "BXLLIB.dll" (ByVal nXPos As Integer, _
                                    ByVal nYPos As Integer, _
                                    ByVal strFontName As String, _
                                    ByVal nFontSize As Integer, _
                                    ByVal nRotaion As Integer, _
                                    ByVal bItalic As Boolean, _
                                    ByVal bBold As Boolean, _
                                    ByVal bUnderline As Boolean, _
                                    ByVal strText As String) _
                                    As Boolean

    Public Declare Function PrintTrueFontLibWithAlign Lib "BXLLIB.dll" (ByVal nXPos As Integer, _
                                    ByVal nYPos As Integer, _
                                    ByVal strFontName As String, _
                                    ByVal nFontSize As Integer, _
                                    ByVal nRotaion As Integer, _
                                    ByVal bItalic As Boolean, _
                                    ByVal bBold As Boolean, _
                                    ByVal bUnderline As Boolean, _
                                    ByVal strText As String, _
                                    ByVal nPrintWidth As String, _
                                    ByVal nAlignment As Integer) _
                                    As Boolean


    Public Declare Function PrintVectorFont Lib "BXLLIB.dll" ( _
                                            ByVal nXPos As Integer, _
                                            ByVal nYPos As Integer, _
                                            ByVal strFontSelection As String, _
                                            ByVal nFontWidth As Integer, _
                                            ByVal nFontHeight As Integer, _
                                            ByVal strRightSideCharSpacing As String, _
                                            ByVal bBold As Boolean, _
                                            ByVal bReversePrinting As Boolean, _
                                            ByVal bTextStyle As Boolean, _
                                            ByVal nRotation As Integer, _
                                            ByVal strTextAlignment As String, _
                                            ByVal nTextDirection As Integer, _
                                            ByVal pData As String) _
                                            As Boolean


    Public Declare Function PrintQRCode Lib "BXLLIB.dll" (ByVal nXPos As Integer, _
                                                          ByVal nYPos As Integer, _
                                                          ByVal nModel As Integer, _
                                                          ByVal nECCLevel As Integer, _
                                                          ByVal nSize As Integer, _
                                                          ByVal nRotation As Integer, _
                                                          ByVal pData As String) _
                                                          As Boolean

    Public Declare Function SetShowMsgBox Lib "BXLLIB.dll" (ByVal bShowMsgBox As Boolean) As Boolean



    Public Declare Function PrintImageLib Lib "BXLLIB.dll" (ByVal nHorizontalStartPos As Integer, _
                                                            ByVal nVerticalStartPos As Integer, _
                                                            ByVal pBitmapFilename As String, _
                                                            ByVal nDither As Integer, _
                                                            ByVal bDataCompression As Boolean) _
                                                            As Boolean

    Public Declare Function PrintImageLibWithSize Lib "BXLLIB.dll" (ByVal nHorizontalStartPos As Integer, _
                                                            ByVal nVerticalStartPos As Integer, _
                                                            ByVal nNewWidth As Integer, _
                                                            ByVal nNewHeight As Integer, _
                                                            ByVal pBitmapFilename As String, _
                                                            ByVal nDither As Integer, _
                                                            ByVal bDataCompression As Boolean) _
                                                            As Boolean

    Private Const msFile As String = "File : BIXOLON.vb, Class : BIXOLON" + vbTab
#End Region

#Region " ETC "

    ' 숫자 입력 처리
    Public Sub pInputValidateDigit(ByRef e As System.Windows.Forms.KeyPressEventArgs)
        If e.KeyChar = "." Then
            e.Handled = True
        ElseIf e.KeyChar = Convert.ToChar(System.Windows.Forms.Keys.Back) OrElse e.KeyChar = Convert.ToChar(System.Windows.Forms.Keys.Delete) Then
            e.Handled = False
        ElseIf Char.IsDigit(e.KeyChar) = True Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    ' 숫자 입력 처리(핸들, 소숫점 포함여부) 
    Public Sub pInputValidateFloat(ByRef e As System.Windows.Forms.KeyPressEventArgs, ByVal sender As Object)
        Dim nPreLen As Integer = 4    ' 정수부 길이
        Dim nPostLen As Integer = 3   ' 소수부 길이 

        '백스페이스는 그냥 허용
        If e.KeyChar = Convert.ToChar(System.Windows.Forms.Keys.Back) Then Exit Sub

        'sender 로부터 텍스트 박스 구함
        Dim editor As TextBox = sender

        '소숫점의 점(dot)이 포함되어 있는지 여부.
        '단, 현재 selection 상태인 텍스트에 점이 포함되어 있으면 비포함으로 간주
        Dim bDotContains As Boolean = editor.Text.Contains(".") AndAlso Not editor.SelectedText.Contains(".")

        '전체 길이 체크를 위한 변수(selection 길이는 뺀다)
        Dim nTextLen As Integer = editor.Text.Length - editor.SelectedText.Length
        '현재 커서 위치
        Dim nCursor As Integer = editor.SelectionStart

        '점과 숫자 이외의 값은 받아들이지 않음.
        If Not e.KeyChar = "." AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
            '소숫점 이하 값이 없는 경우 - 2010.12.29 추가
        ElseIf e.KeyChar = "." AndAlso nPostLen < 1 Then
            e.Handled = True
            '점이 포함되어 있을 경우
        ElseIf bDotContains Then

            '전체 길이 체크 정수부와 소수부의 길이 더하기 점의 길이보다 같거나 크면 받아들이지 않음.
            '또한, 이미 점이 포함되어 있으므로, 점이 들어오면 받아들이지 않음.
            If nTextLen >= nPreLen + nPostLen + 1 OrElse e.KeyChar = "." Then
                e.Handled = True
            Else
                '점의 위치를 구한다.
                Dim nDotPos As Integer = editor.Text.IndexOf(".")
                '텍스트를 정수부와 소수부로 나눈다.
                Dim sSep() As String = editor.Text.Split(".")

                '현재 커서가 점 앞에 있고, 정수부의 길이가 지정된 길이보다 길어지면 받아들이지 않음.
                If nDotPos > nCursor AndAlso sSep(0).Length >= nPreLen Then
                    e.Handled = True
                    '현재 커서가 점 뒤에 있고, 소수부의 길이가 지정된 길이보다 길어지면 받아들이지 않음.
                ElseIf nDotPos < nCursor AndAlso sSep(1).Length >= nPostLen Then
                    e.Handled = True
                End If
            End If
            '들어온 값이 점이 아니고, 현재 텍스트가 점을 포함하지 않으면
            '현재 값은 정수인데, 정수부의 길이가 지정된 길이보다 길어지면 받아들이지 않음.
        ElseIf Not e.KeyChar = "." AndAlso Not bDotContains AndAlso nTextLen >= nPreLen Then
            e.Handled = True
        End If

    End Sub
#End Region



    Public Overridable Function BarCodePrtOut_Slide(ByVal roSndMsg As ArrayList, _
                                                    ByVal riPrtCnt As Integer, ByVal rsPrintPort As String, ByVal rsSocketIP As String, _
                                                    Optional ByVal riLeftPos As Integer = 0, _
                                                    Optional ByVal riTopPos As Integer = 0, _
                                                    Optional ByVal rsBarType As String = "CODABAR") As Boolean
        Dim sFn As String = "BarCodePrtOut_Slide"
        Dim bReturn As Boolean = False
        Dim iFileNo As Integer = 0
        Dim LabelColumnCnt As Integer = 0

        'riPrtCnt 사용 안함.

        Try
            If roSndMsg Is Nothing Then

            Else
                For ix1 As Integer = 0 To roSndMsg.Count - 1
                    If ConnectPrinter(GetInstalledPrinter) = True Then

                        LabelColumnCnt += 1
                        Dim sPrtMsg = fnMakePrtMsg_SLIDE(CType(roSndMsg(ix1), STU_SLIDELABELINFO), riLeftPos, riTopPos, ix1, LabelColumnCnt)

                        If (LabelColumnCnt = 4) Then
                            Prints(1, 1)
                            EndLabel()
                            LabelColumnCnt = 0
                        End If
                    End If

                    Threading.Thread.Sleep(1000)
                Next

                Prints(1, 1) ' Print Command
                EndLabel() ' Set the Label End

                ' Disconnect Printer Driver
                DisconnectPrinter()
            End If

            Return True

        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            MsgBox(msFile + sFn + vbCrLf + ex.Message)
            Return ""
        Finally
            FileClose(iFileNo)

        End Try

    End Function

    Private Function GetInstalledPrinter() As String

        Try
            Cursor.Current = Cursors.WaitCursor

            Dim sbPrinters As New StringBuilder(4096)
            If GetBIXOLON_PrinterList(sbPrinters) <= 0 Then Return False

            Dim seps As String = "^"
            Dim strPrtList() As String = sbPrinters.ToString().Split(seps)

            If strPrtList.Count > 0 Then
                Return strPrtList(0)
            Else
                Return ""
            End If

        Catch ex As Exception
            MsgBox(ex.ToString())
        Finally
            Cursor.Current = Cursors.Default
        End Try

    End Function

    Protected Overridable Function fnMakePrtMsg_SLIDE(ByVal ro_Data As STU_SLIDELABELINFO, ByVal riLeftPos As Integer, ByVal riTopPos As Integer, _
                                                      ByVal iPrintCount As Integer, ByVal LabelColumnCnt As Integer) As Boolean
        Dim sFn As String = "fnMakePrtMsg_SLIDE"

        Try
            Dim MM2D As Integer = 8 ' mm to dot
            ' 203 DPI : 1mm = 8 dots
            ' 300 DPI : 1mm = 12 dots
            MM2D = IIf(GetPrinterResolution() < 300, 8, 12)

            Dim nSpeed As Integer = SPEED_50
            Dim nDensity As Integer = Convert.ToInt32("14")
            Dim bAutoCut As Boolean = False
            Dim bReverseFeeding As Boolean = True

            Dim nMarginX As Integer = Convert.ToInt32(Double.Parse("0.5") * MM2D)
            Dim nMarginY As Integer = Convert.ToInt32(Double.Parse("1") * MM2D)

            ' Paper size : 1 inch = 25.4 mm
            ' Default 4x6 inch -> (4*25.4) x (6*25.4) mm
            ' Dim dWidth As Double = 3.7 * 25.4
            ' Dim dHeight As Double = 0.1 * 23
            Dim nPaper_Width As Integer = Convert.ToInt32(Double.Parse("95.0") * MM2D)
            Dim nPaper_Height As Integer = Convert.ToInt32(Double.Parse("23.0") * MM2D)

            Dim nSensorType As Integer = GAP
            Dim iXGap As Integer = 0

            Select Case LabelColumnCnt
                Case 1 : iXGap = 0
                Case 2 : iXGap = Convert.ToInt32(Double.Parse("23.0") * MM2D)
                Case 3 : iXGap = Convert.ToInt32(Double.Parse("47.0") * MM2D)
                Case 4 : iXGap = Convert.ToInt32(Double.Parse("71.0") * MM2D)
            End Select

            ' Set the label start
            StartLabel()

            ' Set Label and Printer
            SetConfigOfPrinter(SPEED_50, 14, ORIENTATION_TOP, bAutoCut, 0, bReverseFeeding)

            ' Clear Buffer of Printer 
            If iPrintCount = 0 Then
                ClearBuffer()
            End If

            '1 Inch : 25.4mm
            '1 mm   :  8 Dot in 203 DPI such as TX400, T400, D420, D220, SRP-770, SRP-770II
            '1 mm   : 12 Dot in 300 DPI such as TX403, T403, D423, D223
            '4 Inch : 25.4  * 4 * 8 = 812.8
            '6 Inch : 25.4  * 4 * 8 = 1219.2
            SetPaper(nMarginX, nMarginY, nPaper_Width, nPaper_Height, nSensorType, 0, 16) ' 4
            'Thermal transfer
            PrintDirect("STd")

            ' PrintDeviceFont(nMarginX, nMarginY, "Arial", 8, 0, False, True, True, "07/01  B-15-235")
            'PrintTrueFontLib(nMarginX + (iXGap + 5), nMarginY, "Arial", 8, 0, False, True, True, SubstringH(ro_Data.WKMMDD, 0, 2) + "/" + _
            '                                                                       SubstringH(ro_Data.WKMMDD, 2) + "  " + _
            '                                                                       ro_Data.CLSCD + "-" + _
            '                                                                       ro_Data.WKYEAR + "-" + _
            '                                                                       ro_Data.BUNHO)

            PrintTrueFontLib(nMarginX + (iXGap + 5), nMarginY, "Arial", 8, 0, False, True, True, ro_Data.WLNO)

            PrintTrueFontLib(nMarginX + (iXGap + 5), nMarginY + 50, "Arial", 12, 0, False, False, False, ro_Data.REGNO)
            PrintTrueFontLib(nMarginX + (iXGap + 5), nMarginY + 120, "Arial", 12, 0, False, False, False, ro_Data.PATNM)

            '            PrintTrueFontLib(nMarginX + (iXGap + 5), nMarginY + 180, "Arial", 8, 0, False, True, False, "-------------------------")
            '2019-10-17 검사명 추가gh

            PrintTrueFontLib(nMarginX + 150 + (iXGap + 5), nMarginY + 130, "Arial", 6, 0, False, True, False, ro_Data.TNMBP)

            PrintTrueFontLib(nMarginX + (iXGap + 5), nMarginY + 160, "Arial", 8, 0, False, True, False, "-------------------------")

            PrintTrueFontLib(nMarginX + 10 + (iXGap + 5), nMarginY + 190, "Arial", 6, 0, False, True, False, "전 북 대 학 교 병 원")
            PrintTrueFontLib(nMarginX + 10 + (iXGap + 5), nMarginY + 220, "Arial", 6, 0, False, True, False, "진 단 검 사 의 학 과")

        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            Throw (New Exception(ex.Message, ex))

            Return True

        End Try
    End Function

    '' 20170728 ODG 추가
    '' 전북대 혈액은행 QR BARCODE 출력

    Public Overridable Function BarCodePrtOut_BLD(ByVal roSndMsg As ArrayList, _
                                                  ByVal riPrtCnt As Integer, ByVal rsPrintPort As String, ByVal rsSocketIP As String, _
                                                  Optional ByVal riLeftPos As Integer = 0, _
                                                  Optional ByVal riTopPos As Integer = 0, _
                                                  Optional ByVal rsBarType As String = "QRCODE") As Boolean
        Dim sFn As String = "BarCodePrtOut_BLD"
        Dim bReturn As Boolean = False
        Dim iFileNo As Integer = 0
        Dim LabelColumnCnt As Integer = 0

        Try

            If roSndMsg Is Nothing Then
            Else
                'riPrtCnt = 10
                For ix1 As Integer = 0 To roSndMsg.Count - 1

                    LabelColumnCnt = 0

                    'For ix2 As Integer = 1 To riPrtCnt

                    '    If CType(roSndMsg(ix1), STU_BLDLABEL).BCTYPE <> "D" Then
                    '        Dim sPrtMsg = fnMakePrtMsg_BLD(CType(roSndMsg(ix1), STU_BLDLABEL), riLeftPos, riTopPos)
                    '    Else
                    '        Dim sPrtMsg = fnMakePrtMsg_DON(CType(roSndMsg(ix1), STU_BLDLABEL), riLeftPos, riTopPos, ix2)
                    '    End If

                    '    ' Print Command
                    '    Prints(1, 1)

                    '    ' Set the Label End/
                    '    EndLabel()

                    '    ' Disconnect Printer Driver
                    '    DisconnectPrinter()

                    'Next
                    'rsPrintPort // GetInstalledPrinter
                    If ConnectPrinter(rsPrintPort) = True Then
                        'If ConnectPrinter(rsPrintPort) = True Then
                        For ix2 As Integer = 1 To riPrtCnt


                            LabelColumnCnt += 1

                            If CType(roSndMsg(ix1), STU_BLDLABEL).BCTYPE <> "D" Then
                                Dim sPrtMsg = fnMakePrtMsg_BLD(CType(roSndMsg(ix1), STU_BLDLABEL), riLeftPos, riTopPos, LabelColumnCnt)
                            Else
                                Dim sPrtMsg = fnMakePrtMsg_DON(CType(roSndMsg(ix1), STU_BLDLABEL), riLeftPos, riTopPos, ix2, LabelColumnCnt)
                            End If

                            If (LabelColumnCnt = 4) Then
                                Prints(1, 1)
                                EndLabel()
                                LabelColumnCnt = 0
                            End If
                            Threading.Thread.Sleep(1000)
                        Next

                    End If

                    'Threading.Thread.Sleep(1000)

                    Prints(1, 1)
                    EndLabel()

                    ' Disconnect Printer Driver
                    DisconnectPrinter()
                    ' Threading.Thread.Sleep(1000)
                Next
            End If

            Return True

        Catch ioex As System.IO.IOException

        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            MsgBox(msFile + sFn + vbCrLf + ex.Message)
            Return False
        Finally
            FileClose(iFileNo)

        End Try
    End Function

    Protected Overridable Function fnMakePrtMsg_BLD(ByVal ro_Data As STU_BLDLABEL, ByVal riLeftPos As Integer, ByVal riTopPos As Integer, ByVal LabelColumnCnt As Integer) As String
        Dim sFn As String = "fnMakePrtMsg_BLD"

        Try

            Dim MM2D As Integer = 8 ' mm to dot
            ' 203 DPI : 1mm = 8 dots
            ' 300 DPI : 1mm = 12 dots
            MM2D = IIf(GetPrinterResolution() < 300, 8, 12)

            Dim nSpeed As Integer = SPEED_50
            Dim nDensity As Integer = Convert.ToInt32("14")
            Dim bAutoCut As Boolean = False
            Dim bReverseFeeding As Boolean = True

            Dim nMarginX As Integer = Convert.ToInt32(Double.Parse("0.5") * MM2D)
            Dim nMarginY As Integer = Convert.ToInt32(Double.Parse("1") * MM2D)

            ' Paper size : 1 inch = 25.4 mm
            ' Default 4x6 inch -> (4*25.4) x (6*25.4) mm
            ' Dim dWidth As Double = 3.7 * 25.4
            ' Dim dHeight As Double = 0.1 * 23

            Dim nPaper_Width As Integer = Convert.ToInt32(Double.Parse("80.0") * MM2D)
            Dim nPaper_Height As Integer = Convert.ToInt32(Double.Parse("80.0") * MM2D)

            Dim nSensorType As Integer = GAP

            'Dim iXGap As Integer = riLeftPos
            'Dim iYGap As Integer = riTopPos

            Dim iXGap As Integer = 0
            Dim iYGap As Integer = 0

            Select Case LabelColumnCnt
                Case 1 : iXGap = 0
                Case 2 : iXGap = Convert.ToInt32(Double.Parse("23.0") * MM2D)
                Case 3 : iXGap = Convert.ToInt32(Double.Parse("47.0") * MM2D)
                Case 4 : iXGap = Convert.ToInt32(Double.Parse("71.0") * MM2D)
            End Select

            ' Set the label start
            StartLabel()

            ' Set Label and Printer
            'SetConfigOfPrinter(SPEED_50, 14, ORIENTATION_TOP, bAutoCut, 0, bReverseFeeding)
            SetConfigOfPrinter(SPEED_60, 8, ORIENTATION_TOP, bAutoCut, 0, bReverseFeeding)

            ' Clear Buffer of Printer 
            ClearBuffer()

            '1 Inch : 25.4mm
            '1 mm   :  8 Dot in 203 DPI such as TX400, T400, D420, D220, SRP-770, SRP-770II
            '1 mm   : 12 Dot in 300 DPI such as TX403, T403, D423, D223
            '4 Inch : 25.4  * 4 * 8 = 812.8
            '6 Inch : 25.4  * 4 * 8 = 1219.2

            ''SetPaper(nMarginX, nMarginY, nPaper_Width, nPaper_Height, nSensorType, 0, 16) ' 4
            'SetPaper(nMarginX, nMarginY, nPaper_Width, nPaper_Height, nSensorType, 0, 3)


            'result = SetPaper(0, 0, 100 * 8, 100 * 8, 0, 0, 24)
            SetPaper(10, 10, 90 * 12, 90 * 12, 0, 0, 24)

            'Thermal transfer
            PrintDirect("STd")

            ''''    원점 테스트
            'PrintTrueFontLib(0 + 0, 0, "HY견고딕", 10, 0, False, True, True, "asdasasdjfjhfadsfsdf")

            ''''< 1. 등록번호  590 530
            'type1
            'PrintTrueFontLib(nMarginX + (iXGap + 870), nMarginY + (iYGap + 800), "HY견고딕", 16, ROTATE_180, False, True, False, ro_Data.REGNO)
            'type2
            PrintTrueFontLib(nMarginX + (iXGap + 870), nMarginY + (iYGap + 820), "HY견고딕", 16, ROTATE_180, False, True, False, ro_Data.REGNO)

            ''< 2. 환자명
            'type1
            'PrintTrueFontLib(nMarginX + (iXGap + 360), nMarginY + (iYGap + 800), "HY견고딕", 16, ROTATE_180, False, True, False, ro_Data.PATNM)
            'type2
            PrintTrueFontLib(nMarginX + (iXGap + 360), nMarginY + (iYGap + 820), "HY견고딕", 16, ROTATE_180, False, True, False, ro_Data.PATNM)

            ''< 3. 외래-진료과,  병동-진료과/병동/병실
            Dim sDept As String = ""
            Dim sWard As String = ""

            If ro_Data.IOGBN.Trim.Equals("O") Then
                sDept = ro_Data.DEPTWARD.Trim                                                         '외래환자
                sWard = ""
            Else
                If InStr(ro_Data.DEPTWARD.Trim, "/") = 0 Then
                    sDept = ro_Data.DEPTWARD.Trim
                    sWard = ""
                Else
                    sDept = ro_Data.DEPTWARD.Trim.Substring(0, InStr(ro_Data.DEPTWARD.Trim, "/") - 1) '병동환자
                    sWard = ro_Data.DEPTWARD.Trim.Substring(InStr(ro_Data.DEPTWARD.Trim, "/") - 1)
                End If
            End If

            'type1
            'PrintTrueFontLib(nMarginX + (iXGap + 870), nMarginY + (iYGap + 630), "HY견고딕", 16, ROTATE_180, False, True, False, sDept)
            'PrintTrueFontLib(nMarginX + (iXGap + 870), nMarginY + (iYGap + 550), "HY견고딕", 16, ROTATE_180, False, True, False, sWard)
            'type2
            PrintTrueFontLib(nMarginX + (iXGap + 870), nMarginY + (iYGap + 650), "HY견고딕", 16, ROTATE_180, False, True, False, sDept)
            'PrintTrueFontLib(nMarginX + (iXGap + 870), nMarginY + (iYGap + 570), "HY견고딕", 16, ROTATE_180, False, True, False, sWard)

            '''' 201708107 병동 정보가 있을 경우만 출력 ODG
            If sWard <> "" Then
                PrintTrueFontLib(nMarginX + (iXGap + 870), nMarginY + (iYGap + 570), "HY견고딕", 16, ROTATE_180, False, True, False, sWard)
            End If


            ''< 4. 성별/나이
            'type1
            'PrintTrueFontLib(nMarginX + (iXGap + 360), nMarginY + (iYGap + 600), "HY견고딕", 16, ROTATE_180, False, True, False, ro_Data.SEXAGE)
            'type2    
            PrintTrueFontLib(nMarginX + (iXGap + 360), nMarginY + (iYGap + 620), "HY견고딕", 16, ROTATE_180, False, True, False, ro_Data.SEXAGE)


            ''< 5. 환자혈액형
            If ro_Data.PAT_ABORH.Length < 4 Then
                'PrintTrueFontLib(nMarginX + (iXGap + 870), nMarginY + (iYGap + 400), "HY견고딕", 33, ROTATE_180, False, True, False, ro_Data.PAT_ABORH)
                PrintTrueFontLib(nMarginX + (iXGap + 870), nMarginY + (iYGap + 420), "HY견고딕", 33, ROTATE_180, False, True, False, ro_Data.PAT_ABORH)
            ElseIf ro_Data.PAT_ABORH.Length > 4 Then
                'PrintTrueFontLib(nMarginX + (iXGap + 870), nMarginY + (iYGap + 400), "HY견고딕", 33, ROTATE_180, False, True, False, ro_Data.PAT_ABORH)
                PrintTrueFontLib(nMarginX + (iXGap + 870), nMarginY + (iYGap + 420), "HY견고딕", 33, ROTATE_180, False, True, False, ro_Data.PAT_ABORH)
            End If

            ''< 6. 출고혈액형
            If ro_Data.PAT_ABORH.Length < 4 Then
                ' PrintTrueFontLib(nMarginX + (iXGap + 360), nMarginY + (iYGap + 400), "HY견고딕", 33, ROTATE_180, False, True, False, ro_Data.BLD_ABORH)
                PrintTrueFontLib(nMarginX + (iXGap + 360), nMarginY + (iYGap + 420), "HY견고딕", 33, ROTATE_180, False, True, False, ro_Data.BLD_ABORH)
            ElseIf ro_Data.PAT_ABORH.Length > 4 Then
                'PrintTrueFontLib(nMarginX + (iXGap + 360), nMarginY + (iYGap + 400), "HY견고딕", 33, ROTATE_180, False, True, False, ro_Data.BLD_ABORH)
                PrintTrueFontLib(nMarginX + (iXGap + 360), nMarginY + (iYGap + 420), "HY견고딕", 33, ROTATE_180, False, True, False, ro_Data.BLD_ABORH)
            End If

            ''< 7. 혈액번호[type변경x]
            If ro_Data.BLDNO.Count = 1 Then
                '2019-11-19 혈액번호 사이즈 크게 요청
                'PrintDeviceFont(nMarginX + (iXGap + 850), nMarginY + (iYGap + 230), ENG_19X30, 1, 2, ROTATE_180, True, ro_Data.BLDNO(0))
                PrintDeviceFont(nMarginX + (iXGap + 850), nMarginY + (iYGap + 230), ENG_24X38, 1, 2, ROTATE_180, True, ro_Data.BLDNO(0))
            Else
                For ix As Integer = 0 To ro_Data.BLDNO.Count - 1
                    '2019-11-19 혈액번호 사이즈 크게 요청
                    'PrintDeviceFont(nMarginX + (iXGap + 850), nMarginY + (iYGap + 230) + 30 * ix, ENG_19X30, 1, 2, ROTATE_180, True, ro_Data.BLDNO(ix))
                    'PrintDeviceFont(nMarginX + (iXGap + 850), nMarginY + (iYGap + 2350) + 30 * ix, ENG_19X30, 1, 2, ROTATE_180, True, ro_Data.BLDNO(ix))
                    PrintDeviceFont(nMarginX + (iXGap + 850), nMarginY + (iYGap + 2350) + 30 * ix, ENG_24X38, 1, 2, ROTATE_180, True, ro_Data.BLDNO(ix))
                Next
            End If

            ''< 8. 혈액종류(성분제제명)[type변경x]
            'PrintDeviceFont(nMarginX + (iXGap + 350), nMarginY + (iYGap + 230), ENG_19X30, 1, 2, ROTATE_180, True, ro_Data.COMNM)
            'PrintDeviceFont(nMarginX + (iXGap + 850), nMarginY + (iYGap + 150), ENG_19X30, 1, 2, ROTATE_180, True, ro_Data.COMNM)
            PrintTrueFontLib(nMarginX + (iXGap + 850), nMarginY + (iYGap + 150), "HY견고딕", 12, ROTATE_180, False, True, False, ro_Data.COMNM)
            ''< 9. 혈액번호/종류 - 혈액번호 + '/' + COMORDCD(처방코드)
            ''< 11. 교차시험 결과()
            If (ro_Data.XMATCH1.Trim.Equals("적합") Or ro_Data.XMATCH4.Trim.Equals("적합")) Then
                PrintTrueFontLib(nMarginX + (iXGap + 320), nMarginY + (iYGap + 150), "HY견고딕", 12, ROTATE_180, False, True, False, "적합")
            End If
            '' QR CODE
            Dim sBldNoComOrdCd As String = ro_Data.BLDNO(0).ToString.Trim.Replace("-", "") + "/" + ro_Data.COMCD.Trim
            'PrintQRCode(nMarginX + (iXGap + 320), nMarginY + (iYGap + 210), 1, 2, 9, ROTATE_180, sBldNoComOrdCd)

            '2019-11-19 QR코드 사이즈 크게 요청
            'PrintQRCode(nMarginX + (iXGap + 320), nMarginY + (iYGap + 250), 1, 2, 9, ROTATE_180, sBldNoComOrdCd)

            PrintQRCode(nMarginX + (iXGap + 320), nMarginY + (iYGap + 250), 3, 4, 18, ROTATE_180, sBldNoComOrdCd)

            ''< 10. 검사일시 [type변경x]
            PrintDeviceFont(nMarginX + (iXGap + 840), nMarginY + (iYGap + 80), ENG_19X30, 1, 2, ROTATE_180, True, ro_Data.TESTDT)



            Return ""

        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            Throw (New Exception(ex.Message, ex))

            Return ""

        End Try

    End Function
    '20201019 nbm 명지 bixolon 바코드 프린터
    'Public Overridable Function BarCodePrtOut(ByVal ra_PrtData As ArrayList,
    '                                          ByVal rsPrintPort As String, ByVal rsSocketIP As String, ByVal rbFirst As Boolean,
    '                                          Optional ByVal riLeftPos As Integer = 0,
    '                                          Optional ByVal riTopPos As Integer = 0,
    '                                          Optional ByVal rsBarType As String = "CODABAR", Optional ByVal rsLabelgbn As Boolean = False) As Boolean
    '    Dim sFn As String = "BarCodePrtOut"
    '    Dim bReturn As Boolean = False
    '    Dim iFileNo As Integer = 0
    '    Dim sPrtMsg As String = ""
    '    MsgBox("여기들어옴")
    '    Try
    '        '프린터 연결
    '        If ConnectPrinter(rsPrintPort) Then
    '            MsgBox("2")
    '            For ix1 As Integer = 0 To ra_PrtData.Count - 1
    '                'Set the label start
    '                '라벨 만들기 시작
    '                StartLabel()

    '                'Set Label and Printer
    '                SetConfigOfPrinter(SPEED_25, 20, 1, False, 0, True) '출력 속도, 농도, 용지자름여부, 자름시간, 역송공급여부
    '                SetPaper(0, 0, 55 * 8, 35 * 8, 0, 0, 24) '평행공백, 수직공백, 용지넓이, 용지높이, 매체유형, 오프셋(매채유형 Gap 또는 Blackmark), 매채유형 Gap 길이 또는 선 두께 [dot] (1mm = 8dots)
    '                ClearBuffer() 'Crean up Momory of Printer

    '                'T: 텍스트
    '                'B1: 1D 바코드
    '                'P: 인쇄 시작 
    '                'T Xpos, Ypos, Font, 수평확대, 수직확대, 자간, 회전, 문자 역상 정상, 굵게 표준
    '                'sPrtMsg += "SL914"
    '                'sPrtMsg += "SW610"
    '                'sPrtMsg += "T300,0,1,1,1,0,0,N,N,'A'"
    '                'sPrtMsg += "P1"

    '                'Clear Buffer of Printer
    '                ClearBuffer()
    '                MsgBox("3")
    '                If CType(ra_PrtData(ix1), STU_BCPRTINFO).REGNO <> "" Then
    '                    MsgBox("4")
    '                    If CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT <> "T" Then
    '                        MsgBox("5")
    '                        sPrtMsg = fnMakePrtMsg(CType(ra_PrtData(ix1), STU_BCPRTINFO), rbFirst, riLeftPos, riTopPos, rsBarType)
    '                    End If
    '                    'nCopiesOfEachLabel -------------------------------------------------------
    '                    Dim iPrtCnt As Integer = 1

    '                    If CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT = "A" Then
    '                        iPrtCnt = 2
    '                        '< yjlee 2013.03.10 을지병원 요청. 크로스매칭 검체 바코드 3장 안뽑도록..
    '                    ElseIf CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT = "B" Then
    '                        '< CrossMatching 검체
    '                        iPrtCnt = 3
    '                    ElseIf IsNumeric(CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT) Then
    '                        iPrtCnt = Convert.ToInt32(CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT)
    '                    ElseIf CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT = "T" Then '혈액은행 검체일때 바코드 변경 
    '                        sPrtMsg = fnMakePrtMsg_T(CType(ra_PrtData(ix1), STU_BCPRTINFO), 1, riLeftPos, riTopPos)
    '                    End If
    '                    '---------------------------------------------------------------------------

    '                    '출력(nLabelSet, 복사 갯수)
    '                    Prints(1, iPrtCnt)

    '                    'Set the Label End
    '                    EndLabel()

    '                End If
    '            Next
    '        End If


    '        '프린터 연결 종료
    '        DisconnectPrinter()


    '        Return True

    '    Catch ex As Exception
    '        DisconnectPrinter()
    '        Fn.log(msFile + sFn, Err)
    '        MsgBox(msFile + sFn + vbCrLf + ex.Message)
    '        Return False
    '    Finally
    '        FileClose(iFileNo)

    '    End Try
    'End Function
    Public Overridable Function fnMakePrtMsg_T(ByVal ro_Data As STU_BCPRTINFO, ByVal aiCnt As String, ByVal riLeftPos As Integer, ByVal riTopPos As Integer, Optional ByVal sPrtCheck As Boolean = False) As String
        Dim sFn As String = "fnMakePrtMsg_T"

        Try
            Dim sBarCode$ = "", sPID$ = "", sPName$ = "", sSex$ = "", sKind$ = ""
            Dim sDept$ = "", sSpcNo$ = "", sSpcNm$ = "", sTubeNm$ = "", sComment$ = ""
            Dim sCation As String = "", sAbo As String = "", sTestnms = ""
            Dim sEmer As String = ""

            sEmer = SubstringH(ro_Data.EMER, 0, 2)
            sBarCode = SubstringH(ro_Data.BCNOPRT, 0, 11).Trim    '바코드번호(년월일(4)+구분(2)+SEQ1(4)+SEQ2(1)
            sPID = SubstringH(ro_Data.REGNO, 0, 8)             '등록번호
            sPName = SubstringH(ro_Data.PATNM, 0, 12)          '환자이름
            sSex = SubstringH(ro_Data.SEXAGE, 0, 5)             '성별(M/F)/나이
            sKind = SubstringH(ro_Data.BCCLSCD, 0, 2)            '구분(계+검사계)
            sDept = SubstringH(ro_Data.DEPTWARD, 0, 8)            '진료과/병동
            sSpcNo = SubstringH(ro_Data.BCNO, 0, 18)          '검체번호
            sSpcNm = SubstringH(ro_Data.SPCNM, 0, 5)          '검체명(5)
            sTubeNm = "/" & SubstringH(ro_Data.TUBENM, 0, 8)   '"/"+용기명(8)
            sComment = SubstringH(ro_Data.REMARK, 0, 50)       '진료측 comment
            sCation = SubstringH(ro_Data.INFINFO, 0, 6)       '감염정보
            ' sAbo = SubstringH(ro_Data.ABO, 0, 4)       '감염정보
            sTestnms = SubstringH(ro_Data.TESTNMS, 0, 25)       '검사항목

            If sEmer = "E" Then
                sPName = "*" + sPName
            End If

            '< 바코드  
            Print1DBarcode(((riLeftPos * 8) + 30), ((riTopPos * 8) + 10), CODEBAR, 2, 6, 60, ROTATE_90, True, sBarCode)
            '실제바코드내용
            'PrintDeviceFont(((riLeftPos * 8) + 115), ((riTopPos * 8) + 70), 97, 1, 1, ROTATE_90, False, ro_Data.BCNOPRT)
            '검체번호
            PrintDeviceFont(((riLeftPos * 8) + 30), ((riTopPos * 8) + 95), 98, 1, 1, ROTATE_90, False, sSpcNo)
            '혈액형 ( 추가 ) 
            PrintDeviceFont(((riLeftPos * 8) + 290), ((riTopPos * 8) + 85), 2, 2, 1, ROTATE_90, False, sAbo)
            '등록번호
            PrintDeviceFont(((riLeftPos * 8) + 30), ((riTopPos * 8) + 120), 2, 1, 1, ROTATE_90, False, sPID)
            '환자명
            PrintDeviceFont(((riLeftPos * 8) + 180), ((riTopPos * 8) + 120), 98, 1, 1, ROTATE_90, False, sPName)
            '성별/나이
            PrintDeviceFont(((riLeftPos * 8) + 330), ((riTopPos * 8) + 120), 2, 1, 1, ROTATE_90, False, sSex)
            '검체명
            PrintDeviceFont(((riLeftPos * 8) + 35), ((riTopPos * 8) + 150), 98, 1, 1, ROTATE_90, False, sSpcNm)
            '용기
            PrintDeviceFont(((riLeftPos * 8) + 115), ((riTopPos * 8) + 150), 98, 1, 1, ROTATE_90, False, sTubeNm)
            '진료과/병동
            PrintDeviceFont(((riLeftPos * 8) + 230), ((riTopPos * 8) + 150), 98, 1, 1, ROTATE_90, False, sDept)
            '검사항목
            PrintDeviceFont(((riLeftPos * 8) + 30), ((riTopPos * 8) + 175), 97, 1, 1, ROTATE_90, False, sTestnms)

            If sCation = "" Then
            Else
                If Replace(sCation, " ", "").Length > 0 Then
                    PrintBlock(((riLeftPos * 8) + 330), ((riTopPos * 8) + 150), 390, 183, 4, 2)
                    PrintDeviceFont(((riLeftPos * 8) + 337), ((riTopPos * 8) + 154), 2, 1, 1, ROTATE_90, False, Replace(sCation, " ", ""))
                End If
            End If

            '채혈자 확인자
            'gsSndMsg &= "^CFC,10,10^FO30,230^FD" & sComment & "^FS" b ^CFF,20,20^FO
            PrintDeviceFont(((riLeftPos * 8) + 30), ((riTopPos * 8) + 205), 98, 1, 1, ROTATE_90, False, "채혈자:       확인자:")

            Return ""
        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            Throw (New Exception(ex.Message, ex))

            Return ""
        End Try
    End Function
    Protected Overridable Function fnMakePrtMsg(ByVal ro_Data As STU_BCPRTINFO,
                                            ByVal rbFirst As Boolean,
                                            ByVal riLeftPos As Integer, ByVal riTopPos As Integer,
                                            ByVal rsBarType As String, Optional ByVal sPrtCheck As Boolean = False) As String
        Dim sFn As String = "fnMakePrtMsg"

        Try
            Dim sBarCode$ = "", sPID$ = "", sPName$ = "", sSex$ = "", sKind$ = ""
            Dim sDept$ = "", sSpcNo$ = "", sSpcNm$ = "", sTubeNm$ = "", sComment$ = ""
            Dim sCation As String = "", sBcgbn = "", sTestNms = ""
            Dim sEmer As String = ""

            sEmer = SubstringH(ro_Data.EMER, 0, 2)
            sBarCode = SubstringH(ro_Data.BCNOPRT, 0, 11).Trim    '바코드번호(년월일(4)+구분(2)+SEQ1(4)+SEQ2(1)
            sPID = SubstringH(ro_Data.REGNO, 0, 8)             '등록번호
            sPName = SubstringH(ro_Data.PATNM, 0, 12)          '환자이름
            sSex = SubstringH(ro_Data.SEXAGE, 0, 5)             '성별(M/F)/나이
            sKind = SubstringH(ro_Data.BCCLSCD, 0, 2)            '구분(계+검사계)
            sDept = SubstringH(ro_Data.DEPTWARD, 0, 8)            '진료과/병동
            sSpcNo = SubstringH(ro_Data.BCNO, 0, 18)          '검체번호
            sSpcNm = SubstringH(ro_Data.SPCNM, 0, 5)          '검체명(5)
            sTubeNm = "/" & SubstringH(ro_Data.TUBENM, 0, 8)   '"/"+용기명(8)
            sComment = SubstringH(ro_Data.REMARK, 0, 50)       '진료측 comment
            sCation = SubstringH(ro_Data.INFINFO, 0, 6)       '감염정보
            ' sBcgbn = SubstringH(ro_Data.BCGBN, 0, 6)       '바코드 처리
            sTestNms = SubstringH(ro_Data.TESTNMS, 0, 50)       '검사항목

            If sEmer <> "" Then
                sPName = "*" + sPName
            End If

            sTestNms = sTestNms.Replace("  ", "")
            sTestNms = sTestNms.Replace(",", " ")
            sTestNms = sTestNms.Replace("..", "")
            If sTestNms.Length > 42 Then
                sTestNms = sTestNms.Substring(0, 42) + "..."
            End If

            '< 라인 시작  

            '< 바코드  
            If ro_Data.BCNOPRT <> "" Then
                Print1DBarcode(((riLeftPos * 8) + 40), ((riTopPos * 8) + 10), CODEBAR, 2, 6, 110, ROTATE_90, True, sBarCode)

            End If

            Dim sTGrpNm As String = ro_Data.TGRPNM

            If ro_Data.BCTYPE = "M" Then
                '미생물 검체번호
                PrintDeviceFont(((riLeftPos * 8) + 30), ((riTopPos * 8) + 140), 1, 1, 2, ROTATE_90, False, ro_Data.BCNO_MB)
                '배지명
                PrintDeviceFont(((riLeftPos * 8) + 260), ((riTopPos * 8) + 140), 1, 1, 2, ROTATE_90, False, sTGrpNm)

                '< 성별/나이 
                PrintDeviceFont(((riLeftPos * 8) + 330), ((riTopPos * 8) + 176), 2, 1, 1, ROTATE_90, True, sSex)

                '< 등록번호 sPID
                PrintDeviceFont(((riLeftPos * 8) + 30), ((riTopPos * 8) + 176), 2, 1, 1, ROTATE_90, False, sPID)

                '< 환자명 
                PrintDeviceFont(((riLeftPos * 8) + 180), ((riTopPos * 8) + 176), 98, 1, 1, ROTATE_90, False, sPName)

                '< 진료과/병동/병실  
                ' PrintDeviceFont(((riLeftPos * 8) + 330), ((riTopPos * 8) + 170), 98, 1, 1, ROTATE_90, False, sDept)

                '< 진료과/병동/병실  
                PrintDeviceFont(((riLeftPos * 8) + 230), ((riTopPos * 8) + 200), 98, 1, 1, ROTATE_90, False, sDept)
                '용기 신형
                PrintDeviceFont(((riLeftPos * 8) + 115), ((riTopPos * 8) + 200), 98, 1, 1, ROTATE_90, False, sTubeNm)
                '검체명
                PrintDeviceFont(((riLeftPos * 8) + 35), ((riTopPos * 8) + 200), 98, 1, 1, ROTATE_90, False, sSpcNm)

                '< 바코드분류
                PrintDeviceFont(((riLeftPos * 8) + 340), ((riTopPos * 8) + 140), 1, 1, 1, ROTATE_90, False, sKind)

                '< 검사명
                PrintDeviceFont(((riLeftPos * 8) + 30), ((riTopPos * 8) + 226), 97, 1, 1, ROTATE_90, False, sTestNms)
                '< 감염정보  
                If sCation = "" Then
                Else
                    If Replace(sCation, " ", "").Length > 0 Then
                        PrintBlock(((riLeftPos * 8) + 330), ((riTopPos * 8) + 207), 390, 239, 4, 2)
                        PrintDeviceFont(((riLeftPos * 8) + 337), ((riTopPos * 8) + 211), 2, 1, 1, ROTATE_90, False, Replace(sCation, " ", ""))
                    End If
                End If
            Else
                ''< 검체번호  
                PrintDeviceFont(((riLeftPos * 8) + 30), ((riTopPos * 8) + 140), 2, 1, 1, ROTATE_90, False, sSpcNo)

                '< 성별/나이 
                PrintDeviceFont(((riLeftPos * 8) + 330), ((riTopPos * 8) + 166), 2, 1, 1, ROTATE_90, True, sSex)

                '< 등록번호 sPID
                PrintDeviceFont(((riLeftPos * 8) + 30), ((riTopPos * 8) + 170), 2, 1, 1, ROTATE_90, False, sPID)

                '< 환자명 
                PrintDeviceFont(((riLeftPos * 8) + 180), ((riTopPos * 8) + 170), 98, 1, 1, ROTATE_90, False, sPName)

                '< 진료과/병동/병실  
                PrintDeviceFont(((riLeftPos * 8) + 230), ((riTopPos * 8) + 200), 98, 1, 1, ROTATE_90, False, sDept)

                '용기 신형
                PrintDeviceFont(((riLeftPos * 8) + 115), ((riTopPos * 8) + 200), 98, 1, 1, ROTATE_90, False, sTubeNm)
                '검체분류코드
                '검체분류에서 바코드처리구분으로 바뀜
                PrintDeviceFont(((riLeftPos * 8) + 360), ((riTopPos * 8) + 140), 98, 1, 1, ROTATE_90, False, sBcgbn)
                '검체명
                PrintDeviceFont(((riLeftPos * 8) + 35), ((riTopPos * 8) + 200), 98, 1, 1, ROTATE_90, False, sSpcNm)

                '< 검사명
                PrintDeviceFont(((riLeftPos * 8) + 30), ((riTopPos * 8) + 226), 97, 1, 1, ROTATE_90, False, sTestNms)
                '< 감염정보  
                If sCation = "" Then
                Else
                    If Replace(sCation, " ", "").Length > 0 Then
                        PrintBlock(((riLeftPos * 8) + 330), ((riTopPos * 8) + 194), 390, 226, 4, 2)
                        PrintDeviceFont(((riLeftPos * 8) + 337), ((riTopPos * 8) + 198), 2, 1, 1, ROTATE_90, False, Replace(sCation, " ", ""))
                    End If
                End If
            End If




            '< 라인 마지막 
            Return ""

        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            Throw (New Exception(ex.Message, ex))

            Return ""

        End Try

    End Function
    '-------------------------------------->
    Protected Overridable Function fnMakePrtMsg_DON(ByVal ro_Data As STU_BLDLABEL, ByVal riLeftPos As Integer, ByVal riTopPos As Integer, ByVal riIndex As Integer, ByVal LabelColumnCnt As Integer) As String
        Dim sFn As String = "fnMakePrtMsg_BLD"

        Try

            Dim MM2D As Integer = 8 ' mm to dot
            ' 203 DPI : 1mm = 8 dots
            ' 300 DPI : 1mm = 12 dots
            MM2D = IIf(GetPrinterResolution() < 300, 8, 12)

            Dim nSpeed As Integer = SPEED_50
            Dim nDensity As Integer = Convert.ToInt32("14")
            Dim bAutoCut As Boolean = False
            Dim bReverseFeeding As Boolean = True

            Dim nMarginX As Integer = Convert.ToInt32(Double.Parse("0.5") * MM2D)
            Dim nMarginY As Integer = Convert.ToInt32(Double.Parse("1") * MM2D)

            ' Paper size : 1 inch = 25.4 mm
            ' Default 4x6 inch -> (4*25.4) x (6*25.4) mm
            ' Dim dWidth As Double = 3.7 * 25.4
            ' Dim dHeight As Double = 0.1 * 23
            Dim nPaper_Width As Integer = Convert.ToInt32(Double.Parse("50.0") * MM2D)
            Dim nPaper_Height As Integer = Convert.ToInt32(Double.Parse("40.0") * MM2D)

            Dim nSensorType As Integer = GAP
            Dim iXGap As Integer = 0

            Select Case LabelColumnCnt
                Case 1 : iXGap = 0
                Case 2 : iXGap = Convert.ToInt32(Double.Parse("23.0") * MM2D)
                Case 3 : iXGap = Convert.ToInt32(Double.Parse("47.0") * MM2D)
                Case 4 : iXGap = Convert.ToInt32(Double.Parse("71.0") * MM2D)
            End Select

            ' Set the label start
            StartLabel()

            ' Set Label and Printer
            'SetConfigOfPrinter(SPEED_50, 14, ORIENTATION_TOP, bAutoCut, 0, bReverseFeeding)
            SetConfigOfPrinter(SPEED_60, 8, ORIENTATION_TOP, bAutoCut, 0, bReverseFeeding)

            ' Clear Buffer of Printer 
            ClearBuffer()

            '1 Inch : 25.4mm
            '1 mm   :  8 Dot in 203 DPI such as TX400, T400, D420, D220, SRP-770, SRP-770II
            '1 mm   : 12 Dot in 300 DPI such as TX403, T403, D423, D223
            '4 Inch : 25.4  * 4 * 8 = 812.8
            '6 Inch : 25.4  * 4 * 8 = 1219.2

            'SetPaper(nMarginX, nMarginY, nPaper_Width, nPaper_Height, nSensorType, 0, 16) ' 4
            SetPaper(nMarginX, nMarginY, nPaper_Width, nPaper_Height, nSensorType, 0, 3)

            'Thermal transfer
            PrintDirect("STd")

            If riIndex = 1 Then
                '혈액형코드 바코드
                'LK_PrintBarCode(365, 235, 180, "3", 2, 4, 80, 0, ro_Data.BLDCD)
                'LK_PrintDeviceFont(350, 155, 180, 1, 1, 2, 0, ro_Data.BLDCD)
                'LK_PrintDeviceFont(120, 200, 180, 3, 1, 2, 0, ro_Data.BLD_ABORH)

                'LK_PrintBarCode(365, 120, 180, "3", 2, 4, 80, 0, ro_Data.COMCD)
                'LK_PrintDeviceFont(350, 40, 180, 1, 1, 2, 0, ro_Data.COMCD)
                'LK_PrintDeviceFont(120, 100, 180, 3, 1, 2, 0, ro_Data.COMNM)

                Print1DBarcode(nMarginX + (iXGap + 365), nMarginY + 235, CODE93, 2, 4, 80, ROTATE_180, True, ro_Data.BLDCD)
                PrintDeviceFont(nMarginX + (iXGap + 350), nMarginY + 155, ENG_12X20, 1, 2, ROTATE_180, False, ro_Data.BLDCD)
                PrintDeviceFont(nMarginX + (iXGap + 120), nMarginY + 200, ENG_19X30, 1, 2, ROTATE_180, False, ro_Data.BLD_ABORH)

                Print1DBarcode(nMarginX + (iXGap + 365), nMarginY + 120, CODE93, 2, 4, 80, ROTATE_180, True, ro_Data.COMCD)
                PrintDeviceFont(nMarginX + (iXGap + 350), nMarginY + 40, ENG_12X20, 1, 2, ROTATE_180, False, ro_Data.COMCD)
                PrintDeviceFont(nMarginX + (iXGap + 120), nMarginY + 100, ENG_19X30, 1, 2, ROTATE_180, False, ro_Data.COMNM)

            ElseIf riIndex = 2 Then
                '혈액번호 바코드

                '혈액번호
                'LK_PrintBarCode(365, 210, 180, "3", 2, 4, 80, 0, ro_Data.BLOODNO)
                'LK_PrintWindowsFont(375, 250, 180, 25, 1, 0, 0, "굴림체", sFlBldNo)

                Dim sFlBldNo As String = ro_Data.BLOODNO.Substring(0, 2) + "-" + ro_Data.BLOODNO.Substring(2, 2) + "-" + ro_Data.BLOODNO.Substring(4)

                Print1DBarcode(nMarginX + (iXGap + 365), nMarginY + 210, CODE93, 2, 4, 80, ROTATE_180, True, ro_Data.BLOODNO)
                PrintTrueFontLib(nMarginX + (iXGap + 375), nMarginY + 250, "굴림체", 8, ROTATE_180, False, False, False, sFlBldNo)

                '헌혈구분
                'Dim sDongbn As String = ro_Data.DONGBN
                'LK_PrintWindowsFont(400, 120, 180, 25, 1, 0, 0, "굴림체", sDongbn)

                PrintTrueFontLib(nMarginX + (iXGap + 400), nMarginY + 120, "굴림체", 8, ROTATE_180, False, False, False, ro_Data.DONGBN)

                '수혈자
                'Dim sRcvNm As String = ro_Data.RCVNM
                'LK_PrintWindowsFont(270, 120, 180, 25, 1, 0, 0, "굴림체", "수혈자:")
                'LK_PrintWindowsFont(170, 120, 180, 25, 1, 0, 0, "굴림체", sRcvNm)

                PrintTrueFontLib(nMarginX + (iXGap + 270), nMarginY + 120, "굴림체", 8, ROTATE_180, False, False, False, "수혈자")
                PrintTrueFontLib(nMarginX + (iXGap + 170), nMarginY + 120, "굴림체", 8, ROTATE_180, False, False, False, ro_Data.RCVNM)

                '등록번호
                'LK_PrintWindowsFont(400, 90, 180, 25, 1, 0, 0, "굴림체", ro_Data.REGNO)
                PrintTrueFontLib(nMarginX + (iXGap + 400), nMarginY + 90, "굴림체", 8, ROTATE_180, False, False, False, ro_Data.REGNO)

                '헌혈자명
                'Dim sDonNm As String = ro_Data.PATNM
                'LK_PrintWindowsFont(270, 90, 180, 25, 1, 0, 0, "굴림체", "헌혈자:")
                'LK_PrintWindowsFont(170, 90, 180, 25, 1, 0, 0, "굴림체", sDonNm)

                PrintTrueFontLib(nMarginX + (iXGap + 270), nMarginY + 90, "굴림체", 8, ROTATE_180, False, False, False, "헌혈자")
                PrintTrueFontLib(nMarginX + (iXGap + 170), nMarginY + 90, "굴림체", 8, ROTATE_180, False, False, False, ro_Data.PATNM)

                '헌혈자 성별/나이
                'LK_PrintWindowsFont(70, 90, 180, 25, 1, 0, 0, "굴림체", ro_Data.SEXAGE)
                PrintTrueFontLib(nMarginX + (iXGap + 170), nMarginY + 90, "굴림체", 8, ROTATE_180, False, False, False, ro_Data.PATNM)

                '헌혈일시
                'LK_PrintWindowsFont(400, 60, 180, 25, 1, 0, 0, "굴림체", "헌혈일시:")
                'LK_PrintWindowsFont(275, 60, 180, 25, 1, 0, 0, "굴림체", ro_Data.DONDT)

                PrintTrueFontLib(nMarginX + (iXGap + 400), nMarginY + 60, "굴림체", 8, ROTATE_180, False, False, False, "헌혈일시")
                PrintTrueFontLib(nMarginX + (iXGap + 275), nMarginY + 60, "굴림체", 8, ROTATE_180, False, False, False, ro_Data.DONDT)

                '유효일시
                'LK_PrintWindowsFont(400, 30, 180, 25, 1, 0, 0, "굴림체", "유효일시:")
                'LK_PrintWindowsFont(275, 30, 180, 25, 1, 0, 0, "굴림체", ro_Data.AVILDT)

                PrintTrueFontLib(nMarginX + (iXGap + 400), nMarginY + 30, "굴림체", 8, ROTATE_180, False, False, False, "유효일시")
                PrintTrueFontLib(nMarginX + (iXGap + 275), nMarginY + 30, "굴림체", 8, ROTATE_180, False, False, False, ro_Data.AVILDT)

            Else

                '혈액번호 바코드
                'ro_Data.BLOODNO = "2013083101"
                'LK_PrintBarCode(365, 225, 180, "3", 2, 4, 40, 0, ro_Data.BLOODNO)
                ''Dim sFlBldNo As String = ro_Data.BLOODNO.Substring(0, 2) + "-" + ro_Data.BLOODNO.Substring(2, 2) + "-" + ro_Data.BLOODNO.Substring(4)
                'Dim sFlBldNo As String = "20-13-083102"
                'LK_PrintWindowsFont(375, 250, 180, 18, 1, 0, 0, "굴림체", sFlBldNo)

                Dim sFlBldNo As String = ro_Data.BLOODNO.Substring(0, 2) + "-" + ro_Data.BLOODNO.Substring(2, 2) + "-" + ro_Data.BLOODNO.Substring(4)

                Print1DBarcode(nMarginX + (iXGap + 365), nMarginY + 225, CODE93, 2, 4, 80, ROTATE_180, True, ro_Data.BLOODNO)
                PrintTrueFontLib(nMarginX + (iXGap + 375), nMarginY + 250, "굴림체", 8, ROTATE_180, False, False, False, sFlBldNo)

                ''Dim sDongbn As String = ro_Data.DONGBN
                'Dim sDongbn As String = "지정"
                'LK_PrintWindowsFont(350, 180, 180, 20, 1, 0, 0, "굴림체", sDongbn)

                PrintTrueFontLib(nMarginX + (iXGap + 350), nMarginY + 180, "굴림체", 8, ROTATE_180, False, False, False, ro_Data.DONGBN)

                ''Dim sRcvNm As String = ro_Data.RCVNM
                'Dim sRcvNm As String = "김민아"
                'LK_PrintWindowsFont(240, 180, 180, 20, 1, 0, 0, "굴림체", "수혈자 : ")
                'LK_PrintWindowsFont(140, 180, 180, 20, 1, 0, 0, "굴림체", sRcvNm)

                PrintTrueFontLib(nMarginX + (iXGap + 240), nMarginY + 180, "굴림체", 8, ROTATE_180, False, False, False, "수혈자")
                PrintTrueFontLib(nMarginX + (iXGap + 140), nMarginY + 180, "굴림체", 8, ROTATE_180, False, False, False, ro_Data.RCVNM)

                '혈액형코드 바코드
                'LK_PrintBarCode(365, 150, 180, "3", 2, 4, 40, 0, ro_Data.BLDCD)
                'LK_PrintWindowsFont(350, 105, 180, 20, 1, 0, 0, "굴림체", ro_Data.BLDCD)
                'LK_PrintDeviceFont(140, 150, 180, 3, 1, 2, 0, ro_Data.BLD_ABORH)

                Print1DBarcode(nMarginX + (iXGap + 365), nMarginY + 150, CODE93, 2, 4, 80, ROTATE_180, True, ro_Data.BLDCD)
                PrintTrueFontLib(nMarginX + (iXGap + 350), nMarginY + 105, "굴림체", 8, ROTATE_180, False, False, False, ro_Data.BLDCD)
                PrintDeviceFont(nMarginX + (iXGap + 140), nMarginY + 150, ENG_19X30, 1, 2, ROTATE_180, False, ro_Data.BLD_ABORH)

                '성분제제코드 바코드
                'LK_PrintBarCode(365, 80, 180, "3", 2, 4, 40, 0, ro_Data.COMCD)
                'LK_PrintWindowsFont(350, 35, 180, 20, 1, 0, 0, "굴림체", ro_Data.COMCD)
                'LK_PrintDeviceFont(140, 80, 180, 3, 1, 2, 0, ro_Data.COMNM)

                Print1DBarcode(nMarginX + (iXGap + 365), nMarginY + 80, CODE93, 2, 4, 80, ROTATE_180, True, ro_Data.COMCD)
                PrintTrueFontLib(nMarginX + (iXGap + 350), nMarginY + 35, "굴림체", 8, ROTATE_180, False, False, False, ro_Data.COMCD)
                PrintDeviceFont(nMarginX + (iXGap + 140), nMarginY + 80, ENG_19X30, 1, 2, ROTATE_180, False, ro_Data.COMNM)

            End If


            Return ""

        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            Throw (New Exception(ex.Message, ex))

            Return ""

        End Try

    End Function

End Class
