﻿Imports COMMON.CommFN

Public Class COMM
    Private Const mcFile$ = "File : COMM.vb, Class : COMM" + vbTab

    'Public Sub sbSendComm(ByVal rsSendMsg As String, ByVal iComport As String)
    Public Sub sbSendComm(ByVal rsSendMsg As String, ByVal iComport As Integer)
        '20200109 nbm
        Dim sFn As String = ""

        Try
            ''msComm.Settings = "9600,n,8,1" '상호 주석 해지 20130914
            ''msComm.CommPort = iComport '상호 추가 20130505
            ''msComm.PortOpen = True
            ''msComm.Output = rsSendMsg
            ''msComm.PortOpen = False

            Dim btSendMsg() As Byte = System.Text.Encoding.Default.GetBytes(rsSendMsg)

            With mSerial
                .PortName = "COM" + iComport.ToString()
                '.PortName = "COM" + iComport
                .BaudRate = "9600"
                .DataBits = "8"
                .Parity = IO.Ports.Parity.None
                .StopBits = IO.Ports.StopBits.One


                If .IsOpen = False Then .Open()
                '.Write(rsSendMsg)

                .Write(btSendMsg, 0, btSendMsg.Length)
                '.DiscardOutBuffer()
                mSerial.Close()
            End With

        Catch ex As Exception
            CommFN.COMMON_FN.log(mcFile + sFn, Err)

        Finally
            mSerial.Close()

        End Try
    End Sub
End Class