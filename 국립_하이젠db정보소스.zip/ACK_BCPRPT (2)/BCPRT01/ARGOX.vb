Imports COMMON.SVar
Imports COMMON.CommFN
Imports COMMON.CommFN.Fn
Imports COMMON.CommLogin.LOGIN
Imports COMMON.CommPrint

Public Class ARGOX
    Private Const mcFile$ = "File : ARGOX.vb, Class : ARGOX" + vbTab

    Public Overridable Function BarCodePrtOut(ByVal ra_PrtData As ArrayList, _
                                              ByVal rsPrintPort As String, ByVal rsSocketIP As String, ByVal rbFirst As Boolean, _
                                              Optional ByVal riLeftPos As Integer = 0, _
                                              Optional ByVal riTopPos As Integer = 0, _
                                              Optional ByVal rsBarType As String = "CODABAR", Optional ByVal rsUseSide As String = "C") As Boolean

        Dim sFn As String = "BarCodePrtOut"
        Dim bReturn As Boolean = False
        Dim iFileNo As Integer = 0
        Dim sPrtMsg = ""
        '<��ȣ �߰� 20130914
        Dim msComm As New COMM '��ȣ �߰� 20130914
        Dim i As Integer = 0
        Dim sBuf As String = ""

        '>
        'MsgBox(ra_PrtData.Count) 'nbm
        '  MsgBox(ra_PrtData)
        ' MsgBox("����") 'nbm
        Try
            For ix1 As Integer = 0 To ra_PrtData.Count - 1

                ' MsgBox("����1") 'nbm

                If CType(ra_PrtData(ix1), STU_BCPRTINFO).REGNO <> "" Then
                    MsgBox("regno�� ���� �� ���� ����, ���ڵ� ���� function ����")

                    sPrtMsg = fnMakePrtMsg(CType(ra_PrtData(ix1), STU_BCPRTINFO), rbFirst, riLeftPos, riTopPos, rsBarType)
                    MsgBox("���ڵ� ���� function ����")
                    Dim iPrtCnt As Integer = 1


                    If sPrtMsg <> "" Then
                        iPrtCnt = 1
                        'iPrtCnt = CType(CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT, Integer)
                        If CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT = "A" Then
                            iPrtCnt = 2



                        ElseIf CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT = "B" Then
                            '< CrossMatching ��ü
                            iPrtCnt = 2



                        ElseIf IsNumeric(CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT) Then
                            iPrtCnt = CType(CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT, Integer)

                        Else
                            '        MsgBox("������ ã���ÿ�") 'nbm
                            '     MsgBox("�������� �����ϴ�.") 'nbm
                            Return False
                        End If

                        '    MsgBox("��� ���") 'nbm
                        '    MsgBox(iPrtCnt) 'nbm

                        For ix2 As Integer = 1 To iPrtCnt
                            If rsPrintPort.Trim() = "" Then
                                '      MsgBox("��Ʈ�� ���� ��") 'nbm
                                Dim objSkt As New SendSocket

                                objSkt.sbConnectCliSocketToSvrSocket(rsSocketIP, 13734)

                                If objSkt.fnSendMsgOneConn("ITM", sPrtMsg) Then
                                    bReturn = True
                                End If

                                objSkt.sbDispose()

                                Dim sFileNm As String = Application.StartupPath + "\BCPRT.TXT"

                                iFileNo = FreeFile()

                                Try
                                    ' MsgBox(iFileNo, sFileNm)

                                    FileOpen(iFileNo, sFileNm, OpenMode.Output)

                                Catch ex As Exception
                                    sFileNm = Application.StartupPath + "\BCPRT_" + Format(Now, "yyMMddHHmmss") + ".TXT"
                                    FileOpen(iFileNo, sFileNm, OpenMode.Output)
                                End Try



                                Print(iFileNo, sPrtMsg)
                                FileClose(iFileNo)


                                Dim iComport As Integer = CInt(rsPrintPort.Substring(Len(rsPrintPort) - 1))

                                msComm.sbSendComm(sPrtMsg, iComport)
                            Else
                                '   MsgBox("��Ʈ�� �ξƴ� ��") 'nbm

                                Dim strFileNm As String = Application.StartupPath + "\BCPRT.TXT"

                                iFileNo = FreeFile()

                                Try
                                    FileOpen(iFileNo, strFileNm, OpenMode.Output)

                                Catch ex As Exception
                                    strFileNm = Application.StartupPath + "\BCPRT_" + Format(Now, "yyMMddHHmmss") + ".TXT"
                                    FileOpen(iFileNo, strFileNm, OpenMode.Output)
                                End Try

                                Print(iFileNo, sPrtMsg)
                                FileClose(iFileNo)

                                Dim iComport As String = rsPrintPort.Substring(Len(rsPrintPort) - 1)
                                ' Dim iComport  = CInt(rsPrintPort.Substring(Len(rsPrintPort) - 1))

                                'msComm.sbSendComm(sPrtMsg, iComport)
                                PRTAPI.SendFileToPrinter(rsPrintPort, strFileNm)
                            End If

                            ''<Sleep ��� �Ʒ� �������� ���� 20130914
                            'Do
                            '    If sPrtMsg.Count > 0 Then
                            '        i = 1

                            '        sBuf = sPrtMsg.Item(i)

                            '        sPrtMsg.Remove(i)

                            '        Me.lstBcPrt.RemoveItem(i - 1)

                            '        MSCommLib. = sBuf

                            '        sbLog("Print", True, 0)

                            '        '< add freety 2009/09/17 : ���۹����ΰ����� �����Ǿ� �����Ͱ� ��� ���۵� ���� ��ٸ����� ��ġ
                            '        Do
                            '            DoEvents()
                            '        Loop Until Me.mscommBc.OutBufferCount = 0

                            '        sBuf = ""
                            '        '>
                            '    Else
                            '        'tmrBcPrt.Enabled = False

                            '        Exit Do
                            '    End If
                            'Loop
                            ''>

                            'Threading.Thread.Sleep(CInt(sPrtMsg.Length * 1.5)) '��ȣ �ּ� 20130914
                            Threading.Thread.Sleep(500) '��ȣ �ּ� 20130914
                        Next
                    End If

                End If
            Next

            Return True
        Catch ex As Exception
            CommFN.COMMON_FN.log(mcFile + sFn, Err)
            MsgBox(mcFile + sFn + vbCrLf + ex.Message)
            Return False
        Finally
            FileClose(iFileNo)

        End Try
    End Function

    Protected Overridable Function fnMakePrtMsg(ByVal ro_Data As STU_BCPRTINFO, _
                                                ByVal rbFirst As Boolean, _
                                                ByVal riLeftPos As Integer, ByVal riTopPos As Integer, _
                                                ByVal rsBarType As String) As String
        Dim sFn As String = "fnMakePrtMsg"
        ' MsgBox("������")
        Try
            riTopPos += 10

            'ro_Data.INFINFO = "S/MRSA"
            Dim a_sInfInfo As String() = ro_Data.INFINFO.Split("/"c)
            Dim sTestNms As String = ro_Data.TESTNMS
            Dim sLine1 As String = ""
            Dim sLine2 As String = ""

            If ro_Data.TESTNMS.Length < 31 Then
                sLine1 = sTestNms

            Else
                sLine1 = sTestNms.Substring(0, 30)

                'If ro_Data.TESTNMS.Length > 50 Then

                '    sLine2 = sTestNms.Substring(30, 23) + "..."
                'Else
                '    sLine2 = sTestNms.Substring(30, ro_Data.TESTNMS.Length - 30)
                'End If

            End If
            Dim sPrtBuf As String = "", sIOGbn As String = ""
            Dim iXposS As Integer = 0, iYposS As Integer = 0

            sPrtBuf = ""
            sPrtBuf += "N" + vbCrLf
            sPrtBuf += "I8,1,001" + vbCrLf
            sPrtBuf += "JF" + vbCrLf       '-- FB
            sPrtBuf += "D" + vbCrLf        '-- ���� = OD, ���� = D
            sPrtBuf += "D8" + vbCrLf       '-- ��
            sPrtBuf += "S4" + vbCrLf       '-- speed
            sPrtBuf += "Q288,24" + vbCrLf  '-- Label Length, Gap Length
            sPrtBuf += "q440" + vbCrLf     '-- Label(Width)
            sPrtBuf += "ZT" + vbCrLf



            If ro_Data.BCCLSCD = PRG_CONST.BCCLS_BldCrossMatch Or ro_Data.BCCNT = "B" Then
                '< ���� 
                sPrtBuf += "A" + (100 + riLeftPos).ToString + "," + (riTopPos + 200).ToString + ",0,3,1,1,N," & Chr(34) & ro_Data.TUBENM & Chr(34) & vbCrLf
                '< ä����
                sPrtBuf += "A" + (200 + riLeftPos).ToString + "," + (riTopPos + 200).ToString + ",0,9,1,1,N," + Chr(34) & "ä����: " & Chr(34) + vbCrLf
                '< Ȯ����
                sPrtBuf += "A" + (200 + riLeftPos).ToString + "," + (riTopPos + 230).ToString + ",0,9,1,1,N," + Chr(34) & "Ȯ����: " & Chr(34) + vbCrLf
                '< ����
                sPrtBuf += "A" + (6 + riLeftPos).ToString + "," + (riTopPos + 230).ToString + ",0,2,1,1,R," + Chr(34) & "  X-Matching  " & Chr(34) + vbCrLf

            Else
                If ro_Data.BCTYPE = "M" Then
                    '< ��ü��ȣ 
                    sPrtBuf += "A" + (10 + riLeftPos).ToString + "," + (riTopPos + 5).ToString + ",0,1,1,1,N," & Chr(34) & ro_Data.BCNO & Chr(34) & vbCrLf

                    '< ��ü�� 
                    sPrtBuf += "A" + (195 + riLeftPos).ToString + "," + (riTopPos + 5).ToString + ",0,1,1,1,N," & Chr(34) & ro_Data.SPCNM & Chr(34) & vbCrLf
                    '< ������
                    'ro_Data.TGRPNM = "aq"
                    sPrtBuf += "A" + (300 + riLeftPos).ToString + "," + (riTopPos + 5).ToString + ",0,1,1,1,N," & Chr(34) & ro_Data.TGRPNM & Chr(34) & vbCrLf

                    '< �۾���ȣ
                    sPrtBuf += "A" + (20 + riLeftPos).ToString + "," + (riTopPos + 25).ToString + ",0,1,1,1,N," & Chr(34) & ro_Data.BCNO_MB & Chr(34) & vbCrLf
                    ''< ��Ϲ�ȣ sPID
                    'ro_Data.OBFTSYN = "Y"
                    sPrtBuf += "A" + (190 + riLeftPos).ToString + "," + (riTopPos + 25).ToString + ",0,1,1,1,N," & Chr(34) & ro_Data.REGNO & Chr(34) & vbCrLf
                    '< ����/���� 
                    sPrtBuf += "A" + (320 + riLeftPos).ToString + "," + (riTopPos + 25).ToString + ",0,1,1,1,N," & Chr(34) & ro_Data.SEXAGE & Chr(34) & vbCrLf
                    '���ڵ�
                    sPrtBuf += "B" + (45 + riLeftPos).ToString + "," + (riTopPos + 40).ToString + ",0,3,2,4,30,N," & Chr(34) & ro_Data.BCNOPRT & Chr(34) & vbCrLf

                Else
                    '< ��Ϲ�ȣ sPID
                    'ro_Data.OBFTSYN = "Y"
                    sPrtBuf += "A" + (420 + riLeftPos).ToString + "," + (riTopPos + 98).ToString + ",2,2,1,2," & IIf(ro_Data.OBFTSYN = "Y", "R", "N").ToString() & "," & Chr(34) & ro_Data.REGNO & Chr(34) & vbCrLf

                    '< �����/����/����  
                    sPrtBuf += "A" + (220 + riLeftPos).ToString + "," + (riTopPos + 120).ToString + ",2,2,1,1,N," & Chr(34) & ro_Data.DEPTWARD & Chr(34) & vbCrLf

                    '< ����/���� 
                    sPrtBuf += "A" + (120 + riLeftPos).ToString + "," + (riTopPos + 98).ToString + ",2,2,1,1,N," & Chr(34) & ro_Data.SEXAGE & Chr(34) & vbCrLf

                    Dim sPatnm As String = ro_Data.PATNM
                    '< ȯ�ڸ� 
                    sPrtBuf += "A" + (260 + riLeftPos).ToString + "," + (riTopPos + 98).ToString + ",2,9,1,1,N," + Chr(34) + sPatnm + Chr(34) + vbCrLf

                    '< sRemark
                    'ro_Data.REMARK = "C"
                    sPrtBuf += "A" + (430 + riLeftPos).ToString + "," + (riTopPos + 200).ToString + ",2,4,1,1,N," & Chr(34) & IIf(ro_Data.REMARK <> "", "C", "").ToString & Chr(34) & vbCrLf


                    '< ��ü��
                    Dim sSize As String = "2"
                    'For iLen As Integer = 0 To ro_Data.SPCNM.Length - 1
                    '    If Char.GetUnicodeCategory(ro_Data.SPCNM.Substring(iLen, 1)) = Globalization.UnicodeCategory.OtherLetter Then
                    '        sSize = "10"
                    '        Exit For
                    '    End If
                    'Next
                    'sPrtBuf += "A" + (200 + riLeftPos).ToString + "," + (riTopPos + 190).ToString + ",0," + sSize + ",1,2,N," & Chr(34) & ro_Data.SPCNM & Chr(34) & vbCrLf

                    '< ���� 
                    sSize = "2"
                    For iLen As Integer = 0 To ro_Data.TUBENM.Length - 1
                        If Char.GetUnicodeCategory(ro_Data.TUBENM.Substring(iLen, 1)) = Globalization.UnicodeCategory.OtherLetter Then
                            sSize = "9"
                            Exit For
                        End If
                    Next
                    sPrtBuf += "A" + (420 + riLeftPos).ToString + "," + (riTopPos + 63).ToString + ",2," & sSize & ",1,1,N," & Chr(34) & ro_Data.TUBENM + " " + ro_Data.SPCNM & Chr(34) & vbCrLf

                    '< �˻�׷�
                    'ro_Data.TGRPNM = "aq"
                    sPrtBuf += "A" + (380 + riLeftPos).ToString + "," + (riTopPos + 25).ToString + ",2,3,1,1,N," & Chr(34) & ro_Data.TGRPNM & Chr(34) & vbCrLf

                    '< ���ް� ������ ���� sEmer 
                    'ro_Data.URGENT = "Y"
                    'ro_Data.EMER = "Y"
                    If ro_Data.URGENT.Equals("Y") Then
                        Dim sE As String = ro_Data.URGENT
                        If sE = "Y" Then
                            sE = "E"
                        End If

                        sPrtBuf += "A" + (430 + riLeftPos).ToString + "," + (riTopPos + 170).ToString + ",2,2,1,1,R," & Chr(34) & sE & Chr(34) & Chr(13) & vbCrLf

                    ElseIf ro_Data.EMER.Equals("Y") Or ro_Data.EMER.Equals("E") Then
                        Dim sE As String = ro_Data.EMER
                        If sE = "Y" Then
                            sE = "E"
                        End If

                        sPrtBuf += "A" + (430 + riLeftPos).ToString + "," + (riTopPos + 170).ToString + " ,2,2,1,1,N," & Chr(34) & sE & Chr(34) & Chr(13) & vbCrLf
                    End If

                    '< �˻��׸�� 
                    sPrtBuf += "A" + (380 + riLeftPos).ToString + "," + (riTopPos + 45).ToString + ",2,2,1,1,N," + Chr(34) + sLine1 + Chr(34) + vbCrLf


                    '< �� sKind
                    sPrtBuf += "A" + (420 + riLeftPos).ToString + "," + (riTopPos + 45).ToString + ",2,4,1,1,N," & Chr(34) & ro_Data.BCCLSCD & Chr(34) & Chr(13) & vbCrLf

                    '< ��ü��ȣ 
                    sPrtBuf += "A" + (420 + riLeftPos).ToString + "," + (riTopPos + 253).ToString + ",2,1,1,2,N," & Chr(34) & ro_Data.BCNO & Chr(34) & vbCrLf

                    '< �˻���
                    sPrtBuf += "A" + (300 + riLeftPos).ToString + "," + (riTopPos + 0).ToString + ",0,1,1,2,N," & Chr(34) & ro_Data.METHODCD & Chr(34) & vbCrLf

                    '< ���ڵ� ���� �Ͻ�  
                    sPrtBuf += "A" + (90 + riLeftPos).ToString + "," + (riTopPos + 253).ToString + ",2,1,1,1," & IIf(rbFirst, "N", "R").ToString() & "," & Chr(34) & Fn.GetServerDateTime.ToString("HH:mm") & Chr(34) & vbCrLf

                    '< ��������  
                    For iCnt As Integer = 0 To a_sInfInfo.Length - 1
                        If iCnt > 1 Then Exit For
                        sPrtBuf += "A" + (60 + riLeftPos).ToString + "," + (riTopPos + 170 + (iCnt * 30)).ToString + ",2,3,2,1,N," & Chr(34) & a_sInfInfo(iCnt).ToString() & Chr(34) & vbCrLf
                    Next

                    '< ���ڵ�  
                    If ro_Data.BCNOPRT <> "" Then
                        ' CODE 3 OF 9  
                        sPrtBuf += "B" + (405 + riLeftPos).ToString + "," + (riTopPos + 225).ToString + ",2,3,2,4,100,N," & Chr(34) & ro_Data.BCNOPRT & Chr(34) & vbCrLf

                        '< ���ڵ� ��ȣ
                        sPrtBuf += "A" + (405 + riLeftPos).ToString + "," + (riTopPos + 120).ToString + ",2,2,1,1,N," & Chr(34) & ro_Data.BCNOPRT & Chr(34) & vbCrLf
                    Else
                        '< �̼��� ���ڵ� 
                        sPrtBuf += "A" + (365 + riLeftPos).ToString + "," + (riTopPos + 200).ToString + ",2,9,2,2,N," & Chr(34) & "��ä�����ڵ�" & Chr(34) & vbCrLf
                        '>  
                    End If
                End If
            End If



            '< ���� ������ 
            sPrtBuf += "P1" + vbLf

            Return sPrtBuf

        Catch ex As Exception
            Fn.log(mcFile + sFn, Err)
            MsgBox(mcFile + sFn + vbCrLf + ex.Message)

            Return ""

        End Try

    End Function

    Protected Overridable Function fnStartMsg() As String
        Dim sFn As String = "fnMakePrtMsg"

        Try
            Dim sPrtBuf As String = ""

            'sPrtBuf = ""
            'sPrtBuf +=  "I8,1,001" + vbCrLf
            'sPrtBuf +=  "D" + vbCrLf        '-- ���� = OD, ���� = D
            'sPrtBuf +=  "Q256,24" + vbCrLf  '-- Label Length, Gap Length
            'sPrtBuf +=  "q440" + vbCrLf     '-- Label(Width)
            'sPrtBuf +=  "S4" + vbCrLf       '-- speed
            'sPrtBuf +=  "D8" + vbCrLf       '-- ��
            'sPrtBuf +=  "ZT" + vbCrLf
            'sPrtBuf +=  "JF" + vbCrLf       '-- FB

            sPrtBuf = ""
            sPrtBuf += "N" + vbCrLf
            sPrtBuf += "I8,1,001" + vbCrLf
            sPrtBuf += "D" + vbCrLf        '-- ���� = OD, ���� = D
            sPrtBuf += "D8" + vbCrLf       '-- ��
            sPrtBuf += "S4" + vbCrLf       '-- speed
            sPrtBuf += "Q256,24" + vbCrLf  '-- Label Length, Gap Length
            sPrtBuf += "q440" + vbCrLf     '-- Label(Width)
            sPrtBuf += "ZT" + vbCrLf
            sPrtBuf += "JF" + vbCrLf       '-- FB

            Return sPrtBuf

        Catch ex As Exception
            Fn.log(mcFile + sFn, Err)
            MsgBox(mcFile + sFn + vbCrLf + ex.Message)

            Return ""

        End Try
    End Function

    Public Sub PrintStart(Optional ByVal asOUTPUT As String = "", Optional ByVal asIP As String = "")
        Dim sFn As String = "PrintStart"
        Dim bReturn As Boolean = False
        Dim iFileNo As Integer = 0

        Try
            Dim sPrtMsg As String = fnStartMsg()

            If asOUTPUT.Trim() = "" Then
                Dim objSkt As New TCP01.SendSocket

                objSkt.sbConnectCliSocketToSvrSocket(asIP, 13734)
                If objSkt.fnSendMsgOneConn("ITM", sPrtMsg) Then
                    bReturn = True
                End If
                objSkt.sbDispose()
            Else

                Dim objBarPrt As New BarPrtParams
                Dim blnTcpIP As Boolean = False
                objBarPrt = (New BCPRT01.Print_Set).fnGet_PrinterParams_Shared(asOUTPUT.Trim(), blnTcpIP)

                Dim strFileNm As String = "C:\BCPRT.TXT"

                If objBarPrt Is Nothing Then
                    iFileNo = FreeFile()
                    Try
                        FileOpen(iFileNo, strFileNm, OpenMode.Output)

                    Catch ex As Exception
                        strFileNm = "C:\BCPRT_" + Format(Now, "yyMMddHHmmss") + ".TXT"
                        FileOpen(iFileNo, strFileNm, OpenMode.Output)
                    End Try

                    Print(iFileNo, sPrtMsg)
                    FileClose(iFileNo)

                    Process.Start("cmd.exe", "/C TYPE " + strFileNm + " > " + asOUTPUT.Trim())
                Else
                    If objBarPrt.PrinterName.StartsWith("\\") Or blnTcpIP Then
                        Dim objSkt As New TCP01.SendSocket

                        objSkt.sbConnectCliSocketToSvrSocket(asIP, 13734)
                        If objSkt.fnSendMsgOneConn("ITM", sPrtMsg) Then
                            bReturn = True
                        End If
                        objSkt.sbDispose()
                    Else
                        iFileNo = FreeFile()
                        Try
                            FileOpen(iFileNo, strFileNm, OpenMode.Output)

                        Catch ex As Exception
                            strFileNm = "C:\BCPRT_" + Format(Now, "yyMMddHHmmss") + ".TXT"
                            FileOpen(iFileNo, strFileNm, OpenMode.Output)
                        End Try

                        Print(iFileNo, sPrtMsg)
                        FileClose(iFileNo)

                        Process.Start("cmd.exe", "/C TYPE " + strFileNm + " > " & objBarPrt.PrinterPort.Replace(":", ""))
                    End If
                End If

            End If

        Catch ioex As System.IO.IOException
        Catch ex As Exception
            Fn.log(mcFile + sFn, Err)
            MsgBox(mcFile + sFn + vbCrLf + ex.Message)
        Finally
            FileClose(iFileNo)
        End Try
    End Sub
End Class

'Public Class ARGOX2
'    Inherits ARGOX

'    Private Const mcFile$ = "File : ARGOX.vb, Class : ARGOX2" + vbTab

'    Protected Overrides Function fnMakePrtMsg(ByVal asBuf$, ByVal aiCnt%) As String
'        Dim sFn$ = "fnMakePrtMsg"

'        Try
'            Dim sBarCode$ = "", sPID$ = "", sPName$ = "", sSex$ = "", sKind$ = ""
'            Dim sDept$ = "", sSpcNo$ = "", sSpcNm$ = "", sTubeNm$ = "", sComment$ = ""
'            Dim sPrtBuf$ = ""
'            Dim iXposS% = 0, iYposS% = 0

'            sBarCode = SubstringH(asBuf, 2, 11).Trim    '���ڵ��ȣ(�����(4)+����(2)+SEQ1(4)+SEQ2(1)
'            sPID = SubstringH(asBuf, 14, 8)             '��Ϲ�ȣ
'            sPName = SubstringH(asBuf, 23, 20)          'ȯ���̸�
'            sSex = SubstringH(asBuf, 44, 5)             '����(M/F)/����
'            sKind = SubstringH(asBuf, 50, 2)            '����(��+�˻��)
'            sDept = SubstringH(asBuf, 53, 8)            '�����/����
'            sSpcNo = SubstringH(asBuf, 73, 18)          '��ü��ȣ
'            sSpcNm = SubstringH(asBuf, 103, 5)          '��ü��(5)
'            sTubeNm = "/" + SubstringH(asBuf, 109, 8)   '"/"+����(8)
'            sComment = SubstringH(asBuf, 135, 50)       '������ comment

'            'X Position Of Start ����
'            iXposS = -100
'            'Y Position Of Start ����
'            iYposS = 30

'            'Clear Image
'            sPrtBuf += "N" + vbCrLf
'            'FB
'            sPrtBuf += "JF" + vbCrLf
'            'Direct Thermal, Cutter -- ���� = OD, ���� = D
'            sPrtBuf += "O" + "D" + vbCrLf
'            'sPrtBuf += "O" + "D,C" + vbCrLf
'            '��
'            sPrtBuf += "D10" + vbCrLf
'            'Speed
'            sPrtBuf += "S" + "6" + vbCrLf
'            'Label Length, Gap Length
'            sPrtBuf += "Q400,24" + vbCrLf
'            'Label(Width)
'            sPrtBuf += "q400" + vbCrLf
'            'Barcode
'            sPrtBuf += "B" + (iXposS + 160).ToString + "," + (iYposS + 30).ToString + ",0,K,2,5,110,N," + Chr(34) + "A" + sBarCode + "A" + Chr(34) + Chr(10)
'            '���ڵ��ȣ
'            sPrtBuf += "A" + (iXposS + 225).ToString + "," + (iYposS + 145).ToString + ",0,2,1,1,N," + Chr(34) + "A" + sBarCode + "A" + Chr(34) + Chr(10)
'            '��ü��ȣ   �˻��
'            sPrtBuf += "A" + (iXposS + 120).ToString + "," + (iYposS + 165).ToString + ",0,4,1,1,N," + Chr(34) + sSpcNo + Space(1) + sKind + Chr(34) + Chr(10)
'            '��Ϲ�ȣ
'            sPrtBuf += "A" + (iXposS + 120).ToString + "," + (iYposS + 193).ToString + ",0,4,1,1,N," + Chr(34) + sPID + Chr(34) + Chr(10)
'            'ȯ�ڸ�
'            sPrtBuf += "A" + (iXposS + 270).ToString + "," + (iYposS + 193).ToString + ",0,9,1,1,N," + Chr(34) + sPName + Chr(34) + Chr(10)
'            '����/����
'            sPrtBuf += "A" + (iXposS + 425).ToString + "," + (iYposS + 193).ToString + ",0,4,1,1,N," + Chr(34) + sSex + Chr(34) + Chr(10)
'            '��ü��
'            If LengthH(sSpcNm) = Len(sSpcNm) Then
'                sPrtBuf += "A" + (iXposS + 120).ToString + "," + (iYposS + 221).ToString + ",0,4,1,1,N," + Chr(34) + sSpcNm + Chr(34) + Chr(10)
'            Else
'                sPrtBuf += "A" + (iXposS + 120).ToString + "," + (iYposS + 221).ToString + ",0,9,1,1,N," + Chr(34) + sSpcNm + Chr(34) + Chr(10)
'            End If
'            '���
'            sPrtBuf += "A" + (iXposS + 210).ToString + "," + (iYposS + 221).ToString + ",0,4,1,1,N," + Chr(34) + sTubeNm + Chr(34) + Chr(10)
'            '�����/����
'            If LengthH(sSpcNm) = Len(sSpcNm) Then
'                sPrtBuf += "A" + (iXposS + 375).ToString + "," + (iYposS + 221).ToString + ",0,4,1,1,N," + Chr(34) + sDept + Chr(34) + Chr(10)
'            Else
'                sPrtBuf += "A" + (iXposS + 375).ToString + "," + (iYposS + 221).ToString + ",0,9,1,1,N," + Chr(34) + sDept + Chr(34) + Chr(10)
'            End If
'            '�˻��׸�
'            sPrtBuf += "A" + (iXposS + 120).ToString + "," + (iYposS + 249).ToString + ",0,2,1,1,N," + Chr(34) + sComment + Chr(34) + Chr(10)

'            '�׻� 2���� ��µǵ��� ��
'            'sPrtBuf += "P" + "1," + aiCnt.ToString + Chr(10)
'            sPrtBuf += "P" + "1," + 2.ToString + Chr(10)

'            Return sPrtBuf
'        Catch ex As Exception
'            Fn.log(mcFile + sFn, Err)
'            MsgBox(mcFile + sFn + vbCrLf + ex.Message)
'        End Try
'    End Function
'End Class