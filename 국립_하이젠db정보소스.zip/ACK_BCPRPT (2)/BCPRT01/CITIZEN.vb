﻿Imports COMMON.SVar
Imports COMMON.CommFN
Imports COMMON.CommFN.Fn
Imports COMMON.CommPrint
Imports COMMON.CommLogin.LOGIN
Imports System.Windows.Forms.Form

Public Class CITIZEN
    Private Const mcFile$ = "File : CITIZEN.vb, Class : CITIZEN" + vbTab

    Public Overridable Function BarCodePrtOut(ByVal ra_PrtData As ArrayList, _
                                              ByVal rsPrintPort As String, ByVal rsSocketIP As String, ByVal rbFirst As Boolean, _
                                              Optional ByVal riLeftPos As Integer = 0, _
                                              Optional ByVal riTopPos As Integer = 0, _
                                              Optional ByVal rsBarType As String = "CODABAR", Optional ByVal rsUseSide As String = "C") As Boolean
        Dim sFn As String = "BarCodePrtOut"
        Dim bReturn As Boolean = False
        Dim iFileNo As Integer = 0
        Dim sPrtMsg = ""
        Dim sPrtBuf As String = ""

        Try
            For ix1 As Integer = 0 To ra_PrtData.Count - 1
                If CType(ra_PrtData(ix1), STU_BCPRTINFO).REGNO <> "" Then

                    'If rsUseSide = "C" Then

                    sPrtMsg = fnMakePrtMsg(CType(ra_PrtData(ix1), STU_BCPRTINFO), rbFirst, riLeftPos, riTopPos, rsBarType, rsPrintPort)
                    'ElseIf rsUseSide = "L" Then
                    ' sPrtMsg = fnMakePrtMsgLeft(CType(ra_PrtData(ix1), STU_BCPRTINFO), rbFirst, riLeftPos, riTopPos, rsBarType)

                    'Else
                    'sPrtMsg = fnMakePrtMsgRight(CType(ra_PrtData(ix1), STU_BCPRTINFO), rbFirst, riLeftPos, riTopPos, rsBarType)
                    'End If

                    Dim iPrtCnt As Integer = 1

                    If sPrtMsg <> "" Then
                        If CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT = "A" Then
                            iPrtCnt = 2
                        ElseIf CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT = "B" Then
                            '< CrossMatching 검체
                            iPrtCnt = 2
                        ElseIf IsNumeric(CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT) Then
                            iPrtCnt = Convert.ToInt32(CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT)
                        End If



                        For ix2 As Integer = 1 To iPrtCnt
                            If rsPrintPort.Trim() = "" Then
                                Dim objSkt As New TCP01.SendSocket

                                objSkt.sbConnectCliSocketToSvrSocket(rsSocketIP, 13734)

                                If objSkt.fnSendMsgOneConn("ITM", sPrtMsg) Then
                                    bReturn = True
                                End If

                                objSkt.sbDispose()

                                Dim sFileNm As String = Application.StartupPath + "\BCPRT.TXT"

                                iFileNo = FreeFile()
                                Try
                                    FileOpen(iFileNo, sFileNm, OpenMode.Output)

                                Catch ex As Exception
                                    sFileNm = Application.StartupPath + "\BCPRT_" + Format(Now, "yyMMddHHmmss") + ".TXT"
                                    FileOpen(iFileNo, sFileNm, OpenMode.Output)
                                End Try

                                Print(iFileNo, sPrtMsg)
                                FileClose(iFileNo)

                                Dim msComm As New COMM
                                'msComm.sbSendComm(sPrtMsg) '상호 주석 20130505
                                '<상호 수정 20130505
                                Dim iComport = CInt(rsPrintPort.Substring(Len(rsPrintPort) - 1))
                                msComm.sbSendComm(sPrtMsg, iComport)
                            Else

                                Dim strFileNm As String = Application.StartupPath + "\BCPRT.TXT"

                                iFileNo = FreeFile()
                                Try
                                    FileOpen(iFileNo, strFileNm, OpenMode.Output)

                                Catch ex As Exception
                                    strFileNm = Application.StartupPath + "\BCPRT_" + Format(Now, "yyMMddHHmmss") + ".TXT"
                                    FileOpen(iFileNo, strFileNm, OpenMode.Output)
                                End Try

                                Print(iFileNo, sPrtMsg)
                                FileClose(iFileNo)

                                Dim msComm As New COMM
                                'msComm.sbSendComm(sPrtMsg) '상호 주석 20130505
                                '<상호 수정 20130505
                                'Dim iComport = CInt(rsPrintPort.Substring(Len(rsPrintPort) - 1))
                                'msComm.sbSendComm(sPrtMsg, iComport)
                                PRTAPI.SendFileToPrinter(rsPrintPort, strFileNm)
                               
                            End If
                            '<테스트 1
                            'If sPrtMsg.Length < 350 Then
                            '    Threading.Thread.Sleep(CInt(sPrtMsg.Length * 1.5))
                            'Else
                            '    Threading.Thread.Sleep(1500)
                            'End If
                            '>
                            'Threading.Thread.Sleep(CInt(sPrtMsg.Length * 1.5)) '기존 소스
                            Threading.Thread.Sleep(900)
                        Next
                    End If

                End If
            Next

            Return True
        Catch ex As Exception
            Fn.log(mcFile + sFn, Err)
            MsgBox(mcFile + sFn + vbCrLf + ex.Message)
            Return False
        Finally
            FileClose(iFileNo)

        End Try
    End Function

    Protected Overridable Function fnMakePrtMsgRight(ByVal ro_Data As STU_BCPRTINFO, _
                                                ByVal rbFirst As Boolean, _
                                                ByVal riLeftPos As Integer, ByVal riTopPos As Integer, _
                                                ByVal rsBarType As String) As String
        Dim sFn As String = "fnMakePrtMsg"

        Try

            'ro_Data.INFINFO = "S/MRSA"
            Dim a_sInfInfo As String() = ro_Data.INFINFO.Split("/"c)

            Dim sPrtBuf As String = ""
            Dim iXposS As Integer = 0
            Dim iUPosS As Integer = 0

            Dim sXpos As String = ""
            Dim sypos As String = ""

            Dim iHanCnt As Integer = 0

            '>>>>>>>>>>>>> 설정한 인쇄 내용의 시작 < 시작점 초기화>
            sPrtBuf += Chr(2) & "L" & Chr(13)

            '>>>>> 단위를 인치에서 미터로 변경함을 말함 
            sPrtBuf += Chr(2) & "m" & Chr(13)




            'Setting
            '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ' 프린트가능한 프린트 속도
            sPrtBuf += "P3" + Chr(13)

            ' 프린트 가능하지 않은 프린트 속도
            sPrtBuf += "S3" + Chr(13)

            'Pixel Size 셋팅 
            sPrtBuf += "D11" + Chr(13)


            'OffSet 설정(Colum의 방향) < 미터시스템 0000~9999 (0.0 mm 99.9mm)
            sPrtBuf += "C0030" + Chr(13)

            'OffSet 설정(Row 의 방향) < 미터시스템 0000~9999 (0.0 mm 99.9mm)
            sPrtBuf += "R0020" + Chr(13)



            ''< 검체번호   & 바코드 발행 일시  
            sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + "0860" + "KD24" + ro_Data.BCNO + "       " + Fn.GetServerDateTime.ToString("HH:mm") + Chr(13)




            '< 감염정보   
            If ro_Data.INFINFO = "" Then
            Else
                Dim iPosH As Integer = 810


                For ix As Integer = 0 To a_sInfInfo.Length - 1
                    Dim sPosH As String = "0" + CStr(iPosH)

                    If ix > 2 Then Exit For
                    sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + sPosH + "KD24" + a_sInfInfo(ix).ToString() + Chr(13)
                Next

                iPosH += 25

            End If



            '< 바코드  
            If ro_Data.BCNOPRT <> "" Then
                If ro_Data.BCTYPE = "M" Then
                    ' CODAR BAR 
                    sPrtBuf += "2" + "d" + "6" + "2" + "080" + "0330" + "0830" + ro_Data.BCNOPRT.Trim + Chr(13)
                Else
                    ' CODAR BAR 
                    sPrtBuf += "2" + "d" + "6" + "3" + "080" + "0330" + "0830" + ro_Data.BCNOPRT.Trim + Chr(13)
                End If
                

                '< 바코드 번호 & 성별/나이 
                sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0290" + "0790" + "KD24" + ro_Data.BCNOPRT.Trim + "   " + ro_Data.SEXAGE + Chr(13)


            Else
                '< 미수납 바코드  
                sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + "0830" + "미채혈바코드" + Chr(13)

                '< 성별/나이 
                sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0210" + "0790" + "KD24" + ro_Data.SEXAGE + Chr(13)
            End If

            '< 등록번호 sPID   & 환자명 & 진료과/병동/병실 
            sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + "0760" + "KD24" + ro_Data.REGNO + " " + ro_Data.PATNM + "  " + ro_Data.DEPTWARD + Chr(13)



            '< sRemark  
            sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0060" + "0810" + "KD24" + IIf(ro_Data.REMARK = "", "", "C").ToString() + Chr(13)



            If ro_Data.BCCLSCD = PRG_CONST.BCCLS_BldCrossMatch Or ro_Data.BCCNT = "B" Then
                '< 검체명 & 용기명
                sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + "0730" + "KD24" + ro_Data.TUBENM + "  " + ro_Data.SPCNM + "  " + Chr(13)


                '< 채혈자
                sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0130" + "0700" + "KD24" + fnGet_Hangle_Font_1("채혈자:") + Chr(13)

                '< 확인자

                sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0130" + "0670" + "KD24" + fnGet_Hangle_Font_1("확인자:") + Chr(13)





            Else
                If ro_Data.BCTYPE = "M" Then
                    sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0190" + "0700" + "KD24" + ro_Data.SPCNM + "      " + ro_Data.BCNO_MB + Chr(13)


                Else
                    '< 검체명 & 용기명& 검사그룹
                    sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + "0730" + "KD24" + ro_Data.TUBENM + "  " + ro_Data.SPCNM + "  " + ro_Data.TGRPNM + Chr(13)



                    '< 응급 sEmer   
                    If ro_Data.EMER <> "" Then
                        sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0060" + "0790" + "KD24" + ro_Data.EMER + Chr(13)
                    End If




                    Dim sTestNms As String = ro_Data.TESTNMS

                    '>>>>>>>>>>>>>>>>>>>>>>>>> 검사명 두줄 처리를 위한 잘라내기 '>>>>>>>>>>>>>>>>>>>>>>
                    Dim sLine1 As String = ""
                    Dim sLine2 As String = ""

                    If ro_Data.TESTNMS.Length < 31 Then
                        sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + "0700" + "KD24" + ro_Data.BCCLSCD + "  " + sTestNms + Chr(13)


                    Else
                        sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + "0700" + "KD24" + ro_Data.BCCLSCD + "  " + sTestNms.Substring(0, 30) + Chr(13)

                        If ro_Data.TESTNMS.Length > 60 Then

                            sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + "0670" + "KD24" + sTestNms.Substring(30, 56) + "..." + Chr(13)
                        Else
                            sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + "0670" + "KD24" + sTestNms.Substring(30, ro_Data.TESTNMS.Length - sLine1.Length - 1) + Chr(13)
                        End If

                    End If

                    '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


                End If
            End If

            '< 라인 마지막 
            sPrtBuf += "LQ001" + Chr(13)
            sPrtBuf += "E" + Chr(13)


            Return sPrtBuf

        Catch ex As Exception
            Fn.log(mcFile + sFn, Err)
            MsgBox(mcFile + sFn + vbCrLf + ex.Message)

            Return ""
        Finally

        End Try

    End Function
    Protected Overridable Function fnMakePrtMsg(ByVal ro_Data As STU_BCPRTINFO, _
                                               ByVal rbFirst As Boolean, _
                                               ByVal riLeftPos As Integer, ByVal riTopPos As Integer, _
                                               ByVal rsBarType As String, ByVal rsPrintPort As String) As String
        '<여백 조절 가능하도록 상호 수정. 20130915>
        Dim sFn As String = "fnMakePrtMsg"

        '<여백 조절 가능하도록 상호 수정 20130914
        Dim iLeftPos As Integer = riLeftPos
        Dim iTopPos As Integer = riTopPos
        '>

        Try
            'ro_Data.INFINFO = "H/C"
            Dim a_sInfInfo As String() = ro_Data.INFINFO.Split("/"c)

            Dim sPrtBuf As String = ""
            Dim iXposS As Integer = 0
            Dim iUPosS As Integer = 0

            Dim sXpos As String = ""
            Dim sypos As String = ""

            Dim iHanCnt As Integer = 0

            '>>>>>>>>>>>>> 설정한 인쇄 내용의 시작 < 시작점 초기화>
            sPrtBuf += Chr(2) & "m" & Chr(13)

            '>>>>> 단위를 인치에서 미터로 변경함을 말함 
            sPrtBuf += Chr(2) & "L"

            'Setting
            '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ' 프린트가능한 프린트 속도
            'sPrtBuf += "D11" '상호 주석 
            'sPrtBuf += "P3" + Chr(13)
            sPrtBuf += "PO" + Chr(13)

            ' 프린트 가능하지 않은 프린트 속도
            'sPrtBuf += "P6" '상호 주석 
            'sPrtBuf += "S3" + Chr(13)
            sPrtBuf += "SO" + Chr(13)

            'Pixel Size 셋팅 
            'sPrtBuf += "S6" '상호 주석 
            sPrtBuf += "D11" + Chr(13)

            'sPrtBuf += "H20z" + Chr(13) '상호 주석

            'OffSet 설정(Colum의 방향) < 미터시스템 0000~9999 (0.0 mm 99.9mm)
            'sPrtBuf += "C0030" + Chr(13)
            sPrtBuf += "C0000" + Chr(13)

            'OffSet 설정(Row 의 방향) < 미터시스템 0000~9999 (0.0 mm 99.9mm)
            'sPrtBuf += "R0020" + Chr(13)
            sPrtBuf += "R0000" + Chr(13)

            '<상호 추가 20130915
            'Setting print density (head heat factor) -> 00 ~ 30 Initialization value: 10
            sPrtBuf += "H15" + Chr(13)
            '>


            If ro_Data.BCTYPE = "M" Then

                'sPrtBuf += "1" + Chr(27) + "1" + "0" + "001" + "0292" + "0005" + "KR24" + ro_Data.BCNO + " " + ro_Data.SPCNM.Trim.Replace(" ", "") + " " + ro_Data.TGRPNM.Trim + Chr(13) '기존 소스
                sPrtBuf += "1" + Chr(27) + "1" + "0" + "001" + CStr(iTopPos + CInt("306")).PadLeft(4, "0") + CStr(iLeftPos + CInt("5")).PadLeft(4, "0") + "KR24" + ro_Data.BCNO + " " + ro_Data.SPCNM.Trim.Replace(" ", "") + " " + ro_Data.TGRPNM.Trim + Chr(13)
                'sPrtBuf += "1" + Chr(27) + "1" + "0" + "001" + "0267" + "0005" + "KR24" + ro_Data.BCNO_MB + "    " + ro_Data.REGNO + "    " + ro_Data.SEXAGE + Chr(13)'기존 소스
                sPrtBuf += "1" + Chr(27) + "1" + "0" + "001" + CStr(iTopPos + CInt("281")).PadLeft(4, "0") + CStr(iLeftPos + CInt("5")).PadLeft(4, "0") + "KR24" + ro_Data.BCNO_MB + "    " + ro_Data.REGNO + "    " + ro_Data.SEXAGE + Chr(13)
                ' CODAR BAR 
                'sPrtBuf += "1" + "a" + "3" + "1" + "035" + "0230" + "0120" + ro_Data.BCNOPRT.Trim + Chr(13)
                sPrtBuf += "1" + "a" + "3" + "1" + "035" + CStr(iTopPos + CInt("245")).PadLeft(4, "0") + CStr(iLeftPos + CInt("120")).PadLeft(4, "0") + ro_Data.BCNOPRT.Trim + Chr(13)
            Else
                ''< 검체번호   & 검사 방법& 바코드 발행 일시 
                If rbFirst Then
                    'sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + "0285" + "0020" + "KR24" + ro_Data.BCNO + "    " + ro_Data.METHODCD + " " + Fn.GetServerDateTime.ToString("HH:mm") + Chr(13)
                    If ro_Data.BCNO <> "" Then
                        'sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + "0300" + "0040" + "KR24" + ro_Data.BCNO + "      " + ro_Data.METHODCD + " " + Fn.GetServerDateTime.ToString("HH:mm") + Chr(13)
                        sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + CStr(iTopPos + CInt("308")).PadLeft(4, "0") + CStr(iLeftPos + CInt("40")).PadLeft(4, "0") + "KR24" + ro_Data.BCNO + "      " + ro_Data.METHODCD + " " + Fn.GetServerDateTime.ToString("HH:mm") + Chr(13)
                    Else
                        'sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + "0300" + "0420" + "KR24" + Fn.GetServerDateTime.ToString("HH:mm") + Chr(13) + "A1" + Chr(13)
                        sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + CStr(iTopPos + CInt("308")).PadLeft(4, "0") + CStr(iLeftPos + CInt("420")).PadLeft(4, "0") + "KR24" + Fn.GetServerDateTime.ToString("HH:mm") + Chr(13) + "A1" + Chr(13)
                    End If
                Else
                    'sPrtBuf += "A51" + Chr(27) + "1" + "1" + "001" + "0285" + "0020" + "KR24" + ro_Data.BCNO + "    " + ro_Data.METHODCD + " " + Fn.GetServerDateTime.ToString("HH:mm") + Chr(13) + "A1" + Chr(13)
                    'sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + "0300" + "0040" + "KR24" + ro_Data.BCNO + "    " + ro_Data.METHODCD + Chr(13)
                    sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + CStr(iTopPos + CInt("310")).PadLeft(4, "0") + CStr(iLeftPos + CInt("40")).PadLeft(4, "0") + "KR24" + ro_Data.BCNO + "    " + ro_Data.METHODCD + Chr(13)
                    'sPrtBuf += "A51" + Chr(27) + "1" + "1" + "001" + "0300" + "0420" + "KR24" + Fn.GetServerDateTime.ToString("HH:mm") + Chr(13) + "A1" + Chr(13)
                    sPrtBuf += "A51" + Chr(27) + "1" + "1" + "001" + CStr(iTopPos + CInt("310")).PadLeft(4, "0") + CStr(iLeftPos + CInt("420")).PadLeft(4, "0") + "KR24" + Fn.GetServerDateTime.ToString("HH:mm") + Chr(13) + "A1" + Chr(13)
                End If


                '< 감염정보   
                If ro_Data.INFINFO = "" Then
                Else
                    'Dim iPosH As Integer = 510
                    Dim iPosH As Integer = 225


                    For ix As Integer = 0 To a_sInfInfo.Length - 1
                        Dim sPosH As String = "0" + CStr(iPosH)

                        If ix > 2 Then Exit For
                        'sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + sPosH + "0500" + "KR24" + a_sInfInfo(ix).ToString() + Chr(13)
                        sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + CStr(iTopPos + 10 + sPosH).PadLeft(4, "0") + CStr(iLeftPos + CInt("500")).PadLeft(4, "0") + "KR24" + a_sInfInfo(ix).ToString() + Chr(13)

                        If a_sInfInfo(ix).ToString <> "" Then iPosH -= 55

                    Next
                End If


                '< 바코드  
                If ro_Data.BCNOPRT <> "" Then

                    ' CODAR BAR 
                    'sPrtBuf += "1" + "a" + "4" + "2" + "120" + "0170" + "0045" + ro_Data.BCNOPRT.Trim + Chr(13)
                    sPrtBuf += "1" + "a" + "4" + "2" + "120" + CStr(iTopPos + CInt("0185")).PadLeft(4, "0") + CStr(iLeftPos + CInt("45")).PadLeft(4, "0") + ro_Data.BCNOPRT.Trim + Chr(13)
                    '< 바코드 번호 & 성별/나이 

                    'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0145" + "0045" + ro_Data.BCNOPRT.Trim + "       " + ro_Data.DEPTWARD + Chr(13)
                    sPrtBuf += "1" + "9" + "1" + "1" + "001" + CStr(iTopPos + CInt("160")).PadLeft(4, "0") + CStr(iLeftPos + CInt("45")).PadLeft(4, "0") + ro_Data.BCNOPRT.Trim + "       " + ro_Data.DEPTWARD + Chr(13)

                Else
                    '< 미수납 바코드  
                    'sPrtBuf += "1" + Chr(27) + "2" + "2" + "004" + "0175" + "0085" + "KR24" + "미채혈바코드" + Chr(13)
                    'sPrtBuf += "1" + Chr(27) + "2" + "2" + "004" + CStr(iTopPos + CInt("0190")).PadLeft(4, "0") + CStr(iLeftPos + CInt("85")).PadLeft(4, "0") + "KR24" + "미채혈바코드" + Chr(13)
                    'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0135" + "0260" + ro_Data.DEPTWARD + Chr(13)
                    sPrtBuf += "1" + "9" + "1" + "1" + "001" + CStr(iTopPos + CInt("160")).PadLeft(4, "0") + CStr(iLeftPos + CInt("260")).PadLeft(4, "0") + ro_Data.DEPTWARD + Chr(13)
                    '< 성별/나이 

                    'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0135" + "0145" + ro_Data.SEXAGE + Chr(13)
                End If

                '< 등록번호 sPID   & 환자명 & 진료과/병동/병실 
                'sPrtBuf += "1" + Chr(27) + "1" + "2" + "001" + "0075" + "0020" + "KR24" + ro_Data.REGNO + " " + ro_Data.PATNM + "  " + ro_Data.DEPTWARD + Chr(13)

                If ro_Data.OBFTSYN = "" Then
                    'sPrtBuf += "1" + Chr(27) + "1" + "2" + "001" + "0075" + "0020" + "KR24" + ro_Data.REGNO + "    " + ro_Data.PATNM + "     " + ro_Data.SEXAGE + Chr(13)
                    sPrtBuf += "1" + Chr(27) + "1" + "2" + "001" + CStr(iTopPos + CInt("95")).PadLeft(4, "0") + CStr(iLeftPos + CInt("20")).PadLeft(4, "0") + "KR24" + ro_Data.REGNO + "    " + ro_Data.PATNM + "     " + ro_Data.SEXAGE + Chr(13)
                Else
                    'sPrtBuf += "A51" + Chr(27) + "1" + "2" + "001" + "0075" + "0020" + "KR24" + ro_Data.REGNO + Chr(13) + "A1" + Chr(13)
                    sPrtBuf += "A51" + Chr(27) + "1" + "2" + "001" + CStr(iTopPos + CInt("95")).PadLeft(4, "0") + CStr(iLeftPos + CInt("20")).PadLeft(4, "0") + "KR24" + ro_Data.REGNO + Chr(13) + "A1" + Chr(13)
                    'sPrtBuf += "1" + Chr(27) + "1" + "2" + "001" + "0075" + "0210" + "KR24" + ro_Data.PATNM + "     " + ro_Data.SEXAGE + Chr(13)
                    sPrtBuf += "1" + Chr(27) + "1" + "2" + "001" + CStr(iTopPos + CInt("80")).PadLeft(4, "0") + CStr(iLeftPos + CInt("210")).PadLeft(4, "0") + "KR24" + ro_Data.PATNM + "     " + ro_Data.SEXAGE + Chr(13)
                    'sPrtBuf += "1X11000" + "0010" + "0001" + "L" + "010" + "300" + Chr(13)
                    sPrtBuf += "1X11000" + CStr(iTopPos + CInt("25")).PadLeft(4, "0") + CStr(iLeftPos + CInt("1")).PadLeft(4, "0") + "L" + "010" + "300" + Chr(13) 'ori
                

                    '        '                /* 1X11000 0050 0060 L 010 150

                    '        '1:          X11000 = 고정
                    '        '                   0050    = Y축 좌표
                    '        '                   0060    = X축 좌표
                    '        '                   L       = 라인 설정
                    '        '                   010     = 선 두께
                    '        '                   150     = 라인 길이   */
                End If

                '< sRemark
                'ro_Data.REMARK = "C"
                'sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + "0225" + "0003" + "KR24" + IIf(ro_Data.REMARK = "", "", "C").ToString() + Chr(13)
                sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + CStr(iTopPos + CInt("245")).PadLeft(4, "0") + CStr(iLeftPos + CInt("3")).PadLeft(4, "0") + "KR24" + IIf(ro_Data.REMARK = "", "", "C").ToString() + Chr(13)

                If ro_Data.BCCLSCD = PRG_CONST.BCCLS_BldCrossMatch Or ro_Data.BCCNT = "B" Then
                    '< 검체명 & 용기명
                    'sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0200" + "0200" + "KR24" + ro_Data.TUBENM + "  " + ro_Data.SPCNM + "  " + Chr(13)
                    sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + CStr(iTopPos + CInt("220")).PadLeft(4, "0") + CStr(iLeftPos + CInt("200")).PadLeft(4, "0") + "KR24" + ro_Data.TUBENM + "  " + ro_Data.SPCNM + "  " + Chr(13)

                    '< 채혈자
                    'sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0130" + "0400" + "KR24" + fnGet_Hangle_Font_1("채혈자:") + Chr(13)
                    sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + CStr(iTopPos + CInt("150")).PadLeft(4, "0") + CStr(iLeftPos + CInt("400")).PadLeft(4, "0") + "KR24" + fnGet_Hangle_Font_1("채혈자:") + Chr(13)

                    '< 확인자

                    'sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0130" + "0370" + "KR24" + fnGet_Hangle_Font_1("확인자:") + Chr(13)
                    sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + CStr(iTopPos + CInt("150")).PadLeft(4, "0") + CStr(iLeftPos + CInt("370")).PadLeft(4, "0") + "KR24" + fnGet_Hangle_Font_1("확인자:") + Chr(13)

                Else
                    If ro_Data.BCTYPE = "M" Then
                        'sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0190" + "0400" + "KR24" + ro_Data.SPCNM + "      " + ro_Data.BCNO_MB + Chr(13)
                        sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + CStr(iTopPos + CInt("210")).PadLeft(4, "0") + CStr(iLeftPos + CInt("400")).PadLeft(4, "0") + "KR24" + ro_Data.SPCNM + "      " + ro_Data.BCNO_MB + Chr(13)

                    Else
                        '< 검체명 & 용기명& 검사그룹
                        'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0050" + "0020" + ro_Data.TUBENM + "            " + ro_Data.SPCNM + "  " + ro_Data.TGRPNM + Chr(13)
                        sPrtBuf += "1" + "9" + "1" + "1" + "001" + CStr(iTopPos + CInt("70")).PadLeft(4, "0") + CStr(iLeftPos + CInt("20")).PadLeft(4, "0") + ro_Data.TUBENM + "            " + ro_Data.SPCNM + Chr(13)
                        'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0050" + "0020" + ro_Data.TUBENM + "            " + ro_Data.SPCNM + Chr(13)
                        'sPrtBuf += "1" + "9" + "1" + "1" + "001" + CStr(iTopPos + CInt("50")).PadLeft(4, "0") + CStr(iLeftPos + CInt("20")).PadLeft(4, "0") + ro_Data.TUBENM + "            " + ro_Data.SPCNM + Chr(13)

                        'ro_Data.TGRPNM = "B0"
                        'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0005" + "0070" + ro_Data.TGRPNM + Chr(13)
                        'sPrtBuf += "1" + "9" + "1" + "1" + "001" + CStr(iTopPos + CInt("25")).PadLeft(4, "0") + CStr(iLeftPos + CInt("70")).PadLeft(4, "0") + ro_Data.TGRPNM + Chr(13)


                        '< 응급 sEmer   
                        'If ro_Data.EMER <> "" Then
                        'ro_Data.EMER = "E"
                        'sPrtBuf += "1" + Chr(27) + "1" + "2" + "001" + "0130" + "0450" + "KR24" + ro_Data.EMER + Chr(13)
                        'sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + "0170" + "0003" + "KR24" + ro_Data.EMER + Chr(13)
                        sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + CStr(iTopPos + CInt("185")).PadLeft(4, "0") + CStr(iLeftPos + CInt("3")).PadLeft(4, "0") + "KR24" + ro_Data.EMER + Chr(13)
                        'End If


                        Dim sTestNms As String = ro_Data.TESTNMS

                        '>>>>>>>>>>>>>>>>>>>>>>>>> 검사명 두줄 처리를 위한 잘라내기 '>>>>>>>>>>>>>>>>>>>>>>
                        Dim sLine1 As String = ""
                        Dim sLine2 As String = ""

                        'sPrtBuf += "1" + Chr(27) + "1" + "2" + "001" + "0000" + "0020" + "KR24" + ro_Data.BCCLSCD + Chr(13)   '먼저 슬립을 찍음.
                        sPrtBuf += "1" + Chr(27) + "1" + "2" + "001" + CStr(iTopPos + CInt("25")).PadLeft(4, "0") + CStr(iLeftPos + CInt("20")).PadLeft(4, "0") + "KR24" + ro_Data.BCCLSCD + Chr(13)   '상호 수정 20130915


                        'If ro_Data.TESTNMS.Length < 35 Then    '검사명 길이를 확인.
                        'sPrtBuf += "1" + Chr(27) + "1" + "1" + "009" + "0000" + "0020" + "KR24" + ro_Data.BCCLSCD + "  " + sTestNms + Chr(13)

                        'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0030" + "0055" + sTestNms + Chr(13)
                        'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0030" + "0070" + sTestNms + Chr(13)
                        If ro_Data.TESTNMS.Length < 31 Then
                            sTestNms = ro_Data.TESTNMS
                        Else
                            sTestNms = ro_Data.TESTNMS.Substring(0, 30) + "..."
                        End If

                        sPrtBuf += "1" + "9" + "1" + "1" + "001" + CStr(iTopPos + CInt("50")).PadLeft(4, "0") + CStr(iLeftPos + CInt("70")).PadLeft(4, "0") + sTestNms + Chr(13)

                        'ro_Data.TGRPNM
                        sPrtBuf += "1" + "9" + "1" + "1" + "001" + CStr(iTopPos + CInt("30")).PadLeft(4, "0") + CStr(iLeftPos + CInt("70")).PadLeft(4, "0") + ro_Data.TGRPNM + Chr(13)

                        'Else
                        'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0030" + "0070" + sTestNms.Substring(0, 35) + Chr(13)
                        'sPrtBuf += "1" + "9" + "1" + "1" + "001" + CStr(iTopPos + CInt("50")).PadLeft(4, "0") + CStr(iLeftPos + CInt("70")).PadLeft(4, "0") + sTestNms.Substring(0, 35) + Chr(13)

                        'If ro_Data.TESTNMS.Length > 70 Then   '검사명 길이가 31 이상인 것 중에서도 70 이 넘는 것은 ... 로 처리
                        'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0005" + "0055" + sTestNms.Substring(30, sTestNms.Length - 35 - 1) + "..." + Chr(13)
                        'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0005" + "0070" + sTestNms.Substring(30, sTestNms.Length - 35 - 1) + "..." + Chr(13)
                        'sPrtBuf += "1" + "9" + "1" + "1" + "001" + CStr(iTopPos + CInt("25")).PadLeft(4, "0") + CStr(iLeftPos + CInt("70")).PadLeft(4, "0") + sTestNms.Substring(30, sTestNms.Length - 35 - 1) + "..." + Chr(13)
                        'Else
                        'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0005" + "0055" + sTestNms.Substring(30, sTestNms.Length - 35 - 1) + Chr(13)
                        'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0005" + "0070" + sTestNms.Substring(30, sTestNms.Length - 35 - 1) + Chr(13)
                        'End If

                        'End If

                        '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


                    End If
                End If

            End If



            '< 라인 마지막 
            sPrtBuf += "Q0001" + Chr(13)
            sPrtBuf += "E" + Chr(13)

            Return sPrtBuf

        Catch ex As Exception
            Fn.log(mcFile + sFn, Err)
            MsgBox(mcFile + sFn + vbCrLf + ex.Message)

            Return ""
        Finally

        End Try

    End Function
    'Protected Overridable Function fnMakePrtMsg(ByVal ro_Data As STU_BCPRTINFO, _
    '                                           ByVal rbFirst As Boolean, _
    '                                           ByVal riLeftPos As Integer, ByVal riTopPos As Integer, _
    '                                           ByVal rsBarType As String, ByVal rsPrintPort As String) As String
    '    Dim sFn As String = "fnMakePrtMsg"
    '<기존 소스 주석 20130915

    '    Try
    '        'ro_Data.INFINFO = "H/C"
    '        Dim a_sInfInfo As String() = ro_Data.INFINFO.Split("/"c)

    '        Dim sPrtBuf As String = ""
    '        Dim iXposS As Integer = 0
    '        Dim iUPosS As Integer = 0

    '        Dim sXpos As String = ""
    '        Dim sypos As String = ""

    '        Dim iHanCnt As Integer = 0

    '        '>>>>>>>>>>>>> 설정한 인쇄 내용의 시작 < 시작점 초기화>
    '        sPrtBuf += Chr(2) & "m" & Chr(13)

    '        '>>>>> 단위를 인치에서 미터로 변경함을 말함 
    '        sPrtBuf += Chr(2) & "L"




    '        'Setting
    '        '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    '        ' 프린트가능한 프린트 속도
    '        sPrtBuf += "D11"

    '        ' 프린트 가능하지 않은 프린트 속도
    '        sPrtBuf += "P6"

    '        'Pixel Size 셋팅 
    '        sPrtBuf += "S6"

    '        sPrtBuf += "H20z" + Chr(13)

    '        'OffSet 설정(Colum의 방향) < 미터시스템 0000~9999 (0.0 mm 99.9mm)
    '        'sPrtBuf += "C0030" + Chr(13)

    '        'OffSet 설정(Row 의 방향) < 미터시스템 0000~9999 (0.0 mm 99.9mm)
    '        'sPrtBuf += "R0020" + Chr(13)

    '        If ro_Data.BCTYPE = "M" Then

    '            sPrtBuf += "1" + Chr(27) + "1" + "0" + "001" + "0292" + "0005" + "KR24" + ro_Data.BCNO + " " + ro_Data.SPCNM.Trim.Replace(" ", "") + " " + ro_Data.TGRPNM.Trim + Chr(13)
    '            sPrtBuf += "1" + Chr(27) + "1" + "0" + "001" + "0267" + "0005" + "KR24" + ro_Data.BCNO_MB + "    " + ro_Data.REGNO + "    " + ro_Data.SEXAGE + Chr(13)
    '            ' CODAR BAR 
    '            sPrtBuf += "1" + "a" + "3" + "1" + "035" + "0230" + "0120" + ro_Data.BCNOPRT.Trim + Chr(13)

    '        Else
    '            ''< 검체번호   & 검사 방법& 바코드 발행 일시 
    '            If rbFirst Then
    '                'sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + "0285" + "0020" + "KR24" + ro_Data.BCNO + "    " + ro_Data.METHODCD + " " + Fn.GetServerDateTime.ToString("HH:mm") + Chr(13)
    '                If ro_Data.BCNO <> "" Then
    '                    sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + "0300" + "0040" + "KR24" + ro_Data.BCNO + "      " + ro_Data.METHODCD + " " + Fn.GetServerDateTime.ToString("HH:mm") + Chr(13)
    '                Else
    '                    sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + "0300" + "0420" + "KR24" + Fn.GetServerDateTime.ToString("HH:mm") + Chr(13) + "A1" + Chr(13)
    '                End If
    '            Else
    '                'sPrtBuf += "A51" + Chr(27) + "1" + "1" + "001" + "0285" + "0020" + "KR24" + ro_Data.BCNO + "    " + ro_Data.METHODCD + " " + Fn.GetServerDateTime.ToString("HH:mm") + Chr(13) + "A1" + Chr(13)
    '                sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + "0300" + "0040" + "KR24" + ro_Data.BCNO + "    " + ro_Data.METHODCD + Chr(13)
    '                sPrtBuf += "A51" + Chr(27) + "1" + "1" + "001" + "0300" + "0420" + "KR24" + Fn.GetServerDateTime.ToString("HH:mm") + Chr(13) + "A1" + Chr(13)
    '            End If





    '            '< 감염정보   
    '            If ro_Data.INFINFO = "" Then
    '            Else
    '                'Dim iPosH As Integer = 510
    '                Dim iPosH As Integer = 225


    '                For ix As Integer = 0 To a_sInfInfo.Length - 1
    '                    Dim sPosH As String = "0" + CStr(iPosH)

    '                    If ix > 2 Then Exit For
    '                    sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + sPosH + "0500" + "KR24" + a_sInfInfo(ix).ToString() + Chr(13)

    '                    If a_sInfInfo(ix).ToString <> "" Then iPosH -= 55

    '                Next

    '                'iPosH += 25
    '                'iPosH -= 50

    '            End If



    '            '< 바코드  
    '            If ro_Data.BCNOPRT <> "" Then

    '                ' CODAR BAR 
    '                'sPrtBuf += "1" + "a" + "4" + "1" + "120" + "0160" + "0085" + ro_Data.BCNOPRT.Trim + Chr(13)
    '                sPrtBuf += "1" + "a" + "4" + "2" + "120" + "0170" + "0045" + ro_Data.BCNOPRT.Trim + Chr(13)
    '                '< 바코드 번호 & 성별/나이 
    '                'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0135" + "0145" + ro_Data.BCNOPRT.Trim + "       " + ro_Data.DEPTWARD + Chr(13)
    '                sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0145" + "0045" + ro_Data.BCNOPRT.Trim + "       " + ro_Data.DEPTWARD + Chr(13)

    '            Else
    '                '< 미수납 바코드  
    '                sPrtBuf += "1" + Chr(27) + "2" + "2" + "004" + "0175" + "0085" + "KR24" + "미채혈바코드" + Chr(13)
    '                sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0135" + "0260" + ro_Data.DEPTWARD + Chr(13)
    '                '< 성별/나이 
    '                'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0135" + "0145" + ro_Data.SEXAGE + Chr(13)
    '            End If

    '            '< 등록번호 sPID   & 환자명 & 진료과/병동/병실 
    '            'sPrtBuf += "1" + Chr(27) + "1" + "2" + "001" + "0075" + "0020" + "KR24" + ro_Data.REGNO + " " + ro_Data.PATNM + "  " + ro_Data.DEPTWARD + Chr(13)

    '            If ro_Data.OBFTSYN = "" Then
    '                sPrtBuf += "1" + Chr(27) + "1" + "2" + "001" + "0075" + "0020" + "KR24" + ro_Data.REGNO + "    " + ro_Data.PATNM + "     " + ro_Data.SEXAGE + Chr(13)
    '            Else
    '                sPrtBuf += "A51" + Chr(27) + "1" + "2" + "001" + "0075" + "0020" + "KR24" + ro_Data.REGNO + Chr(13) + "A1" + Chr(13)
    '                sPrtBuf += "1" + Chr(27) + "1" + "2" + "001" + "0075" + "0210" + "KR24" + ro_Data.PATNM + "     " + ro_Data.SEXAGE + Chr(13)
    '                sPrtBuf += "1X11000" + "0010" + "0001" + "L" + "010" + "300" + Chr(13)

    '                '        '                /* 1X11000 0050 0060 L 010 150

    '                '        '1:          X11000 = 고정
    '                '        '                   0050    = Y축 좌표
    '                '        '                   0060    = X축 좌표
    '                '        '                   L       = 라인 설정
    '                '        '                   010     = 선 두께
    '                '        '                   150     = 라인 길이   */
    '            End If

    '            '< sRemark
    '            'ro_Data.REMARK = "C"
    '            'sPrtBuf += "1" + Chr(27) + "1" + "2" + "001" + "0230" + "0450" + "KR24" + IIf(ro_Data.REMARK = "", "", "C").ToString() + Chr(13)
    '            sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + "0225" + "0003" + "KR24" + IIf(ro_Data.REMARK = "", "", "C").ToString() + Chr(13)


    '            If ro_Data.BCCLSCD = PRG_CONST.BCCLS_BldCrossMatch Or ro_Data.BCCNT = "B" Then
    '                '< 검체명 & 용기명
    '                sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0200" + "0200" + "KR24" + ro_Data.TUBENM + "  " + ro_Data.SPCNM + "  " + Chr(13)


    '                '< 채혈자
    '                sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0130" + "0400" + "KR24" + fnGet_Hangle_Font_1("채혈자:") + Chr(13)

    '                '< 확인자

    '                sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0130" + "0370" + "KR24" + fnGet_Hangle_Font_1("확인자:") + Chr(13)





    '            Else
    '                If ro_Data.BCTYPE = "M" Then
    '                    sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0190" + "0400" + "KR24" + ro_Data.SPCNM + "      " + ro_Data.BCNO_MB + Chr(13)


    '                Else
    '                    '< 검체명 & 용기명& 검사그룹
    '                    'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0050" + "0020" + ro_Data.TUBENM + "            " + ro_Data.SPCNM + "  " + ro_Data.TGRPNM + Chr(13)
    '                    sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0050" + "0020" + ro_Data.TUBENM + "            " + ro_Data.SPCNM + Chr(13)
    '                    'ro_Data.TGRPNM = "B0"
    '                    sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0005" + "0070" + ro_Data.TGRPNM + Chr(13)



    '                    '< 응급 sEmer   
    '                    'If ro_Data.EMER <> "" Then
    '                    'ro_Data.EMER = "E"
    '                    'sPrtBuf += "1" + Chr(27) + "1" + "2" + "001" + "0130" + "0450" + "KR24" + ro_Data.EMER + Chr(13)
    '                    sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + "0170" + "0003" + "KR24" + ro_Data.EMER + Chr(13)
    '                    'End If


    '                    Dim sTestNms As String = ro_Data.TESTNMS

    '                    '>>>>>>>>>>>>>>>>>>>>>>>>> 검사명 두줄 처리를 위한 잘라내기 '>>>>>>>>>>>>>>>>>>>>>>
    '                    Dim sLine1 As String = ""
    '                    Dim sLine2 As String = ""

    '                    sPrtBuf += "1" + Chr(27) + "1" + "2" + "001" + "0000" + "0020" + "KR24" + ro_Data.BCCLSCD + Chr(13)   '먼저 슬립을 찍음.

    '                    If ro_Data.TESTNMS.Length < 35 Then    '검사명 길이를 확인.
    '                        'sPrtBuf += "1" + Chr(27) + "1" + "1" + "009" + "0000" + "0020" + "KR24" + ro_Data.BCCLSCD + "  " + sTestNms + Chr(13)

    '                        'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0030" + "0055" + sTestNms + Chr(13)
    '                        sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0030" + "0070" + sTestNms + Chr(13)

    '                    Else
    '                        sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0030" + "0070" + sTestNms.Substring(0, 35) + Chr(13)

    '                        If ro_Data.TESTNMS.Length > 70 Then   '검사명 길이가 31 이상인 것 중에서도 70 이 넘는 것은 ... 로 처리
    '                            'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0005" + "0055" + sTestNms.Substring(30, sTestNms.Length - 35 - 1) + "..." + Chr(13)
    '                            sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0005" + "0070" + sTestNms.Substring(30, sTestNms.Length - 35 - 1) + "..." + Chr(13)
    '                        Else
    '                            'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0005" + "0055" + sTestNms.Substring(30, sTestNms.Length - 35 - 1) + Chr(13)
    '                            'sPrtBuf += "1" + "9" + "1" + "1" + "001" + "0005" + "0070" + sTestNms.Substring(30, sTestNms.Length - 35 - 1) + Chr(13)
    '                        End If

    '                    End If

    '                    '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


    '                End If
    '            End If

    '        End If



    '        '< 라인 마지막 
    '        sPrtBuf += "Q0001" + Chr(13)
    '        sPrtBuf += "E" + Chr(13)

    '        Return sPrtBuf

    '    Catch ex As Exception
    '        Fn.log(mcFile + sFn, Err)
    '        MsgBox(mcFile + sFn + vbCrLf + ex.Message)

    '        Return ""
    '    Finally

    '    End Try

    'End Function


    Protected Overridable Function fnMakePrtMsgLeft(ByVal ro_Data As STU_BCPRTINFO, _
                                            ByVal rbFirst As Boolean, _
                                            ByVal riLeftPos As Integer, ByVal riTopPos As Integer, _
                                            ByVal rsBarType As String) As String
        Dim sFn As String = "fnMakePrtMsg"

        Try

            'ro_Data.INFINFO = "S/MRSA"
            Dim a_sInfInfo As String() = ro_Data.INFINFO.Split("/"c)

            Dim sPrtBuf As String = ""
            Dim iXposS As Integer = 0
            Dim iUPosS As Integer = 0

            Dim sXpos As String = ""
            Dim sypos As String = ""

            Dim iHanCnt As Integer = 0

            '>>>>>>>>>>>>> 설정한 인쇄 내용의 시작 < 시작점 초기화>
            sPrtBuf += Chr(2) & "L" & Chr(13)

            '>>>>> 단위를 인치에서 미터로 변경함을 말함 
            sPrtBuf += Chr(2) & "m" & Chr(13)




            'Setting
            '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ' 프린트가능한 프린트 속도
            sPrtBuf += "P3" + Chr(13)

            ' 프린트 가능하지 않은 프린트 속도
            sPrtBuf += "S3" + Chr(13)

            'Pixel Size 셋팅 
            sPrtBuf += "D11" + Chr(13)


            'OffSet 설정(Colum의 방향) < 미터시스템 0000~9999 (0.0 mm 99.9mm)
            sPrtBuf += "C0030" + Chr(13)

            'OffSet 설정(Row 의 방향) < 미터시스템 0000~9999 (0.0 mm 99.9mm)
            sPrtBuf += "R0020" + Chr(13)



            ''< 검체번호   & 바코드 발행 일시  
            sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + "0260" + "KD24" + ro_Data.BCNO + "       " + Fn.GetServerDateTime.ToString("HH:mm") + Chr(13)




            '< 감염정보   
            If ro_Data.INFINFO = "" Then
            Else
                Dim iPosH As Integer = 210


                For ix As Integer = 0 To a_sInfInfo.Length - 1
                    Dim sPosH As String = "0" + CStr(iPosH)

                    If ix > 2 Then Exit For
                    sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + sPosH + "KD24" + a_sInfInfo(ix).ToString() + Chr(13)
                Next

                iPosH += 25

            End If



            '< 바코드  
            If ro_Data.BCNOPRT <> "" Then

                ' CODAR BAR 
                sPrtBuf += "2" + "d" + "6" + "2" + "080" + "0330" + "0230" + ro_Data.BCNOPRT.Trim + Chr(13)

                '< 바코드 번호 & 성별/나이 
                sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0290" + "0190" + "KD24" + ro_Data.BCNOPRT.Trim + "   " + ro_Data.SEXAGE + Chr(13)


            Else
                '< 미수납 바코드  
                sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + "0230" + "미채혈바코드" + Chr(13)

                '< 성별/나이 
                sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0210" + "0190" + "KD24" + ro_Data.SEXAGE + Chr(13)
            End If

            '< 등록번호 sPID   & 환자명 & 진료과/병동/병실 
            sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + "0160" + "KD24" + ro_Data.REGNO + " " + ro_Data.PATNM + "  " + ro_Data.DEPTWARD + Chr(13)



            '< sRemark  
            sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0060" + "0210" + "KD24" + IIf(ro_Data.REMARK = "", "", "C").ToString() + Chr(13)



            If ro_Data.BCCLSCD = PRG_CONST.BCCLS_BldCrossMatch Or ro_Data.BCCNT = "B" Then
                '< 검체명 & 용기명
                sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + "0130" + "KD24" + ro_Data.TUBENM + "  " + ro_Data.SPCNM + "  " + Chr(13)


                '< 채혈자
                sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0130" + "0100" + "KD24" + fnGet_Hangle_Font_1("채혈자:") + Chr(13)

                '< 확인자

                sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0130" + "0070" + "KD24" + fnGet_Hangle_Font_1("확인자:") + Chr(13)





            Else
                If ro_Data.BCTYPE = "M" Then
                    sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0190" + "0100" + "KD24" + ro_Data.SPCNM + "      " + ro_Data.BCNO_MB + Chr(13)


                Else
                    '< 검체명 & 용기명& 검사그룹
                    sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + "0130" + "KD24" + ro_Data.TUBENM + "  " + ro_Data.SPCNM + "  " + ro_Data.TGRPNM + Chr(13)



                    '< 응급 sEmer   
                    If ro_Data.EMER <> "" Then
                        sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0060" + "0190" + "KD24" + ro_Data.EMER + Chr(13)
                    End If




                    Dim sTestNms As String = ro_Data.TESTNMS

                    '>>>>>>>>>>>>>>>>>>>>>>>>> 검사명 두줄 처리를 위한 잘라내기 '>>>>>>>>>>>>>>>>>>>>>>
                    Dim sLine1 As String = ""
                    Dim sLine2 As String = ""

                    If ro_Data.TESTNMS.Length < 31 Then
                        sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + "0100" + "KD24" + ro_Data.BCCLSCD + "  " + sTestNms + Chr(13)


                    Else
                        sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + "0100" + "KD24" + ro_Data.BCCLSCD + "  " + sTestNms.Substring(0, 30) + Chr(13)

                        If ro_Data.TESTNMS.Length > 60 Then

                            sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + "0070" + "KD24" + sTestNms.Substring(30, 56) + "..." + Chr(13)
                        Else
                            sPrtBuf += "2" + Chr(27) + "1" + "1" + "004" + "0365" + "0070" + "KD24" + sTestNms.Substring(30, ro_Data.TESTNMS.Length - sLine1.Length - 1) + Chr(13)
                        End If

                    End If

                    '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


                End If
            End If

            '< 라인 마지막 
            sPrtBuf += "LQ001" + Chr(13)
            sPrtBuf += "E" + Chr(13)


            Return sPrtBuf

        Catch ex As Exception
            Fn.log(mcFile + sFn, Err)
            MsgBox(mcFile + sFn + vbCrLf + ex.Message)

            Return ""
        Finally

        End Try

    End Function

    Protected Overridable Function fnMakePrtMsg_RIS(ByVal ro_Data As STU_BCPRTINFO, _
                                                ByVal rbFirst As Boolean, _
                                                ByVal riLeftPos As Integer, ByVal riTopPos As Integer, _
                                                ByVal rsBarType As String, ByVal rsPrintPort As String) As String

        Dim sTestCds As String = ro_Data.TESTCD
        Dim iTop As Integer = riTopPos - 5
        Dim sLine1 As String = ""
        Dim sLine2 As String = ""
        Dim sLine3 As String = ""

        riLeftPos += 20

        Select Case ro_Data.TESTCD.Length
            Case Is < 24
                sLine1 = sTestCds.Substring(0, sTestCds.Length)
            Case Is < 48
                sLine1 = sTestCds.Substring(0, 24)
                sLine2 = sTestCds.Substring(24, sTestCds.Length - 24)
            Case Is < 72
                sLine1 = sTestCds.Substring(0, 24)
                sLine2 = sTestCds.Substring(24, 24)
                sLine3 = sTestCds.Substring(48, sTestCds.Length - 48)
            Case Else
                sLine1 = sTestCds.Substring(0, 24)
                sLine2 = sTestCds.Substring(24, 24)
                sLine3 = sTestCds.Substring(48, sTestCds.Length - 72) + ", ..."
        End Select

        Dim sFn As String = "fnMakePrtMsg_RIS"

        Try

            Dim sPrtBuf As String = ""
            Dim iXposS As Integer = 0
            Dim iUPosS As Integer = 0

            Dim sXpos As String = ""
            Dim sypos As String = ""

            Dim iHanCnt As Integer = 0

            '>>>>>>>>>>>>> 설정한 인쇄 내용의 시작 < 시작점 초기화>
            sPrtBuf += Chr(2) & "m" & Chr(13)

            '>>>>> 단위를 인치에서 미터로 변경함을 말함 
            sPrtBuf += Chr(2) & "L"

            Dim sSpcNm As String = ro_Data.SPCNM
            Dim sTubeNm As String = ro_Data.TUBENM
            Dim sTGrpNm As String = ro_Data.TGRPNM

            'Setting
            '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ' 프린트가능한 프린트 속도
            sPrtBuf += "D11"

            ' 프린트 가능하지 않은 프린트 속도
            sPrtBuf += "P6"

            'Pixel Size 셋팅 
            sPrtBuf += "S6"

            sPrtBuf += "H20z" + Chr(13)
            '< 등록번호
            sPrtBuf += "1" + Chr(27) + "1" + "2" + "001" + "0240" + "0040" + "KR24" + ro_Data.REGNO + Chr(13)

            '< 성별/나이 
            'Dim sSexAge As String = ro_Data.SEXAGE
            sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + "0220" + "0365" + "KR24" + ro_Data.SEXAGE + Chr(13)
            '< 환자명 
            'Dim sPatNm As String = ro_Data.PATNM
            sPrtBuf += "1" + Chr(27) + "1" + "2" + "001" + "0240" + "0195" + "KR24" + ro_Data.PATNM + Chr(13)
            '< 검체명
            sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + "0200" + "0040" + "KR24" + ro_Data.SPCNM + "     " + ro_Data.DEPTWARD + Chr(13)
            '< 용기명 
            sPrtBuf += "1" + Chr(27) + "1" + "2" + "001" + "0150" + "0035" + "KR24" + sTubeNm.Substring(0, 8) + "-" + Chr(13)
            '< 용기명 
            sPrtBuf += "1" + Chr(27) + "2" + "2" + "001" + "0150" + "0165" + "KR24" + sTubeNm.Substring(8) + Chr(13)
            '< 처방날짜
            Dim sOrdDt As String = ro_Data.ORDDT
            sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + "0110" + "0035" + "KR24" + "처방일자 : " + ro_Data.ORDDT + Chr(13)

            If sLine1 <> "" Then
                sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + "0070" + "0035" + "KR24" + sLine1 + Chr(13)
                If sLine2 <> "" Then
                    sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + "0050" + "0035" + "KR24" + sLine2 + Chr(13)
                    If sLine3 <> "" Then
                        sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + "0030" + "0035" + "KR24" + sLine3 + Chr(13)
                    End If
                End If
            End If

            '-- 연속검사일 시 검사명 표시
            If ro_Data.SEQTYN <> "" Then
                sPrtBuf += "1" + Chr(27) + "1" + "1" + "001" + "0010" + "0035" + "KR24" + ro_Data.SEQTYN + Chr(13)
            End If

            '< 라인 마지막
            sPrtBuf += "Q0001" + Chr(13)
            sPrtBuf += "E" + Chr(13)

            Return sPrtBuf

        Catch ex As Exception
            Fn.log(mcFile + sFn, Err)
            MsgBox(mcFile + sFn + vbCrLf + ex.Message)

            Return ""
        Finally

        End Try
    End Function

    '20130908 이상백
    Public Overridable Function BarCodePrtOut_RIS(ByVal ra_PrtData As ArrayList, _
                                               ByVal rsPrintPort As String, ByVal rsSocketIP As String, ByVal rbFirst As Boolean, _
                                               Optional ByVal riLeftPos As Integer = 0, _
                                               Optional ByVal riTopPos As Integer = 0, _
                                               Optional ByVal rsBarType As String = "CODABAR", Optional ByVal rsUseSide As String = "C") As Boolean
        Dim sFn As String = "BarCodePrtOut"
        Dim bReturn As Boolean = False
        Dim iFileNo As Integer = 0
        Dim sPrtMsg = ""
        Dim sWkNo As String = ""

        Try
            For ix1 As Integer = 0 To ra_PrtData.Count - 1
                If CType(ra_PrtData(ix1), STU_BCPRTINFO).REGNO <> "" Then

                    If sWkNo <> CType(ra_PrtData(ix1), STU_BCPRTINFO).TUBENM Then    '같은 작업번호(작업그룹)는 1회만 출력한다.
                        sWkNo = CType(ra_PrtData(ix1), STU_BCPRTINFO).TUBENM
                    Else
                        Continue For
                    End If

                    'If rsUseSide = "C" Then

                    sPrtMsg = fnMakePrtMsg_RIS(CType(ra_PrtData(ix1), STU_BCPRTINFO), rbFirst, riLeftPos, riTopPos, rsBarType, rsPrintPort)
                    'ElseIf rsUseSide = "L" Then
                    ' sPrtMsg = fnMakePrtMsgLeft(CType(ra_PrtData(ix1), STU_BCPRTINFO), rbFirst, riLeftPos, riTopPos, rsBarType)

                    'Else
                    'sPrtMsg = fnMakePrtMsgRight(CType(ra_PrtData(ix1), STU_BCPRTINFO), rbFirst, riLeftPos, riTopPos, rsBarType)
                    'End If

                    Dim iPrtCnt As Integer = 1

                    If sPrtMsg <> "" Then
                        If CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT = "A" Then
                            iPrtCnt = 2
                        ElseIf CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT = "B" Then
                            '< CrossMatching 검체
                            iPrtCnt = 2
                        ElseIf IsNumeric(CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT) Then
                            iPrtCnt = Convert.ToInt32(CType(ra_PrtData(ix1), STU_BCPRTINFO).BCCNT)
                        End If

                        For ix2 As Integer = 1 To iPrtCnt
                            If rsPrintPort.Trim() = "" Then
                                Dim objSkt As New TCP01.SendSocket

                                objSkt.sbConnectCliSocketToSvrSocket(rsSocketIP, 13734)

                                If objSkt.fnSendMsgOneConn("ITM", sPrtMsg) Then
                                    bReturn = True
                                End If

                                objSkt.sbDispose()

                                Dim sFileNm As String = Application.StartupPath + "\BCPRT.TXT"

                                iFileNo = FreeFile()
                                Try
                                    FileOpen(iFileNo, sFileNm, OpenMode.Output)

                                Catch ex As Exception
                                    sFileNm = Application.StartupPath + "\BCPRT_" + Format(Now, "yyMMddHHmmss") + ".TXT"
                                    FileOpen(iFileNo, sFileNm, OpenMode.Output)
                                End Try

                                Print(iFileNo, sPrtMsg)
                                FileClose(iFileNo)

                                Dim msComm As New COMM
                                'msComm.sbSendComm(sPrtMsg) '상호 주석 20130505
                                '<상호 수정 20130505
                                Dim iComport = CInt(rsPrintPort.Substring(Len(rsPrintPort) - 1))
                                msComm.sbSendComm(sPrtMsg, iComport)
                            Else
                                'Dim oBarPrt As New BarPrtParams
                                'Dim bTcpIP As Boolean = False
                                'oBarPrt = (New BCPRT01.Print_Set).fnGet_PrinterParams_Shared(rsPrintPort.Trim(), bTcpIP)

                                'If oBarPrt Is Nothing Then
                                '    Dim sFileNm As String = Application.StartupPath + "\BCPRT.TXT"

                                '    iFileNo = FreeFile()
                                '    Try
                                '        FileOpen(iFileNo, sFileNm, OpenMode.Output)

                                '    Catch ex As Exception
                                '        sFileNm = Application.StartupPath + "\BCPRT_" + Format(Now, "yyMMddHHmmss") + ".TXT"
                                '        FileOpen(iFileNo, sFileNm, OpenMode.Output)
                                '    End Try

                                '    Print(iFileNo, sPrtMsg)
                                '    FileClose(iFileNo)

                                '    IO.File.Copy(sFileNm, rsPrintPort.Trim())

                                'Else
                                '    Dim sFileNm As String = Application.StartupPath + "\BCPRT.TXT"

                                '    iFileNo = FreeFile()
                                '    Try
                                '        FileOpen(iFileNo, sFileNm, OpenMode.Output)

                                '    Catch ex As Exception
                                '        sFileNm = Application.StartupPath + "\BCPRT_" + Format(Now, "yyMMddHHmmss") + ".TXT"
                                '        FileOpen(iFileNo, sFileNm, OpenMode.Output)
                                '    End Try

                                '    Print(iFileNo, sPrtMsg)
                                '    FileClose(iFileNo)

                                '    Process.Start("cmd.exe", "/C TYPE " + sFileNm + " > " + rsPrintPort.Trim())
                                'End If
                                Dim strFileNm As String = Application.StartupPath + "\BCPRT.TXT"

                                iFileNo = FreeFile()
                                Try
                                    FileOpen(iFileNo, strFileNm, OpenMode.Output)

                                Catch ex As Exception
                                    strFileNm = Application.StartupPath + "\BCPRT_" + Format(Now, "yyMMddHHmmss") + ".TXT"
                                    FileOpen(iFileNo, strFileNm, OpenMode.Output)
                                End Try

                                Print(iFileNo, sPrtMsg)
                                FileClose(iFileNo)

                                Dim msComm As New COMM
                                'msComm.sbSendComm(sPrtMsg) '상호 주석 20130505
                                '<상호 수정 20130505
                                Dim iComport = CInt(rsPrintPort.Substring(Len(rsPrintPort) - 1))
                                msComm.sbSendComm(sPrtMsg, iComport)
                                'Process.Start("cmd.exe", "/C TYPE " + strFileNm + " > " + rsPrintPort.Trim())
                                'Process.Start("cmd.exe", "/C TYPE " + Chr(34) + strFileNm + Chr(34) + " > " + rsPrintPort.Trim())
                                'Dim msComm As New COMM
                                'msComm.sbSendComm(sPrtMsg)
                            End If

                            Threading.Thread.Sleep(CInt(sPrtMsg.Length * 1.5))
                        Next
                    End If

                End If
            Next

            Return True
        Catch ex As Exception
            Fn.log(mcFile + sFn, Err)
            MsgBox(mcFile + sFn + vbCrLf + ex.Message)
            Return False
        Finally
            FileClose(iFileNo)

        End Try
    End Function





    'Protected Overridable Function fnMakePrtMsg_BLD(ByVal ro_Data As STU_BLDLABEL) As String
    '    Dim sFn As String = "fnMakePrtMsg"

    '    Try
    '        Dim sPrtBuf As String = ""
    '        Dim sCrLf As String = Chr(13) + Chr(10)

    '        Dim iMaxLen As Integer = 33

    '        '< 기본설정 
    '        sPrtBuf = ""
    '        'sPrtBuf = sPrtBuf + "I8,1,001" + vbCrLf

    '        'sPrtBuf = sPrtBuf + "D" + vbCrLf        '-- 감열 = OD, 리본 = D
    '        'sPrtBuf = sPrtBuf + "Q464,24" + vbCrLf  '-- Label Length, Gap Length
    '        'sPrtBuf = sPrtBuf + "q696" + vbCrLf     '-- Label(Width)
    '        'sPrtBuf = sPrtBuf + "S4" + vbCrLf       '-- speed
    '        'sPrtBuf = sPrtBuf + "D8" + vbCrLf       '-- 농도
    '        'sPrtBuf = sPrtBuf + "ZT" + vbCrLf
    '        'sPrtBuf = sPrtBuf + "JF" + vbCrLf       '-- FB
    '        sPrtBuf = sPrtBuf & "N" + vbCrLf

    '        '< 등록번호
    '        sPrtBuf = sPrtBuf + "A170,20,0,3,1,2,N," + Chr(34) + ro_Data.REGNO + Chr(34) + vbCrLf

    '        '< 환자명  
    '        sPrtBuf = sPrtBuf + "A500,25,0,8,2,1,N," + Chr(34) + ro_Data.PATNM + Chr(34) + vbCrLf

    '        '< 진료과/병동/병실  
    '        sPrtBuf = sPrtBuf + "A180,68,0,3,1,1,N," + Chr(34) + ro_Data.DEPTWARD + Chr(34) + vbCrLf

    '        '< 성별/나이 
    '        sPrtBuf = sPrtBuf + "A530,68,0,3,1,1,N," + Chr(34) + ro_Data.SEXAGE + Chr(34) + vbCrLf

    '        '< 환자 혈액형 
    '        sPrtBuf = sPrtBuf + "A220,95,0,3,1,2,N," + Chr(34) + ro_Data.PAT_ABORH + Chr(34) + vbCrLf

    '        '< 출고 혈액형 
    '        sPrtBuf = sPrtBuf + "A550,95,0,3,1,2,N," + Chr(34) + ro_Data.BLD_ABORH + Chr(34) + vbCrLf

    '        ''< 혈액종류 
    '        Dim bHangul As Boolean = False
    '        For iLen As Integer = 0 To ro_Data.COMNM.Length - 1
    '            If Char.GetUnicodeCategory(ro_Data.COMNM.Substring(iLen, 1)) = Globalization.UnicodeCategory.OtherLetter Then
    '                bHangul = True
    '                Exit For
    '            End If
    '        Next

    '        If bHangul Then
    '            sPrtBuf = sPrtBuf + "A170,143,0,8,1,1,N," + Chr(34) + ro_Data.COMNM + Chr(34) + vbCrLf
    '        Else
    '            sPrtBuf = sPrtBuf + "A170,143,0,2,1,1,N," + Chr(34) + ro_Data.COMNM + Chr(34) + vbCrLf
    '        End If


    '        '< 적합부적합
    '        If ro_Data.XMATCH1 = "-" Then ro_Data.XMATCH1 = "적합"
    '        If ro_Data.XMATCH1 = "+" Then ro_Data.XMATCH1 = "부적합"

    '        If ro_Data.XMATCH2 = "-" Then ro_Data.XMATCH2 = "적합"
    '        If ro_Data.XMATCH2 = "+" Then ro_Data.XMATCH2 = "부적합"

    '        'sPrtBuf = sPrtBuf + "A190,185,0,8,1,1,N," + Chr(34) + sRst1 + Chr(34) + vbCrLf
    '        sPrtBuf = sPrtBuf + "A190,215,0,8,1,1,N," + Chr(34) + ro_Data.XMATCH2 + Chr(34) + vbCrLf

    '        '-- 혈액번호
    '        If ro_Data.BLDNO.Count = 1 Then
    '            sPrtBuf = sPrtBuf + "A500,180,0,3,1,1,N," + Chr(34) + ro_Data.BLDNO(0) + Chr(34) + vbCrLf
    '        Else
    '            For ix As Integer = 0 To ro_Data.BLDNO.Count - 1
    '                sPrtBuf = sPrtBuf + "A500," + (150 + (ix * 30)).ToString + ",0,3,1,1,N," + Chr(34) + ro_Data.BLDNO(ix) + Chr(34) + vbCrLf
    '            Next
    '        End If

    '        '< IR
    '        'sIR = "1" : sFilter_in = "1"
    '        sPrtBuf = sPrtBuf + "A190,263,0,3,1,1,N," + Chr(34) + IIf(ro_Data.IR = "1", "Y", "").ToString().PadLeft(1, " "c) + "/" + IIf(ro_Data.FITER = "1", "F", "").ToString + Chr(34) + vbCrLf
    '        '>

    '        '< 확인
    '        sPrtBuf = sPrtBuf + "A450,263,0,3,1,1,N," + Chr(34) + "OK" + Chr(34) + vbCrLf
    '        '>


    '        '< 검사자
    '        sPrtBuf = sPrtBuf + "A180,303,0,8,1,1,N," + Chr(34) + ro_Data.BEFOUTNM + Chr(34) + vbCrLf

    '        '< 검사일자
    '        sPrtBuf = sPrtBuf + "A500,303,0,2,1,1,N," + Chr(34) + ro_Data.BEFOUTDT + Chr(34) + vbCrLf

    '        '< 출고자
    '        sPrtBuf = sPrtBuf + "A180,343,0,8,1,1,N," + Chr(34) + ro_Data.OUTNM + Chr(34) + vbCrLf

    '        '< 출고일자
    '        sPrtBuf = sPrtBuf + "A500,343,0,2,1,1,N," + Chr(34) + ro_Data.OUTDT + Chr(34) + vbCrLf

    '        '< 수령자
    '        sPrtBuf = sPrtBuf + "A180,383,0,8,1,1,N," + Chr(34) + ro_Data.RECNM + Chr(34) + vbCrLf


    '        '< 라인 마지막 
    '        sPrtBuf = sPrtBuf & "P1" + vbCrLf
    '        '>  

    '        Return sPrtBuf

    '    Catch ex As Exception
    '        Fn.log(mcFile + sFn, Err)
    '        MsgBox(mcFile + sFn + vbCrLf + ex.Message)

    '        Return ""

    '    End Try
    'End Function

  

    Public Function fnGet_Hangle_Font_1(ByVal rsValue As String) As String
        '한글 변환(KS-5601)
        Try
            Dim btBuf As Byte() = System.Text.Encoding.Default.GetBytes(rsValue)

            Dim sFont As String = ""
            Dim ix As Integer = 0
            Dim iPos As Integer = 0

            Do While ix < btBuf.Length - 1
                If btBuf(ix) > 128 Then
                    sFont += Chr(27) + "K2B" + Chr(btBuf(ix) - 128) + Chr(btBuf(ix + 1) - 128)
                    ix += 2
                Else
                    sFont += Chr(27) + "M" + rsValue.Substring(iPos, 1)
                    ix += 1
                End If

                iPos += 1
            Loop

            Return sFont

        Catch ex As Exception

            Return ""
            MsgBox(ex.Message)
        End Try

    End Function

    Public Function fnGet_Hangle_Font_2(ByVal rsValue As String) As String
        '한글 바탕(명조)
        Try
            Dim btBuf As Byte() = System.Text.Encoding.Default.GetBytes(rsValue)

            Dim sFont As String = ""
            Dim ix As Integer = 0
            Dim iPos As Integer = 0

            Do While ix < btBuf.Length
                If btBuf(ix) > 128 Then
                    sFont += Chr(27) + "PR" + Chr(27) + "RF010002," + rsValue.Substring(iPos, 1)
                    ix += 2
                Else
                    sFont += Chr(27) + "PS" + Chr(27) + "RF010002," + "0" + rsValue.Substring(iPos, 1)
                    ix += 1
                End If
                iPos += 1
            Loop

            Return sFont

        Catch ex As Exception
            Return ""
            MsgBox(ex.Message)
        End Try
    End Function

    Public Function fnGet_Hangle_Font_3(ByVal rsValue As String) As String
        '한글(굴림(고딕))
        Try
            Dim btBuf As Byte() = System.Text.Encoding.Default.GetBytes(rsValue)

            Dim sFont As String = ""
            Dim ix As Integer = 0
            Dim iPos As Integer = 0

            Do While ix < btBuf.Length
                If btBuf(ix) > 128 Then
                    sFont += Chr(27) + "PR" + Chr(27) + "RF020002," + rsValue.Substring(iPos, 1)
                    ix += 2
                Else
                    sFont += Chr(27) + "PS" + Chr(27) + "RF020002," + "0" + rsValue.Substring(iPos, 1)
                    ix += 1
                End If
                iPos += 1
            Loop

            Return sFont

        Catch ex As Exception
            Return ""
            MsgBox(ex.Message)
        End Try
    End Function

End Class
