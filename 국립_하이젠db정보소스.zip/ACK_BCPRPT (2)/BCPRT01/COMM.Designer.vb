﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class COMM
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(COMM))
        Me.msComm = New AxMSCommLib.AxMSComm()
        Me.mSerial = New System.IO.Ports.SerialPort(Me.components)
        CType(Me.msComm, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'msComm
        '
        Me.msComm.Enabled = True
        Me.msComm.Location = New System.Drawing.Point(53, 45)
        Me.msComm.Name = "msComm"
        Me.msComm.OcxState = CType(resources.GetObject("msComm.OcxState"), System.Windows.Forms.AxHost.State)
        Me.msComm.Size = New System.Drawing.Size(38, 38)
        Me.msComm.TabIndex = 0
        '
        'COMM
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 262)
        Me.Controls.Add(Me.msComm)
        Me.Name = "COMM"
        Me.Text = "comm"
        CType(Me.msComm, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents msComm As AxMSCommLib.AxMSComm
    Friend WithEvents mSerial As System.IO.Ports.SerialPort
End Class
