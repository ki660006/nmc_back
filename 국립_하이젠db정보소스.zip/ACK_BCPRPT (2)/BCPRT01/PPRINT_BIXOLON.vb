﻿Imports COMMON.SVar
Imports COMMON.CommFN
Imports COMMON.CommFN.Fn
Imports COMMON.CommPrint
Imports COMMON.CommLogin.LOGIN

Imports System.Drawing
Imports System.Drawing.Printing

Public Class PPRINT_BIXOLON

    Private Const msFile As String = "File : TMPPRINT.vb, Class : TMPPRINT" + vbTab

    Private ma_PrtData As New ArrayList
    Private miLeftPos As Integer = 0
    Private miTopPos As Integer = 0
    Private mi_Copy As Integer = 1
    Private mb_First As Boolean = False
    Private PrtIdx As Integer = 0
    'Public Overridable Function BarCodePrtOut_CheckOut(ByVal ra_PrtData As ArrayList, _
    '                                        ByVal rsPrintPort As String, ByVal rsSocketIP As String, ByVal rbFirst As Boolean, _
    '                                        Optional ByVal riLeftPos As Integer = 0, _
    '                                        Optional ByVal riTopPos As Integer = 0, _
    '                                        Optional ByVal rsBarType As String = "CODABAR", _
    '                                        Optional ByVal rbLabelGbn As Boolean = False) As Boolean
    '    Dim sFn As String = "BarCodePrtOut"
    '    Try
    '        ma_PrtData = ra_PrtData
    '        miLeftPos = riLeftPos
    '        miTopPos = riTopPos
    '        mb_First = rbFirst

    '        Dim prtR As New PrintDocument

    '        Dim prtDialog As New PrintDialog
    '        Dim prtBPress As New DialogResult

    '        prtDialog.Document = prtR
    '        prtR.DocumentName = "BARPRINT"
    '        prtR.PrinterSettings.PrinterName = rsPrintPort

    '        If rbFirst = True And CType(ra_PrtData(0), STU_BCPRTINFO).BCNO = "" And CType(ra_PrtData(0), STU_BCPRTINFO).FORM = "" Then
    '            '혈액은행 접수 라벨 내역 (FGB06_CBUH) 
    '            For Me.PrtIdx = 0 To ma_PrtData.Count - 1
    '                AddHandler prtR.PrintPage, AddressOf sbPrintPage_BloodJubSuLabel
    '                AddHandler prtR.BeginPrint, AddressOf sbPrintData
    '                AddHandler prtR.EndPrint, AddressOf sbReport

    '                prtR.Print()
    '            Next
    '        ElseIf rbFirst = True And CType(ra_PrtData(0), STU_BCPRTINFO).BCNO = "" And CType(ra_PrtData(0), STU_BCPRTINFO).FORM = "FGB09" Then

    '            '혈액은행 접수 라벨 내역 (FGB06_CBUH) 
    '            For Me.PrtIdx = 0 To ma_PrtData.Count - 1
    '                AddHandler prtR.PrintPage, AddressOf sbPrintPage_BloodOUTLABEL
    '                AddHandler prtR.BeginPrint, AddressOf sbPrintData
    '                AddHandler prtR.EndPrint, AddressOf sbReport

    '                prtR.Print()
    '            Next
    '        Else
    '            '바코드 재출력 라벨 내역 (FGJ03)


    '            '<-------- test bccnt(바코드구분) 출력 장수 설정
    '            'Dim iPrtCnt As Integer = 1

    '            'If CType(ra_PrtData(0), STU_BCPRTINFO).BCCNT = "A" Then
    '            '    iPrtCnt = 2
    '            'ElseIf CType(ra_PrtData(0), STU_BCPRTINFO).BCCNT = "B" Then
    '            '    '< CrossMatching 검체
    '            '    iPrtCnt = 3
    '            'ElseIf IsNumeric(CType(ra_PrtData(0), STU_BCPRTINFO).BCCNT) Then
    '            '    iPrtCnt = Convert.ToInt32(CType(ra_PrtData(0), STU_BCPRTINFO).BCCNT)
    '            'End If

    '            'For i As Integer = 1 To iPrtCnt
    '            '    AddHandler prtR.PrintPage, AddressOf sbPrintPage
    '            '    AddHandler prtR.BeginPrint, AddressOf sbPrintData
    '            '    AddHandler prtR.EndPrint, AddressOf sbReport

    '            '    prtR.Print()
    '            'Next
    '            '--------->


    '            AddHandler prtR.PrintPage, AddressOf sbPrintPage
    '            AddHandler prtR.BeginPrint, AddressOf sbPrintData
    '            AddHandler prtR.EndPrint, AddressOf sbReport

    '            prtR.Print()

    '        End If

    '        Return True
    '    Catch ex As Exception
    '        Fn.log(msFile + sFn, Err)
    '        MsgBox(msFile + sFn + vbCrLf + ex.Message)
    '        Return False
    '    End Try
    'End Function
    Public Overridable Function BarCodePrtOut(ByVal ra_PrtData As ArrayList, _
                                              ByVal rsPrintPort As String, ByVal rsSocketIP As String, ByVal rbFirst As Boolean, _
                                              Optional ByVal riLeftPos As Integer = 0, _
                                              Optional ByVal riTopPos As Integer = 0, _
                                              Optional ByVal rsBarType As String = "CODABAR", _
                                              Optional ByVal rbLabelGbn As Boolean = False) As Boolean
        Dim sFn As String = "BarCodePrtOut"

        '  MsgBox("barcode")
        Try
            ma_PrtData = ra_PrtData
            miLeftPos = riLeftPos
            miTopPos = riTopPos
            mb_First = rbFirst

            Dim prtR As New PrintDocument

            Dim prtDialog As New PrintDialog
            Dim prtBPress As New DialogResult

            prtDialog.Document = prtR
            prtR.DocumentName = "BARPRINT"
            prtR.PrinterSettings.PrinterName = rsPrintPort
            'MsgBox("출발")
            If rbFirst = True And CType(ra_PrtData(0), STU_BCPRTINFO).BCNO = "" And CType(ra_PrtData(0), STU_BCPRTINFO).FORM = "" Then
                'MsgBox("barcode1")
                '혈액은행 접수 라벨 내역 (FGB06_CBUH) 
                For Me.PrtIdx = 0 To ma_PrtData.Count - 1
                    AddHandler prtR.PrintPage, AddressOf sbPrintPage_BloodJubSuLabel
                    AddHandler prtR.BeginPrint, AddressOf sbPrintData
                    AddHandler prtR.EndPrint, AddressOf sbReport
                    ' MsgBox("barcode33")
                    prtR.Print()
                    'MsgBox("barcode35")
                Next
            ElseIf rbFirst = True And CType(ra_PrtData(0), STU_BCPRTINFO).BCNO = "" And CType(ra_PrtData(0), STU_BCPRTINFO).FORM = "FGB09" Then
                'MsgBox("barcode2")
                '혈액은행 접수 라벨 내역 (FGB06_CBUH) 
                For Me.PrtIdx = 0 To ma_PrtData.Count - 1
                    AddHandler prtR.PrintPage, AddressOf sbPrintPage_BloodOUTLABEL
                    AddHandler prtR.BeginPrint, AddressOf sbPrintData
                    AddHandler prtR.EndPrint, AddressOf sbReport
                    ' MsgBox("barcode4")
                    prtR.Print()
                    'MsgBox("barcode6")
                Next
            Else
                '바코드 재출력 라벨 내역 (FGJ03)

                'MsgBox("장수간다")
                '<-------- test bccnt(바코드구분) 출력 장수 설정
                Dim iPrtCnt As Integer = 1

                If CType(ra_PrtData(0), STU_BCPRTINFO).BCCNT = "A" Then
                    iPrtCnt = 2
                ElseIf CType(ra_PrtData(0), STU_BCPRTINFO).BCCNT = "B" Then
                    '< CrossMatching 검체
                    iPrtCnt = 3
                ElseIf IsNumeric(CType(ra_PrtData(0), STU_BCPRTINFO).BCCNT) Then
                    iPrtCnt = Convert.ToInt32(CType(ra_PrtData(0), STU_BCPRTINFO).BCCNT)
                End If

                For i As Integer = 1 To iPrtCnt
                    AddHandler prtR.PrintPage, AddressOf sbPrintPage
                    AddHandler prtR.BeginPrint, AddressOf sbPrintData
                    AddHandler prtR.EndPrint, AddressOf sbReport

                    prtR.Print()
                Next
                '--------->


                'AddHandler prtR.PrintPage, AddressOf sbPrintPage
                'AddHandler prtR.BeginPrint, AddressOf sbPrintData
                'AddHandler prtR.EndPrint, AddressOf sbReport

                '' prtR.Print()

            End If

            Return True
        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            MsgBox(msFile + sFn + vbCrLf + ex.Message)
            Return False
        End Try
    End Function
    '20191220 nbm
    Public Overridable Function BarCodePrtOut_Ris(ByVal ra_PrtData As ArrayList, _
                                          ByVal rsPrintPort As String, ByVal rsSocketIP As String, ByVal rbFirst As Boolean, _
                                          Optional ByVal riLeftPos As Integer = 0, _
                                          Optional ByVal riTopPos As Integer = 0, _
                                          Optional ByVal rsBarType As String = "CODABAR", _
                                          Optional ByVal rbLabelGbn As Boolean = False) As Boolean
        Dim sFn As String = "BarCodePrtOut_Ris()"

        Try

            ma_PrtData = ra_PrtData
            miLeftPos = riLeftPos
            miTopPos = riTopPos
            mb_First = rbFirst
            Dim sWkNo As String = ""

            Dim prtR As New PrintDocument

            Dim prtDialog As New PrintDialog
            Dim prtBPress As New DialogResult

            prtDialog.Document = prtR
            prtR.DocumentName = "BARPRINT"
            prtR.PrinterSettings.PrinterName = rsPrintPort

            For Me.PrtIdx = 0 To ma_PrtData.Count - 1
                If sWkNo <> CType(ra_PrtData(PrtIdx), STU_BCPRTINFO).TUBENM Then    '같은 작업번호(작업그룹)는 1회만 출력한다.
                    sWkNo = CType(ra_PrtData(PrtIdx), STU_BCPRTINFO).TUBENM
                Else
                    Continue For
                End If

                If rbLabelGbn = True Then
                    '핵의학실 외부검사라벨 출력 
                    AddHandler prtR.PrintPage, AddressOf sbPrintPage_General
                Else
                    '핵의학실 분주 라벨 출력 (FGJ03)
                    AddHandler prtR.PrintPage, AddressOf sbPrintPage_RIS
                End If
                AddHandler prtR.BeginPrint, AddressOf sbPrintData
                AddHandler prtR.EndPrint, AddressOf sbReport

                prtR.Print()
            Next

            Return True
        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            MsgBox(msFile + sFn + vbCrLf + ex.Message)
            Return False
        End Try
    End Function
    '------------------------->
    Public Overridable Function BarCodePrtOut_BloodJubSuLabel(ByVal ra_PrtData As ArrayList, _
                                                              ByVal rsPrintPort As String, ByVal rsSocketIP As String, ByVal rbFirst As Boolean, _
                                                              Optional ByVal riLeftPos As Integer = 0, _
                                                              Optional ByVal riTopPos As Integer = 0, _
                                                              Optional ByVal rsBarType As String = "CODABAR", _
                                                              Optional ByVal rbLabelGbn As Boolean = False) As Boolean
        Dim sFn As String = "BarCodePrtOut"

        Try
            ma_PrtData = ra_PrtData
            miLeftPos = riLeftPos
            miTopPos = riTopPos
            mb_First = rbFirst

            Dim prtR As New PrintDocument

            Dim prtDialog As New PrintDialog
            Dim prtBPress As New DialogResult

            prtDialog.Document = prtR
            prtR.DocumentName = "BARPRINT"
            prtR.PrinterSettings.PrinterName = rsPrintPort

            AddHandler prtR.PrintPage, AddressOf sbPrintPage_BloodJubSuLabel
            AddHandler prtR.BeginPrint, AddressOf sbPrintData
            AddHandler prtR.EndPrint, AddressOf sbReport

            prtR.Print()

            Return True
        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            MsgBox(msFile + sFn + vbCrLf + ex.Message)
            Return False
        End Try
    End Function
    Public Overridable Function BarCodePrtOut_BLD(ByVal ra_PrtData As ArrayList, ByVal riCopy As Integer, _
                                                  ByVal rsPrintPort As String, ByVal rsSocketIP As String, _
                                                  Optional ByVal riLeftPos As Integer = 0, _
                                                  Optional ByVal riTopPos As Integer = 0) As Boolean
        Dim sFn As String = "BarCodePrtOut_BLD"

        Try
            ma_PrtData = ra_PrtData
            miLeftPos = riLeftPos
            miTopPos = riTopPos
            mi_Copy = riCopy

            Dim prtR As New PrintDocument

            Dim prtDialog As New PrintDialog
            Dim prtBPress As New DialogResult

            prtDialog.Document = prtR
            prtR.DocumentName = "BLDPRINT"
            prtR.PrinterSettings.PrinterName = rsPrintPort

            AddHandler prtR.PrintPage, AddressOf sbPrintPage_blood
            AddHandler prtR.BeginPrint, AddressOf sbPrintData
            AddHandler prtR.EndPrint, AddressOf sbReport

            prtR.Print()

            Return True
        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            MsgBox(msFile + sFn + vbCrLf + ex.Message)
            Return False
        End Try

    End Function

    Public Overridable Sub sbPrintPage(ByVal sender As Object, ByVal e As PrintPageEventArgs)
        Dim sFn As String = "sbPrintPage"

        Try
            e.Graphics.PageUnit = GraphicsUnit.Millimeter

            Dim fnt_1 As New Font("굴림체", 6, FontStyle.Regular)
            Dim fnt_1_b As New Font("굴림체", 6, FontStyle.Bold)

            Dim fnt_2 As New Font("굴림체", 7, FontStyle.Regular)
            Dim fnt_2_b As New Font("굴림체", 7, FontStyle.Bold)

            Dim fnt_3_b As New Font("굴림체", 8, FontStyle.Bold)


            Dim fnt_3 As New Font("굴림체", 8, FontStyle.Regular)
            Dim fnt_4 As New Font("굴림체", 10, FontStyle.Bold)
            Dim fnt_5 As New Font("굴림체", 11, FontStyle.Bold)

            Dim fnt_6 As New Font("굴림체", 13, FontStyle.Bold)

            Dim fnt_b2 As New Font("굴림체", 7, FontStyle.Bold)
            Dim fnt_b3 As New Font("굴림체", 9, FontStyle.Bold)
            Dim fnt_b5 As New Font("굴림체", 11, FontStyle.Bold)

            Dim fnt_1_u As New Font("굴림체", 6, FontStyle.Underline)
            Dim fnt_5_u As New Font("굴림체", 11, FontStyle.Underline)
            Dim fnt_6_u As New Font("굴림체", 13, FontStyle.Underline)

            'Dim fnt_BarCd As New Font("Code39(2:3)", 24, FontStyle.Regular)
            Dim fnt_BarCd As New Font("Code39(2:3)", 24, FontStyle.Regular)
            'Dim fnt_BarCd As New Font("Code39One", 16, FontStyle.Regular)
            'Dim fnt_BarCd As New Font("Free 3 of 9", 24, FontStyle.Regular)

            Dim sf_c As New Drawing.StringFormat
            Dim sf_l As New Drawing.StringFormat
            Dim sf_r As New Drawing.StringFormat

            sf_c.LineAlignment = StringAlignment.Center : sf_c.Alignment = Drawing.StringAlignment.Center
            sf_l.LineAlignment = StringAlignment.Center : sf_l.Alignment = Drawing.StringAlignment.Near
            sf_r.LineAlignment = StringAlignment.Center : sf_r.Alignment = Drawing.StringAlignment.Far

            Dim intCnt As Integer = 0

            For ix1 As Integer = 0 To ma_PrtData.Count - 1
                If CType(ma_PrtData(ix1), STU_BCPRTINFO).REGNO <> "" Then
                    Dim iPrtCnt As Integer = 1

                    If CType(ma_PrtData(ix1), STU_BCPRTINFO).BCCNT = "A" Then
                        iPrtCnt = 2
                    ElseIf CType(ma_PrtData(ix1), STU_BCPRTINFO).BCCNT = "B" Then
                        '< CrossMatching 검체
                        iPrtCnt = 3
                    ElseIf IsNumeric(CType(ma_PrtData(ix1), STU_BCPRTINFO).BCCNT) Then
                        iPrtCnt = Convert.ToInt32(CType(ma_PrtData(ix1), STU_BCPRTINFO).BCCNT)
                    End If

                    For ix2 As Integer = 1 To iPrtCnt
                        Dim bpi As STU_BCPRTINFO = CType(ma_PrtData(ix1), STU_BCPRTINFO)

                        intCnt += 1
                        Dim intPosX As Integer = ((intCnt - 1) Mod 3)
                        Dim intPosY As Integer = intCnt / 3

                        If (intCnt * intPosY) + ((intCnt - 1) Mod 3) <> intCnt Then intPosY -= 1
                        If intPosY < 0 Then intPosY = 0

                        Dim sgLeft As Single = miLeftPos + 6 + 60 * intPosX
                        Dim sgTop As Single = miTopPos + 0 + 35 * intPosY

                        Dim rect As New Drawing.RectangleF
                        Dim sTmp As String = ""

                        If bpi.BCTYPE = "M" Then
                            '< 작업 그룹이 알맞게 설정이 되었는지 확인 
                            If bpi.WKGRPCD = "" Then
                                Throw (New Exception("작업그룹이 설정되었는지 확인하세요."))
                            End If
                            '< 작업번호
                            Dim sWkno As String = bpi.BCNO_MB.Substring(8, 2) + "-" + bpi.BCNO_MB.Substring(10)
                            rect = New Drawing.RectangleF(sgLeft, sgTop, 25, 5)
                            e.Graphics.DrawString(sWkno, fnt_6, Drawing.Brushes.Black, rect, sf_l)

                            '< 환자명 
                            rect = New Drawing.RectangleF(sgLeft + 24, sgTop, 25, 5)
                            e.Graphics.DrawString(bpi.PATNM, fnt_6, Drawing.Brushes.Black, rect, sf_l)

                            '< 검체번호 
                            rect = New Drawing.RectangleF(sgLeft, sgTop + 5, 30, 5)
                            e.Graphics.DrawString(bpi.BCNO, fnt_3, Drawing.Brushes.Black, rect, sf_l)

                            '< 성별/나이 
                            rect = New Drawing.RectangleF(sgLeft + 28, sgTop + 5, 20, 5)
                            e.Graphics.DrawString(bpi.SEXAGE, fnt_3, Drawing.Brushes.Black, rect, sf_l)

                            '< 바코드
                            rect = New Drawing.RectangleF(sgLeft, sgTop + 8, 500, 13)
                            e.Graphics.DrawString("*" + bpi.BCNOPRT.Substring(0, 11) + "*", fnt_BarCd, Drawing.Brushes.Black, rect, sf_l)

                            '< 검체명
                            rect = New Drawing.RectangleF(sgLeft, sgTop + 19, 20, 4)
                            e.Graphics.DrawString(bpi.SPCNM, fnt_5, Drawing.Brushes.Black, rect, sf_l)

                            ''< 배지명
                            rect = New Drawing.RectangleF(sgLeft + 25, sgTop + 19, 40, 4)
                            e.Graphics.DrawString(bpi.TGRPNM, fnt_5, Drawing.Brushes.Black, rect, sf_l)


                        Else
                            '-- 검체번호
                            rect = New Drawing.RectangleF(sgLeft, sgTop, 35, 4)
                            e.Graphics.DrawString(bpi.BCNO, fnt_4, Drawing.Brushes.Black, rect, sf_l)

                            '-- 발행일시
                            If mb_First Then
                                rect = New Drawing.RectangleF(sgLeft + 41, sgTop, 8, 3)
                                e.Graphics.DrawString(Fn.GetServerDateTime.ToString("HH:mm"), fnt_3_b, Drawing.Brushes.Black, rect, sf_l)
                            Else
                                Dim blackpen As Pen = New Pen(Color.Black, 2)
                                e.Graphics.DrawRectangle(blackpen, sgLeft + 41, sgTop, 8, 2)

                                rect = New Drawing.RectangleF(sgLeft + 40, sgTop, 9, 3)
                                e.Graphics.DrawString(Fn.GetServerDateTime.ToString("HH:mm"), fnt_3_b, Drawing.Brushes.White, rect, sf_l)
                            End If

                            '< 감염정보  
                            'bpi.INFINFO = "A/MRAS"
                            'rect = New Drawing.RectangleF(sgLeft + 32, sgTop + 30, 15, 4)
                            'e.Graphics.DrawString(bpi.INFINFO, fnt_b5, Drawing.Brushes.Black, rect, sf_l)

                            Dim a_sInfInfo As String() = bpi.INFINFO.Split("/"c)

                            For iCnt As Integer = 0 To a_sInfInfo.Length - 1
                                If iCnt > 1 Then Exit For

                                rect = New Drawing.RectangleF(sgLeft + 48, sgTop + 5 + 4 * iCnt, 5, 4)
                                e.Graphics.DrawString(a_sInfInfo(iCnt).ToString().Trim, fnt_2, Drawing.Brushes.Black, rect, sf_l)
                            Next

                            Dim sTestNm As String = bpi.TESTNMS.Trim
                            Dim sBarcNo As String = ""

                            If sTestNm.Length > 20 Then
                                sTestNm = sTestNm.Substring(0, 19) & "..."
                            End If

                            If sTestNm.IndexOf("...") > -1 Then
                                If sTestNm.Substring(0, sTestNm.IndexOf("...")).Length > 20 Then
                                    sTestNm = sTestNm.Substring(0, 19) & "..."
                                End If
                            End If

                            '< 바코드 
                            If bpi.BCNOPRT <> "" Then
                                rect = New Drawing.RectangleF(sgLeft - 1, sgTop + 3, 520, 13)
                                e.Graphics.DrawString("*" + bpi.BCNOPRT.Substring(0, 11) + "*", fnt_BarCd, Drawing.Brushes.Black, rect, sf_l)
                                rect = New Drawing.RectangleF(sgLeft - 2, sgTop + 13, 20, 5)
                                e.Graphics.DrawString(bpi.BCNOPRT, fnt_2, Drawing.Brushes.Black, rect, sf_c)
                            Else
                                rect = New Drawing.RectangleF(sgLeft, sgTop + 3, 40, 13)
                                e.Graphics.DrawString("미채혈바코드", fnt_6, Drawing.Brushes.Black, rect, sf_c)
                            End If

                            ''< 진료과/병동/병실  
                            rect = New Drawing.RectangleF(sgLeft + 26, sgTop + 15, 20, 2)
                            e.Graphics.DrawString(bpi.DEPTWARD, fnt_2, Drawing.Brushes.Black, rect, sf_l)

                            '외래전(OBFTSYN) - 등록번호 음영 표시
                            If bpi.OBFTSYN.Trim = "Y" Then
                                Dim blackpen2 As Pen = New Pen(Color.Black, 2)
                                e.Graphics.DrawRectangle(blackpen2, sgLeft, sgTop + 18, 18, 2)

                                ''< 등록번호 sPID
                                rect = New Drawing.RectangleF(sgLeft, sgTop + 17, 22, 5)
                                If PRG_CONST.BCCLS_ExLab.Contains(bpi.BCNO) Then
                                    e.Graphics.DrawString(bpi.REGNO, fnt_5_u, Drawing.Brushes.White, rect, sf_l)
                                Else
                                    e.Graphics.DrawString(bpi.REGNO, fnt_5, Drawing.Brushes.White, rect, sf_l)
                                End If

                            Else
                                ''< 등록번호 sPID
                                rect = New Drawing.RectangleF(sgLeft, sgTop + 17, 22, 5)
                                If PRG_CONST.BCCLS_ExLab.Contains(bpi.BCNO) Then
                                    e.Graphics.DrawString(bpi.REGNO, fnt_5_u, Drawing.Brushes.Black, rect, sf_l)
                                Else
                                    e.Graphics.DrawString(bpi.REGNO, fnt_5, Drawing.Brushes.Black, rect, sf_l)
                                End If
                            End If

                            ''< 환자명 
                            rect = New Drawing.RectangleF(sgLeft + 20, sgTop + 17, 25, 5)
                            e.Graphics.DrawString(bpi.PATNM, fnt_5, Drawing.Brushes.Black, rect, sf_l)

                            ''< 성별/나이 
                            rect = New Drawing.RectangleF(sgLeft + 38, sgTop + 17, 20, 5)
                            e.Graphics.DrawString(bpi.SEXAGE, fnt_5, Drawing.Brushes.Black, rect, sf_l)

                            ''< sRemark
                            ''sRemark = "C"
                            rect = New Drawing.RectangleF(sgLeft + 48, sgTop + 13, 10, 2)
                            e.Graphics.DrawString(IIf(bpi.REMARK = "", "", "C").ToString, fnt_2, Drawing.Brushes.Black, rect, sf_l)

                            If bpi.BCCLSCD = PRG_CONST.BCCLS_BldCrossMatch Or bpi.BCCNT = "B" Then
                                '< 용기명 
                                rect = New Drawing.RectangleF(sgLeft, sgTop + 25, 20, 4)
                                e.Graphics.DrawString(bpi.TUBENM, fnt_4, Drawing.Brushes.Black, rect, sf_l)

                                '< 채혈자
                                rect = New Drawing.RectangleF(sgLeft + 25, sgTop + 25, 10, 4)
                                e.Graphics.DrawString("채혈자:", fnt_4, Drawing.Brushes.Black, rect, sf_l)
                                '< 확인자
                                rect = New Drawing.RectangleF(sgLeft + 25, sgTop + 29, 10, 4)
                                e.Graphics.DrawString("확인자:", fnt_4, Drawing.Brushes.Black, rect, sf_l)
                                '< 음영
                                e.Graphics.DrawRectangle(Pens.Black, New Drawing.Rectangle(sgLeft, sgTop + 29, 20, 4))
                                rect = New Drawing.RectangleF(sgLeft, sgTop + 29, 20, 4)
                                e.Graphics.DrawString("X-Matching", fnt_4, Drawing.Brushes.Black, rect, sf_l)

                                'ElseIf bpi.BCCLSCD = PRG_CONST.BCCLS_BloodBank Then
                                '    '< 용기명 
                                '    rect = New Drawing.RectangleF(sgLeft, sgTop + 25, 20, 4)
                                '    e.Graphics.DrawString(bpi.TUBENM, fnt_4, Drawing.Brushes.Black, rect, sf_l)
                                '    '< 채혈자
                                '    rect = New Drawing.RectangleF(sgLeft + 25, sgTop + 25, 10, 4)
                                '    e.Graphics.DrawString("채혈자:", fnt_4, Drawing.Brushes.Black, rect, sf_l)
                                '    '< 확인자
                                '    rect = New Drawing.RectangleF(sgLeft + 25, sgTop + 29, 10, 4)
                                '    e.Graphics.DrawString("확인자:", fnt_4, Drawing.Brushes.Black, rect, sf_l)
                                '    '< 검사항목(음영)
                                '    If sTestNm.Length > 12 Then sTestNm = sTestNm.Substring(0, 12)
                                '    rect = New Drawing.RectangleF(sgLeft, sgTop + 29, 10, 4)
                                '    e.Graphics.DrawString(sTestNm, fnt_3, Drawing.Brushes.Black, rect, sf_l)

                            Else
                                If bpi.BCTYPE = "M" Then
                                    '< 검사그룹 sComment2
                                    rect = New Drawing.RectangleF(sgLeft + 30, sgTop + 27, 20, 4)
                                    e.Graphics.DrawString(bpi.TGRPNM, fnt_b3, Drawing.Brushes.Black, rect, sf_l)

                                    '< 미생물 검체번호
                                    rect = New Drawing.RectangleF(sgLeft, sgTop + 28, 40, 4)
                                    e.Graphics.DrawString(bpi.BCNO_MB, fnt_4, Drawing.Brushes.Black, rect, sf_l)

                                Else
                                    ''< 용기명 
                                    'rect = New Drawing.RectangleF(sgLeft + 23, sgTop + 25, 10, 4)
                                    'e.Graphics.DrawString(bpi.TUBENM, fnt_4, Drawing.Brushes.Black, rect, sf_l)

                                    ''< 검사그룹 sComment2
                                    ''bpi.TGRPNM = "H C E"
                                    'rect = New Drawing.RectangleF(sgLeft + 30, sgTop + 25, 10, 4)
                                    'e.Graphics.DrawString(bpi.TGRPNM, fnt_b3, Drawing.Brushes.Black, rect, sf_l)

                                    '< 용기명 
                                    rect = New Drawing.RectangleF(sgLeft, sgTop + 21, 20, 4)
                                    e.Graphics.DrawString(bpi.TUBENM, fnt_3, Drawing.Brushes.Black, rect, sf_l)

                                    '< 계 sKind
                                    rect = New Drawing.RectangleF(sgLeft, sgTop + 25, 6, 4)
                                    e.Graphics.DrawString(bpi.BCCLSCD, fnt_b5, Drawing.Brushes.Black, rect, sf_l)

                                    '< 검사항목명
                                    rect = New Drawing.RectangleF(sgLeft + 6, sgTop + 24, 50, 4)
                                    e.Graphics.DrawString(sTestNm, fnt_b2, Drawing.Brushes.Black, rect, sf_l)

                                    '< 검사그룹 sComment2
                                    'bpi.TGRPNM = "H C E"
                                    rect = New Drawing.RectangleF(sgLeft + 6, sgTop + 27, 20, 4)
                                    e.Graphics.DrawString(bpi.TGRPNM, fnt_2, Drawing.Brushes.Black, rect, sf_l)

                                    '< 응급과 초응급 구분 sEmer 
                                    'bpi.URGENT = "Y"
                                    'bpi.EMER = "Y"
                                    If bpi.URGENT.Equals("Y") Then
                                        Dim sE As String = bpi.URGENT
                                        If sE = "Y" Then
                                            sE = "E"
                                        End If

                                        '초응급(음영처리)
                                        Dim blackpen3 As Pen = New Pen(Color.Black, 2)
                                        e.Graphics.DrawRectangle(blackpen3, sgLeft + 48, sgTop + 26, 2, 2)

                                        rect = New Drawing.RectangleF(sgLeft + 48, sgTop + 26, 2, 3)
                                        e.Graphics.DrawString(sE, fnt_3_b, Drawing.Brushes.White, rect, sf_l)

                                    ElseIf bpi.EMER.Equals("Y") Or bpi.EMER.Equals("E") Then
                                        Dim sE As String = bpi.EMER
                                        If sE = "Y" Then
                                            sE = "E"
                                        End If
                                        '응급
                                        rect = New Drawing.RectangleF(sgLeft + 48, sgTop + 26, 2, 3)
                                        e.Graphics.DrawString(sE, fnt_3_b, Drawing.Brushes.Black, rect, sf_l)
                                    End If

                                End If
                            End If
                            ''< 검체명
                            rect = New Drawing.RectangleF(sgLeft + 30, sgTop + 21, 50, 4)
                            e.Graphics.DrawString(bpi.SPCNM, fnt_3, Drawing.Brushes.Black, rect, sf_l)

                        End If
                    Next
                End If
            Next

        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            MsgBox(msFile + sFn + vbCrLf + ex.Message)
        End Try

    End Sub
    Public Overridable Sub sbPrintPage_BloodJubSuLabel(ByVal sender As Object, ByVal e As PrintPageEventArgs)
        Dim sFn As String = "sbPrintPage_BloodJubSuLabel"

        Try
            e.Graphics.PageUnit = GraphicsUnit.Millimeter

            Dim fnt_1 As New Font("굴림체", 6, FontStyle.Regular)
            Dim fnt_1_b As New Font("굴림체", 6, FontStyle.Bold)

            Dim fnt_2 As New Font("굴림체", 7, FontStyle.Regular)
            Dim fnt_2_b As New Font("굴림체", 7, FontStyle.Bold)

            Dim fnt_3_b As New Font("굴림체", 8, FontStyle.Bold)



            Dim fnt_3 As New Font("굴림체", 8, FontStyle.Regular)
            Dim fnt_4 As New Font("굴림체", 10, FontStyle.Regular)
            Dim fnt_5 As New Font("굴림체", 11, FontStyle.Bold)
            Dim fnt_5_HY견고딕 As New Font("HY견고딕", 9, FontStyle.Bold)

            Dim fnt_6 As New Font("굴림체", 13, FontStyle.Bold)

            Dim fnt_b2 As New Font("굴림체", 7, FontStyle.Bold)
            Dim fnt_b3 As New Font("굴림체", 9, FontStyle.Bold)
            Dim fnt_b5 As New Font("굴림체", 11, FontStyle.Bold)

            Dim fnt_1_u As New Font("굴림체", 6, FontStyle.Underline)
            Dim fnt_5_u As New Font("굴림체", 11, FontStyle.Underline)
            Dim fnt_6_u As New Font("굴림체", 13, FontStyle.Underline)

            'Dim fnt_BarCd As New Font("Code39(2:3)", 24, FontStyle.Regular)
            Dim fnt_BarCd As New Font("Code39(2:3)", 24, FontStyle.Regular)
            'Dim fnt_BarCd As New Font("Code39One", 16, FontStyle.Regular)
            'Dim fnt_BarCd As New Font("Free 3 of 9", 24, FontStyle.Regular)

            Dim sf_c As New Drawing.StringFormat
            Dim sf_l As New Drawing.StringFormat
            Dim sf_r As New Drawing.StringFormat

            sf_c.LineAlignment = StringAlignment.Center : sf_c.Alignment = Drawing.StringAlignment.Center
            sf_l.LineAlignment = StringAlignment.Center : sf_l.Alignment = Drawing.StringAlignment.Near
            sf_r.LineAlignment = StringAlignment.Center : sf_r.Alignment = Drawing.StringAlignment.Far

            Dim intCnt As Integer = 0

            'For ix1 As Integer = 0 To ma_PrtData.Count - 1
            If CType(ma_PrtData(PrtIdx), STU_BCPRTINFO).REGNO <> "" Then
                Dim iPrtCnt As Integer = 1

                If CType(ma_PrtData(PrtIdx), STU_BCPRTINFO).BCCNT = "A" Then
                    iPrtCnt = 2
                ElseIf CType(ma_PrtData(PrtIdx), STU_BCPRTINFO).BCCNT = "B" Then
                    '< CrossMatching 검체
                    iPrtCnt = 3
                ElseIf IsNumeric(CType(ma_PrtData(PrtIdx), STU_BCPRTINFO).BCCNT) Then
                    iPrtCnt = Convert.ToInt32(CType(ma_PrtData(PrtIdx), STU_BCPRTINFO).BCCNT)
                End If

                'For ix2 As Integer = 1 To iPrtCnt
                Dim bpi As STU_BCPRTINFO = CType(ma_PrtData(PrtIdx), STU_BCPRTINFO)

                intCnt += 1
                Dim intPosX As Integer = ((intCnt - 1) Mod 3)
                Dim intPosY As Integer = intCnt / 3

                If (intCnt * intPosY) + ((intCnt - 1) Mod 3) <> intCnt Then intPosY -= 1
                If intPosY < 0 Then intPosY = 0

                Dim sgLeft As Single = miLeftPos + 2 + 60 * intPosX
                Dim sgTop As Single = miTopPos + 1 + 35 * intPosY

                Dim rect As New Drawing.RectangleF
                Dim sTmp As String = ""

                If bpi.BCTYPE = "B" Then
                    '< 환자명 
                    rect = New Drawing.RectangleF(sgLeft, sgTop + 1, 25, 5)
                    e.Graphics.DrawString(bpi.PATNM, fnt_6, Drawing.Brushes.Black, rect, sf_l)

                    '< 혈액형
                    rect = New Drawing.RectangleF(sgLeft + 20, sgTop + 1, 25, 5)
                    e.Graphics.DrawString(bpi.PAT_ABORH, fnt_6, Drawing.Brushes.Black, rect, sf_l)

                    '< 등록번호 
                    rect = New Drawing.RectangleF(sgLeft, sgTop + 6, 20, 5)
                    e.Graphics.DrawString(bpi.REGNO, fnt_5_HY견고딕, Drawing.Brushes.Black, rect, sf_l)

                    '< 성별/나이 
                    Dim sSexAge As String = ""
                    If bpi.SEXAGE.Contains("/") = True Then
                        sSexAge = bpi.SEXAGE.Trim
                    Else
                        sSexAge = bpi.SEXAGE.Trim.Substring(0, 1) + "/" + bpi.SEXAGE.Trim.Substring(1)
                    End If
                    rect = New Drawing.RectangleF(sgLeft + 20, sgTop + 6, 10, 5)
                    e.Graphics.DrawString(sSexAge, fnt_5_HY견고딕, Drawing.Brushes.Black, rect, sf_l)

                    '< 과코드
                    rect = New Drawing.RectangleF(sgLeft + 32, sgTop + 6, 20, 5)
                    e.Graphics.DrawString(bpi.DEPTWARD, fnt_5_HY견고딕, Drawing.Brushes.Black, rect, sf_l)

                    '< 성분제제명
                    rect = New Drawing.RectangleF(sgLeft, sgTop + 12, 500, 5)
                    e.Graphics.DrawString(bpi.COMNM, fnt_5_HY견고딕, Drawing.Brushes.Black, rect, sf_l)

                    '< 처방일
                    rect = New Drawing.RectangleF(sgLeft, sgTop + 18, 15, 4)
                    e.Graphics.DrawString("처방일:", fnt_3, Drawing.Brushes.Black, rect, sf_l)
                    Dim sOrddt As String = bpi.ORDDT.Substring(0, 10)
                    rect = New Drawing.RectangleF(sgLeft + 11, sgTop + 18, 25, 4)
                    e.Graphics.DrawString(sOrddt, fnt_3, Drawing.Brushes.Black, rect, sf_l)

                    '< 처방의
                    rect = New Drawing.RectangleF(sgLeft + 27, sgTop + 18, 15, 4)
                    e.Graphics.DrawString("처방의:", fnt_3, Drawing.Brushes.Black, rect, sf_l)
                    rect = New Drawing.RectangleF(sgLeft + 37, sgTop + 18, 25, 4)
                    e.Graphics.DrawString(bpi.DRNM, fnt_3, Drawing.Brushes.Black, rect, sf_l)

                    '< 접수일
                    rect = New Drawing.RectangleF(sgLeft, sgTop + 22, 15, 4)
                    e.Graphics.DrawString("접수일:", fnt_3, Drawing.Brushes.Black, rect, sf_l)
                    rect = New Drawing.RectangleF(sgLeft + 11, sgTop + 22, 25, 4)
                    e.Graphics.DrawString(bpi.TKDT, fnt_3, Drawing.Brushes.Black, rect, sf_l)

                    '< 접수자
                    rect = New Drawing.RectangleF(sgLeft, sgTop + 26, 15, 4)
                    e.Graphics.DrawString("접수자:", fnt_3, Drawing.Brushes.Black, rect, sf_l)
                    rect = New Drawing.RectangleF(sgLeft + 11, sgTop + 26, 25, 4)
                    e.Graphics.DrawString(bpi.TKID, fnt_3, Drawing.Brushes.Black, rect, sf_l)
                End If
                '  Next
            End If

            'Next

        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            MsgBox(msFile + sFn + vbCrLf + ex.Message)
        End Try

    End Sub
    Public Overridable Sub sbPrintPage_BloodOUTLABEL(ByVal sender As Object, ByVal e As PrintPageEventArgs)
        Dim sFn As String = "sbPrintPage_BloodJubSuLabel"

        Try
            e.Graphics.PageUnit = GraphicsUnit.Millimeter

            Dim fnt_1 As New Font("굴림체", 6, FontStyle.Regular)
            Dim fnt_1_b As New Font("굴림체", 6, FontStyle.Bold)

            Dim fnt_2 As New Font("굴림체", 7, FontStyle.Regular)
            Dim fnt_2_b As New Font("굴림체", 7, FontStyle.Bold)

            Dim fnt_3_b As New Font("굴림체", 8, FontStyle.Bold)



            Dim fnt_3 As New Font("굴림체", 8, FontStyle.Regular)
            Dim fnt_4 As New Font("굴림체", 10, FontStyle.Regular)
            Dim fnt_5 As New Font("굴림체", 11, FontStyle.Bold)
            Dim fnt_5_HY견고딕 As New Font("HY견고딕", 9, FontStyle.Bold)

            Dim fnt_6 As New Font("굴림체", 13, FontStyle.Bold)

            Dim fnt_b2 As New Font("굴림체", 7, FontStyle.Bold)
            Dim fnt_b3 As New Font("굴림체", 9, FontStyle.Bold)
            Dim fnt_b5 As New Font("굴림체", 11, FontStyle.Bold)

            Dim fnt_1_u As New Font("굴림체", 6, FontStyle.Underline)
            Dim fnt_5_u As New Font("굴림체", 11, FontStyle.Underline)
            Dim fnt_6_u As New Font("굴림체", 13, FontStyle.Underline)

            'Dim fnt_BarCd As New Font("Code39(2:3)", 24, FontStyle.Regular)
            Dim fnt_BarCd As New Font("Code39(2:3)", 24, FontStyle.Regular)
            'Dim fnt_BarCd As New Font("Code39One", 16, FontStyle.Regular)
            'Dim fnt_BarCd As New Font("Free 3 of 9", 24, FontStyle.Regular)

            Dim sf_c As New Drawing.StringFormat
            Dim sf_l As New Drawing.StringFormat
            Dim sf_r As New Drawing.StringFormat

            sf_c.LineAlignment = StringAlignment.Center : sf_c.Alignment = Drawing.StringAlignment.Center
            sf_l.LineAlignment = StringAlignment.Center : sf_l.Alignment = Drawing.StringAlignment.Near
            sf_r.LineAlignment = StringAlignment.Center : sf_r.Alignment = Drawing.StringAlignment.Far

            Dim intCnt As Integer = 0

            'For ix1 As Integer = 0 To ma_PrtData.Count - 1
            If CType(ma_PrtData(PrtIdx), STU_BCPRTINFO).REGNO <> "" Then
                Dim iPrtCnt As Integer = 1

                If CType(ma_PrtData(PrtIdx), STU_BCPRTINFO).BCCNT = "A" Then
                    iPrtCnt = 2
                ElseIf CType(ma_PrtData(PrtIdx), STU_BCPRTINFO).BCCNT = "B" Then
                    '< CrossMatching 검체
                    iPrtCnt = 3
                ElseIf IsNumeric(CType(ma_PrtData(PrtIdx), STU_BCPRTINFO).BCCNT) Then
                    iPrtCnt = Convert.ToInt32(CType(ma_PrtData(PrtIdx), STU_BCPRTINFO).BCCNT)
                End If

                'For ix2 As Integer = 1 To iPrtCnt
                Dim bpi As STU_BCPRTINFO = CType(ma_PrtData(PrtIdx), STU_BCPRTINFO)

                intCnt += 1
                Dim intPosX As Integer = ((intCnt - 1) Mod 3)
                Dim intPosY As Integer = intCnt / 3

                If (intCnt * intPosY) + ((intCnt - 1) Mod 3) <> intCnt Then intPosY -= 1
                If intPosY < 0 Then intPosY = 0

                Dim sgLeft As Single = miLeftPos + 2 + 60 * intPosX
                Dim sgTop As Single = miTopPos + 1 + 35 * intPosY

                Dim rect As New Drawing.RectangleF
                Dim sTmp As String = ""

                If bpi.BCTYPE = "B" Then
                    '<출고와료
                    rect = New Drawing.RectangleF(sgLeft, sgTop + 1, 25, 5)
                    e.Graphics.DrawString("출고완료", fnt_6, Drawing.Brushes.Black, rect, sf_l)

                    '< 환자명 
                    rect = New Drawing.RectangleF(sgLeft, sgTop + 6, 25, 5)
                    e.Graphics.DrawString(bpi.PATNM, fnt_6, Drawing.Brushes.Black, rect, sf_l)

                    '< 혈액형
                    rect = New Drawing.RectangleF(sgLeft + 20, sgTop + 6, 25, 5)
                    e.Graphics.DrawString(bpi.PAT_ABORH, fnt_6, Drawing.Brushes.Black, rect, sf_l)

                    '< 등록번호 
                    rect = New Drawing.RectangleF(sgLeft, sgTop + 12, 20, 5)
                    e.Graphics.DrawString(bpi.REGNO, fnt_5_HY견고딕, Drawing.Brushes.Black, rect, sf_l)

                    '< 성별/나이 
                    Dim sSexAge As String = ""
                    If bpi.SEXAGE.Contains("/") = True Then
                        sSexAge = bpi.SEXAGE.Trim
                    Else
                        sSexAge = bpi.SEXAGE.Trim.Substring(0, 1) + "/" + bpi.SEXAGE.Trim.Substring(1)
                    End If
                    rect = New Drawing.RectangleF(sgLeft + 20, sgTop + 12, 10, 5)
                    e.Graphics.DrawString(sSexAge, fnt_5_HY견고딕, Drawing.Brushes.Black, rect, sf_l)

                    '< 과코드
                    rect = New Drawing.RectangleF(sgLeft + 32, sgTop + 12, 20, 5)
                    e.Graphics.DrawString(bpi.DEPTWARD, fnt_5_HY견고딕, Drawing.Brushes.Black, rect, sf_l)

                    '< 성분제제명
                    rect = New Drawing.RectangleF(sgLeft, sgTop + 18, 500, 5)
                    e.Graphics.DrawString(bpi.COMNM, fnt_5_HY견고딕, Drawing.Brushes.Black, rect, sf_l)

                    '< 혈액번호 
                    rect = New Drawing.RectangleF(sgLeft, sgTop + 24, 500, 5)
                    e.Graphics.DrawString(bpi.BLDNO, fnt_5_HY견고딕, Drawing.Brushes.Black, rect, sf_l)

                    ''< 처방일
                    'rect = New Drawing.RectangleF(sgLeft, sgTop + 18, 15, 4)
                    'e.Graphics.DrawString("처방일:", fnt_3, Drawing.Brushes.Black, rect, sf_l)
                    'Dim sOrddt As String = bpi.ORDDT.Substring(0, 10)
                    'rect = New Drawing.RectangleF(sgLeft + 11, sgTop + 18, 25, 4)
                    'e.Graphics.DrawString(sOrddt, fnt_3, Drawing.Brushes.Black, rect, sf_l)

                    ''< 처방의
                    'rect = New Drawing.RectangleF(sgLeft + 27, sgTop + 18, 15, 4)
                    'e.Graphics.DrawString("처방의:", fnt_3, Drawing.Brushes.Black, rect, sf_l)
                    'rect = New Drawing.RectangleF(sgLeft + 37, sgTop + 18, 25, 4)
                    'e.Graphics.DrawString(bpi.DRNM, fnt_3, Drawing.Brushes.Black, rect, sf_l)

                    ''< 접수일
                    'rect = New Drawing.RectangleF(sgLeft, sgTop + 22, 15, 4)
                    'e.Graphics.DrawString("접수일:", fnt_3, Drawing.Brushes.Black, rect, sf_l)
                    'rect = New Drawing.RectangleF(sgLeft + 11, sgTop + 22, 25, 4)
                    'e.Graphics.DrawString(bpi.TKDT, fnt_3, Drawing.Brushes.Black, rect, sf_l)

                    ''< 접수자
                    'rect = New Drawing.RectangleF(sgLeft, sgTop + 26, 15, 4)
                    'e.Graphics.DrawString("접수자:", fnt_3, Drawing.Brushes.Black, rect, sf_l)
                    'rect = New Drawing.RectangleF(sgLeft + 11, sgTop + 26, 25, 4)
                    'e.Graphics.DrawString(bpi.TKID, fnt_3, Drawing.Brushes.Black, rect, sf_l)
                End If
                '  Next
            End If

            'Next

        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            MsgBox(msFile + sFn + vbCrLf + ex.Message)
        End Try

    End Sub
    Public Overridable Sub sbPrintPage_blood(ByVal sender As Object, ByVal e As PrintPageEventArgs)
        Dim sFn As String = "sbPrintPage_blood"

        Try
            e.Graphics.PageUnit = GraphicsUnit.Millimeter

            Dim fnt_1 As New Font("굴림체", 6, FontStyle.Regular)
            Dim fnt_2 As New Font("굴림체", 7, FontStyle.Regular)
            Dim fnt_3 As New Font("굴림체", 8, FontStyle.Regular)
            Dim fnt_4 As New Font("굴림체", 10, FontStyle.Bold)
            Dim fnt_5 As New Font("굴림체", 12, FontStyle.Bold)
            Dim fnt_6 As New Font("굴림체", 15, FontStyle.Bold)

            Dim fnt_b2 As New Font("굴림체", 9, FontStyle.Bold)
            Dim fnt_b3 As New Font("굴림체", 10, FontStyle.Bold)
            Dim fnt_b5 As New Font("굴림체", 14, FontStyle.Bold)

            Dim fnt_BarCd As New Font("Code39(2:3)", 10, FontStyle.Regular)

            Dim sf_c As New Drawing.StringFormat
            Dim sf_l As New Drawing.StringFormat
            Dim sf_r As New Drawing.StringFormat

            sf_c.LineAlignment = StringAlignment.Center : sf_c.Alignment = Drawing.StringAlignment.Center
            sf_l.LineAlignment = StringAlignment.Center : sf_l.Alignment = Drawing.StringAlignment.Near
            sf_r.LineAlignment = StringAlignment.Center : sf_r.Alignment = Drawing.StringAlignment.Far

            Dim sgPosX(0 To 4) As Single
            Dim sgPosY(0 To 8) As Single

            For ix1 As Integer = 0 To ma_PrtData.Count - 1

                For ix2 As Integer = 1 To mi_Copy

                    Dim sgLeft As Single = 5 + miLeftPos
                    Dim sgTop As Single = 5 + miTopPos

                    sgPosX(0) = sgLeft
                    sgPosX(1) = sgPosX(0) + 18
                    sgPosX(2) = sgPosX(1) + 22
                    sgPosX(3) = sgPosX(2) + 18
                    sgPosX(4) = sgPosX(3) + 22

                    sgPosY(0) = sgTop
                    sgPosY(1) = sgPosY(0) + 3

                    For ix As Integer = 1 To sgPosY.Length - 2
                        sgPosY(ix) = sgPosY(ix - 1) + 8
                    Next
                    sgPosY(sgPosY.Length - 1) = sgPosY(sgPosY.Length - 2) + 5

                    Dim sgPrtH As Single = 61

                    For ix3 As Integer = 0 To 2
                        ''-- 세로
                        'For ix = 0 To sgPosX.Length - 1
                        '    If ix = 0 Or ix = sgPosX.Length - 1 Then
                        '        e.Graphics.DrawLine(Drawing.Pens.Black, sgPosX(ix), sgPosY(1) + (ix3 * sgPrtH), sgPosX(ix), sgPosY(sgPosY.Length - 1) + (ix3 * sgPrtH))
                        '    Else
                        '        e.Graphics.DrawLine(Drawing.Pens.Black, sgPosX(ix), sgPosY(1) + (ix3 * sgPrtH), sgPosX(ix), sgPosY(sgPosY.Length - 2) + (ix3 * sgPrtH))
                        '    End If
                        'Next

                        ''-- 가로
                        'For ix = 1 To sgPosY.Length - 1
                        '    e.Graphics.DrawLine(Drawing.Pens.Black, sgPosX(0), sgPosY(ix) + (ix3 * sgPrtH), sgPosX(sgPosX.Length - 1), sgPosY(ix) + (ix3 * sgPrtH))
                        'Next

                        Dim bpi As STU_BLDLABEL = CType(ma_PrtData(ix1), STU_BLDLABEL)

                        Dim rect As New Drawing.RectangleF

                        ''-- 환자혈액형
                        'rect = New Drawing.RectangleF(sgPosX(0), sgPosY(1) + (ix3 * sgPrtH), sgPosX(1) - sgPosX(0), sgPosY(2) - sgPosY(1))
                        'e.Graphics.DrawString("환자혈액형", fnt_1, Drawing.Brushes.Black, rect, sf_c)
                        ''-- 적합혈액
                        'rect = New Drawing.RectangleF(sgPosX(2), sgPosY(1) + (ix3 * sgPrtH), sgPosX(3) - sgPosX(2), sgPosY(2) - sgPosY(1))
                        'e.Graphics.DrawString("적합혈액", fnt_1, Drawing.Brushes.Black, rect, sf_c)

                        ''-- 등록번호
                        'rect = New Drawing.RectangleF(sgPosX(0), sgPosY(2) + (ix3 * sgPrtH), sgPosX(1) - sgPosX(0), sgPosY(3) - sgPosY(2))
                        'e.Graphics.DrawString("등록번호", fnt_1, Drawing.Brushes.Black, rect, sf_c)
                        ''-- 성    명
                        'rect = New Drawing.RectangleF(sgPosX(2), sgPosY(2) + (ix3 * sgPrtH), sgPosX(3) - sgPosX(2), sgPosY(3) - sgPosY(2))
                        'e.Graphics.DrawString("성    명", fnt_1, Drawing.Brushes.Black, rect, sf_c)

                        ''-- 성별/나이
                        'rect = New Drawing.RectangleF(sgPosX(0), sgPosY(3) + (ix3 * sgPrtH), sgPosX(1) - sgPosX(0), sgPosY(4) - sgPosY(3))
                        'e.Graphics.DrawString("성별/나이", fnt_1, Drawing.Brushes.Black, rect, sf_c)
                        ''-- 과/병동
                        'rect = New Drawing.RectangleF(sgPosX(2), sgPosY(3) + (ix3 * sgPrtH), sgPosX(3) - sgPosX(2), sgPosY(4) - sgPosY(3))
                        'e.Graphics.DrawString("과/병동", fnt_1, Drawing.Brushes.Black, rect, sf_c)

                        ''-- 혈액제제명
                        'rect = New Drawing.RectangleF(sgPosX(0), sgPosY(4) + (ix3 * sgPrtH), sgPosX(1) - sgPosX(0), sgPosY(5) - sgPosY(4))
                        'e.Graphics.DrawString("혈액제제명", fnt_1, Drawing.Brushes.Black, rect, sf_c)
                        ''-- 혈액번호
                        'rect = New Drawing.RectangleF(sgPosX(2), sgPosY(4) + (ix3 * sgPrtH), sgPosX(3) - sgPosX(2), sgPosY(5) - sgPosY(4))
                        'e.Graphics.DrawString("혈액번호", fnt_1, Drawing.Brushes.Black, rect, sf_c)

                        ''-- 검사일시
                        'rect = New Drawing.RectangleF(sgPosX(0), sgPosY(5) + (ix3 * sgPrtH), sgPosX(1) - sgPosX(0), sgPosY(6) - sgPosY(5))
                        'e.Graphics.DrawString("검사일시", fnt_1, Drawing.Brushes.Black, rect, sf_c)
                        ''-- 검사자
                        'rect = New Drawing.RectangleF(sgPosX(2), sgPosY(5) + (ix3 * sgPrtH), sgPosX(3) - sgPosX(2), sgPosY(6) - sgPosY(5))
                        'e.Graphics.DrawString("검 사 자", fnt_1, Drawing.Brushes.Black, rect, sf_c)

                        ''-- 출고일시
                        'rect = New Drawing.RectangleF(sgPosX(0), sgPosY(6) + (ix3 * sgPrtH), sgPosX(1) - sgPosX(0), sgPosY(7) - sgPosY(6))
                        'e.Graphics.DrawString("수령일시", fnt_1, Drawing.Brushes.Black, rect, sf_c)
                        ''-- 출고자
                        'rect = New Drawing.RectangleF(sgPosX(2), sgPosY(6) + (ix3 * sgPrtH), sgPosX(3) - sgPosX(2), sgPosY(7) - sgPosY(6))
                        'e.Graphics.DrawString("출 고 자", fnt_1, Drawing.Brushes.Black, rect, sf_c)



                        '-- 환자혈액형
                        rect = New Drawing.RectangleF(sgPosX(1), sgPosY(1) + (ix3 * sgPrtH), sgPosX(2) - sgPosX(1), sgPosY(2) - sgPosY(1))
                        e.Graphics.DrawString(bpi.PAT_ABORH, fnt_b5, Drawing.Brushes.Black, rect, sf_c)
                        '-- 출고혈액형
                        rect = New Drawing.RectangleF(sgPosX(3), sgPosY(1) + (ix3 * sgPrtH), sgPosX(4) - sgPosX(3), sgPosY(2) - sgPosY(1))
                        e.Graphics.DrawString(bpi.BLD_ABORH, fnt_b5, Drawing.Brushes.Black, rect, sf_c)

                        '-- 등록번호
                        rect = New Drawing.RectangleF(sgPosX(1), sgPosY(2) + (ix3 * sgPrtH), sgPosX(2) - sgPosX(1), sgPosY(3) - sgPosY(2))
                        e.Graphics.DrawString(bpi.REGNO, fnt_b3, Drawing.Brushes.Black, rect, sf_c)
                        '-- 성명
                        rect = New Drawing.RectangleF(sgPosX(3), sgPosY(2) + (ix3 * sgPrtH), sgPosX(4) - sgPosX(3), sgPosY(3) - sgPosY(2))
                        e.Graphics.DrawString(bpi.PATNM, fnt_b3, Drawing.Brushes.Black, rect, sf_c)

                        '-- 성별/나이
                        rect = New Drawing.RectangleF(sgPosX(1), sgPosY(3) + (ix3 * sgPrtH), sgPosX(2) - sgPosX(1), sgPosY(4) - sgPosY(3))
                        e.Graphics.DrawString(bpi.SEXAGE, fnt_4, Drawing.Brushes.Black, rect, sf_c)
                        '-- 진료과
                        rect = New Drawing.RectangleF(sgPosX(3), sgPosY(3) + (ix3 * sgPrtH), sgPosX(4) - sgPosX(3), sgPosY(4) - sgPosY(3))
                        e.Graphics.DrawString(bpi.DEPTWARD, fnt_4, Drawing.Brushes.Black, rect, sf_c)

                        '-- 혈액제제명
                        rect = New Drawing.RectangleF(sgPosX(1), sgPosY(4) + (ix3 * sgPrtH), sgPosX(2) - sgPosX(1), sgPosY(5) - sgPosY(4))
                        e.Graphics.DrawString(bpi.COMNM, fnt_b3, Drawing.Brushes.Black, rect, sf_c)
                        '-- 혈액번호
                        rect = New Drawing.RectangleF(sgPosX(3), sgPosY(4) + (ix3 * sgPrtH), sgPosX(4) - sgPosX(3), sgPosY(5) - sgPosY(4))
                        e.Graphics.DrawString(bpi.BLDNO(0), fnt_b2, Drawing.Brushes.Black, rect, sf_c)

                        '-- 검사일시
                        rect = New Drawing.RectangleF(sgPosX(1), sgPosY(5) + (ix3 * sgPrtH), sgPosX(2) - sgPosX(1), sgPosY(6) - sgPosY(5))
                        e.Graphics.DrawString(bpi.TESTDT, fnt_3, Drawing.Brushes.Black, rect, sf_c)
                        '-- 검사자
                        rect = New Drawing.RectangleF(sgPosX(3), sgPosY(5) + (ix3 * sgPrtH), sgPosX(2) - sgPosX(1), sgPosY(6) - sgPosY(5))
                        e.Graphics.DrawString(bpi.TESTNM, fnt_4, Drawing.Brushes.Black, rect, sf_c)

                        '-- 출고일시
                        rect = New Drawing.RectangleF(sgPosX(1), sgPosY(6) + (ix3 * sgPrtH), sgPosX(2) - sgPosX(1), sgPosY(7) - sgPosY(6))
                        e.Graphics.DrawString(bpi.OUTDT, fnt_3, Drawing.Brushes.Black, rect, sf_c)
                        '-- 출고자
                        rect = New Drawing.RectangleF(sgPosX(3), sgPosY(6) + (ix3 * sgPrtH), sgPosX(4) - sgPosX(3), sgPosY(7) - sgPosY(6))
                        e.Graphics.DrawString(bpi.OUTNM, fnt_4, Drawing.Brushes.Black, rect, sf_c)


                        ''-- 병원명
                        'rect = New Drawing.RectangleF(sgPosX(0), sgPosY(7) + (ix3 * sgPrtH), sgPosX(sgPosX.Length - 1) - sgPosX(0), sgPosY(8) - sgPosY(7))
                        'e.Graphics.DrawString(PRG_CONST.Tail_WorkList + " 혈액은행", fnt_b3, Drawing.Brushes.Black, rect, sf_c)

                    Next

                Next
            Next

        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            MsgBox(msFile + sFn + vbCrLf + ex.Message)
        End Try

    End Sub
    Public Overridable Sub sbPrintPage_RIS(ByVal sender As Object, ByVal e As PrintPageEventArgs)
        Dim sFn As String = "sbPrintPage_RIS"

        Try
            e.Graphics.PageUnit = GraphicsUnit.Millimeter

            Dim fnt_1 As New Font("굴림체", 6, FontStyle.Regular)
            Dim fnt_1_b As New Font("굴림체", 6, FontStyle.Bold)

            Dim fnt_2 As New Font("굴림체", 7, FontStyle.Regular)
            Dim fnt_2_b As New Font("굴림체", 7, FontStyle.Bold)

            Dim fnt_3_b As New Font("굴림체", 8, FontStyle.Bold)



            Dim fnt_3 As New Font("굴림체", 8, FontStyle.Regular)
            Dim fnt_4 As New Font("굴림체", 10, FontStyle.Regular)
            Dim fnt_4_b As New Font("굴림체", 10, FontStyle.Bold)
            Dim fnt_5 As New Font("굴림체", 11, FontStyle.Bold)
            Dim fnt_5_HY견고딕 As New Font("HY견고딕", 9, FontStyle.Bold)
            Dim fnt_6_HY견고딕 As New Font("HY견고딕", 13, FontStyle.Bold)

            Dim fnt_6 As New Font("굴림체", 15, FontStyle.Bold)

            Dim fnt_b2 As New Font("굴림체", 7, FontStyle.Bold)
            Dim fnt_b3 As New Font("굴림체", 9, FontStyle.Bold)
            Dim fnt_b5 As New Font("굴림체", 11, FontStyle.Bold)

            Dim fnt_1_u As New Font("굴림체", 6, FontStyle.Underline)
            Dim fnt_5_u As New Font("굴림체", 11, FontStyle.Underline)
            Dim fnt_6_u As New Font("굴림체", 13, FontStyle.Underline)

            'Dim fnt_BarCd As New Font("Code39(2:3)", 24, FontStyle.Regular)
            Dim fnt_BarCd As New Font("Code39(2:3)", 24, FontStyle.Regular)
            'Dim fnt_BarCd As New Font("Code39One", 16, FontStyle.Regular)
            'Dim fnt_BarCd As New Font("Free 3 of 9", 24, FontStyle.Regular)

            Dim sf_c As New Drawing.StringFormat
            Dim sf_l As New Drawing.StringFormat
            Dim sf_r As New Drawing.StringFormat

            sf_c.LineAlignment = StringAlignment.Center : sf_c.Alignment = Drawing.StringAlignment.Center
            sf_l.LineAlignment = StringAlignment.Center : sf_l.Alignment = Drawing.StringAlignment.Near
            sf_r.LineAlignment = StringAlignment.Center : sf_r.Alignment = Drawing.StringAlignment.Far

            Dim intCnt As Integer = 0

            If CType(ma_PrtData(PrtIdx), STU_BCPRTINFO).REGNO <> "" Then
                Dim iPrtCnt As Integer = 1

                If CType(ma_PrtData(PrtIdx), STU_BCPRTINFO).BCCNT = "A" Then
                    iPrtCnt = 2
                ElseIf CType(ma_PrtData(PrtIdx), STU_BCPRTINFO).BCCNT = "B" Then
                    '< CrossMatching 검체
                    iPrtCnt = 3
                ElseIf IsNumeric(CType(ma_PrtData(PrtIdx), STU_BCPRTINFO).BCCNT) Then
                    iPrtCnt = Convert.ToInt32(CType(ma_PrtData(PrtIdx), STU_BCPRTINFO).BCCNT)
                End If

                'For ix2 As Integer = 1 To iPrtCnt
                Dim bpi As STU_BCPRTINFO = CType(ma_PrtData(PrtIdx), STU_BCPRTINFO)

                intCnt += 1
                Dim intPosX As Integer = ((intCnt - 1) Mod 3)
                Dim intPosY As Integer = intCnt / 3

                If (intCnt * intPosY) + ((intCnt - 1) Mod 3) <> intCnt Then intPosY -= 1
                If intPosY < 0 Then intPosY = 0

                Dim sgLeft As Single = miLeftPos + 2 + 60 * intPosX
                Dim sgTop As Single = miTopPos + 1 + 35 * intPosY

                Dim rect As New Drawing.RectangleF
                Dim sTmp As String = ""


                ''< 등록번호 
                rect = New Drawing.RectangleF(sgLeft + 2, sgTop + 2, 30, 5)
                e.Graphics.DrawString(bpi.REGNO, fnt_6_HY견고딕, Drawing.Brushes.Black, rect, sf_l)

                ''< 환자명 
                rect = New Drawing.RectangleF(sgLeft + 28, sgTop + 1, 35, 7)
                e.Graphics.DrawString(bpi.PATNM, fnt_b5, Drawing.Brushes.Black, rect, sf_l)

                ''< 성별/나이 
                Dim sSexAge As String = ""
                If bpi.SEXAGE.Contains("/") = True Then
                    sSexAge = bpi.SEXAGE.Trim
                Else
                    sSexAge = bpi.SEXAGE.Trim.Substring(0, 1) + "/" + bpi.SEXAGE.Trim.Substring(1)
                End If
                rect = New Drawing.RectangleF(sgLeft + 43, sgTop + 1, 20, 5)
                e.Graphics.DrawString(sSexAge, fnt_3, Drawing.Brushes.Black, rect, sf_l)

                ''< 검체명
                rect = New Drawing.RectangleF(sgLeft + 2, sgTop + 8, 40, 5)
                e.Graphics.DrawString(bpi.SPCNM, fnt_4_b, Drawing.Brushes.Black, rect, sf_l)

                ''< 진료과/병동/병실
                rect = New Drawing.RectangleF(sgLeft + 40, sgTop + 8, 30, 5)
                e.Graphics.DrawString(bpi.DEPTWARD, fnt_4_b, Drawing.Brushes.Black, rect, sf_l)

                ''< WKNO - 작업번호
                rect = New Drawing.RectangleF(sgLeft + 2, sgTop + 14, 20, 5)
                e.Graphics.DrawString(bpi.TUBENM.Substring(0, 8) + "-", fnt_4_b, Drawing.Brushes.Black, rect, sf_l)

                ''< WKNO - 작업번호
                rect = New Drawing.RectangleF(sgLeft + 20, sgTop + 14, 50, 5)
                e.Graphics.DrawString(bpi.TUBENM.Substring(8), fnt_6_HY견고딕, Drawing.Brushes.Black, rect, sf_l)

                ''< 처방일
                rect = New Drawing.RectangleF(sgLeft + 2, sgTop + 19, 25, 5)
                e.Graphics.DrawString("처방일자 : ", fnt_3_b, Drawing.Brushes.Black, rect, sf_l)
                'Dim sOrddt As String = bpi.ORDDT.Substring(0, 10)
                Dim sOrddt As String = bpi.ORDDT.Substring(0, IIf(bpi.ORDDT.Length >= 10, 10, bpi.ORDDT.Length))
                rect = New Drawing.RectangleF(sgLeft + 18, sgTop + 19, 25, 5)
                e.Graphics.DrawString(sOrddt, fnt_3_b, Drawing.Brushes.Black, rect, sf_l)


                ''< 검사코드
                rect = New Drawing.RectangleF(sgLeft + 2, sgTop + 23, 50, 5)
                e.Graphics.DrawString(bpi.TESTCD, fnt_3, Drawing.Brushes.Black, rect, sf_l)
            End If

        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            MsgBox(msFile + sFn + vbCrLf + ex.Message)
        End Try

    End Sub
    Public Overridable Sub sbPrintPage_General(ByVal sender As Object, ByVal e As PrintPageEventArgs)
        Dim sFn As String = "sbPrintPage_General"

        Try
            e.Graphics.PageUnit = GraphicsUnit.Millimeter

            Dim fnt_1 As New Font("굴림체", 6, FontStyle.Regular)
            Dim fnt_2 As New Font("굴림체", 7, FontStyle.Regular)
            Dim fnt_3 As New Font("굴림체", 8, FontStyle.Regular)
            Dim fnt_4 As New Font("굴림체", 10, FontStyle.Bold)
            Dim fnt_5 As New Font("굴림체", 11, FontStyle.Bold)
            Dim fnt_6 As New Font("굴림체", 13, FontStyle.Bold)

            Dim fnt_b3 As New Font("굴림체", 9, FontStyle.Bold)
            Dim fnt_b5 As New Font("굴림체", 11, FontStyle.Bold)

            Dim fnt_1_u As New Font("굴림체", 6, FontStyle.Underline)
            Dim fnt_5_u As New Font("굴림체", 11, FontStyle.Underline)
            Dim fnt_6_u As New Font("굴림체", 13, FontStyle.Underline)

            Dim fnt_BarCd As New Font("Code39(2:3)", 24, FontStyle.Regular)
            'Dim fnt_BarCd As New Font("Code39One", 16, FontStyle.Regular)
            'Dim fnt_BarCd As New Font("Free 3 of 9", 24, FontStyle.Regular)

            Dim sf_c As New Drawing.StringFormat
            Dim sf_l As New Drawing.StringFormat
            Dim sf_r As New Drawing.StringFormat

            sf_c.LineAlignment = StringAlignment.Center : sf_c.Alignment = Drawing.StringAlignment.Center
            sf_l.LineAlignment = StringAlignment.Center : sf_l.Alignment = Drawing.StringAlignment.Near
            sf_r.LineAlignment = StringAlignment.Center : sf_r.Alignment = Drawing.StringAlignment.Far

            Dim intCnt As Integer = 0

            For ix1 As Integer = 0 To ma_PrtData.Count - 1
                If CType(ma_PrtData(ix1), STU_BCPRTINFO).REGNO <> "" Then
                    Dim iPrtCnt As Integer = 1

                    If CType(ma_PrtData(ix1), STU_BCPRTINFO).BCCNT = "A" Then
                        iPrtCnt = 2
                    ElseIf CType(ma_PrtData(ix1), STU_BCPRTINFO).BCCNT = "B" Then
                        '< CrossMatching 검체
                        iPrtCnt = 3
                    ElseIf IsNumeric(CType(ma_PrtData(ix1), STU_BCPRTINFO).BCCNT) Then
                        iPrtCnt = Convert.ToInt32(CType(ma_PrtData(ix1), STU_BCPRTINFO).BCCNT)
                    End If

                    For ix2 As Integer = 1 To iPrtCnt
                        Dim bpi As STU_BCPRTINFO = CType(ma_PrtData(ix1), STU_BCPRTINFO)

                        intCnt += 1
                        Dim intPosX As Integer = ((intCnt - 1) Mod 3)
                        Dim intPosY As Integer = intCnt / 3

                        If (intCnt * intPosY) + ((intCnt - 1) Mod 3) <> intCnt Then intPosY -= 1
                        If intPosY < 0 Then intPosY = 0

                        Dim sgLeft As Single = miLeftPos + 2 + 60 * intPosX
                        Dim sgTop As Single = miTopPos + 1 + 35 * intPosY

                        Dim rect As New Drawing.RectangleF
                        Dim sTmp As String = ""

                        rect = New Drawing.RectangleF(miLeftPos, miTopPos, 50, 35)
                        e.Graphics.DrawRectangle(Drawing.Pens.Black, miLeftPos, miTopPos, 50, 35)

                        '-- 검체번호
                        rect = New Drawing.RectangleF(sgLeft, sgTop, 25, 2)
                        e.Graphics.DrawString(bpi.BCNO, fnt_1, Drawing.Brushes.Black, rect, sf_l)

                        '-- 발행일시
                        rect = New Drawing.RectangleF(sgLeft + 33, sgTop, 20, 2)
                        If mb_First Then
                            e.Graphics.DrawString(Fn.GetServerDateTime.ToString("MM-dd HH:mm"), fnt_1, Drawing.Brushes.Black, rect, sf_l)
                        Else
                            e.Graphics.DrawString(Fn.GetServerDateTime.ToString("MM-dd HH:mm"), fnt_1_u, Drawing.Brushes.Black, rect, sf_l)
                        End If

                        '< 감염정보  
                        'bpi.INFINFO = "A/MRAS"
                        rect = New Drawing.RectangleF(sgLeft + 32, sgTop + 30, 15, 4)
                        e.Graphics.DrawString(bpi.INFINFO, fnt_b5, Drawing.Brushes.Black, rect, sf_l)

                        'Dim a_sInfInfo As String() = bpi.INFINFO.Split("/"c)

                        'For iCnt As Integer = 0 To a_sInfInfo.Length - 1
                        '    If iCnt > 1 Then Exit For

                        '    rect = New Drawing.RectangleF(sgLeft + 35, sgTop + 5 + 4 * iCnt, 5, 4)
                        '    e.Graphics.DrawString(a_sInfInfo(iCnt).ToString().Trim, fnt_b5, Drawing.Brushes.Black, rect, sf_l)
                        'Next

                        Dim sTestNm As String = bpi.TESTNMS.Trim

                        If sTestNm.Length > 20 Then
                            sTestNm = sTestNm.Substring(0, 19) & "..."
                        End If

                        If sTestNm.IndexOf("...") > -1 Then
                            If sTestNm.Substring(0, sTestNm.IndexOf("...")).Length > 20 Then
                                sTestNm = sTestNm.Substring(0, 19) & "..."
                            End If
                        End If

                        '< 바코드  
                        If bpi.BCNOPRT <> "" Then
                            rect = New Drawing.RectangleF(sgLeft, sgTop + 0, 500, 16)
                            e.Graphics.DrawString("*" + bpi.BCNOPRT.Substring(0, 10) + "*", fnt_BarCd, Drawing.Brushes.Black, rect, sf_l)

                            rect = New Drawing.RectangleF(sgLeft + 10, sgTop + 16, 25, 2)
                            e.Graphics.DrawString(bpi.BCNOPRT, fnt_2, Drawing.Brushes.Black, rect, sf_c)
                        Else
                            rect = New Drawing.RectangleF(sgLeft + 10, sgTop + 3, 35, 13)
                            e.Graphics.DrawString("미채혈바코드", fnt_6, Drawing.Brushes.Black, rect, sf_c)
                        End If

                        ''< 등록번호 sPID
                        rect = New Drawing.RectangleF(sgLeft, sgTop + 19, 22, 5)
                        If PRG_CONST.BCCLS_ExLab.Contains(bpi.BCNO) Then
                            e.Graphics.DrawString(bpi.REGNO, fnt_6_u, Drawing.Brushes.Black, rect, sf_l)
                        Else
                            e.Graphics.DrawString(bpi.REGNO, fnt_6, Drawing.Brushes.Black, rect, sf_l)
                        End If

                        ''< 진료과/병동/병실  
                        rect = New Drawing.RectangleF(sgLeft + 38, sgTop + 23, 20, 2)
                        e.Graphics.DrawString(bpi.DEPTWARD, fnt_2, Drawing.Brushes.Black, rect, sf_l)

                        ''< 성별/나이 
                        rect = New Drawing.RectangleF(sgLeft + 40, sgTop + 19, 10, 1.5)
                        e.Graphics.DrawString(bpi.SEXAGE, fnt_1, Drawing.Brushes.Black, rect, sf_l)

                        ''< 환자명 
                        rect = New Drawing.RectangleF(sgLeft + 23, sgTop + 18, 15, 4)
                        e.Graphics.DrawString(bpi.PATNM, fnt_5, Drawing.Brushes.Black, rect, sf_l)

                        ''< sRemark
                        ''sRemark = "C"
                        rect = New Drawing.RectangleF(sgLeft + 48, sgTop + 13, 10, 2)
                        e.Graphics.DrawString(IIf(bpi.REMARK = "", "", "C").ToString, fnt_2, Drawing.Brushes.Black, rect, sf_l)


                        If bpi.BCCLSCD = PRG_CONST.BCCLS_BldCrossMatch Or bpi.BCCNT = "B" Then
                            '< 용기명 
                            rect = New Drawing.RectangleF(sgLeft, sgTop + 25, 20, 4)
                            e.Graphics.DrawString(bpi.TUBENM, fnt_4, Drawing.Brushes.Black, rect, sf_l)

                            '< 채혈자
                            rect = New Drawing.RectangleF(sgLeft + 25, sgTop + 25, 10, 4)
                            e.Graphics.DrawString("채혈자:", fnt_4, Drawing.Brushes.Black, rect, sf_l)
                            '< 확인자
                            rect = New Drawing.RectangleF(sgLeft + 25, sgTop + 29, 10, 4)
                            e.Graphics.DrawString("확인자:", fnt_4, Drawing.Brushes.Black, rect, sf_l)
                            '< 음영
                            e.Graphics.DrawRectangle(Pens.Black, New Drawing.Rectangle(sgLeft, sgTop + 29, 20, 4))
                            rect = New Drawing.RectangleF(sgLeft, sgTop + 29, 20, 4)
                            e.Graphics.DrawString("X-Matching", fnt_4, Drawing.Brushes.Black, rect, sf_l)

                            'ElseIf bpi.BCCLSCD = PRG_CONST.BCCLS_BloodBank Then
                            '    '< 용기명 
                            '    rect = New Drawing.RectangleF(sgLeft, sgTop + 25, 20, 4)
                            '    e.Graphics.DrawString(bpi.TUBENM, fnt_4, Drawing.Brushes.Black, rect, sf_l)
                            '    '< 채혈자
                            '    rect = New Drawing.RectangleF(sgLeft + 25, sgTop + 25, 10, 4)
                            '    e.Graphics.DrawString("채혈자:", fnt_4, Drawing.Brushes.Black, rect, sf_l)
                            '    '< 확인자
                            '    rect = New Drawing.RectangleF(sgLeft + 25, sgTop + 29, 10, 4)
                            '    e.Graphics.DrawString("확인자:", fnt_4, Drawing.Brushes.Black, rect, sf_l)
                            '    '< 검사항목(음영)
                            '    If sTestNm.Length > 12 Then sTestNm = sTestNm.Substring(0, 12)
                            '    rect = New Drawing.RectangleF(sgLeft, sgTop + 29, 10, 4)
                            '    e.Graphics.DrawString(sTestNm, fnt_3, Drawing.Brushes.Black, rect, sf_l)

                        Else
                            If bpi.BCTYPE = "M" Then
                                '< 검사그룹 sComment2
                                rect = New Drawing.RectangleF(sgLeft + 30, sgTop + 27, 20, 4)
                                e.Graphics.DrawString(bpi.TGRPNM, fnt_b3, Drawing.Brushes.Black, rect, sf_l)

                                '< 미생물 검체번호
                                rect = New Drawing.RectangleF(sgLeft, sgTop + 28, 40, 4)
                                e.Graphics.DrawString(bpi.BCNO_MB, fnt_4, Drawing.Brushes.Black, rect, sf_l)
                            Else
                                '< 검사항목명 
                                rect = New Drawing.RectangleF(sgLeft + 5, sgTop + 30, 40, 4)
                                e.Graphics.DrawString(sTestNm, fnt_3, Drawing.Brushes.Black, rect, sf_l)

                                '< 용기명 
                                rect = New Drawing.RectangleF(sgLeft + 23, sgTop + 25, 10, 4)
                                e.Graphics.DrawString(bpi.TUBENM, fnt_4, Drawing.Brushes.Black, rect, sf_l)

                                '< 검사그룹 sComment2
                                'bpi.TGRPNM = "H C E"
                                rect = New Drawing.RectangleF(sgLeft + 30, sgTop + 25, 10, 4)
                                e.Graphics.DrawString(bpi.TGRPNM, fnt_b3, Drawing.Brushes.Black, rect, sf_l)

                                '< 응급 sEmer 
                                'bpi.EMER = "E"
                                rect = New Drawing.RectangleF(sgLeft + 45, sgTop + 8, 5, 2)
                                e.Graphics.DrawString(bpi.EMER, fnt_2, Drawing.Brushes.Black, rect, sf_l)

                                '< 계 sKind
                                rect = New Drawing.RectangleF(sgLeft, sgTop + 28, 5, 4)
                                e.Graphics.DrawString(bpi.BCCLSCD, fnt_b3, Drawing.Brushes.Black, rect, sf_l)
                            End If
                        End If

                        ''< 검체명
                        rect = New Drawing.RectangleF(sgLeft, sgTop + 25, 10, 4)
                        e.Graphics.DrawString(bpi.SPCNM, fnt_4, Drawing.Brushes.Black, rect, sf_l)
                    Next
                End If
            Next

        Catch ex As Exception
            Fn.log(msFile + sFn, Err)
            MsgBox(msFile + sFn + vbCrLf + ex.Message)
        End Try

    End Sub

    Private Sub sbReport(ByVal sender As Object, ByVal e As PrintEventArgs)

    End Sub

    Private Sub sbPrintData(ByVal sender As Object, ByVal e As PrintEventArgs)

    End Sub

End Class
