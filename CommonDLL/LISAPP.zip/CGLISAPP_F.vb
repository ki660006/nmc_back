﻿'/*****************************************************************************************/
'/*                                                                                       */
'/* Project Name : 관동대명지병원 Laboratory Information System(KMC_LIS)                  */
'/*                                                                                       */
'/*                                                                                       */
'/* FileName     : CGLISAPP_F.vb                                                              */
'/* PartName     : 기초자료관리                                                           */
'/* Description  : 기초자료관리의 Data Query구문관련 Class                                */
'/* Design       : 2003-08-23 freety                                                      */
'/* Coded        :                                                                        */
'/* Modified     :                                                                        */
'/*                                                                                       */
'/*                                                                                       */
'/*                                                                                       */
'/*****************************************************************************************/
Imports Oracle.DataAccess.Client

Imports DBORA.DbProvider
Imports COMMON.CommFN
Imports common.commlogin.login

Public Class APP_F
    Private Const msFile As String = "File : CGLISAPP_F.vb, Class : LISAPP.APP_F" & vbTab

    '-- 검사코드 리스트
    Public Function fnGet_testspc_autorst(ByVal rsTestCd As String, ByVal rsSPcCd As String) As DataTable
        Dim sFn As String = "Function fnGet_testspc_autorst(String, String) As DataTable"
        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT DISTINCT"
            sSql += "       '' chk, f6.tnmd, f6.tnmp tnmp, f6.testcd, f6.spccd, RPAD(f6.testcd, 8, ' ') || f6.spccd testspc,"
            sSql += "       f6.tordcd, f6.tordslip, f6.tcdgbn, f6.partcd || f6.slipcd partslip, NVL(f6.titleyn, '0') titleyn,"
            sSql += "       NVL(f6.mbttype, '0') mbttype, NVL(f6.poctyn, '0') poctyn,"
            sSql += "       f3.spcnmd, NVL(f2.dispseq, 999) sort1, NVL(f6.dispseql, 999) sort2"
            sSql += "  FROM lf060m f6, lf021m f2, lf030m f3"
            sSql += " WHERE f6.usdt <= fn_ack_sysdate"
            sSql += "   AND f6.uedt >  fn_ack_sysdate"

            If rsTestCd <> "" Then
                sSql += "   AND f6.testcd = :testcd"
                al.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            End If

            If rsTestCd <> "" Then
                sSql += "   AND f6.spccd = :spccd"
                al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSPcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSPcCd))
            End If

            sSql += "   AND f6.testcd IN (SELECT testcd FROM lf083m)"
            sSql += "   AND f6.partcd = f2.partcd"
            sSql += "   AND f6.slipcd = f2.slipcd"
            sSql += "   AND f2.usdt  <= fn_ack_sysdate"
            sSql += "   AND f2.uedt   > fn_ack_sysdate"
            sSql += "   AND f6.spccd  = f3.spccd"
            sSql += "   AND f3.usdt  <= fn_ack_sysdate"
            sSql += "   AND f3.uedt   > fn_ack_sysdate"
            sSql += " ORDER BY sort1, sort2, testspc"

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function GetUsUeDupl_FtCd(ByVal rsCd As String, ByVal rsUsDt As String, ByVal rsUseTag As String, ByVal rsCompDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeDupl_FtCd() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT a.*"
            sSql += "  FROM ("
            sSql += "        SELECT ftcd, ftnm, usdt, uedt"
            sSql += "          FROM lf121m"
            sSql += "         WHERE ftcd = :ftcd"
            sSql += "           AND usdt < " + IIf(rsUseTag = "USDT", "=", "").ToString + " :compdt"
            sSql += "           AND uedt > " + IIf(rsUseTag = "USDT", "", "=").ToString + " :compdt"
            sSql += "       ) a LEFT OUTER JOIN"
            sSql += "       ("
            sSql += "        SELECT ftcd, ftnm, usdt, uedt"
            sSql += "          FROM lf121m"
            sSql += "         WHERE ftcd = :ftcd"
            sSql += "           AND usdt = :usdt"
            sSql += "       ) b ON (a.ftcd = b.ftcd AND a.usdt = b.usdt)"
            sSql += " WHERE NVL(b.ftcd, ' ') = ' '"

            al.Add(New OracleParameter("ftcd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("ftcd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
           Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetUsUeCd_FtCd(ByVal rsCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeCd_FtCd() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT ftcd"
            sSql += "  FROM lf120m"
            sSql += " WHERE ftcd  = :ftcd"
            sSql += "   AND uedt <= fn_ack_sysdate"

            al.Add(New OracleParameter("ftcd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
           Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    '-- 2008/03/07 YEJ add
    Public Function GetUsUeDupl_ComCd(ByVal rsCd As String, ByVal rsUsDt As String, ByVal rsUseTag As String, ByVal rsCompDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeDupl_ComCd() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT a.*"
            sSql += "  FROM ("
            sSql += "        SELECT comcd, comnmd, usdt, uedt"
            sSql += "          FROM lf120m"
            sSql += "         WHERE comcd = :comcd"
            sSql += "           AND usdt  <" + IIf(rsUseTag = "USDT", "=", "").ToString + " :compdt"
            sSql += "           AND uedt  >" + IIf(rsUseTag = "USDT", "", "=").ToString + " :compdt"
            sSql += "       ) a LEFT JOIN"
            sSql += "       (SELECT comcd, comnmd, usdt, uedt"
            sSql += "          FROM lf120m"
            sSql += "         WHERE comcd = :comcd"
            sSql += "           AND usdt  = :usdt"
            sSql += "       ) b ON (a.comcd = b.comcd AND a.usdt = b.usdt)"
            sSql += " WHERE NVL(b.comcd, ' ') = ' '"

            al.Add(New OracleParameter("comcd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("comcd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
           Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    '-- 2008/03/07 YEJ add
    Public Function GetUsUeCd_ComCd(ByVal rsCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeCd_ComCd() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT comcd"
            sSql += "  FROM lb020m"
            sSql += " WHERE comcd = :comcd"
            sSql += " UNION ALL "
            sSql += "SELECT comcd"
            sSql += "  FROM lb030m"
            sSql += " WHERE (comcd = :comcd OR comcd_out = :comcd)"
            sSql += " UNION ALL "
            sSql += "SELECT comcd"
            sSql += "  FROM lb031m"
            sSql += " WHERE (comcd = :comcd or comcd_out = :comcd)"
            sSql += " UNION ALL "
            sSql += "SELECT comcd"
            sSql += "  FROM lb042m"
            sSql += " WHERE comcd = :comcd"
            sSql += " UNION ALL "
            sSql += "SELECT comcd"
            sSql += "  FROM lb043m"
            sSql += " WHERE (comcd = :comcd or comcd_out = :comcd)"


            al.Add(New OracleParameter("comcd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))

            al.Add(New OracleParameter("comcd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("comcd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))

            al.Add(New OracleParameter("comcd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("comcd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))

            al.Add(New OracleParameter("comcd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))

            al.Add(New OracleParameter("comcd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("comcd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
           Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetUsUeDupl_BacGen_Anti(ByVal rsCd As String, ByVal rsUseTag As String, ByVal rsCompDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeDupl_BacGen_Anti() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT a.*"
            sSql += "  FROM ("
            sSql += "        SELECT bacgencd"
            sSql += "          FROM lf240m"
            sSql += "         WHERE bacgencd = :bacgencd"
            sSql += "       ) a LEFT OUTER JOIN"
            sSql += "       ("
            sSql += "        SELECT bacgencd"
            sSql += "          FROM lf240m"
            sSql += "         WHERE bacgencd = :bacgencd"
            sSql += "       ) b ON (.bacgencd = b.bacgencd)"
            sSql += " WHERE NVL(b.bacgencd, ' ') = ' '"

            al.Add(New OracleParameter("bacgencd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("bacgencd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetUsUeDupl_Anti(ByVal rsCd As String, ByVal rsUsDt As String, ByVal rsUseTag As String, ByVal rsCompDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeDupl_Anti() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT a.*"
            sSql += "  FROM ("
            sSql += "        SELECT anticd, antinmd, usdt, uedt"
            sSql += "          FROM lf230m"
            sSql += "         WHERE anticd = :anticd"
            sSql += "           AND usdt   <" + IIf(rsUseTag = "USDT", "=", "").ToString + " :compdt"
            sSql += "           AND uedt   >" + IIf(rsUseTag = "USDT", "", "=").ToString + " :compdt"
            sSql += "       ) a LEFT OUTER JOIN"
            sSql += "       ("
            sSql += "        SELECT anticd, antinmd, usdt, uedt"
            sSql += "          FROM lf230m"
            sSql += "         WHERE anticd = :anticd"
            sSql += "           AND usdt   = :usdt"
            sSql += "        ) b ON (a.anticd = b.anticd AND a.usdt = b.usdt)"
            sSql += " WHERE NVL(b.anticd, ' ') = ' '"

            al.Add(New OracleParameter("anticd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("anticd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetUsUeCd_Anti(ByVal rsCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeCd_Anti() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT anticd"
            sSql += "  FROM (SELECT anticd"
            sSql += "          FROM lf240m"
            sSql += "         WHERE anticd = :anticd"
            sSql += "         UNION ALL "
            sSql += "        SELECT anticd"
            sSql += "          FROM lm013m"
            sSql += "         WHERE anticd = :anticd"
            sSql += "       ) a"
            sSql += " WHERE ROWNUM = 1"

            al.Add(New OracleParameter("anticd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("anticd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetUsUeDupl_Bac(ByVal rsCd As String, ByVal rsUsDt As String, ByVal rsUseTag As String, ByVal rsCompDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeDupl_Bac() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            rsCompDt = rsCompDt.Replace("-", "").Replace(" ", "").Replace(":", "")
            rsUsDt = rsUsDt.Replace("-", "").Replace(" ", "").Replace(":", "")

            sSql = ""
            sSql += "SELECT a.*"
            sSql += "  FROM ("
            sSql += "        SELECT baccd, bacnmd, usdt, uedt"
            sSql += "          FROM lf210m"
            sSql += "         WHERE baccd = :baccd"
            sSql += "           AND usdt  <" + IIf(rsUseTag = "USDT", "=", "").ToString + " :compdt"
            sSql += "           AND uedt  >" + IIf(rsUseTag = "USDT", "", "=").ToString + " :compdt"
            sSql += "       ) a left join"
            sSql += "       ("
            sSql += "        SELECT baccd, bacnmd, usdt, uedt"
            sSql += "          FROM lf210m"
            sSql += "         WHERE baccd = :baccd"
            sSql += "           AND usdt  = :usdt"
            sSql += "       ) b ON (a.baccd = b.baccd AND a.usdt = b.usdt)"
            sSql += " WHERE NVL(b.baccd, ' ') = ' '"

            al.Add(New OracleParameter("baccd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("baccd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetUsUeCd_Bac(ByVal rsCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeCd_Bac() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT bcno  FROM lm012m"
            sSql += " WHERE baccd = :baccd"

            al.Add(New OracleParameter("baccd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetUsUeCd_BacGen(ByVal rsCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeCd_BacGen() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT bacgencd"
            sSql += "  FROM ("
            sSql += "        SELECT bacgencd  FROM lf210m"
            sSql += "         WHERE bacgencd = :bacgencd"
            sSql += "         UNION ALL "
            sSql += "        SELECT bacgencd  FROM lf240m"
            sSql += "         WHERE bacgencd = :bacgencd"
            sSql += "       ) a"
            sSql += " WHERE ROWNUM = 1"

            al.Add(New OracleParameter("bacgencd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("bacgencd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetUsUeDupl_BacGen(ByVal rsCd As String, ByVal rsUsDt As String, ByVal rsUseTag As String, ByVal rsCompDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeDupl_BacGen() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT a.*"
            sSql += "  FROM ("
            sSql += "        SELECT bacgencd, bacgennmd, usdt, uedt"
            sSql += "          FROM lf220m"
            sSql += "         WHERE bacgencd = :bacgencd"
            sSql += "           AND usdt     <" + IIf(rsUseTag = "USDT", "=", "").ToString + " :compdt"
            sSql += "           AND uedt     >" + IIf(rsUseTag = "USDT", "", "=").ToString + " :compdt"
            sSql += "       ) a LEFT JOIN"
            sSql += "       ("
            sSql += "        SELECT bacgencd, bacgennmd, usdt, uedt"
            sSql += "          FROM lf220m"
            sSql += "         WHERE bacgencd = :bacgencd"
            sSql += "           AND usdt     = :usdt"
            sSql += "       ) b ON (a.bacgencd = b.bacgencd AND a.usdt = b.usdt)"
            sSql += " WHERE NVL(b.bacgencd, ' ') = ' '"

            al.Add(New OracleParameter("bacgencd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("bacgencd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
         Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetUsUeCd_Test(ByVal rsCd1 As String, ByVal rsCd2 As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeCd_Test() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT bcno  FROM lj011m"
            sSql += " WHERE tclscd  = :testcd"
            sSql += "   AND spccd   = :spccd"
            sSql += "   AND colldt >= :usdt"
            sSql += "   AND ROWNUM  = 1"
            sSql += " UNION ALL "
            sSql += "SELECT bcno  FROM lr010m"
            sSql += " WHERE testcd  = :testcd"
            sSql += "   AND spccd   = :spccd"
            sSql += "   AND tkdt   >= :usdt"
            sSql += "   AND ROWNUM  = 1"
            sSql += " UNION ALL "
            sSql += "SELECT bcno  FROM lm010m"
            sSql += " WHERE testcd  = :testcd"
            sSql += "   AND spccd   = :spccd"
            sSql += "   AND tkdt   >= :usdt"
            sSql += "   AND ROWNUM  = 1"

            al.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsCd1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd1))
            al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsCd2.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd2))
            al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            al.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsCd1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd1))
            al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsCd2.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd2))
            al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            al.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsCd1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd1))
            al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsCd2.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd2))
            al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
           Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetUsUeDupl_Test(ByVal rsCd1 As String, ByVal rsCd2 As String, ByVal rsUsDt As String, ByVal rsUseTag As String, ByVal rsCompDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeDupl_Test() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT a.*"
            sSql += "  FROM ("
            sSql += "        SELECT testcd, spccd, tnm, usdt, uedt"
            sSql += "          FROM lf060m"
            sSql += "         WHeRE testcd = :testcd"
            sSql += "           AND spccd  = :spccd"
            sSql += "           AND usdt   <" + IIf(rsUseTag = "USDT", "=", "").ToString + " :compdt"
            sSql += "           AND uedt   >" + IIf(rsUseTag = "USDT", "", "=").ToString + " :compdt"
            sSql += "       ) a LEFT OUTER JOIN"
            sSql += "       ("
            sSql += "        SELECT testcd, spccd, tnm, usdt, uedt"
            sSql += "          FROM lf060m"
            sSql += "         WHERE testcd = :testcd"
            sSql += "           AND spccd  = :spccd"
            sSql += "           AND usdt   = :usdt"
            sSql += "       ) b ON (a.testcd = b.testcd AND a.spccd = b.spccd AND a.usdt = b.usdt)"
            sSql += " WHERE NVL(b.testcd, ' ') = ' '"
            sSql += "   AND NVL(b.spccd,  ' ') = ' '"

            al.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsCd1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd1))
            al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsCd2.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd2))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsCd1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd1))
            al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsCd2.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd2))
            al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
           Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetUsUeCd_ExLab(ByVal rsCd As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeCd_ExLab() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT exlabcd  FROM lf060m"
            sSql += " WHERE exlabcd = :exlabcd"

            al.Add(New OracleParameter("exlabcd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetUsUeCd_Tube(ByVal rsCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeCd_Tube() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT tubecd"
            sSql += "  FROM lf060m"
            sSql += " WHERE tubecd = :tubecd"

            al.Add(New OracleParameter("tubecd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))

            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetUsUeDupl_Tube(ByVal rsCd As String, ByVal rsUsDt As String, ByVal rsUseTag As String, ByVal rsCompDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeDupl_Tube() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT a.*"
            sSql += "  FROM ("
            sSql += "        SELECT tubecd, tubenmd, usdt, uedt"
            sSql += "          FROM lf040m"
            sSql += "         WHERE tubecd = :tubecd"
            sSql += "           AND usdt <" + IIf(rsUseTag = "USDT", "=", "").ToString + " :compdt"
            sSql += "           AND uedt >" + IIf(rsUseTag = "USDT", "", "=").ToString + " :compdt"
            sSql += "       ) a LEFT OUTER JOIN"
            sSql += "       ("
            sSql += "        SELECT tubecd, tubenmd, usdt, uedt"
            sSql += "          FROM lf040m"
            sSql += "         WHERE tubecd = :tubecd"
            sSql += "           AND usdt   = :usdt"
            sSql += "        ) b ON (a.tubecd = b.tubecd AND a.usdt = b.usdt)"
            sSql += " WHERE NVL(b.tubecd, ' ') = ' '"

            al.Add(New OracleParameter("tubecd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("tubecd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
           Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetUsUeCd_Slip(ByVal rsCd1 As String, ByVal rsCd2 As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeCd_Slip() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT testcd, spccd, tnm, usdt, uedt"
            sSql += "  FROM lf060m"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND slipcd = :slipcd"
            sSql += "   AND usdt  >= :usdt"

            al.Add(New OracleParameter("partcd",  OracleDbType.Varchar2, rsCd1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd1))
            al.Add(New OracleParameter("slipcd",  OracleDbType.Varchar2, rsCd2.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd2))
            al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
           Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetUsUeDupl_Slip(ByVal rsCd1 As String, ByVal rsCd2 As String, ByVal rsUsDt As String, ByVal rsUseTag As String, ByVal rsCompDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeCd_Slip() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT a.*"
            sSql += "  FROM ("
            sSql += "        SELECT partcd, slipcd, slipnm, usdt, uedt"
            sSql += "          FROM lf021m"
            sSql += "         WHERE partcd = :partcd"
            sSql += "           AND slipcd = :slipcd"
            sSql += "           AND usdt   <" + IIf(rsUseTag = "USDT", "=", "").ToString + " :compdt"
            sSql += "           AND uedt   >" + IIf(rsUseTag = "USDT", "", "=").ToString + " :compdt"
            sSql += "       ) a LEFT OUTER JOIN"
            sSql += "       ("
            sSql += "        SELECT partcd, slipcd, slipnm, usdt, uedt"
            sSql += "          FROM lf021m"
            sSql += "         WHERE partcd = :partcd"
            sSql += "           AND slipcd = :slipcd"
            sSql += "           AND usdt   = :usdt"
            sSql += "        ) b ON (a.partcd = b.partcd AND a.slipcd = b.slipcd AND a.usdt = b.usdt)"
            sSql += " WHERE NVL(b.partcd, ' ') = ' '"
            sSql += "   AND NVL(b.slipcd, ' ') = ' '"

            al.Add(New OracleParameter("partcd",  OracleDbType.Varchar2, rsCd1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd1))
            al.Add(New OracleParameter("slipcd",  OracleDbType.Varchar2, rsCd2.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd2))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("partcd",  OracleDbType.Varchar2, rsCd1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd1))
            al.Add(New OracleParameter("slipcd",  OracleDbType.Varchar2, rsCd2.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd2))
            al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
           Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetUsUeDupl_bccls(ByVal rsCd1 As String, ByVal rsUsDt As String, ByVal rsUseTag As String, ByVal rsCompDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeDupl_bccls() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT a.*"
            sSql += "  FROM ("
            sSql += "        SELECT bcclscd, bcclsnm, usdt, uedt"
            sSql += "          FROM lf010m"
            sSql += "         WHERE bcclscd = :bcclscd"
            sSql += "           AND usdt    <" + IIf(rsUseTag = "USDT", "=", "").ToString + " :compdt"
            sSql += "           AND uedt    >" + IIf(rsUseTag = "USDT", "", "=").ToString + " :compdt"
            sSql += "       ) a LEFT OUTER JOIN"
            sSql += "       ("
            sSql += "        SELECT bcclscd, bcclsnm, usdt, uedt"
            sSql += "          FROM lf010m"
            sSql += "         WHERE bcclscd = :bcclscd"
            sSql += "           AND usdt    = :usdt"
            sSql += "        ) b ON (a.bcclscd = b.bcclscd AND a.usdt = b.usdt)"
            sSql += " WHERE NVL(b.bcclscd, ' ') = :bcclscd"

            al.Add(New OracleParameter("bcclscd",  OracleDbType.Varchar2, rsCd1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd1))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("bcclscd",  OracleDbType.Varchar2, rsCd1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd1))
            al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsCd1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))
            al.Add(New OracleParameter("bcclscd",  OracleDbType.Varchar2, rsCd1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd1))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetUsUeDupl_OSlip(ByVal rsCd As String, ByVal rsUsDt As String, ByVal rsUseTag As String, ByVal rsCompDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeDupl_OSlip() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT a.*"
            sSql += "  FROM ("
            sSql += "        SELECT tordslip, tordslipnm, usdt, uedt"
            sSql += "          FROM lf100m"
            sSql += "         WHERE tordslip = :tordslip"
            sSql += "           AND usdt     <" + IIf(rsUseTag = "USDT", "=", "").ToString + " :compdt"
            sSql += "           AND uedt     >" + IIf(rsUseTag = "USDT", "", "=").ToString + " :compdt"
            sSql += "       ) a LEFT OUTER JOIN"
            sSql += "       ("
            sSql += "        SELECT tordslip, tordslipnm, usdt, uedt"
            sSql += "          FROM lf100m"
            sSql += "         WHERE tordslip = :tordslip"
            sSql += "           AND usdt     = :usdt"
            sSql += "        ) b ON (a.tordslip = b.tordslip AND a.usdt = b.usdt)"
            sSql += " WHERE NVL(b.tordslip, ' ') = ' '"

            al.Add(New OracleParameter("tordslip",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("tordslip",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransKSRackInfo_UE(ByVal rsBcclscd As String, ByVal rsRackId As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = " Public Function TransKSRackInfo_UE(string, string, string, string, string, string) As Boolean"

        Try
            Dim sSql As String = ""
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = "", sMsg As String = ""
            Dim alTest As New ArrayList

            sMsg = ifExistOtherUsableData("LF160", "RACKID", rsRackId, rsRegID)

            If IsNothing(sMsg) Then
                MsgBox("쿼리문의 오류가 있습니다!!", MsgBoxStyle.Exclamation)
                Exit Function
            End If

            If Not sMsg = "" Then
                MsgBox(sMsg, MsgBoxStyle.Critical)
                Exit Function
            End If

            'LF160M : 보관검체 마스터
            '   LF160H Insert
            sSql = ""
            sSql += "INSERT INTO lf160h "
            sSql += "SELECT fn_ack_sysdate, '" + rsRegID + "', f.* FROM lf160m f"
            sSql += " WHERE bcclscd = '" + rsBcclscd + "'"
            sSql += "   AND rackid  = '" + rsRackId + "'"

            alTest.Add(sSql)

            '   LF160M Delete
            sSql = ""
            sSql += "DELETE lf160m"
            sSql += " WHERE bcclscd = '" + rsBcclscd + "'"
            sSql += "   AND rackid  = '" + rsRackId + "'"
            alTest.Add(sSql)

            If LISAPP.APP_DB.DBSql.ExcuteSql(alTest) = False Then
                Return False
            End If

            Return True

        Catch ex As Exception
          Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function TransSectInfo_Slip_E(ByVal rsSLIP As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUsDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransSectInfo_UPD_US() As Boolean"

        Try
            Dim sSql As String = ""
            Dim alTest As New ArrayList

            'LF010M : 슬립 마스터 
            '   LF010H Insert 
            sSql = ""
            sSql += "INSERT INTO lf100h "
            sSql += "SELECT fn_ack_sysdate, '" + rsRegID + "', f.* FROM lf100m f"
            sSql += " WHERE tordslip = '" + rsSLIP + "'"
            sSql += "   AND usdt     = '" + rsUsDt + "'"
            alTest.Add(sSql)

            '   LF010M Update 
            sSql = ""
            sSql += "UPDATE lf100m SET"
            sSql += "       uedt     = '" + rsUsDtNew + "',"
            sSql += "       regdt    = fn_ack_sysdate,"
            sSql += "       regid    = '" + rsRegID + "'"
            sSql += " WHERE tordslip = '" + rsSLIP + "'"
            sSql += "   AND usdt     ='" + rsUsDt + "'"
            alTest.Add(sSql)

            If LISAPP.APP_DB.DBSql.ExcuteSql(alTest) = False Then
                Return False
            End If

            Return True

        Catch ex As Exception
          Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetUsUeCd_bccls(ByVal rsCd1 As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeCd_bccls() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT testcd, spccd, tnm, usdt, uedt"
            sSql += "  FROM lf060m"
            sSql += " WHERE bcclscd = :bcclscd"
            sSql += "   AND usdt   >= :usdt"

            al.Add(New OracleParameter("bcclscd",  OracleDbType.Varchar2, rsCd1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd1))
            al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
          Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetUsUeCd_tordslip(ByVal rsCd1 As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeCd_tordSlip() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT testcd, spccd, tnm, usdt, uedt"
            sSql += "  FROM lf060m"
            sSql += " WHERE tordslip = :tordslip"
            sSql += "   AND uedt    >= fn_ack_sysdate"

            al.Add(New OracleParameter("tordslip",  OracleDbType.Varchar2, rsCd1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd1))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetNewUSDT() As DataTable
        Dim sFn As String = "Public Function GetNewUSDT() As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT TO_CHAR(SYSDATE, 'yyyymmdd') || '000000' newusdt FROM DUAL"

            DbCommand()
            GetNewUSDT = DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetNewRegDT() As DataTable
        Dim sFn As String = "Public Function GetNewUSDT() As DataTable"

        Try
            Dim sSql As String = ""

            sSql = "SELECT fn_ack_sysdate FROM DUAL"

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
           Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetBacgenInfo() As DataTable
        Dim sFn As String = "Public Function GetBacgenInfo() As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT '[' || bacgencd || '] ' || bacgennmd bacgen"
            sSql += "  FROM lf220m"
            sSql += " ORDER BY bacgencd"

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
          Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetComCdInfo(ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetComCdInfo(String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT DISTINCT '[' || comcd || '] ' || comnmd comnmd, dispseql sort_key"
            sSql += "  FROM lf120m"

            If rsUsDt <> "" Then
                sSql += " WHERE usdt <= :usdt"
                sSql += "   AND uedt >  :usdt"

                alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))
                alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))
            Else
                sSql += " WHERE usdt <= fn_ack_sysdate"
                sSql += "   AND uedt >  fn_ack_sysdate"

            End If
            sSql += " ORDER BY sort_key, comnmd"

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
           Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetExLabInfo() As DataTable
        Dim sFn As String = "Public Function GetExLabInfo() As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT '[' || exlabcd || '] ' || exlabnmd exlabnmd"
            sSql += "  FROM lf050m"
            sSql += " WHERE NVL(delflg, '0') = '0'"
            sSql += " ORDER BY exlabcd"


            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetFtCdInfo() As DataTable
        Dim sFn As String = "Public Function GetFtCdInfo() As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT '[' || ftcd || '] '|| ftnms ftnm"
            sSql += "  FROM lf121m"
            sSql += " ORDER BY ftcd"

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function
    '<<<20170418 참고치 엑셀 추가 
    Public Function GetRefExcel(ByVal asTestcd As String, ByVal asSpccd As String) As DataTable
        Dim sFn As String = "Public Function GetSpcInfo(String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT f60.testcd , f60.tnm , f60.spccd , f30.spcnm , " + vbCrLf
            sSql += "       case f61.ageymd when 'Y' then '년' " + vbCrLf
            sSql += "                       when 'M' then '월' " + vbCrLf
            sSql += "                       when 'D' then '일'  end  as ageymd " + vbCrLf
            sSql += "       ,f61.sage || ' - ' || f61.eage as years " + vbCrLf
            sSql += "       ,f61.reflm || ' - ' || f61.refhm as man " + vbCrLf
            sSql += "       ,f61.reflf || ' - ' || f61.refhf as woman" + vbCrLf
            sSql += "       ,F61.REFLT" + vbCrLf
            sSql += "  from lf061m f61 , lf060m f60 , lf030m f30" + vbCrLf
            sSql += " where f60.usdt <= fn_ack_sysdate  " + vbCrLf
            sSql += "   and f60.uedt >= fn_ack_sysdate" + vbCrLf
            sSql += "   and f60.testcd = '" + asTestcd + "'" + vbCrLf
            sSql += "   and f60.spccd = '" + asSpccd + "'" + vbCrLf
            sSql += "   and f61.testcd = f60.testcd " + vbCrLf
            sSql += "   and f61.spccd = f60.spccd" + vbCrLf
            sSql += "   and F61.USDT = f60.usdt" + vbCrLf
            sSql += "   and f60.spccd = f30.spccd " + vbCrLf
            sSql += " order by f60.testcd ,f60.spccd " + vbCrLf
            sSql += "" + vbCrLf

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function


    Public Function GetSpcInfo(ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetSpcInfo(String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT '[' || spccd || '] ' ||  spcnmd spcnmd"
            sSql += "  FROM lf030m"
            sSql += " WHERE usdt <= :usdt"
            sSql += "   AND uedt >  :usdt"
            sSql += " ORDER BY spccd"

            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)
        Catch ex As Exception
           Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetTestCdInfo_xls(ByVal rsTableNm As String, ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsUsDt As String, ByVal rsTclsCd As String, ByVal rsTSpcCd As String) As DataTable
        Dim sFn As String = "Public Function GetTestCdInfo() As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            If rsTableNm.ToLower = "lf062m" Then
                sSql += " SELECT *"
                sSql += "   FROM " + rsTableNm + ""
                sSql += "  WHERE testcd = :testcd"
                sSql += "    AND spccd  = :spccd"
                sSql += "    AND tclscd = :tclscd"
                sSql += "    AND tspccd = :tspccd"

                alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
                alParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
                alParm.Add(New OracleParameter("tclscd",  OracleDbType.Varchar2, rsTclsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTclsCd))
                alParm.Add(New OracleParameter("tspccd",  OracleDbType.Varchar2, rsTSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTSpcCd))
            Else
                sSql += " SELECT *"
                sSql += "   FROM " + rsTableNm + ""
                sSql += "  WHERE testcd = :testcd"
                sSql += "    AND spccd  = :spccd"
                sSql += "    AND usdt   = :usdt"

                alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
                alParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
                alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            End If

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
           Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetTestCdInfo(ByVal rsTestCd As String) As DataTable
        Dim sFn As String = "Public Function GetTClsCdInfo(ByVal asTClsCd As String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT MIN(CASE WHEN tcdgbn = 'C' THEN '-- ' || tnmd ELSE tnmd END) tnmd, bcclscd, tcdgbn, titleyn"
            sSql += "  FROM lf060m"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND usdt <= fn_ack_sysdate"
            sSql += "   AND uedt >  fn_ack_sysdate"
            sSql += " GROUP BY bcclscd, tcdgbn, titleyn"

            alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
          Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetTestCdInfo(ByVal rsTestCd As String, ByVal rsSpcCd As String, Optional ByVal rsUsDt As String = "") As DataTable
        Dim sFn As String = "Public Function GetTestCdInfo(String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT f6.testcd, f6.spccd,"
            sSql += "       MIN(CASE WHEN f6.tcdgbn = 'C' THEN '-- ' || f6.tnmd ELSE f6.tnmd END) tnmd, MIN(f3.spcnmd) spcnmd,"
            sSql += "       f6.tcdgbn, NVL(f6.mbttype, '0') mbttype, f6.bcclscd, f6.titleyn"
            sSql += "  FROM lf060m f6, lf030m f3"
            sSql += " WHERE f6.usdt  <= fn_ack_sysdate"
            sSql += "   AND f6.uedt  >  fn_ack_sysdate"
            sSql += "   AND f6.spccd  = f3.spccd"
            sSql += "   AND f3.usdt  <= fn_ack_sysdate"
            sSql += "   AND f3.uedt  >  fn_ack_sysdate"
            sSql += "   AND f6.testcd = :testcd"

            alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))

            If rsSpcCd <> "" Then
                sSql += "    AND f6.spccd = :spccd"
                alParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
            End If

            If rsUsDt <> "" Then
                sSql += "   AND f6.usdt = :usdt"
                alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))
            End If

            sSql += " GROUP BY f6.testcd, f6.spccd, f6.tcdgbn, f6.mbttype, f6.bcclscd, f6.titleyn"
            sSql += " ORDER BY testcd, spccd"


            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
          Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function GetTOrdSlipInfo(ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetTOrdSlipInfo(String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT '[' || tordslip || '] ' || tordslipnm tordslipnmd"
            sSql += "  FROM lf100m"
            sSql += " WHERE usdt <= :usdt"
            sSql += "   AND uedt >  :usdt"
            sSql += " ORDER BY dispseq, tordslip"

            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function
    Public Function GetBcclsInfo(ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetTSectInfo(ByVal asUSDT As String, ByVal asUEDT As String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT '[' || bcclscd || '] ' ||  bcclsnmd bcclsnmd"
            sSql += "  FROM lf010m"
            sSql += " WHERE usdt <= :usdt"
            sSql += "   AND uedt >  :usdt"
            sSql += " ORDER BY bcclscd"

            alParm.Add(New OracleParameter("usdt", OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))
            alParm.Add(New OracleParameter("usdt", OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function
    Public Function GetRefInfo(ByVal rsRefcd As String) As DataTable
        Dim sFn As String = "Public Function GetTSectInfo(ByVal asUSDT As String, ByVal asUEDT As String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            'sSql += "SELECT '[' || refcd || '] ' ||  refnm"
            sSql += "SELECT refcd, refnm , refnmd , groupcd , seq "
            sSql += "  FROM lf510m"

            If rsRefcd <> "" Then
                sSql += "  where refcd  = :refcd "
                alParm.Add(New OracleParameter("usdt", OracleDbType.Varchar2, rsRefcd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsRefcd))
            End If

            sSql += " ORDER BY refcd"

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function


    Public Function GetRefInfo(ByVal riMode As Integer, ByVal rsSearch As String) As DataTable
        Dim sFn As String = "Public Function GetTSectInfo(ByVal asUSDT As String, ByVal asUEDT As String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList


            If riMode = 0 Then

                sSql += "SELECT refcd , refnm , refnmd , groupcd , seq"
                sSql += "  FROM lf510m"


            Else
                sSql += "SELECT refcd , refnm , refnmd , groupcd , seq"
                sSql += "  FROM lf510m"

                If rsSearch <> "" Then

                    sSql += " WHERE refcd = :refcd"

                    alParm.Add(New OracleParameter("refcd", OracleDbType.Varchar2, rsSearch.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSearch))
                End If

                sSql += " ORDER BY refcd"



            End If

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function GetTubeInfo(ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetTubeInfo(ByVal asUSDT As String, ByVal asUEDT As String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT '[' || tubecd || '] ' ||  tubenmd tubenmd"
            sSql += "  FROM lf040m"
            sSql += " WHERE usdt <= :usdt"
            sSql += "   AND uedt >  :usdt"
            sSql += " ORDER BY tubecd"

            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetUsrInfo(ByVal rbOnlyDr As Boolean) As DataTable
        Dim sFn As String = "Public Function GetUsrInfo(Boolean) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT usrid, usrnm, usrpwd, usrlvl, usrsect, drspyn, usrflg,"
            sSql += "       fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid"
            sSql += "  FROM lf090m"
            sSql += " WHERE NVL(usrflg, '0') = '0'"

            If rbOnlyDr Then
                sSql += "   AND NVL(drspyn, '0') = '1'"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
           Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function GetUsrInfo(ByVal rsUsrId As String, ByVal rbOnlyDr As Boolean) As DataTable
        Dim sFn As String = "Public Function GetUsrInfo(String, Boolean) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT usrnm, usrpwd, usrlvl, medino, other, drspyn, delflg ,"
            sSql += "       fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid"
            sSql += "  FROM lf090m"
            sSql += " WHERE usrid = :usrid"

            alParm.Add(New OracleParameter("usrid",  OracleDbType.Varchar2, rsUsrId.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsrId))

            If rbOnlyDr Then
                sSql += "   AND NVL(drspyn, '0') = '1'"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
           Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function ifExistOtherUsableData(ByVal rsCurTblNm As String, ByVal rsColNm1 As String, ByVal rsCd1 As String, ByVal rsUsDt As String) As String
        Dim sFn As String = "ifExistOtherUsableData"

        Try
            Dim sReturn As String = ""
            Dim sTblNm As String = ""

            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT table_name"
            sSql += "  FROM user_tab_columns"
            sSql += " WHERE column_name = :colnm"

            alParm.Add(New OracleParameter("colnm",  OracleDbType.Varchar2, rsColNm1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsColNm1))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, alParm)

            If dt.Rows.Count < 1 Then Return ""

            For ix As Integer = 0 To dt.Rows.Count - 1
                sTblNm = dt.Rows(ix).Item("table_name").ToString

                If sTblNm.StartsWith(rsCurTblNm) Then GoTo next_i
                If Not sTblNm.StartsWith("LF") Then GoTo next_i
                If sTblNm.EndsWith("H") Then GoTo next_i
                If sTblNm.IndexOf("LF061M") >= 0 Then GoTo next_i

                Fn.log(rsCurTblNm + " 관련 TABLE_NAME : " + sTblNm)

                sSql = ""
                sSql += "SELECT column_name"
                sSql += "  FROM user_tab_columns"
                sSql += " WHERE table_name  = :tblnm"
                sSql += "   AND column_name = 'UEDT'"

                alParm.Clear()
                alParm.Add(New OracleParameter("tblnm",  OracleDbType.Varchar2, sTblNm.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, sTblNm))

                DbCommand()
                Dim dt2 As DataTable = DbExecuteQuery(sSql, alParm)

                If dt2.Rows.Count > 0 Then
                    sSql = ""
                    sSql += "SELECT " + rsColNm1
                    sSql += "  FROM " + sTblNm + ""
                    sSql += " WHERE " + rsColNm1 + " = :colnm"
                    sSql += "   AND uedt > :usdt"

                    alParm.Clear()
                    alParm.Add(New OracleParameter("colnm",  OracleDbType.Varchar2, rsCd1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd1))
                    alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

                    DbCommand()
                    Dim dt3 As DataTable = DbExecuteQuery(sSql, alParm)

                    If dt3.Rows.Count < 0 Then
                        sReturn += "해당 코드를 사용하는 데이터 확인을 필요로 합니다!!(" + sTblNm + ")" + vbCrLf
                    End If
                Else
                    sSql = ""
                    sSql += "SELECT " + rsColNm1
                    sSql += "  FROM " + sTblNm + ""
                    sSql += " WHERE " + rsColNm1 + " = :colnm"

                    alParm.Clear()
                    alParm.Add(New OracleParameter("colnm",  OracleDbType.Varchar2, rsCd1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd1))

                    DbCommand()
                    Dim dt3 As DataTable = DbExecuteQuery(sSql, alParm)

                    If dt3.Rows.Count < 0 Then
                        sReturn += "해당 코드를 사용하는 데이터 확인을 필요로 합니다!!(" + sTblNm + ")" + vbCrLf
                    End If
                End If
next_i:
            Next

            Return sReturn
        Catch ex As Exception
          Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function ifExistOtherUsableData(ByVal rsCurTblNm As String, ByVal rsColNm1 As String, ByVal rsColNm2 As String, ByVal rsCd1 As String, ByVal rsCd2 As String, ByVal rsUsDt As String) As String
        Dim sFn As String = "ifExistOtherUsableData"

        Try
            Dim sReturn As String = ""
            Dim sTblNm As String = ""

            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT table_name"
            sSql += "  FROM user_tab_columns"
            sSql += " WHERE column_name = :colnm1"
            sSql += " INTERSECT "
            sSql += "SELECT table_name"
            sSql += "  FROM user_tab_columns"
            sSql += " WHERE column_name = :colnm2"

            alParm.Add(New OracleParameter("colnm1",  OracleDbType.Varchar2, rsColNm1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsColNm1))
            alParm.Add(New OracleParameter("colnm2",  OracleDbType.Varchar2, rsColNm2.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsColNm2))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, alParm)

            If dt.Rows.Count < 1 Then Return ""

            For ix As Integer = 0 To dt.Rows.Count - 1
                sTblNm = dt.Rows(ix).Item("table_name").ToString

                If sTblNm.StartsWith(rsCurTblNm) Then GoTo next_i
                If Not sTblNm.StartsWith("LF") Then GoTo next_i
                If sTblNm.EndsWith("H") Then GoTo next_i
                If Not sTblNm = "LF021M" Then GoTo next_i

                Fn.log(rsCurTblNm + " 관련 TABLE_NAME : " + sTblNm)

                sSql = ""
                sSql += "SELECT column_name"
                sSql += "  FROM user_tab_columns"
                sSql += " WHERE table_name = :tblnm"
                sSql += "   AND column_name = 'UEDT'"

                alParm.Clear()
                alParm.Add(New OracleParameter("tblnm",  OracleDbType.Varchar2, sTblNm.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, sTblNm))

                DbCommand()
                Dim dt2 As DataTable = DbExecuteQuery(sSql, alParm)

                If dt2.Rows.Count > 0 Then
                    sSql = ""
                    sSql += "SELECT " + rsColNm1
                    sSql += "  FROM " + sTblNm + ""
                    sSql += " WHERE " + rsColNm1 + " = :colnm1"
                    sSql += "   AND " + rsColNm2 + " = :colnm2"
                    sSql += "   AND uedt > :uedt"

                    alParm.Clear()
                    alParm.Add(New OracleParameter("colnm1",  OracleDbType.Varchar2, rsCd1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd1))
                    alParm.Add(New OracleParameter("colnm2",  OracleDbType.Varchar2, rsCd2.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd2))
                    alParm.Add(New OracleParameter("uedt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))


                    DbCommand()
                    Dim dt3 As DataTable = DbExecuteQuery(sSql, alParm)

                    If dt3.Rows.Count > 0 Then
                        sReturn += "해당 코드를 사용하는 데이터 확인을 필요로 합니다!!(" + sTblNm & ")" + vbCrLf
                    End If
                Else
                    sSql = ""
                    sSql += "SELECT " + rsColNm1
                    sSql += "  FROM " + sTblNm + ""
                    sSql += " WHERE " + rsColNm1 + " = :colnm1"
                    sSql += "   AND " + rsColNm2 + " = :colnm2"

                    alParm.Clear()
                    alParm.Add(New OracleParameter("colnm1",  OracleDbType.Varchar2, rsCd1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd1))
                    alParm.Add(New OracleParameter("colnm2",  OracleDbType.Varchar2, rsCd2.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd2))

                    DbCommand()
                    Dim dt3 As DataTable = DbExecuteQuery(sSql, alParm)

                    If dt3.Rows.Count > 0 Then
                        sReturn += "해당 코드를 사용하는 데이터 확인을 필요로 합니다!!(" + sTblNm + ")" + vbCrLf
                    End If
                End If
next_i:
            Next

            Return sReturn
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function ifExistOtherUsableData(ByVal ra_RTblNm() As String, ByVal rsColNm1 As String, ByVal rsColNm2 As String, ByVal rsCd1 As String, ByVal rsCd2 As String, ByVal rsUsDt As String) As String
        Dim sFn As String = "ifExistOtherUsableData"

        Try
            Dim sReturn As String = ""
            Dim sTblNm As String = ""

            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT table_name"
            sSql += "  FROM user_tab_columns"
            sSql += " WHERE column_name = :colnm1"
            sSql += " INTERSECT "
            sSql += "SELECT table_name"
            sSql += "  FROM user_tab_columns"
            sSql += " WHERE column_name = :colnm2"

            alParm.Add(New OracleParameter("colnm1",  OracleDbType.Varchar2, rsColNm1.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsColNm1))
            alParm.Add(New OracleParameter("colnm2",  OracleDbType.Varchar2, rsColNm2.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsColNm2))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, alParm)

            If dt.Rows.Count < 1 Then Return ""

            For ix As Integer = 0 To dt.Rows.Count - 1
                sTblNm = dt.Rows(ix).Item("table_name").ToString

                For j As Integer = 0 To ra_RTblNm.Length - 1
                    If sTblNm.StartsWith(ra_RTblNm(j).ToString) Then GoTo next_i
                Next

                If Not sTblNm.StartsWith("LF") Then GoTo next_i
                If sTblNm.EndsWith("H") Then GoTo next_i

                Fn.log(ra_RTblNm(0).ToString + " 관련 TABLE_NAME : " + sTblNm)

                sSql = ""
                sSql += "SELECT column_name"
                sSql += "  FROM user_tab_columns"
                sSql += " WHERE table_name = :tblnm"
                sSql += "   AND column_name = 'UEDT'"

                alParm.Clear()
                alParm.Add(New OracleParameter("tblnm",  OracleDbType.Varchar2, sTblNm.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, sTblNm))

                DbCommand()
                Dim dt2 As DataTable = DbExecuteQuery(sSql, alParm)

                If dt2.Rows.Count > 0 Then
                    sSql = " SELECT " + rsColNm1 + ", " + rsColNm2
                    sSql += "  FROM " + sTblNm + ""
                    sSql += " WHERE " + rsColNm1 + " = '" + rsCd1 + "'"
                    sSql += "   AND " + rsColNm2 + " = '" + rsCd2 + "'"
                    sSql += "   AND uedt > '" + rsUsDt + "'"

                    Dim objDT3 As DataTable

                    DbCommand()
                    objDT3 = DbExecuteQuery(sSql)

                    If objDT3.Rows.Count > 0 Then
                        sReturn += "해당 코드를 사용하는 데이터 확인을 필요로 합니다!!(" & sTblNm & ")" & vbCrLf
                    End If
                Else
                    sSql = " SELECT " + rsColNm1 + ", " + rsColNm2
                    sSql += "  FROM " + sTblNm + ""
                    sSql += " WHERE " + rsColNm1 + " = '" + rsCd1 + "'"
                    sSql += "   AND " + rsColNm2 + " = '" + rsCd2 + "'"

                    Dim objDT3 As DataTable

                    DbCommand()
                    objDT3 = DbExecuteQuery(sSql)

                    If objDT3.Rows.Count > 0 Then
                        sReturn += "해당 코드를 사용하는 데이터 확인을 필요로 합니다!!(" & sTblNm & ")" & vbCrLf
                    End If
                End If
next_i:
            Next

            Return sReturn
        Catch ex As Exception
           Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

End Class

#Region " APP_F_% 일반검사, 공통 "

Public Class APP_F_KEYPAD
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_KEYPAD" & vbTab

    Public Function TransKeyPadInfo_UE(ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsRegId As String) As Boolean
        Dim sFn As String = "Public Function TransCvtRstInfo_UE(String, String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF420H Backup
            sSql = ""
            sSql += "INSERT INTO lf420h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf420m f"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()


            sSql = ""
            sSql += "DELETE lf420m"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function GetTclsCdsInfo(ByVal rsTestCd As String, ByVal rsSpcCd As String) As DataTable
        Dim sFn As String = "Public Function GetTclsCdsInfo(string, string) As DataTable"

        Try
            Dim sSql As String = ""
            Dim arlParm As New ArrayList

            sSql += "SELECT testcd, tnmd"
            sSql += "  FROM lf060m"
            sSql += " WHERE testcd LIKE :testcd || '%'"
            sSql += "   AND testcd <> :testcd"
            sSql += "   AND spccd  =  :spccd"
            sSql += "   AND usdt   <= fn_ack_sysdate"
            sSql += "   AND uedt   >  fn_ack_sysdate"

            sSql += " UNION "
            sSql += "SELECT a.testcd, b.tnmd"
            sSql += "  FROM lf062m a, lf060m b"
            sSql += " WHERE a.tclscd = :testcd"
            sSql += "   AND a.tspccd = :spccd"
            sSql += "   AND a.testcd = b.testcd"
            sSql += "   AND a.tspccd = b.spccd"
            sSql += "   AND b.usdt  <= fn_ack_sysdate"
            sSql += "   AND b.uedt  >  fn_ack_sysdate"

            arlParm.Add(New OracleParameter("testcd", rsTestCd))
            arlParm.Add(New OracleParameter("testcd", rsTestCd))
            arlParm.Add(New OracleParameter("spccd", rsSpcCd))

            arlParm.Add(New OracleParameter("testcd", rsTestCd))
            arlParm.Add(New OracleParameter("spccd", rsSpcCd))

            DbCommand()
            Return DbExecuteQuery(sSql, arlParm)

        Catch ex As Exception
             Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function TransKeyPadInfo(ByVal rITcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                    ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransCalcInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF420M :KEYPAD 설정 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With rITcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                If sValue = "" Then
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = DBNull.Value
                                Else
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End If

                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf420m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With rITcol1
                        'LF420H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf420h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf420m f"
                        sSql += " WHERE testcd = :testcd"
                        sSql += "   AND spccd  = :spccd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        sSql = ""
                        sSql += "DELETE lf420m"
                        sSql += " WHERE testcd = :testcd"
                        sSql += "   AND spccd  = :spccd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                If sValue = "" Then
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = DBNull.Value
                                Else
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End If
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf420M (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function GetKeyPadInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetKeyPadInfo(Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT testspc, tnmd, spcnmd, formgbn, testcd, spccd"
                sSql += "  FROM ("
                sSql += "        SELECT DISTINCT"
                sSql += "              RPAD(f42.testcd, 6, ' ') || f42.spccd testspc, f60.tnmd, f30.spcnmd, f42.testcd, f42.spccd,"
                sSql += "              CASE WHEN f42.formgbn = '0' THEN '숫자' ELSE '알파벳' END formgbn"
                sSql += "         FROM lf420m f42, lf060m f60, lf030m f30"
                sSql += "        WHERE f42.testcd = f60.testcd"
                sSql += "          AND f42.spccd  = f60.spccd"
                sSql += "          AND f42.spccd  = f30.spccd"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If

            ElseIf riMode = 1 Then
                sSql += "SELECT testspc, tnmd, spcnmd, formgbn, testcd, spccd, diffday, moddt, modid"
                sSql += "  FROM ("
                sSql += "        SELECT RPAD(f42.testcd, 6, ' ') || f42.spccd testspc, f60.tnmd, f30.spcnmd, f42.testcd, f42.spccd,"
                sSql += "               CASE WHEN f42.formgbn = '0' THEN '숫자' ELSE '알파벳' END formgbn,"
                sSql += "               null diffday, '' moddt, '' modid"
                sSql += "          FROM lf420m f42, lf060m f60, lf030m f30"
                sSql += "         WHERE f42.testcd = f60.testcd"
                sSql += "           AND f42.spccd  = f60.spccd"
                sSql += "           AND f42.spccd  = f30.spccd"
                sSql += "         UNION ALL "
                sSql += "        SELECT RPAD(f42.testcd, 6, ' ') || f42.spccd testspc, f60.tnmd, f30.spcnmd, f42.testcd, f42.spccd,"
                sSql += "               CASE WHEN f42.formgbn = '0' THEN '숫자' ELSE '알파벳' END formgbn, -1 diffday,"
                sSql += "               fn_ack_date_str(f42.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, f42.modid"
                sSql += "          FROM lf420h f42, lf060m f60, lf030m f30"
                sSql += "        WHERE f42.testcd = f60.testcd"
                sSql += "          AND f42.spccd  = f60.spccd"
                sSql += "          AND f42.spccd  = f30.spccd"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY testspc, moddt, modid"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try

    End Function

    Public Function GetKeyPadInfo(ByVal rsTclsCd As String, ByVal rsSpcCd As String) As DataTable
        Dim sFn As String = "Public Function GetKeyPadInfo(String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT DISTINCT"
            sSql += "       a.testcd, a.spccd, a.formgbn, a.cnttestcd, a.pertestcd, a.wbctestcd, d.tnmd wbctnmd,"
            sSql += "       fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, a.regid,"
            sSql += "       null moddt, null modid, null modnm, fn_ack_get_usr_name(a.regid) regnm,"
            sSql += "       b.tnmd, c.spcnmd"
            sSql += "  FROM lf420m a, lf060m b, lf030m c, lf060m d"
            sSql += " WHERE a.testcd    = b.testcd"
            sSql += "   AND a.spccd     = b.spccd"
            sSql += "   AND b.usdt     <= fn_ack_sysdate"
            sSql += "   AND b.uedt     >  fn_ack_sysdate"
            sSql += "   AND a.spccd     = c.spccd"
            sSql += "   AND c.usdt     <= fn_ack_sysdate"
            sSql += "   AND c.uedt     >  fn_ack_sysdate"
            sSql += "   AND a.wbctestcd = d.testcd (+)"
            sSql += "   AND a.spccd     = d.spccd (+)"
            sSql += "   AND a.testcd    = :testcd"
            sSql += "   AND a.spccd     = :spccd"

            al.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTclsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTclsCd))
            al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try

    End Function

    Public Function GetKeyPadInfo(ByVal rsModDt As String, ByVal rsModId As String, ByVal rsTclsCd As String, ByVal rsSpcCd As String) As DataTable
        Dim sFn As String = "Public Function GetKeyPadInfo(string, string, String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT DISTINCT"
            sSql += "       a.testcd, a.spccd, a.formgbn, a.cnttestcd, a.pertestcd, a.wbctestcd, d.tnmd wbctnmd,"
            sSql += "       fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, a.regid,"
            sSql += "       fn_ack_date_str(a.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, a.modid,"
            sSql += "       fn_ack_get_usr_name(a.modid)  modnm, fn_ack_get_usr_name(a.regid) regnm,"
            sSql += "       b.tnmd, c.spcnmd"
            sSql += "  FROM lf060m b, lf030m c, lf420h a, lf060m d"
            sSql += " WHERE a.testcd    = b.testcd"
            sSql += "   AND a.spccd     = b.spccd"
            sSql += "   AND b.usdt     <= fn_ack_sysdate"
            sSql += "   AND b.uedt     >  fn_ack_sysdate"
            sSql += "   AND a.spccd     = c.spccd"
            sSql += "   AND c.usdt     <= fn_ack_sysdate"
            sSql += "   AND c.uedt     >  fn_ack_sysdate"
            sSql += "   AND a.wbctestcd = d.testcd (+)"
            sSql += "   AND a.spccd     = d.spccd (+)"
            sSql += "   AND a.moddt     = :moddt"
            sSql += "   AND a.modid     = :modid"
            sSql += "   AND a.testcd    = :testcd"
            sSql += "   AND a.spccd     = :spccd"

            al.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDt))
            al.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModId.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModId))
            al.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTclsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTclsCd))
            al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try

    End Function

End Class

Public Class APP_F_CVT_RST
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_CALC" & vbTab

    Public Function TransCvtRstInfo_UE(ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsRstCd As String, ByVal rsRegId As String) As Boolean
        Dim sFn As String = "Public Function TransCvtRstInfo_UE(String, String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0


            sSql = ""
            sSql += "INSERT INTO lf084h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf084m f"
            sSql += " WHERE testcd   = :testcd"
            sSql += "   AND spccd    = :spccd"
            sSql += "   AND rstcdseq = :rstseq"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("rstseq",  OracleDbType.Varchar2).Value = rsRstCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            sSql = ""
            sSql += "DELETE lf084m"
            sSql += " WHERE testcd   = :testcd"
            sSql += "   AND spccd    = :spccd"
            sSql += "   AND rstcdseq = :rstseq"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("rstseq",  OracleDbType.Varchar2).Value = rsRstCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            'LF061H Backup
            sSql = ""
            sSql += "INSERT INTO lf085h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf085m f"
            sSql += " WHERE testcd   = :testcd"
            sSql += "   AND spccd    = :spccd"
            sSql += "   AND rstcdseq = :rstseq"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("rstseq",  OracleDbType.Varchar2).Value = rsRstCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            sSql = ""
            sSql += "DELETE lf085m"
            sSql += " WHERE testcd   = :testcd"
            sSql += "   AND spccd    = :spccd"
            sSql += "   AND rstcdseq = :rstseq"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("rstseq",  OracleDbType.Varchar2).Value = rsRstCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()


            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransCvtRstInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                     ByVal ro_Tcol2 As ItemTableCollection, ByVal riType2 As Integer, _
                                     ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsRstCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransCalcInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF084M : 계산식 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue

                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf084m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF084H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf084h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf084m f"
                        sSql += " WHERE testcd   = :testcd"
                        sSql += "   AND spccd    = :spccd"
                        sSql += "   AND rstcdseq = :rstseq"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                        dbCmd.Parameters.Add("rstseq",  OracleDbType.Varchar2).Value = rsRstCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        sSql = ""
                        sSql += "DELETE lf084m"
                        sSql += " WHERE testcd   = :testcd"
                        sSql += "   AND spccd    = :spccd"
                        sSql += "   AND rstcdseq = :rstseq"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                        dbCmd.Parameters.Add("rstseq",  OracleDbType.Varchar2).Value = rsRstCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf084m (" + sFields + ") VALUES (" + sValues + ")"
                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                        Next
                    End With
            End Select

            'LF085M : 계산식 검사내용
            Select Case riType2
                Case 0      '----- 신규
                    With ro_Tcol2
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf085m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    'LF061H Backup
                    sSql = ""
                    sSql += "INSERT INTO lf085h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf085m f"
                    sSql += " WHERE testcd   = :testcd"
                    sSql += "   AND spccd    = :spccd"
                    sSql += "   AND rstcdseq = :rstseq"

                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                    dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                    dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                    dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                    dbCmd.Parameters.Add("rstseq",  OracleDbType.Varchar2).Value = rsRstCd

                    dbCmd.CommandText = sSql
                    iRet += dbCmd.ExecuteNonQuery()

                    sSql = ""
                    sSql += "DELETE lf085m"
                    sSql += " WHERE testcd   = :testcd"
                    sSql += "   AND spccd    = :spccd"
                    sSql += "   AND rstcdseq = :rstseq"

                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                    dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                    dbCmd.Parameters.Add("rstseq",  OracleDbType.Varchar2).Value = rsRstCd

                    dbCmd.CommandText = sSql
                    iRet += dbCmd.ExecuteNonQuery()

                    With ro_Tcol2
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf085m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function GetCvtRstInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetCalcRstInfo(Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT testspc, testcd, spccd, cvtform, cvtrange, cvtfldgbn, tnmd, spcnmd, rstcdseq, keypad, rstcont"
                sSql += "  FROM ("
                sSql += "        SELECT DISTINCT"
                sSql += "               RPAD(f83.testcd, 8, ' ') || f83.spccd testspc,"
                sSql += "               f83.testcd, f83.spccd, f83.cvtform, f83.cvtrange, f83.cvtfldgbn, MIN(f60.tnmd) tnmd, MIN(f30.spcnmd) spcnmd,"
                sSql += "               f64.rstcdseq, f64.keypad, f64.rstcont"
                sSql += "          FROM lf084m f83, lf060m f60, lf030m f30, lf083m f64"
                sSql += "         WHERE f83.testcd   = f60.testcd"
                sSql += "           AND f83.spccd   IN ('" + "0".PadLeft(PRG_CONST.Len_SpcCd, "0"c) + "', f60.spccd)"
                sSql += "           AND f83.spccd   IN ('" + "0".PadLeft(PRG_CONST.Len_SpcCd, "0"c) + "', f30.spccd)"
                sSql += "           AND f83.testcd   = f64.testcd"
                sSql += "           AND f83.rstcdseq = f64.rstcdseq"
                sSql += "         GROUP BY f83.testcd, f83.spccd, f83.cvtform, f83.cvtrange, f83.cvtfldgbn, f64.rstcdseq, f64.keypad, f64.rstcont"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
            ElseIf riMode = 1 Then
                sSql += "SELECT testspc, testcd, spccd, cvtform, cvtrange, cvtfldgbn, tnmd, spcnmd, rstcdseq, keypad, rstcont,"
                sSql += "       diffday, moddt, modid"
                sSql += "  FROM ("
                sSql += "        SELECT DISTINCT"
                sSql += "               RPAD(f83.testcd, 8, ' ') || f83.spccd testspc,"
                sSql += "               f83.testcd, f83.spccd, f83.cvtform, f83.cvtrange, f83.cvtfldgbn, MIN(f60.tnmd) tnmd, MIN(f30.spcnmd) spcnmd,"
                sSql += "               f64.rstcdseq, f64.keypad, f64.rstcont,"
                sSql += "               NULL diffday, NULL moddt, NULL modid"
                sSql += "          FROM lf084m f83, lf060m f60, lf030m f30, lf083m f64"
                sSql += "         WHERE f83.testcd   = f60.testcd"
                sSql += "           AND f83.spccd   IN ('" + "0".PadLeft(PRG_CONST.Len_SpcCd, "0"c) + "', f60.spccd)"
                sSql += "           AND f83.spccd   IN ('" + "0".PadLeft(PRG_CONST.Len_SpcCd, "0"c) + "', f30.spccd)"
                sSql += "           AND f83.testcd   = f64.testcd"
                sSql += "           AND f83.rstcdseq = f64.rstcdseq"
                sSql += "         GROUP BY f83.testcd, f83.spccd, f83.cvtform, f83.cvtrange, f83.cvtfldgbn, f64.rstcdseq, f64.keypad, f64.rstcont"
                sSql += "         UNION ALL  "
                sSql += "        SELECT DISTINCT"
                sSql += "               RPAD(f83.testcd, 8, ' ') || f83.spccd testspc,"
                sSql += "               f83.testcd, f83.spccd, f83.cvtform, f83.cvtrange, f83.cvtfldgbn, MIN(f60.tnmd) tnmd, MIN(f30.spcnmd) spcnmd,"
                sSql += "               f64.rstcdseq, f64.keypad, f64.rstcont,"
                sSql += "               -1 diffday,"
                sSql += "               fn_ack_date_str(f83.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, f83.modid"
                sSql += "          FROM lf084h f83, lf060m f60, lf030m f30, lf083m f64"
                sSql += "         WHERE f83.testcd   = f60.testcd"
                sSql += "           AND f83.spccd   IN ('" + "0".PadLeft(PRG_CONST.Len_SpcCd, "0"c) + "', f60.spccd)"
                sSql += "           AND f83.spccd   IN ('" + "0".PadLeft(PRG_CONST.Len_SpcCd, "0"c) + "', f30.spccd)"
                sSql += "           AND f83.testcd   = f64.testcd"
                sSql += "           AND f83.rstcdseq = f64.rstcdseq"
                sSql += "         GROUP BY f83.testcd, f83.spccd, f83.cvtform, f83.cvtrange, f83.cvtfldgbn, f64.rstcdseq, f64.keypad, f64.rstcont, f83.moddt, f83.modid"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY testcd, spccd, moddt, modid"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
             Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function GetRstCdInfo(ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsRstCd As String) As DataTable
        Dim sFn As String = "Public Function GetCalcRstInfo(String, String, string) As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT rstcont FROM lf083m"
            sSql += " WHERE testcd   = :testcd"
            sSql += "   AND spccd    = :spccd"
            sSql += "   AND rstcdseq = :rstseq"

            al.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
            al.Add(New OracleParameter("rstseq",  OracleDbType.Varchar2, rsRstCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsRstCd))

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
             Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function GetCvtRstInfo(ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsRstCd As String) As DataTable
        Dim sFn As String = "Public Function GetCalcRstInfo(String, String, string) As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            If rsSpcCd = "0".PadLeft(PRG_CONST.Len_SpcCd, "0"c) Then
                sSql += "SELECT DISTINCT"
                sSql += "       a.testcd, a.spccd, a.rstcdseq, a.cvtfldgbn, a.cvttype, a.cvtrange, a.cvtview, a.cvtform,"
                sSql += "       fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, a.regid,"
                sSql += "       fn_ack_get_usr_name(a.regid) regnm, null moddt, null modid, null modnm,"
                sSql += "       MAX(b.tnmd) tnmd, '' spcnmd, d.rstcont,"
                sSql += "       e.cvtparam, e.reflgbn, e.refl, e.refls, e.ctestcd, e.cspccd, MAX(f.tnmd) ctnmd, "
                sSql += "       e.refhs, e.refhgbn, e.refh, e.reflt, e.reflts, '' cspcnmd"
                sSql += "  FROM lf084m a, lf060m b, lf083m d,"
                sSql += "       lf085m e, lf060m f"
                sSql += " WHERE a.testcd = b.testcd"
                sSql += "   AND b.usdt    <= fn_ack_sysdate"
                sSql += "   AND b.uedt    >  fn_ack_sysdate"
                sSql += "   AND a.testcd   = d.testcd"
                sSql += "   AND a.rstcdseq = d.rstcdseq"
                sSql += "   AND a.testcd   = e.testcd"
                sSql += "   AND a.spccd    = e.spccd"
                sSql += "   AND a.rstcdseq = e.rstcdseq"
                sSql += "   AND e.ctestcd  = f.testcd"
                sSql += "   AND f.usdt    <= fn_ack_sysdate"
                sSql += "   AND f.uedt    >  fn_ack_sysdate"
                sSql += "   AND a.testcd   = :testcd"
                sSql += "   AND a.spccd    = :spccd"
                sSql += "   AND a.rstcdseq = :rstseq"
                sSql += " GROUP BY a.testcd, a.spccd, a.rstcdseq, a.cvtfldgbn, a.cvttype, a.cvtrange, a.cvtview, a.cvtform,"
                sSql += "          a.regdt, a.regid, a.regid, d.rstcont, e.cvtparam, e.reflgbn, e.refl, e.refls, e.ctestcd, e.cspccd,"
                sSql += "          e.refhs, e.refhgbn, e.refh, e.reflt, e.reflts"
            Else
                sSql += "SELECT DISTINCT"
                sSql += "       a.testcd, a.spccd, a.rstcdseq, a.cvtfldgbn, a.cvttype, a.cvtrange, a.cvtview, a.cvtform,"
                sSql += "       fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, a.regid,"
                sSql += "       fn_ack_get_usr_name(a.regid) regnm, null moddt, null modid, null modnm,"
                sSql += "       b.tnmd, c.spcnmd, d.rstcont,"
                sSql += "       e.cvtparam, e.reflgbn, e.refl, e.refls, e.ctestcd, e.cspccd, f.tnmd ctnmd, "
                sSql += "       e.refhs, e.refhgbn, e.refh, e.reflt, e.reflts, g.spcnmd cspcnmd"
                sSql += "  FROM lf084m a, lf060m b, lf030m c, lf083m d,"
                sSql += "       lf085m e, lf060m f, lf030m g"
                sSql += " WHERE a.testcd = b.testcd"
                sSql += "   AND a.spccd  = b.spccd"
                sSql += "   AND b.usdt    <= fn_ack_sysdate"
                sSql += "   AND b.UEDT    >  fn_ack_sysdate"
                sSql += "   AND a.spccd    = c.spccd"
                sSql += "   AND c.usdt    <= fn_ack_sysdate"
                sSql += "   AND c.uedt    >  fn_ack_sysdate"
                sSql += "   AND a.testcd   = d.testcd"
                sSql += "   AND a.rstcdseq = d.rstcdseq"
                sSql += "   AND a.testcd   = e.testcd"
                sSql += "   AND a.spccd    = e.spccd"
                sSql += "   AND a.rstcdseq = e.rstcdseq"
                sSql += "   AND e.ctestcd  = f.testcd"
                sSql += "   AND e.cspccd   = f.spccd"
                sSql += "   AND f.usdt    <= fn_ack_sysdate"
                sSql += "   AND f.uedt    >  fn_ack_sysdate"
                sSql += "   AND e.spccd    = g.spccd"
                sSql += "   AND g.usdt    <= fn_ack_sysdate"
                sSql += "   AND g.uedt    >  fn_ack_sysdate"
                sSql += "   AND a.testcd   = :testcd"
                sSql += "   AND a.spccd    = :spccd"
                sSql += "   AND a.rstcdseq = :rstseq"
            End If


            al.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
            al.Add(New OracleParameter("rstseq",  OracleDbType.Varchar2, rsRstCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsRstCd))

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
             Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function GetCvtRstInfo(ByVal rsModDt As String, ByVal rsModId As String, ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsRstCd As String) As DataTable
        Dim sFn As String = "Public Function GetCalcRstInfo(string, string, String, String, string) As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT DISTINCT"
            sSql += "       a.testcd, a.spccd, a.rstcdseq, a.cvtfldgbn, a.cvttype, a.cvtrange, a.cvtview, a.cvtform,"
            sSql += "       fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, a.regid,"
            sSql += "       fn_ack_get_usr_name(a.regid) regnm, null moddt, null modid, null modnm,"
            sSql += "       b.tnmd, c.spcnmd, d.rstcont,"
            sSql += "       e.cvtparam, e.reflgbn, e.refl, e.refls, e.ctestcd, e.cspccd, f.tnmd ctnmd, "
            sSql += "       e.refhs, e.refhgbn, e.refh, e.reflt, e.reflts, g.spcnmd cspcnmd"
            sSql += "  FROM lf084h a, lf060m b, lf030m c, lf083m d,"
            sSql += "       lf085h e, lf060m f, lf030m g"
            sSql += " WHERE a.testcd   = b.testcd"
            sSql += "   AND a.spccd    = b.spccd"
            sSql += "   AND b.usdt    <= fn_ack_sysdate"
            sSql += "   AND b.uedt    >  fn_ack_sysdate"
            sSql += "   AND a.spccd    = c.spccd"
            sSql += "   AND c.usdt    <= fn_ack_sysdate"
            sSql += "   AND c.uedt    >  fn_ack_sysdate"
            sSql += "   AND a.testcd   = d.testcd"
            sSql += "   AND a.rstcdseq = d.rstcdseq"
            sSql += "   AND a.testcd   = e.testcd"
            sSql += "   AND a.spccd    = e.spccd"
            sSql += "   AND a.rstcdseq = e.rstcdseq"
            sSql += "   AND e.ctestcd  = f.testcd"
            sSql += "   AND e.cspccd   = f.spccd"
            sSql += "   AND f.usdt    <= fn_ack_sysdate"
            sSql += "   AND f.uedt    >  fn_ack_sysdate"
            sSql += "   AND e.spccd    = g.spccd"
            sSql += "   AND g.usdt    <= fn_ack_sysdate"
            sSql += "   AND g.uedt    >  fn_ack_sysdate"
            sSql += "   AND a.moddt    = :moddt"
            sSql += "   AND a.modid    = :modid"
            sSql += "   AND a.testcd   = :testcd"
            sSql += "   AND a.spccd    = :spccd"
            sSql += "   AND a.rstcdseq = :rstseq"

            al.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDt))
            al.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModId.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModId))
            al.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
            al.Add(New OracleParameter("rstseq",  OracleDbType.Varchar2, rsRstCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsRstCd))

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
             Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

End Class

Public Class APP_F_CVT_CMT
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_CALC_CMT" & vbTab

    Public Function TransCvtCmtInfo_UE(ByVal rsCmtCd As String, ByVal rsRegId As String) As Boolean
        Dim sFn As String = "Public Function TransCvtRstInfo_UE(String, String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF081H Backup
            sSql = ""
            sSql += "INSERT INTO lf081h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf081m f"
            sSql += " WHERE cmtcd = :cmtcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsCmtCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            sSql = ""
            sSql += "DELETE FROM lf081m"
            sSql += " WHERE cmtcd = :cmtcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsCmtCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            'LF061H Backup
            sSql = ""
            sSql += "INSERT INTO lf082h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf082m f"
            sSql += " WHERE cmtcd = :cmtcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsCmtCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            sSql = ""
            sSql += "DELETE lf082m"
            sSql += " WHERE cmtcd = :cmtcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsCmtCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransCvtCmtInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                     ByVal ro_Tcol2 As ItemTableCollection, ByVal riType2 As Integer, _
                                     ByVal rsCmtCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransCalcInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF084M : 계산식 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf081m (" + sFields + ") VALUES (" + sValues + ")"
                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF081H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf081h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf081m f"
                        sSql += " WHERE cmtcd = :cmtcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsCmtCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        sSql = ""
                        sSql += "DELETE lf081m"
                        sSql += " WHERE cmtcd = :cmtcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsCmtCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()


                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf081m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            'LF085M : 계산식 검사내용
            Select Case riType2
                Case 0      '----- 신규
                    With ro_Tcol2
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf082m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    'LF061H Backup
                    sSql = ""
                    sSql += "INSERT INTO lf082h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf082m f"
                    sSql += " WHERE cmtcd = :cmtcd"

                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                    dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                    dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsCmtCd

                    dbCmd.CommandText = sSql
                    iRet += dbCmd.ExecuteNonQuery()

                    sSql = ""
                    sSql += "DELETE lf082m"
                    sSql += " WHERE cmtcd = :cmtcd"

                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsCmtCd

                    dbCmd.CommandText = sSql
                    iRet += dbCmd.ExecuteNonQuery()

                    With ro_Tcol2
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf082m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function GetCmtInfo(ByVal rsCmtCd As String) As DataTable
        Dim sFn As String = "Public Function GetCmtInfo(String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT f8.cmtcd, f8.cmtcont,"
            sSql += "       '[' || NVL(f8.partcd, '') || NVL(f8.slipcd, '') || '] ' ||  NVL(f2.slipnmd, CASE WHEN f8.cmtcd = '00' THEN '공통' ELSE f2.slipnmd END) slipnmd"
            sSql += "  FROM lf080m f8 LEFT OUTER JOIN "
            sSql += "       lf021m f2 ON (f8.partcd = f2.partcd AND f8.slipcd = f2.slipcd)"
            sSql += " WHERE f2.usdt <= fn_ack_sysdate"
            sSql += "   AND f2.uedt >  fn_ack_sysdate"
            If rsCmtCd <> "" Then
                sSql += "   AND f8.cmtcd = :cmtcd"
                alParm.Add(New oracleParameter("cmtcd", rsCmtCd))

            End If
            sSql += " ORDER BY cmtcd"

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function GetTestCdInfo(ByVal rsSlipCd As String, ByVal rsTestCd As String, ByVal rsSpcCd As String) As DataTable
        Dim sFn As String = "Public Function GetTestCdInfo(String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT f6.testcd, f6.spccd,"
            sSql += "       MIN(CAS WHEN f6.tcdgbn = 'C' TEHN '-- ' || f6.tnmd ELSE f6.tnmd END) tnmd, MIN(f3.spcnmd) spcnmd,"
            sSql += "       f6.tcdgbn, NVL(f6.mbttype, '0') mbttype, f6.titleyn"
            sSql += "  FROM lf060m f6, lf030m f3"
            sSql += " WHERE f6.usdt <= fn_ack_sysdate"
            sSql += "   AND f6.uedt >  fn_ack_sysdate"
            sSql += "   AND f6.spccd = f3.spccd"
            sSql += "   AND f3.usdt <= f6.usdt AND f3.uedt > f6.usdt"

            If rsSlipCd <> "" Then
                sSql += "   AND f6.partcd + f6.slipcd = :slipcd"
                al.Add(New OracleParameter("slipcd",  OracleDbType.Varchar2, rsSlipCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSlipCd))
            Else
                If rsTestCd <> "" Then
                    sSql += "   AND f6.testcd = :testcd"
                    al.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
                End If

                If rsTestCd <> "" Then
                    sSql += "   AND f6.spccd = :spccd"
                    al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
                End If
            End If
            sSql += " GROUP BY f6.testcd, f6.spccd, f6.tcdgbn, f6.mbttype, f6.titleyn"
            sSql += " ORDER BY testcd, spccd"

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetCvtCmtInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetCalcCmtInfo(Integer, ByVal Serch As String"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT cmtcd, cvtform, cmtcont"
                sSql += "  FROM ( "
                sSql += "        SELECT DISTINCT"
                sSql += "               f81.cmtcd, f81.cvtform, f80.cmtcont"
                sSql += "          FROM lf081m f81, lf080m f80"
                sSql += "         WHERE f81.cmtcd = f80.cmtcd"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If

            ElseIf riMode = 1 Then
                sSql += "SELECT cmtcd, cvtform, cmtcont, diffday, moddt, modid"
                sSql += "  FROM ("
                sSql += "        SELECT f81.cmtcd, f81.cvtform, f80.cmtcont,"
                sSql += "               NULL diffday, NULL moddt, NULL modid"
                sSql += "          FROM lf081m f81, lf080m f80"
                sSql += "         WHERE f81.cmtcd = f80.cmtcd"
                sSql += "         UNION ALL "
                sSql += "        SELECT f81.cmtcd, f81.cvtform, f80.cmtcont,"
                sSql += "               -1 diffday,"
                sSql += "               fn_ack_date_str(f81.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, f81.modid"
                sSql += "          FROM lf081h f81, lf080m f80"
                sSql += "         WHERE f81.cmtcd = f80.cmtcd"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY cmtcd, moddt, modid"

            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
           Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function GetCvtCmtInfo(ByVal rsCmtCd As String) As DataTable
        Dim sFn As String = "Public Function GetCalcRstInfo(String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT DISTINCT"
            sSql += "       a.cmtcd, a.cvtform,"
            sSql += "       fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, a.regid,"
            sSql += "        NULL moddt, NULL modid, NULL modnm, fn_ack_get_usr_name(a.regid) regnm,"
            sSql += "       '[' || b.partcd || b.slipcd || '] ' ||  NVL(c.slipnmd, '공통') slipnmd, b.cmtcont,"
            sSql += "       e.cvtparam, e.reflgbn, e.refl, e.refls, e.testcd, e.spccd, f.tnmd, e.refhs, e.refhgbn, e.refh, e.reflt, e.reflts, g.spcnmd spcnmd"
            sSql += "  FROM lf081m a, lf082m e, lf060m f, lf030m g,"
            sSql += "       lf080m b LEFT OUTER JOIN"
            sSql += "       lf021m c ON ( b.partcd = c.partcd AND b.slipcd = c.slipcd AND c.usdt <= fn_ack_sysdate AND c.uedt >  fn_ack_sysdate)"
            sSql += " WHERE a.cmtcd  = b.cmtcd"
            sSql += "   AND a.cmtcd  = e.cmtcd"
            sSql += "   AND e.testcd = f.testcd"
            sSql += "   AND e.spccd  = f.spccd"
            sSql += "   AND f.usdt  <= fn_ack_sysdate"
            sSql += "   AND f.uedt  >  fn_ack_sysdate"
            sSql += "   AND e.spccd  = g.spccd"
            sSql += "   AND g.usdt  <= fn_ack_sysdate"
            sSql += "   AND g.uedt  >  fn_ack_sysdate"
            sSql += "   AND a.cmtcd  = :cmtcd"

            al.Add(New OracleParameter("cmtcd",  OracleDbType.Varchar2, rsCmtCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCmtCd))

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function GetCvtCmtInfo(ByVal rsModDt As String, ByVal rsModId As String, ByVal rsCmtCd As String) As DataTable
        Dim sFn As String = "Public Function GetCalcRstInfo(string, string, String, String, string) As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT DISTINCT"
            sSql += "       a.cmtcd, a.cvtform,"
            sSql += "       fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, a.regid,"
            sSql += "       fn_ack_date_str(a.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, a.modid,"
            sSql += "       fn_ack_get_usr_name(a.modid) modnm, fn_ack_get_usr_name(a.regid) regnm,"
            sSql += "       '[' || b.partcd || b.slipcd || '] ' ||  NVL(c.slipnmd, '공통') slipnmd, b.cmtcont,"
            sSql += "       e.cvtparam, e.reflgbn, e.refl, e.refls, e.testcd, e.spccd, f.tnmd, e.refhs, e.refhgbn, e.refh, e.reflt, e.reflts, g.spcnmd spcnmd"
            sSql += "  FROM lf081h a, lf082m e, lf060m f, lf030m g,"
            sSql += "       lf080m b LEFT OUTER JOIN"
            sSql += "       lf021m c ON ( b.partcd = c.partcd AND b.slipcd = c.slipcd) AND c.usdt <= fn_ack_sysdate AND c.uedt >  fn_ack_sysdate"
            sSql += " WHERE a.cmtcd   = b.cmtcd"
            sSql += "   AND a.cmtcd   = e.cmtcd"
            sSql += "   AND e.testcd  = f.testcd"
            sSql += "   AND e.spccd   = f.spccd"
            sSql += "   AND f.usdt   <= fn_ack_sysdate"
            sSql += "   AND f.uedt   >  fn_ack_sysdate"
            sSql += "   AND e.spccd   = g.spccd"
            sSql += "   AND g.usdt   <= fn_ack_sysdate"
            sSql += "   AND g.uedt   >  fn_ack_sysdate"
            sSql += "   AND a.moddt   = :moddt"
            sSql += "   AND a.modid   = :modid"
            sSql += "   AND a.cmtcd   = :cmtcd"

            al.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDt))
            al.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModId.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModId))
            al.Add(New OracleParameter("cmtcd",  OracleDbType.Varchar2, rsCmtCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCmtCd))

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

End Class

Public Class APP_F_ALERT_RULE
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_ALERT_RULE" & vbTab

    Public Function GetAlertRlue_Tcls() As DataTable
        Dim sFn As String = "Public Function GetAlertRuleInfo(Integer) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT '[' || testcd || '] ' ||  MAX(tnmd) tnmd_01"
            sSql += "  FROM lf060m"
            sSql += " WHERE usdt <= fn_ack_sysdate"
            sSql += "   AND uedt >  fn_ack_sysdate"
            sSql += "   AND alertgbn IN ('A', 'B', 'C', '5')"
            sSql += " GROUP BY testcd"

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try


    End Function

    Public Function GetAlertRuleInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetAlertRuleInfo(Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT testcd, tnmd, regdt, regid"
                sSql += "  FROM ("
                sSql += "        SELECT f18.testcd, MAX(f60.tnmd) tnmd, fn_ack_date_str(f18.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f18.regid"
                sSql += "          FROM lf180m f18, lf060m f60"
                sSql += "         WHERE f18.testcd = f60.testcd"
                sSql += "           AND f60.usdt  <= f18.regdt"
                sSql += "           AND f60.uedt  >  f18.regdt"
                sSql += "         GROUP BY f18.testcd, f18.regdt, f18.regid"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If

            ElseIf riMode = 1 Then
                sSql += "SELECT testcd, tnmd, regdt, regid, diffday, moddt, modid"
                sSql += "   FROM ("
                sSql += "         SELECT f18.testcd, MAX(f60.tnmd) tnmd, NULL diffday, NULL moddt, NULL modid,"
                sSql += "                fn_ack_date_str(f18.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f18.regid"
                sSql += "           FROM lf180m f18, lf060m f60"
                sSql += "          WHERE f18.testcd = f60.testcd"
                sSql += "            AND f60.usdt  <= f18.regdt"
                sSql += "            AND f60.uedt  >  f18.regdt"
                sSql += "          GROUP BY f18.testcd, f18.regdt, f18.regid"
                sSql += "          UNION ALL"
                sSql += "         SELECT f18.testcd, MAX(f60.tnmd) tnmd,"
                sSql += "                -1 diffday, "
                sSql += "                fn_ack_date_str(f18.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, f18.modid,"
                sSql += "                fn_ack_date_str(f18.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f18.regid"
                sSql += "           FROM lf180h f18, lf060m f60"
                sSql += "          WHERE f18.testcd = f60.testcd"
                sSql += "            AND f60.usdt  <= f18.regdt"
                sSql += "            AND f60.uedt  >  f18.regdt"
                sSql += "          GROUP BY f18.testcd, f18.moddt, f18.modid, f18.regdt, f18.regid"
                sSql += "        ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY testcd, moddt, modid"

            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function GetAlertRuleInfo(ByVal rsTClsCd As String) As DataTable
        Dim sFn As String = "Public Function GetAlertRuleInfo(String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT '[' || f18.testcd || '] ' ||  f60.tnmd tnmd_01,"
            sSql += "       f18.sex, f18.deptcds, f18.spccds, f18.orgrst, f18.viewrst, f18.eqflag, f18.baccds, f18.antic,"
            sSql += "       f18.panic, f18.delta,"
            sSql += "       fn_ack_date_str(f18.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f18.regid,"
            sSql += "       NULL moddt, NULL modid, NULL modnm, fn_ack_get_usr_name(f18.regid) regnm"
            sSql += "  FROM lf180m f18,"
            sSql += "       (SELECT testcd, MAX(tnmd) tnmd"
            sSql += "          FROM lf060m"
            sSql += "         GROUP BY testcd"
            sSql += "       ) f60"
            sSql += " WHERE f18.testcd = f60.testcd"
            sSql += "   AND f18.testcd = :testcd"

            al.Add(New OracleParameter("testcd", rsTClsCd))

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function GetAlertRuleInfo(ByVal rsModDT As String, ByVal rsModID As String, ByVal rsTClsCd As String) As DataTable
        Dim sFn As String = "Public Function GetAlertRuleInfo(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT '[' || f18.testcd || '] ' ||  f60.tnmd tnmd_01,"
            sSql += "       f18.sex, f18.deptcds, f18.spccds, f18.orgrst, f18.viewrst, F18.eqflag, f18.baccds, f18.antic,"
            sSql += "       f18.panic, f18.delta,"
            sSql += "       fn_ack_date_str(f18.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f18.regid," '20140527 정선영 수정, 쿼리 오류 수정
            sSql += "       fn_ack_date_str(f18.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, f18.modid,"
            sSql += "       fn_ack_get_usr_name(f18.modid) modnm, fn_ack_get_usr_name (f18.regid) regnm"
            sSql += "  FROM lf180h f18,"
            sSql += "       (SELECT testcd, MIN(tnmd) tnmd FROM lf060m GROUP BY testcd) f60"
            sSql += " WHERE f18.testcd = f60.testcd"
            sSql += "   AND f18.testcd = :testcd"
            sSql += "   AND f18.moddt  = :moddt"
            sSql += "   AND f18.modid  = :modid"

            al.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTClsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTClsCd))
            al.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDT.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDT))
            al.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModID.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModID))

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function GetRecentAlertRuleInfo(ByVal rsTestCd As String) As DataTable
        Dim sFn As String = "Public Function GetRecentAlertRuleInfo(String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim arlParm As New ArrayList

            sSql += "SELECT testcd FROM lf180m WHERE testcd = :testcd"

            arlParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))

            DbCommand()
            Return DbExecuteQuery(sSql, arlParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function TransAlertRuleInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                       ByVal rsTClsCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransAlertRuleInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF180M : Alert Rule
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf180m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF180H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf180h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf180m f" '20140528 정선영 수정
                        sSql += " WHERE testcd = :testcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTClsCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        sSql = ""
                        sSql += "DELETE lf180m"
                        sSql += " WHERE testcd = :testcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTClsCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf180m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransAlertRuleInfo_UE(ByVal rsTClsCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransAlertRuleInfo_UE(String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF180M : 계산식 마스터
            '   LF180H Insert
            sSql = ""
            sSql += "INSERT INTO lf180h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf180m f"
            sSql += " WHERE testcd = :testcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTClsCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF180M Delete
            sSql = ""
            sSql += "DELETE lf180m"
            sSql += " WHERE testcd = :testcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTClsCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

End Class

Public Class APP_F_CALC
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_CALC" & vbTab

    Public Function GetCalcInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetCalcInfo(Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT testcd, spccd, tnmd, spcnmd"
                sSql += "  FROM ("
                sSql += "        SELECT f66.testcd, f66.spccd, MIN(f60.tnmd) tnmd, MIN(f30.spcnmd) spcnmd"
                sSql += "          FROM (lf069m f66 LEFT OUTER JOIN"
                sSql += "                lf060m f60 ON (f66.testcd = f60.testcd AND f66.spccd = f60.spccd)"
                sSql += "               ) LEFT OUTER JOIN lf030m f30 ON (f66.spccd = f30.spccd)"
                sSql += "         GROUP BY f66.testcd, f66.spccd"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If

            ElseIf riMode = 1 Then
                sSql += "SELECT testcd, spccd, tnmd, spcnmd, diffday, moddt, modid"
                sSql += "  FROM ("
                sSql += "        SELECT f66.testcd, f66.spccd, MIN(f60.tnmd) tnmd, MIN(f30.spcnmd) spcnmd,"
                sSql += "               NULL diffday, NULL moddt, NULL modid"
                sSql += "          FROM (lf069m f66 LEFT OUTER JOIN"
                sSql += "                lf060m f60 ON (f66.testcd = f60.testcd AND f66.spccd = f60.spccd)"
                sSql += "               ) LEFT OUTER JOIN lf030m f30 ON (f66.spccd = f30.spccd)"
                sSql += "         GROUP BY f66.testcd, f66.spccd"
                sSql += "         UNION ALL"
                sSql += "        SELECT f66.testcd, f66.spccd, MIN(f60.tnmd) tnmd, MIN(f30.spcnmd) spcnmd,"
                sSql += "               -1 diffday,"
                sSql += "               fn_ack_date_str(f66.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, f66.modid modid"
                sSql += "          FROM (lf069h f66 LEFT OUTER JOIN"
                sSql += "                lf060m f60 ON (f66.testcd = f60.testcd AND f66.spccd = f60.spccd)"
                sSql += "               ) LEFT OUTER JOIN lf030m f30 ON (f66.spccd = f30.spccd)"
                sSql += "         GROUP BY  f66.testcd, f66.spccd, f66.moddt, f66.modid"
                sSql += "     ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY testcd, spccd, moddt, modid"

            End If

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetCalcInfo(ByVal rsTestCd As String, ByVal rsSpcCd As String) As DataTable
        Dim sFn As String = "Public Function GetCalcInfo(String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT f66.testcd, f66.spccd, f60.tnmd, f30.spcnmd, f66.calrange,"
            sSql += "       NVL(f66.caltype, 'M') caltype, f66.paramcnt,"
            sSql += "       f66.param0, f66.param1, f66.param2, f66.param3, f66.param4,"
            sSql += "       f66.param5, f66.param6, f66.param7, f66.param8, f66.param9, f66.calform,"
            sSql += "       fn_ack_date_str(f66.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f66.regid,"
            sSql += "       NULL moddt, NULL modid, NULL modnm, NVL(f66.calview, 'A') calview, f66.caldays,"
            sSql += "       fn_ack_get_usr_name(f66.regid) regnm"
            sSql += "  FROM (lf069m f66 LEFT OUTER JOIN"
            sSql += "        (SELECT testcd, spccd, MIN(tnmd) tnmd"
            sSql += "           FROM lf060m"
            sSql += "          GROUP BY testcd, spccd"
            sSql += "        ) f60 ON (f66.testcd = f60.testcd AND f66.spccd = f60.spccd)"
            sSql += "       ) LEFT OUTER JOIN"
            sSql += "       (SELECT spccd, MIN(spcnmd) spcnmd"
            sSql += "          FROM lf030m"
            sSql += "         GROUP BY spccd"
            sSql += "       ) f30 ON (f66.spccd = f30.spccd)"
            sSql += " WHERE f66.testcd = :testcd"
            sSql += "   AND f66.spccd  = :spccd"

            al.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetCalcInfo(ByVal rsModDT As String, ByVal rsModID As String, ByVal rsTestCd As String, ByVal rsSpcCd As String) As DataTable
        Dim sFn As String = "Public Function GetCalcInfo(String, String, String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += " SELECT f66.testcd, f66.spccd, f60.tnmd, f30.spcnmd, f66.calrange,"
            sSql += "        NVL(f66.caltype, 'M') caltype, f66.paramcnt,"
            sSql += "        f66.param0, f66.param1, f66.param2, f66.param3, f66.param4,"
            sSql += "        f66.param5, f66.param6, f66.param7, f66.param8, f66.param9, f66.calform,"
            sSql += "        fn_ack_date_str(f66.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f66.regid,"
            sSql += "        fn_ack_date_str(f66.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, f66.modid,"
            sSql += "        fn_ack_get_usr_name(f66.modid) modnm,"
            sSql += "        NVL(f66.calview, 'A') calview, f66.caldays, fn_ack_get_usr_name(f66.regid) regnm"
            sSql += "  FROM (lf069h f66 LEFT OUTER JOIN"
            sSql += "        (SELECT testcd, spccd,MIN(tnmd) tnmd"
            sSql += "           FROM lf060m"
            sSql += "          GROUP BY testcd, spccd"
            sSql += "        ) f60 ON (f66.testcd = f60.testcd AND f66.spccd = f60.spccd)"
            sSql += "       ) LEFT OUTER JOIN"
            sSql += "       (SELECT spccd, MIN(spcnmd) spcnmd"
            sSql += "          FROM lf030m"
            sSql += "         GROUP BY spccd"
            sSql += "       ) f30 ON (f66.spccd = f30.spccd)"
            sSql += "  WHERE f66.testcd = :testcd"
            sSql += "    AND f66.spccd  = :spccd"
            sSql += "    AND f66.moddt  = :moddt"
            sSql += "    AND f66.modid  = :modid"

            al.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
            al.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDT.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDT))          '                                 
            al.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModID.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModID))

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentCalcInfo(ByVal rsTestCd As String, ByVal rsSpcCd As String) As DataTable
        Dim sFn As String = "Public Function GetRecentCalcInfo(String, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT testcd, spccd"
            sSql += "  FROM lf069m"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"

            Dim alParm As New ArrayList
            alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            alParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransCalcInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                   ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransCalcInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF069M : 계산식 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf069m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF069H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf069h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf069m f"
                        sSql += " WHERE testcd = :testcd"
                        sSql += "   AND spccd  = :spccd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        sSql = ""
                        sSql += "DELETE lf069m"
                        sSql += " WHERE testcd = :testcd"
                        sSql += "   AND spccd  = :spccd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf069m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransCalcInfo_UE(ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransCalcInfo_UE(String, String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF069M : 계산식 마스터
            '   LF069H Insert
            sSql = ""
            sSql += "INSERT INTO lf069h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf069m f"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF069M Delete
            sSql = ""
            sSql += "DELETE lf069m"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()

            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function
End Class

Public Class APP_F_VCMT
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_VCMT" & vbTab

    Public Function GetVCmtInfo(ByVal iMode As Integer, ByVal rsCdSep As String, ByVal Serch As String, ByVal asNull As String) As DataTable
        Dim sFn As String = "Public Function GetVCmtInfo(Integer, String, ByVal Serch As String, ByVal asNull As String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            If iMode = 0 Then
                sSql += "SELECT cdseq, cdtitle, cdcont"
                sSql += "  FROM lf320m"
                sSql += " WHERE cdsep = :cdsep"
                If Serch <> "" Then
                    sSql += "   AND " + Serch + ""
                End If
                sSql += " ORDER BY cdseq"

                alParm.Add(New OracleParameter("cdsep",  OracleDbType.Varchar2, rsCdSep.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCdSep))
            ElseIf iMode = 1 Then
                sSql += "SELECT cdseq, cdtitle, cdcont, NULL diffday, NULL moddt, NULL modid"
                sSql += "  FROM lf320m"
                sSql += " WHERE cdsep = :cdsep"
                If Serch <> "" Then
                    sSql += "   AND " + Serch + ""
                End If
                sSql += " UNION "
                sSql += "SELECT cdseq, cdtitle, cdcont, -1 DIFFDAY,"
                sSql += "       fn_ack_date_str(moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, modid"
                sSql += "  FROM lf320h"
                sSql += " WHERE cdsep = :cdsep"
                If Serch <> "" Then
                    sSql += "   AND " + Serch + ""
                End If
                sSql += " ORDER BY cdseq, moddt, modid"

                alParm.Add(New OracleParameter("cdsep",  OracleDbType.Varchar2, rsCdSep.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCdSep))
                alParm.Add(New OracleParameter("cdsep",  OracleDbType.Varchar2, rsCdSep.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCdSep))
            End If

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetVCmtInfo(ByVal rsCdSep As String, ByVal rsCdSeq As String) As DataTable
        Dim sFn As String = "Public Function GetVCmtInfo(Integer, String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT cdseq, cdtitle, cdcont,"
            sSql += "       fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid,"
            sSql += "       '' moddt, '' modid, '' modnm, fn_ack_get_usr_name(regid) regnm"
            sSql += "  FROM lf320m"
            sSql += " WHERE cdsep = :cdsep"
            sSql += "   AND cdseq = :cdseq"

            alParm.Add(New OracleParameter("cdsep",  OracleDbType.Varchar2, rsCdSep.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCdSep))
            alParm.Add(New OracleParameter("cdseq",  OracleDbType.Varchar2, rsCdSeq.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCdSeq))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetVCmtInfo(ByVal rsModDT As String, ByVal rsModID As String, ByVal rsCdSep As String, ByVal rsCdSeq As String) As DataTable
        Dim sFn As String = "Public Function GetVCmtInfo(String, String, String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT cdseq, cdtitle, cdcont,"
            sSql += "       fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid,"
            sSql += "       fn_ack_date_str(moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, modid,"
            sSql += "       fn_ack_get_usr_name(modid) modnm, fn_ack_get_usr_name(regid) regnm"
            sSql += "  FROM lf320h"
            sSql += " WHERE cdsep = :cdsep"
            sSql += "   AND cdseq = :cdseq"
            sSql += "   AND moddt = :moddt"
            sSql += "   AND modid = :modid"

            alParm.Add(New OracleParameter("cdsep",  OracleDbType.Varchar2, rsCdSep.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCdSep))
            alParm.Add(New OracleParameter("cdseq",  OracleDbType.Varchar2, rsCdSeq.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCdSeq))
            alParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDT.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDT))
            alParm.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModID.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModID))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentVCmtInfo(ByVal rsCdSep As String, ByVal rsCdSeq As String) As DataTable
        Dim sFn As String = "Public Function GetRecentVCmtInfo(String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT cdseq  FROM lf320m"
            sSql += " WHERE cdsep = :cdsep"
            sSql += "   AND cdseq = :cdseq"

            alParm.Add(New OracleParameter("cdsep",  OracleDbType.Varchar2, rsCdSep.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCdSep))
            alParm.Add(New OracleParameter("cdseq",  OracleDbType.Varchar2, rsCdSeq.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCdSeq))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransVCmtInfo(ByVal roTcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                  ByVal rsCdSep As String, ByVal rsCdSeq As String, ByVal rsRegId As String) As Boolean
        Dim sFn As String = "Public Function TransVCmtInfo(Object, Integer, String, String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF320M : 
            Select Case riType1
                Case 0      '----- 신규
                    With roTcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf320m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With roTcol1
                        'LF080H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf320h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf320m f"
                        sSql += " WHERE cdsep = :cdsep"
                        sSql += "   AND cdseq = :cdseq"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegId
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("cdsep",  OracleDbType.Varchar2).Value = rsCdSep
                        dbCmd.Parameters.Add("cdseq",  OracleDbType.Varchar2).Value = rsCdSeq

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        sSql = ""
                        sSql += "DELETE lf320m"
                        sSql += " WHERE cdsep = :cdsep"
                        sSql += "   AND cdseq = :cdseq"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("cdsep",  OracleDbType.Varchar2).Value = rsCdSep
                        dbCmd.Parameters.Add("cdseq",  OracleDbType.Varchar2).Value = rsCdSeq

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf320m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransVCmtInfo_UE(ByVal rsCdSep As String, ByVal rsCdSeq As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransVCmtInfo_UE(String, String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = "", sMsg As String = ""

            'LF320M : 소견 마스터
            '   LF320H Insert
            sSql = ""
            sSql += "INSERT INTO lf320h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf320m f"
            sSql += " WHERE cdsep = :cdsep"
            sSql += "   AND cdseq = :cdseq"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("cdsep",  OracleDbType.Varchar2).Value = rsCdSep
            dbCmd.Parameters.Add("cdseq",  OracleDbType.Varchar2).Value = rsCdSeq

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF320M Delete
            sSql = ""
            sSql += "DELETE lf320m"
            sSql += " WHERE cdsep = :cdsep"
            sSql += "   AND cdseq = :cdseq"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("cdsep",  OracleDbType.Varchar2).Value = rsCdSep
            dbCmd.Parameters.Add("cdseq",  OracleDbType.Varchar2).Value = rsCdSeq

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

End Class

Public Class APP_F_VCMT_TCLS
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_VCMT_TCLS" & vbTab

    Public Function GetVCmtTclsInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetVCmtTclsInfo(Integer, String, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT cdnm, regdt"
                sSql += "  FROM (SELECT '종합정보 검사항목 소견설정' cdnm, fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt"
                sSql += "          FROM lf321m"
                sSql += "         WHERE ROWNUM = 1"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY regdt"

            ElseIf riMode = 1 Then
                sSql += "SELECT cdnm, regdt, diffday, moddt, modid "
                sSql += "  FROM (SELECT '종합정보 검사항목 소견설정' cdnm, fn_ack_date_str(MAX(regdt), 'yyyy-mm-dd hh24:mi:ss') regdt,"
                sSql += "               NULL diffday, NULL moddt, NULL modid"
                sSql += "          FROM lf321m"
                sSql += "         WHERE ROWNUM = 1"
                sSql += "         UNION "
                sSql += "        SELECT '종합정보 검사항목 소견설정' cdnm, fn_ack_date_str(MAX(regdt), 'yyyy-mm-dd hh24:mi:ss') regdt, -1 diffday,"
                sSql += "               fn_ack_date_str(moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, modid"
                sSql += "          FROM lf321h"
                sSql += "         WHERE ROWNUM = 1"
                sSql += "         GROUP BY moddt, modid"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY cdnm, moddt, modid"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetVCmtTclsInfo() As DataTable
        Dim sFn As String = "Public Function GetVCmtTclsInfo() As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT a.testcd, MAX(b.tnmd) tnmd, a.cdseqnl, a.cdseqnh, a.cdseqp, a.cdseqd, a.cdseqcl, a.cdseqch,"
            sSql += "       a.reflt, a.reflts, a.cdseqt,"
            sSql += "       fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, a.regid,"
            sSql += "       MAX(b.dispseql) dispseql, fn_ack_get_usr_name(a.regid) regnm"
            sSql += "  FROM lf321m a, lf060m b"
            sSql += " WHERE a.testcd = b.testcd"
            sSql += " GROUP BY a.testcd, a.cdseqnl, a.cdseqnh, a.cdseqp, a.cdseqd, a.cdseqcl, a.cdseqch,"
            sSql += "          a.reflt, a.reflts, a.cdseqt, A.regdt, a.regid"
            sSql += " ORDER BY dispseql, a.testcd"

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function


    Public Function GetVCmtTclsInfo(ByVal rsModDT As String, ByVal rsModID As String) As DataTable
        Dim sFn As String = "Public Function GetVCmtTclsInfo(String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim arlParm As New ArrayList

            sSql += "SELECT a.testcd, MAX(b.tnmd) tnmd, a.cdseqnl, a.cdseqnh, a.cdseqp, a.cdseqd, a.cdseqcl, a.cdseqch,"
            sSql += "       a.reflt, a.reflts, a.cdseqt,"
            sSql += "       fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, a.regid,"
            sSql += "       MAX(b.dispseql) dispseql, fn_ack_get_usr_name(a.regid) regnm"
            sSql += "  FROM lf321h a, lf060m b"
            sSql += " WHERE a.moddt = :moddt"
            sSql += "   AND a.modid = :modid"
            sSql += "   AND a.testcd = b.testcd"
            sSql += " GROUP BY a.testcd, a.cdseqnl, a.cdseqnh, a.cdseqp, a.cdseqd, a.cdseqcl, a.cdseqch,"
            sSql += "          a.reflt, a.reflts, a.cdseqt, A.regdt, a.regid"
            sSql += " ORDER BY dispseql, a.testcd"

            arlParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDT.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDT))
            arlParm.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModID.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModID))

            DbCommand()
            Return DbExecuteQuery(sSql, arlParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentVCmtTclsInfo(ByVal rsRstDt As String) As DataTable
        Dim sFn As String = "Public Function GetRecentVCmtTclsInfo(String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim arlParm As New ArrayList

            sSql += "SELECT rstdt"
            sSql += "  FROM lf321m"
            sSql += " WHERE rstdt = :rstdt"

            arlParm.Add(New OracleParameter("rstdt",  OracleDbType.Varchar2, rsRstDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsRstDt))

            DbCommand()
            Return DbExecuteQuery(sSql, arlParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))


        End Try
    End Function

    Public Function TransVCmtTclsInfo(ByVal roTcol1 As ItemTableCollection, ByVal rsRegId As String) As Boolean
        Dim sFn As String = "Public Function TransVCmtTclsInfo(Object, Integer, String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF321M : 
            With roTcol1
                'LF321H Backup
                sSql = ""
                sSql += "INSERT INTO lf321h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf321m f"

                dbCmd.Parameters.Clear()
                dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegId
                dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP

                dbCmd.CommandText = sSql
                iRet += dbCmd.ExecuteNonQuery()

                sSql = ""
                sSql += "DELETE lf321m"

                dbCmd.Parameters.Clear()

                dbCmd.CommandText = sSql
                iRet += dbCmd.ExecuteNonQuery()


                For i As Integer = 1 To .ItemTableRowCount
                    sField = "" : sFields = "" : sValue = "" : sValues = ""

                    dbCmd.Parameters.Clear()
                    For j As Integer = 1 To .ItemTableColCount
                        sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                        sFields += sField + ","

                        sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                        sValues += ":" + sField + ","

                        dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                    Next

                    'insert new record
                    sFields = sFields.Substring(0, sFields.Length - 1)
                    sValues = sValues.Substring(0, sValues.Length - 1)
                    sSql = "INSERT INTO lf321m (" + sFields + ") VALUES (" + sValues + ")"

                    dbCmd.CommandText = sSql
                    iRet += dbCmd.ExecuteNonQuery()
                Next
            End With

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransVCmtTclsInfo_UE(ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransVCmtTclsInfo_UE(String, String) As Boolean"

        Try
            Dim sSql As String = ""
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = "", sMsg As String = ""
            Dim alTest As New ArrayList

            'LF321M : 소견 마스터
            '   LF320H Insert
            sSql = ""
            sSql += "INSERT INTO lf321h SELECT fn_ack_sysdate, '" + rsRegID + "', '" + USER_INFO.LOCALIP + "', f.* FROM lf321m f"
            alTest.Add(sSql)

            '   LF321M Delete
            sSql = ""
            sSql += "DELETE lf321m"
            alTest.Add(sSql)

            If LISAPP.APP_DB.DBSql.ExcuteSql(alTest) = False Then
                Return False
            End If

            Return True
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

End Class

Public Class APP_F_VCMT_DOCTOR
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_VCMT_DOCTOR" & vbTab

    Public Overloads Function GetVCmtDoctorInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetVCmtDoctorInfo(Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT doctorcd, doctornm, medino, usdt, uedt"
                sSql += "  FROM (SELECT DISTINCT"
                sSql += "               a.doctorcd, fn_ack_get_dr_name(a.doctorcd) doctornm, a.medino,"
                sSql += "               a.usdt, a.uedt"
                sSql += "          FROM lf322m a"
                sSql += "         WHERE a.uedt >= fn_ack_sysdate"
                sSql += "       ) t"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY doctorcd"
            ElseIf riMode = 1 Then
                sSql += "SELECT doctorcd, doctornm, medino, usdt, uedt, diffday"
                sSql += "  FROM (SELECT DISTINCT"
                sSql += "               a.doctorcd, fn_ack_get_dr_name(a.doctorcd) doctornm, a.medino,"
                sSql += "               a.usdt, a.uedt,"
                sSql += "               CASE WHEN TO_DATE(uedt, 'yyyymmddhh24miss') - SYSDATE < 0 THEN -1 ELSE 0 END diffday"
                sSql += "          FROM lf322m a"
                sSql += "       ) t"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY doctorcd"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Overloads Function GetVCmtDoctorInfo(ByVal rsDoctorCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Overloads Function GetVCmtDoctorInfo(Integer, String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT a.doctorcd, fn_ack_get_dr_name(a.doctorcd) doctornm, a.medino,"
            sSql += "       fn_ack_date_str(a.usdt, 'yyyy-mm-dd hh24:mi:ss') usdt,"
            sSql += "       fn_ack_date_str(a.uedt, 'yyyy-mm-dd hh24:mi:ss') uedt,"
            sSql += "       fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid,"
            sSql += "       fn_ack_get_usr_name(a.regid) regnm"
            sSql += "  FROM lf322m a"
            sSql += " WHERE a.doctorcd = :drcd"
            sSql += "   AND a.usdt     = :usdt"
            sSql += " ORDER BY a.doctorcd"

            alParm.Add(New OracleParameter("drcd",  OracleDbType.Varchar2, rsDoctorCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsDoctorCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentVCmtDoctorInfo(ByVal rsDoctorCd As String, ByVal rsUSDT As String) As DataTable
        Dim sFn As String = "Public Function GetRecentVCmtDoctorInfo(String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT usdt"
            sSql += "  FROM (SELECT usdt"
            sSql += "          FROM lf322m"
            sSql += "         WHERE doctorcd = :drcd"
            sSql += "           AND usdt    >= :usdt"
            sSql += "         ORDER BY usdt DESC"
            sSql += "       ) a"
            sSql += " WHERE ROWNUM = 1"

            alParm.Add(New OracleParameter("drcd",  OracleDbType.Varchar2, rsDoctorCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsDoctorCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUSDT.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUSDT))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetUsUeDupl_VCmtDoctor(ByVal rsCd As String, ByVal rsUsDt As String, ByVal rsUseTag As String, ByVal rsCompDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeDupl_VCmtDoctor() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT a.*"
            sSql += "  FROM ("
            sSql += "        SELECT doctorcd, medino, usdt, uedt"
            sSql += "          FROM lf322m"
            sSql += "         WHERE doctorcd = :drcd"
            sSql += "           AND usdt <" + IIf(rsUseTag = "USDT", "=", "").ToString + " :compdt"
            sSql += "           AND uedt >" + IIf(rsUseTag = "USDT", "", "=").ToString + " :compdt"
            sSql += "       ) a LEFT OUTER JOIN"
            sSql += "       ("
            sSql += "        SELECT doctorcd, medino, usdt, uedt"
            sSql += "          FROM lf322m"
            sSql += "         WHERE doctorcd = :drcd"
            sSql += "           AND usdt     = :usdt"
            sSql += "       ) b ON (a.doctorcd = b.doctorcd AND a.usdt = b.usdt)"
            sSql += " WHERE NVL(b.doctorcd, ' ') = ' '"

            al.Add(New OracleParameter("drcd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("drcd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransVcmtDoctorInfo(ByVal roTcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                              ByVal rsDoctorCd As String, ByVal rsUsDt As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransVcmtDoctorInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF322M : 종합검증 의사면허번호
            Select Case riType1
                Case 0      '----- 신규
                    With roTcol1
                        'UPDATE uedt of previous record
                        sSql = ""
                        sSql += "UPDATE lf322m SET uedt = :usdt"
                        sSql += " WHERE (doctorcd, usdt) IN"
                        sSql += "       (SELECT a.doctorcd, a.usdt"
                        sSql += "          FROM (SELECT doctorcd, usdt"
                        sSql += "                  FROM lf322m"
                        sSql += " 		          WHERE doctorcd = :drcd"
                        sSql += " 				    AND usdt    <= :usdt"
                        sSql += " 				    AND uedt     > :usdt"
                        sSql += "                 ORDER BY usdt DESC"
                        sSql += "               ) a"
                        sSql += "         WHERE ROWNUM = 1"
                        sSql += "       )"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("drcd",  OracleDbType.Varchar2).Value = rsDoctorCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf322m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With roTcol1
                        'LF030H Backup
                        sSql += ""
                        sSql += "INSERT INTO lf322h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf322m f"
                        sSql += " WHERE doctorcd = :drcd"
                        sSql += "   AND usdt     = :usdt"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("drcd",  OracleDbType.Varchar2).Value = rsDoctorCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value

                                Select Case sField.ToUpper
                                    Case "DOCTORCD", "USDT"

                                    Case Else
                                        sFields += sField + " = :" + sField + ","
                                        dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End Select
                            Next

                            'UPDATE record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sSql = ""
                            sSql += "UPDATE lf322m SET " + sFields
                            sSql += " WHERE doctorcd = :drcd"
                            sSql += "   AND usdt     = :usdt"

                            dbCmd.Parameters.Add("drcd",  OracleDbType.Varchar2).Value = rsDoctorCd
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransVCmtDoctorInfo_DEL(ByVal rsDoctorCd As String, ByVal rsUsDt As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = " Public Function TransVCmtDoctorInfo_DEL() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF322M : 의사면허
            '   LF322H Insert
            sSql = ""
            sSql += "INSERT INTO lf322h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf322m f"
            sSql += " WHERE doctorcd = :drcd"
            sSql += "   AND usdt     = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("drcd",  OracleDbType.Varchar2).Value = rsDoctorCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF322M Delete
            sSql = ""
            sSql += "DELETE lf322m"
            sSql += " WHERE doctorcd = :drcd"
            sSql += "   AND usdt     = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("drcd",  OracleDbType.Varchar2).Value = rsDoctorCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()
            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransVCmtDoctorInfo_UPD_US(ByVal rsDoctorCd As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUsDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransVCmtDoctorInfo_UPD_US() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF322M : 면허번호
            '   LF322H Insert
            sSql = ""
            sSql += "INSERT INTO lf322h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf322m f"
            sSql += " WHERE doctorcd = :drcd"
            sSql += "   AND usdt     = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("drcd",  OracleDbType.Varchar2).Value = rsDoctorCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF322M Update
            sSql = ""
            sSql += "UPDATE lf322m SET"
            sSql += "       usdt     = :usdtchg,"
            sSql += "       regdt    = fn_ack_sysdate,"
            sSql += "       regid    = :regid"
            sSql += " WHERE doctorcd = :drcd"
            sSql += "   AND usdt     = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("usdtchg",  OracleDbType.Varchar2).Value = rsUsDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("drcd",  OracleDbType.Varchar2).Value = rsDoctorCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransVCmtDoctorInfo_UPD_UE(ByVal rsDoctorCd As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUeDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransVCmtDoctorInfo_UPD_UE() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF322M :면허번호
            '   LF322H Insert
            sSql = ""
            sSql += "INSERT INTO lf322h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf322m f"
            sSql += " WHERE doctorcd = :drcd"
            sSql += "   AND usdt     = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("drcd",  OracleDbType.Varchar2).Value = rsDoctorCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF030M Update
            sSql = ""
            sSql += "UPDATE lf322m SET"
            sSql += "       uedt     = :uedt,"
            sSql += "       regdt    = fn_ack_sysdate,"
            sSql += "       regid    = :regid"
            sSql += " WHERE doctorcd = :drcd"
            sSql += "   AND usdt     = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("drcd",  OracleDbType.Varchar2).Value = rsDoctorCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransVCmtDoctorInfo_UE(ByVal rsDoctorCd As String, ByVal rsUSDT As String, ByVal rsRegID As String, ByVal rsUeDt As String) As Boolean
        Dim sFn As String = " Public Function TransSpcInfo_UE(String, String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF322M : 검체 마스터
            '   LF322H Insert
            sSql = ""
            sSql += "INSERT INTO lf322h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf322m f"
            sSql += " WHERE doctorcd = :drcd"
            sSql += "   AND usdt     = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("drcd",  OracleDbType.Varchar2).Value = rsDoctorCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUSDT

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF030M Update
            sSql = " UPDATE lf322m SET uedt = :uedt, regid = :regid"
            sSql += " WHERE doctorcd = :drcd"
            sSql += "   AND usdt     = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDt
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("drcd",  OracleDbType.Varchar2).Value = rsDoctorCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUSDT

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

End Class

Public Class APP_F_CMT
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_CMT" & vbTab

    Public Function GetCmtInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetCmtInfo(ByVal iMode As Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT cmtcd, cmtcont, slipnmd slipnmd_01"
                sSql += "  FROM ("
                sSql += "        SELECT f8.cmtcd, f8.cmtcont, '[' || f8.partcd || f8.slipcd || '] ' ||  NVL(f2.slipnmd, CASE WHEN f8.partcd || f8.slipcd = '00' THEN '공통' ELSE NVL(f2.slipnmd, '') END ) slipnmd"
                sSql += "          FROM lf080m f8 LEFT OUTER JOIN lf021m f2 ON (f8.partcd = f2.partcd AND f8.slipcd = f2.slipcd)"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY cmtcd"
            ElseIf riMode = 1 Then
                sSql += "SELECT cmtcd, cmtcont, slipnmd slipnmd_01, diffday, moddt, modid"
                sSql += "  FROM ("
                sSql += "        SELECT f8.cmtcd, f8.cmtcont, '[' || f8.partcd || f8.slipcd || '] ' ||  NVL(f2.slipnmd, CASE WHEN f8.partcd || f8.slipcd = '00' THEN '공통' ELSE NVL(f2.slipnmd, '') END) slipnmd,"
                sSql += "               NULL diffday, NULL moddt, NULL modid"
                sSql += "          FROM lf080m f8 LEFT OUTER JOIN lf021m f2 ON (f8.partcd = f2.partcd AND f8.slipcd = f2.slipcd)"
                sSql += "         UNION ALL"
                sSql += "        SELECT f8.cmtcd, f8.cmtcont, '[' || f8.partcd || f8.slipcd || '] ' ||  NVL(f2.slipnmd, CASE WHEN f8.partcd || f8.slipcd = '00' THEN '공통' ELSE NVL(f2.slipnmd, '') END) slipnmd,"
                sSql += "               -1 diffday,"
                sSql += "               fn_ack_date_str(f8.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, f8.modid"
                sSql += "          FROM lf080h f8 LEFT OUTER JOIN lf021m f2 ON (f8.partcd = f2.partcd AND f8.slipcd = f2.slipcd)"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY cmtcd, moddt, modid"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetCmtInfo(ByVal rsCmtCd As String) As DataTable
        Dim sFn As String = "Public Function GetCmtInfo( String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT cmtcd, cmtcont, slipnmd slipnmd_01, regdt, regid, fn_ack_get_usr_name(regid) regnm"
            sSql += "  FROM ("
            sSql += "        SELECT f8.cmtcd, f8.cmtcont, '[' || f8.partcd || f8.slipcd || '] ' ||  NVL(f2.slipnmd, CASE WHEN f8.partcd || f8.slipcd = '00' THEN '공통' ELSE NVL(f2.slipnmd, '') END) slipnmd,"
            sSql += "               fn_ack_date_str(f8.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f8.regid"
            sSql += "          FROM lf080m f8 LEFT OUTER JOIN lf021m f2 ON (f8.partcd = f2.partcd AND f8.slipcd = f2.slipcd)"
            sSql += "       ) a"
            sSql += " WHERE cmtcd = :cmtcd"

            alParm.Add(New OracleParameter("cmtcd",  OracleDbType.Varchar2, rsCmtCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCmtCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetCmtInfo(ByVal rsModDT As String, ByVal rsModID As String, ByVal rsCmtCd As String) As DataTable
        Dim sFn As String = "Public Function GetCmtInfo(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT cmtcd, cmtcont, slipnmd slipnmd_01, regdt, regid, moddt, modid, fn_ack_get_usr_name(regid) regnm, fn_ack_get_usr_name(modid) modnm"
            sSql += "  FROM ("
            sSql += "        SELECT f8.cmtcd, f8.cmtcont, '[' || f8.partcd || f8.slipcd || '] ' ||  NVL(f2.slipnmd, CASE WHEN f8.partcd || f8.slipcd = '00' THEN '공통' ELSE NVL(f2.slipnmd, '') END) slipnmd,"
            sSql += "               fn_ack_date_str(f8.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f8.regid,"
            sSql += "               fn_ack_date_str(f8.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, f8.modid"
            sSql += "          FROM lf080h f8 LEFT OUTER JOIN lf021m f2 ON (f8.partcd = f2.partcd AND f8.slipcd = f2.slipcd)"
            sSql += "       ) a"
            sSql += " WHERE a.moddt = :moddt"
            sSql += "   AND a.modid = :modid"
            sSql += "   AND a.cmtcd = :cmtcd"

            alParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDT.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDT))
            alParm.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModID.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModID))
            alParm.Add(New OracleParameter("cmtcd",  OracleDbType.Varchar2, rsCmtCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCmtCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try

    End Function

    Public Function GetRecentCmtInfo(ByVal rsCmtCd As String) As DataTable
        Dim sFn As String = "Public Function GetRecentCmtInfo(String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT cmtcd FROM lf080m"
            sSql += " WHERE cmtcd = :cmtcd"

            alParm.Add(New OracleParameter("cmtcd",  OracleDbType.Varchar2, rsCmtCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCmtCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransCmtInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                  ByVal rsCmtCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransCmtInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF080M : 소견 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf080m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF080H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf080h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf080m f"
                        sSql += " WHERE cmtcd = :cmtcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsCmtCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        sSql = ""
                        sSql += "DELETE lf080m"
                        sSql += " WHERE cmtcd = :cmtcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsCmtCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf080m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransCmtInfo_UE(ByVal rsCmtCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransCmtInfo_UE(String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF080M : 소견 마스터
            '   LF080H Insert
            sSql = ""
            sSql += "INSERT INTO lf080h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf080m f"
            sSql += " WHERE cmtcd = :cmtcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsCmtCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF080M Delete
            sSql = ""
            sSql += "DELETE lf080m"
            sSql += " WHERE cmtcd = :cmtcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsCmtCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransTestInfo_Dispseql(ByVal rsCmtCd As String, ByVal rsDispSeq As String, ByVal rsUsrId As String) As Boolean
        Dim sFn As String = "Public Function TransTestInfo_Dispseql(String, String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            sSql = ""
            sSql += "UPDATE lf080m SET dispseq = :dispseq"
            sSql += " WHERE cmtcd = :cmtcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("dispseq",  OracleDbType.Varchar2).Value = rsDispSeq
            dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsCmtCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

End Class

Public Class APP_F_EQ
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_EQ" & vbTab

    Public Overloads Function GetEqInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Overloads Function GetEqInfo(Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT eqcd, eqnms, CASE WHEN DELFLG='0' THEN 'Y'WHEN DELFLG='1' THEN 'N' END AS USEYN"
                sSql += "  FROM lf070m"
                If rsSerch <> "" Then
                    sSql += "   WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY eqcd"
            ElseIf riMode = 1 Then
                sSql += "SELECT eqcd, eqnms, CASE WHEN DELFLG='0' THEN 'Y'WHEN DELFLG='1' THEN 'N' END AS USEYN,"
                sSql += "       TO_NUMBER(NVL(delflg, '0')) * -1 diffday"
                sSql += "  FROM lf070m"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += "  ORDER BY eqcd"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Overloads Function GetEqInfo(ByVal rsEqCd As String) As DataTable
        Dim sFn As String = "Public Overloads Function GetEqInfo(Integer, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT a.eqcd, a.eqnm, a.eqnms,"
            sSql += "       a.delflg, fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, a.regid,"
            sSql += "       fn_ack_get_usr_name(a.regid) regnm,"
            sSql += "       '[' || a.eqgbn || '] ' || b.slipnmd eqgbn_01"
            sSql += "  FROM lf070m a LEFT OUTER JOIN"
            sSql += "       lf021m b ON (SUBSTR(a.eqgbn, 1, 1) = b.partcd AND SUBSTR(a.eqgbn, 2, 1) = b.slipcd AND b.usdt <= fn_ack_sysdate AND b.uedt >  fn_ack_sysdate)"
            sSql += " WHERE a.eqcd  = :eqcd"

            Dim alParm As New ArrayList
            alParm.Add(New OracleParameter("eqcd",  OracleDbType.Varchar2, rsEqCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsEqCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentEqInfo(ByVal rsEqCd As String) As DataTable
        Dim sFn As String = "Public Function GetRecentEqInfo(String, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT eqnm"
            sSql += "  FROM lf070m"
            sSql += " WHERE eqcd = :eqcd"

            Dim alParm As New ArrayList
            alParm.Add(New OracleParameter("eqcd",  OracleDbType.Varchar2, rsEqCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsEqCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransEqInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                ByVal rsEqCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransEqInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF070M : 장비 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf070m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정 
                    With ro_Tcol1
                        'LF070H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf070h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf070m f"
                        sSql += " WHERE eqcd = :eqcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("eqcd",  OracleDbType.Varchar2).Value = rsEqCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value

                                Select Case sField.ToUpper
                                    Case "EQCD", "USDT"

                                    Case Else
                                        sFields += sField + " = :" + sField + ","

                                        dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End Select
                            Next

                            'UPDATE record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sSql = ""
                            sSql += "UPDATE lf070m SET " + sFields
                            sSql += " WHERE eqcd = :eqcd"

                            dbCmd.Parameters.Add("eqcd",  OracleDbType.Varchar2).Value = rsEqCd

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransEqInfo_UE(ByVal rsEqCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransEqInfo_UE(String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF070M : 장비 마스터 
            '   LF070H Insert 
            sSql = ""
            sSql += "INSERT INTO lf070h SELECT fn_ack_sysdate, :modid, :modip,  f.* FROM lf070m f"
            sSql += " WHERE eqcd = :eqcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("eqcd",  OracleDbType.Varchar2).Value = rsEqCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF070M Update
            sSql = ""
            sSql += "UPDATE lf070m SET delflg = '1', regdt = fn_ack_sysdate, regid = :regid"
            sSql += " WHERE eqcd = :eqcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("eqcd",  OracleDbType.Varchar2).Value = rsEqCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function GetUsUeCd_Eq(ByVal rsCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeCd_Eqmt() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT eqcd FROM lm010m"
            sSql += " WHERE eqcd = :eqcd"
            sSql += " UNION ALL "
            sSql += "SELECT eqcd FROM lr010m"
            sSql += " WHERE eqcd = eqcd"

            al.Add(New OracleParameter("eqcd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("eqcd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function TransEqInfo_DEL(ByVal rsEqCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = " Public Function TransSpcInfo_DEL() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF020M : 검체 마스터
            '   LF030H Insert
            sSql = ""
            sSql += "INSERT INTO lf070h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf070m f"
            sSql += " WHERE eqcd = :eqcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("eqcd",  OracleDbType.Varchar2).Value = rsEqCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF030M Delete
            sSql = ""
            sSql += "DELETE lf070m"
            sSql += " WHERE eqcd = :eqcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("eqcd",  OracleDbType.Varchar2).Value = rsEqCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

End Class

Public Class APP_F_EXLAB
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_EXLAB" & vbTab

    Public Overloads Function GetExLabInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Overloads Function GetExLabInfo(ByVal iMode As Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT exlabcd, exlabnmd, TO_NUMBER(NVL(delflg, '0')) * - 1 diffday, CASE WHEN DELFLG='0' THEN 'Y'WHEN DELFLG='1' THEN 'N' END AS USEYN"
            sSql += "  FROM lf050m"
            If rsSerch <> "" Then
                sSql += " WHERE " + rsSerch + ""
            End If
            sSql += " ORDER BY exlabcd"

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Overloads Function GetExLabInfo(ByVal rsExLabCd As String) As DataTable
        Dim sFn As String = "Public Overloads Function GetExLabInfo(String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT delflg, exlabcd, exlabnm, exlabnms, exlabnmd, exlabnmp, exlabnmbp,"
            sSql += "       fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid,"
            sSql += "       fn_ack_get_usr_name(regid) regnm"
            sSql += "  FROM lf050m"
            sSql += " WHERE exlabcd = :exlabcd"

            Dim alParm As New ArrayList
            alParm.Add(New OracleParameter("exlabcd",  OracleDbType.Varchar2, rsExLabCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsExLabCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransExLabInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                   ByVal rsExLabCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransExLabInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF050M : 위탁기관마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)

                            sSql = "INSERT INTO lf050m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF050H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf050h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf050m f"
                        sSql += " WHERE exlabcd = :exlabcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("exlabcd",  OracleDbType.Varchar2).Value = rsExLabCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value

                                Select Case sField.ToUpper
                                    Case "EXLABCD"

                                    Case Else
                                        sFields += sField + " = :" + sField + ","

                                        dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue

                                End Select
                            Next

                            'UPDATE record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sSql = ""
                            sSql += "UPDATE lf050m set " + sFields
                            sSql += " WHERE exlabcd = :exlabcd"

                            dbCmd.Parameters.Add("exlabcd",  OracleDbType.Varchar2).Value = rsExLabCd

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransExLabInfo_DEL(ByVal rsExLabCd As String, ByVal rsUsDt As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = " Public Function TransTestInfo_DEL() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF050M : 위탁기관 마스터
            '   LF050H Insert
            sSql = ""
            sSql += "INSERT INTO lf050h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf050m f"
            sSql += " WHERE exlabcd = :exlabcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("exlabcd",  OracleDbType.Varchar2).Value = rsExLabCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF050M Delete
            sSql = ""
            sSql += "DELETE lf050m"
            sSql += " WHERE exlabcd = :exlabcd"


            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("exlabcd",  OracleDbType.Varchar2).Value = rsExLabCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

End Class

Public Class APP_F_OSLIP
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_OSLIP" & vbTab

    Public Function GetRecentOSlipInfo(ByVal rsOSlipCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetRecentOSlipInfo() As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT tordslip"
            sSql += "  FROM lf100m"
            sSql += " WHERE tordslip = :tordslip"
            sSql += "   AND usdt     = :usdt"

            alParm.Add(New OracleParameter("tordslip",  OracleDbType.Varchar2, rsOSlipCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsOSlipCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetOSlipInfo(ByVal riMode As Integer, ByVal Serch As String) As DataTable
        Dim sFn As String = "Public Function GetOSlipInfo(Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT tordslip, tordslipnm, usdt, uedt, null diffday"
                sSql += "  FROM lf100m"
                sSql += " WHERE uedt > fn_ack_sysdate"
                If Serch <> "" Then
                    sSql += "   AND " + Serch + ""
                End If
                sSql += " ORDER BY tordslip"
            ElseIf riMode = 1 Then
                sSql += "SELECT f68.tordslip, f68.tordslipnm, usdt, uedt,"
                sSql += "       CASE WHEN TO_DATE(uedt, 'yyyymmddhh24miss') - SYSDATE < 0 THEN -1 ELSE 0 END diffday,"
                sSql += "       NULL moddt, NULL modid"
                sSql += " FROM lf100m f68"
                If Serch <> "" Then
                    sSql += " WHERE " + Serch + ""
                End If
                sSql += " ORDER BY tordslip, moddt, modid"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try

    End Function

    Public Function GetOSlipInfo(ByVal rsOrdSlip As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetOSlipInfo(String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT f68.tordslip, f68.tordslipnm, f68.dispseq,"
            sSql += "       fn_ack_date_str(f68.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt,"
            sSql += "       fn_ack_get_usr_name(f68.regid) regnm,"
            sSql += "       null moddt, null modid, doctorid1, doctorid2,"
            sSql += "       fn_ack_date_str(usdt, 'yyyy-mm-dd hh24:mi:ss') usdt,"
            sSql += "       fn_ack_date_str(uedt, 'yyyy-mm-dd hh24:mi:ss') uedt,"
            sSql += "       fn_ack_get_usr_name(doctorid1) docnm1,"
            sSql += "       fn_ack_get_usr_name(doctorid2) docnm2"
            sSql += "  FROM lf100m f68"
            sSql += " WHERE f68.tordslip = :tordslip"
            sSql += "   AND usdt         = :usdt"

            Dim alParm As New ArrayList
            alParm.Add(New OracleParameter("tordslip",  OracleDbType.Varchar2, rsOrdSlip.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsOrdSlip))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetOSlipInfo(ByVal rsModDt As String, ByVal rsModId As String, ByVal rsOSlipCd As String) As DataTable
        Dim sFn As String = "Public Function GetOSlipInfo(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT tordslip, tordslipnm, dispseq,"
            sSql += "       fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt,"
            sSql += "       fn_ack_get_usr_name(regid) regnm,"
            sSql += "       doctorid1, doctorid2,"
            sSql += "       fn_ack_date_str(usdt, 'yyyy-mm-dd hh24:mi:ss') usdt,"
            sSql += "       fn_ack_date_str(uedt, 'yyyy-mm-dd hh24:mi:ss') uedt,"
            sSql += "       fn_ack_date_str(moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, f68.modid,"
            sSql += "       fn_usr_name(doctorid1) docnm1,"
            sSql += "       fn_usr_name(doctorid2) docnm2"
            sSql += "  FROM lf100h"
            sSql += " WHERE tordslip = :tordslip"
            sSql += "   AND moddt    = :modid"
            sSql += "   AND modid    = :modip"

            alParm.Add(New OracleParameter("tordslip",  OracleDbType.Varchar2, rsOSlipCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsOSlipCd))
            alParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDt))
            alParm.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModId.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModId))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransOSlipInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                     ByVal ro_Tcol2 As ItemTableCollection, ByVal riType2 As Integer, _
                                        ByVal rsOrdSlip As String, ByVal rsUsDt As String, ByVal rsRegId As String) As Boolean
        Dim sFn As String = "Public Function TransOSlipInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF100M : 처방슬립 마스터
            Select Case riType1
                Case 0      '----- 신규
                    'UPDATE uedt of previous record
                    sSql = ""
                    sSql += "UPDATE lf100m SET uedt = :usdt"
                    sSql += " WHERE (tordslip, usdt) IN"
                    sSql += "       (SELECT a.tordslip, a.usdt"
                    sSql += "          FROM (SELECT tordslip, usdt"
                    sSql += " 		 		   FROM lf100m"
                    sSql += " 				  WHERE tordslip = :tordslip"
                    sSql += " 				    AND usdt     < :usdt"
                    sSql += " 				    AND uedt     > :usdt"
                    sSql += "                 ORDER BY usdt DESC"
                    sSql += "               ) a"
                    sSql += "         WHERE ROWNUM = 1"
                    sSql += " 	    )"

                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                    dbCmd.Parameters.Add("tordslip",  OracleDbType.Varchar2).Value = rsOrdSlip
                    dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                    dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                    dbCmd.CommandText = sSql
                    iRet += dbCmd.ExecuteNonQuery()

                    With ro_Tcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf100m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF100H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf100h "
                        sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf100m f"
                        sSql += " WHERE tordslip = :tordslip"
                        sSql += "   AND usdt     = :usdt"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegId
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("tordslip",  OracleDbType.Varchar2).Value = rsOrdSlip
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value

                                Select Case sField.ToUpper
                                    Case "TORDSLIP"

                                    Case Else
                                        sFields += sField + " = :" + sField + ","

                                        dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End Select
                            Next

                            'UPDATE record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sSql = ""
                            sSql += "UPDATE lf100m SET " + sFields
                            sSql += " WHERE tordslip = :tordslip"
                            sSql += "   AND usdt     = :usdt"

                            dbCmd.Parameters.Add("tordslip",  OracleDbType.Varchar2).Value = rsOrdSlip
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransOSlipInfo_DEL(ByVal rsOrdSlip As String, ByVal rsUsDt As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = " Public Function TransOSlipInfo_DEL() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'lf100m : 검사슬립 마스터
            '   lf100h Insert
            sSql = ""
            sSql += "INSERT INTO lf100h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf100m f"
            sSql += " WHERE tordslip = :tordslip"
            sSql += "   AND usdt     = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("tordslip",  OracleDbType.Varchar2).Value = rsOrdSlip
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   lf100m Update
            sSql = ""
            sSql += "DELETE lf100m"
            sSql += " WHERE tordslip = :tordslip"
            sSql += "   AND usdt     = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("tordslip",  OracleDbType.Varchar2).Value = rsOrdSlip
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransOSlipInfo_UE(ByVal rsOrdSlip As String, ByVal rsUsDt As String, ByVal rsRegId As String, ByVal rsUeDt As String) As Boolean
        Dim sFn As String = " Public Function TransOSlipInfo_UE() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            Dim sMsg As String = ""

            'LF100M : 검사처방슬립코드 마스터
            '   LF100H Insert
            sSql = ""
            sSql += "INSERT INTO lf100h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf100m f"
            sSql += " WHERE tordslip = :tordslip"
            sSql += "   AND usdt     = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("tordslip",  OracleDbType.Varchar2).Value = rsOrdSlip
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF100M UPDATE
            sSql = ""
            sSql += "UPDATE lf100m SET uedt = :usdt, regid = :regid"
            sSql += " WHERE tordslip = :tordslip"
            sSql += "   AND usdt     = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDt
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("tordslip",  OracleDbType.Varchar2).Value = rsOrdSlip
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransOSlipInfo_UPD_UE(ByVal rsOrdSlip As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUeDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransBcclsInfo_UPD_UE() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF010M : 검체분류 마스터
            '   LF010H Insert
            sSql = ""
            sSql += "INSERT INTO lf100h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf100m f"
            sSql += " WHERE tordslip = :tordslip"
            sSql += "   AND usdt     = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("tordslip",  OracleDbType.Varchar2).Value = rsOrdSlip
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF010M Update
            sSql = ""
            sSql += "UPDATE lf100m SET"
            sSql += "       uedt  = :uedt,"
            sSql += "       regdt = fn_ack_sysdate,"
            sSql += "       regid = :regid"
            sSql += " WHERE tordslip = :tordslip"
            sSql += "   AND usdt     = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("tordslip",  OracleDbType.Varchar2).Value = rsOrdSlip
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransOSlipInfo_UPD_US(ByVal rsOrdSlip As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUsDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransBcclsInfo_UPD_US() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF010M : 검체 마스터 
            '   LF010H Insert 
            sSql = ""
            sSql += "INSERT INTO lf100h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf100m f"
            sSql += " WHERE tordslip = :tordslip"
            sSql += "   AND usdt     = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("tordslip",  OracleDbType.Varchar2).Value = rsOrdSlip
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF010M Update 
            sSql = ""
            sSql += "UPDATE lf100m SET"
            sSql += "       usdt  = :usdtchg,"
            sSql += "       regdt = fn_ack_sysdate,"
            sSql += "       regid = :regid"
            sSql += " WHERE tordslip = :tordslip"
            sSql += "   AND usdt     = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("usdtchg",  OracleDbType.Varchar2).Value = rsUsDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("tordslip",  OracleDbType.Varchar2).Value = rsOrdSlip
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub
End Class

Public Class APP_F_RSTCD
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_RSTCD" & vbTab

    Public Function GetRstCdInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetRstCdInfo(Integer, String, String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT testcd, tnmd"
                sSql += "  FROM ("
                sSql += "        SELECT f64.testcd, MIN(CASE WHEN f60.tcdgbn = 'C' THEN '-- ' || f60.tnmd ELSE f60.tnmd END) tnmd"
                sSql += "          FROM lf083m f64, lf060m f60"
                sSql += "         WHERE f64.testcd = f60.testcd"
                sSql += "           AND f60.usdt <= fn_ack_sysdate"
                sSql += "           AND f60.uedt >  fn_ack_sysdate"
                sSql += "         GROUP BY f64.testcd"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
            ElseIf riMode = 1 Then
                sSql += "SELECT testcd, tnmd, diffday"
                sSql += "  FROM ("
                sSql += "        SELECT f64.testcd, MIN(CASE WHEN f60.tcdgbn = 'C' THEN '-- ' || f60.tnmd ELSE f60.tnmd END) tnmd,"
                sSql += "               NULL diffday, NULL moddt, NULL modid"
                sSql += "          FROM lf083m f64, lf060m f60"
                sSql += "         WHERE f64.testcd = f60.testcd"
                sSql += "           AND f60.usdt <= fn_ack_sysdate"
                sSql += "           AND f60.uedt >  fn_ack_sysdate"
                sSql += "         GROUP BY f64.testcd"
                sSql += "         UNION ALL"
                sSql += "        SELECT f64.testcd, MIN(CASE WHEN f60.tcdgbn = 'C' THEN '-- ' || f60.tnmd ELSE f60.tnmd END) tnmd,"
                sSql += "               -1 diffday, fn_ack_date_str(f64.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, f64.modid modid"
                sSql += "          FROM lf083h f64, lf060m f60"
                sSql += "         WHERE f64.testcd = f60.testcd"
                sSql += "           AND f60.usdt <= f64.moddt"
                sSql += "           AND f60.uedt >  f64.moddt"
                sSql += "         GROUP BY f64.testcd, f64.moddt, f64.modid"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY testcd, moddt, modid"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRstCdInfo(ByVal rsTestCd As String, ByVal rimode As Integer) As DataTable
        Dim sFn As String = "Public Function GetRstCdInfo(ByVal asTClsCd As String, ByVal iMode As Integer) As DataTable"

        Try
            Dim sSql As String = ""

            If rimode = 0 Then
                sSql += "SELECT f8.testcd, f8.rstcdseq, f6.tnmd, f8.keypad, f8.rstcont,"
                sSql += "       fn_ack_date_str(f8.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f8.regid,"
                sSql += "       fn_ack_get_usr_name(f8.regid) regnm,"
                sSql += "       NULL moddt, NULL modid, NULL modnm, f8.grade, f8.rstlvl"
                sSql += "  FROM (SELECT f8.testcd, MIN(CASE WHEN f6.tcdgbn = 'C' THEN '-- ' || f6.tnmd ELSE f6.tnmd END) tnmd"
                sSql += "          FROM lf083m f8, lf060m f6"
                sSql += " 		  WHERE f8.testcd = f6.testcd"
                sSql += " 		    AND f6.usdt <= fn_ack_sysdate"
                sSql += " 		    AND f6.uedt >  fn_ack_sysdate"
                sSql += " 		    AND f8.testcd = :testcd"
                sSql += " 		  GROUP BY f8.testcd"
                sSql += "        ) f6, lf083m f8"
                sSql += " WHERE f8.testcd = f6.testcd"
                sSql += " ORDER BY f8.testcd, f8.rstcdseq"

            ElseIf rimode = 1 Then
                sSql += "SELECT f8.testcd, f8.rstcdseq, f6.tnmd, f8.keypad, f8.rstcont,"
                sSql += "       fn_ack_date_str(f8.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f8.regid,"
                sSql += "       fn_ack_get_usr_name(f8.regid) regnm,"
                sSql += "       NULL moddt, NULL modid, NULL modnm, f8.grade, f8.rstlvl"
                sSql += "  FROM (SELECT f8.testcd, MIN(CASE WHEN f6.tcdgbn = 'C' THEN '-- ' || f6.tnmd ELSE f6.tnmd END) tnmd"
                sSql += "          FROM lf083m f8, lf060m f6"
                sSql += " 		  WHERE f8.testcd  = f6.testcd"
                sSql += " 		    AND f6.usdt   <= fn_ack_sysdate"
                sSql += " 		    AND f6.uedt   >  fn_ack_sysdate"
                sSql += " 		    AND f8.testcd  = :testcd"
                sSql += " 		  GROUP BY f8.testcd"
                sSql += "        ) f6, lf083m f8"
                sSql += " WHERE f8.testcd = f6.testcd"
                sSql += " UNION ALL "
                sSql += " SELECT f8.testcd, f8.rstcdseq, f6.tnmd, f8.keypad, f8.rstcont,"
                sSql += "       fn_ack_date_str(f8.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f8.regid,"
                sSql += "       fn_ack_get_usr_name(f8.regid) regnm,"
                sSql += "       NULL moddt, NULL modid, NULL modnm, f8.grade, f8.rstlvl"
                sSql += "  FROM (SELECT f8.testcd, MIN(CASE WHEN f6.tcdgbn = 'C' THEN '-- ' || f6.tnmd ELSE f6.tnmd END) tnmd"
                sSql += "          FROM lf083h f8, lf060m f6"
                sSql += " 		  WHERE f8.testcd = f6.testcd"
                sSql += " 		    AND f6.usdt <= fn_ack_sysdate"
                sSql += " 		    AND f6.uedt >  fn_ack_sysdate"
                sSql += " 		    AND f8.testcd = :testcd"
                sSql += " 		  GROUP BY f8.testcd"
                sSql += "        ) f6, lf083h f8"
                sSql += " WHERE f8.testcd = f6.testcd "
            End If

            Dim alParm As New ArrayList

            If rimode = 0 Then
                alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            ElseIf rimode = 1 Then
                alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
                alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            End If

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRstCdInfo(ByVal rsModDT As String, ByVal rsModID As String, ByVal rsTestCd As String) As DataTable
        Dim sFn As String = "Public Function GetRstCdInfo(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT f8.testcd, f8.rstcdseq, f6.tnmd, f8.keypad, f8.rstcont,"
            sSql += "       fn_get_sting(f8.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f8.regid,"
            sSql += "       fn_ack_get_usr_name(f8.regid) regnm,"
            sSql += " 	    fn_get_sting(f8.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, f8.modid,"
            sSql += "       fn_ack_get_usr_name(f8.modid) modnm, f8.grade, f8.rstlvl"
            sSql += "  FROM (SELECT f6.testcd, MIN(CASE WHEN f6.tcdgbn = 'C' THEN '-- ' || f6.tnmd ELSE f6.tnmd END) tnmd"
            sSql += "          FROM lf060 f6"
            sSql += "         WHERE f6.testcd = :testcd"
            sSql += " 	        AND f6.usdt  <= :moddt"
            sSql += " 	        AND f6.uedt   > :moddt"
            sSql += " 	      GROUP BY f6.testcd"
            sSql += "       ) f6, lf083h f8"
            sSql += " WHERE f8.testcd = f6.testcd"
            sSql += "   AND f8.moddt  = :moddt"
            sSql += "   AND f8.modid  = :modid"
            sSql += " ORDER BY f8.testcd, f8.rstcdseq"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            alParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDT.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDT))
            alParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDT.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDT))
            alParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDT.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDT))
            alParm.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModID.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModID))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentRstCdInfo(ByVal rsTestCd As String) As DataTable
        Dim sFn As String = "Public Function GetRecentRstCdInfo(ByVal asTClsCd As String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT testcd FROM lf083m"
            sSql += " WHERE testcd = :testcd"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransRstCdInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                        ByVal rsTestCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransRstCdInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF083M : 결과코드 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf083m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF083H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf083h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf083m f"
                        sSql += " WHERE testcd = :testcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()


                        sSql = ""
                        sSql += "DELETE lf083m"
                        sSql += " WHERE testcd = :testcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue


                            Next
                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf083m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next

                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransRstCdInfo_UE(ByVal rsTestCd As String, ByVal rsRegId As String) As Boolean
        Dim sFn As String = "Public Function TransRstCdInfo_UE(ByVal asTClsCd As String, ByVal asRegID As String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF083M : 결과코드 마스터 
            '   LF083H Insert 
            sSql = ""
            sSql += "INSERT INTO lf083h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf083m f"
            sSql += " WHERE testcd = :testcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF083M Delete 
            sSql = ""
            sSql += "DELETE lf083m"
            sSql += " WHERE testcd = :testcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()


            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function
End Class
'<<< 병원체검사 추가 20170601
Public Class APP_F_REF
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_REF" & vbTab

    Private Function ifExistMoreSameRef(ByVal rsRefCd As String, ByVal rsUsDt As String) As Boolean
        Dim sFn As String = "Private Function ifExistMoreSameBccls(String, String) As Boolean"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT refcd"
            sSql += "  FROM lf510m"
            sSql += " WHERE refcd = :refcd"

            alParm.Add(New OracleParameter("refcd", OracleDbType.Varchar2, rsRefCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsRefCd))

            DbCommand()
            Dim objDT As DataTable = DbExecuteQuery(sSql, alParm)

            If objDT.Rows.Count > 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function


    Public Function TransRefInfo_UE(ByVal rsRefCd As String, ByVal rsUsDt As String, ByVal rsRegId As String, ByVal rsUedt As String) As Boolean
        Dim sFn As String = " Public Function TransRefInfo_UE() As Boolean"

        Dim dbCn As New OracleConnection
        Dim dbTran As OracleTransaction
        Dim dbCmd As New OracleCommand

        Try
            Dim sMsg As String = ""

            sMsg = ifExistOtherUsableData("LF051", "REFCD", rsRefCd, rsUsDt)

            If IsNothing(sMsg) Then
                MsgBox("쿼리문의 오류가 있습니다!!", MsgBoxStyle.Exclamation)
                Return False
            End If

            If Not sMsg = "" Then
                MsgBox(sMsg, MsgBoxStyle.Critical)
                Return False
            End If

            'LF510M : 검사분류 마스터
            If ifExistMoreSameRef(rsRefCd, rsUsDt) Then Return False

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            dbCn = GetDbConnection()
            dbTran = dbCn.BeginTransaction()

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            '   LF510H Insert
            sSql = ""
            sSql += "INSERT INTO lf010h SELECT fn_ack_sysdate, :modid, :modip,  f.* FROM lf010m f"
            sSql += " WHERE bcclscd = :bcclscd"
            sSql += "   AND usdt    = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid", OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("modip", OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("bcclscd", OracleDbType.Varchar2).Value = rsRefCd
            dbCmd.Parameters.Add("usdt", OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF510M Update
            sSql = ""
            sSql += "UPDATE lf510m SET uedt = :uedt, regdt = fn_ack_sysdate, regid = :regid"
            sSql += " WHERE bcclscd = :bcclscd"
            sSql += "   AND usdt    = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt", OracleDbType.Varchar2).Value = rsUedt
            dbCmd.Parameters.Add("regid", OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("bcclscd", OracleDbType.Varchar2).Value = rsRefCd
            dbCmd.Parameters.Add("usdt", OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()
            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            If dbCn.State = ConnectionState.Open Then
                dbTran.Dispose() : dbTran = Nothing
                dbCn.Close()
            End If
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function


    Public Function GetSameRef(ByVal rsRefCd As String, ByVal rsUsDt As String, ByVal rsRefnm As String, Optional ByVal riRegType As Integer = 0) As DataTable
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList


            sSql = ""
            sSql += "SELECT refcd, refnm"
            sSql += "  FROM lf510m "
            sSql += " WHERE refcd  =  :refcd"

            alParm.Add(New OracleParameter("refcd", OracleDbType.Varchar2, rsRefCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsRefCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))


        End Try
    End Function
    Public Function TransRefInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                   ByVal rsBcclsCd As String, ByVal rsUsDt As String, ByVal rsRegId As String) As Boolean
        Dim sFn As String = "Public Function TransRefInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF510M :병원체 코드 마스터 
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        'UPDATE uedt of previous record
                        sSql = ""
                        sSql += "UPDATE lf010m SET uedt = :usdt"
                        sSql += " WHERE (bcclscd, usdt) IN"
                        sSql += "       (SELECT a.bcclscd, a.usdt"
                        sSql += "          FROM (SELECT bcclscd, usdt"
                        sSql += " 			 	   FROM lf010m"
                        sSql += " 				  WHERE bcclscd = :bcclscd"
                        sSql += " 				    AND usdt    < :usdt"
                        sSql += " 				    AND uedt    > :usdt"
                        sSql += "                 ORDER BY usdt DESC"
                        sSql += "              ) a"
                        sSql += "        WHERE ROWNUM = 1"
                        sSql += " 	    )"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("usdt", OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("bcclscd", OracleDbType.Varchar2).Value = rsBcclsCd
                        dbCmd.Parameters.Add("usdt", OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("usdt", OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)

                            sSql = "INSERT INTO lf010m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF010H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf010h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf010m f"
                        sSql += " WHERE (bcclscd, usdt) IN (SELECT a.bcclscd, a.usdt"
                        sSql += "                              FROM (SELECT bcclscd, usdt"
                        sSql += " 							           FROM lf010m"
                        sSql += " 							          WHERE bcclscd = :bcclscd"
                        sSql += " 							          ORDER BY usdt DESC"
                        sSql += "                                   ) a"
                        sSql += " 							  WHERE ROWNUM = 1"
                        sSql += " 							)"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid", OracleDbType.Varchar2).Value = rsRegId
                        dbCmd.Parameters.Add("modip", OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("bcclscd", OracleDbType.Varchar2).Value = rsBcclsCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()

                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value

                                Select Case sField.ToUpper
                                    Case "BCCLSCD", "USDT"

                                    Case Else
                                        sFields += sField + " = :" + sField + ","
                                        dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End Select
                            Next

                            'UPDATE record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sSql = ""
                            sSql += "UPDATE lf010m set " + sFields
                            sSql += " WHERE bcclscd = :bcclscd"
                            sSql += "   AND usdt   <= :usdt"
                            sSql += "   AND uedt    > :usdt"

                            dbCmd.Parameters.Add("bcclscd", OracleDbType.Varchar2).Value = rsBcclsCd
                            dbCmd.Parameters.Add("usdt", OracleDbType.Varchar2).Value = rsUsDt
                            dbCmd.Parameters.Add("uedt", OracleDbType.Varchar2).Value = rsUsDt

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

End Class

Public Class APP_F_BCCLS
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_BCCLS" & vbTab

    Private Function ifExistMoreSameBccls(ByVal rsBcclsCd As String, ByVal rsUsDt As String) As Boolean
        Dim sFn As String = "Private Function ifExistMoreSameBccls(String, String) As Boolean"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT bcclscd"
            sSql += "  FROM lf010m"
            sSql += " WHERE bcclscd = :bcclscd"
            sSql += "   AND uedt   >= fn_ack_sysdate"
            sSql += "   AND bcclscd NOT IN (SELECT bcclscd FROM lf010m"
            sSql += "                        WHERE bcclscd = :bcclscd"
            sSql += "                          AND uedt   >= :usdt"
            sSql += "                          AND usdt    = :usdt"
            sSql += "                      )"

            alParm.Add(New OracleParameter("bcclscd",  OracleDbType.Varchar2, rsBcclsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsBcclsCd))
            alParm.Add(New OracleParameter("bcclscd",  OracleDbType.Varchar2, rsBcclsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsBcclsCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Dim objDT As DataTable = DbExecuteQuery(sSql, alParm)

            If objDT.Rows.Count > 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetSameBC(ByVal rsBcclsCd As String, ByVal rsUsDt As String, ByVal rsBcclsnmbp As String, Optional ByVal riRegType As Integer = 0) As DataTable
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            '수정
            sSql = ""
            sSql += "SELECT bcclscd, partgbn"
            sSql += "  FROM vw_ack_tot_bccls_info "
            sSql += " WHERE uedt     >= fn_ack_sysdate"
            sSql += "   AND bcclsnmbp = :bcclsnmbp"
            sSql += "   AND bcclscd  <> :bcclscd"

            alParm.Add(New OracleParameter("bcclsnmbp",  OracleDbType.Varchar2, rsBcclsnmbp.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsBcclsnmbp))
            alParm.Add(New OracleParameter("bcclscd",  OracleDbType.Varchar2, rsBcclsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsBcclsCd))

            If riRegType = 0 Then
                '신규

                sSql += "   OR (bcclscd = :bcclscd AND usdt >= :usdt AND PARTGBN = '[진단검사실]')"
                sSql += "   OR (bcclscd = :bcclscd AND PARTGBN = '[핵의학검사실]')"

                alParm.Add(New OracleParameter("bcclscd",  OracleDbType.Varchar2, rsBcclsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsBcclsCd))
                alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))
                alParm.Add(New OracleParameter("bcclscd",  OracleDbType.Varchar2, rsBcclsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsBcclsCd))

            End If

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))


        End Try
    End Function


    Public Function GetRecentBcclsInfo(ByVal rsBcclsCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetRecentBcclsInfo() As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT usdt, partgbn"
            sSql += "  FROM vw_ack_tot_bccls_info"
            sSql += " WHERE bcclscd = :bcclscd"
            sSql += "   AND ((usdt   >= :usdt AND PARTGBN = '[진단검사실]') OR PARTGBN = '[핵의학검사실]') "
            sSql += "   AND ROWNUM  = 1"
            sSql += " ORDER BY usdt DESC"

            Dim alParm As New ArrayList
            alParm.Add(New OracleParameter("bcclscd",  OracleDbType.Varchar2, rsBcclsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsBcclsCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))


            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Overloads Function GetBcclsInfo(ByVal riMode As Integer, ByVal Serch As String) As DataTable
        Dim sFn As String = "Public Function GetBcclsInfo(ByVal iMode As Integer) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT bcclscd, bcclsnmd, bcclsnmbp, usdt,"
                sSql += "       CASE WHEN TO_DATE(uedt, 'yyyymmddhh24miss') - SYSDATE < 0 THEN -1 ELSE 0 END diffday"
                sSql += "  FROM lf010m"
                sSql += " WHERE uedt >= fn_ack_sysdate"
                If Serch <> "" Then
                    sSql += "   AND " + Serch + ""
                End If
                sSql += " ORDER BY bcclscd, bcclsnmbp"
            ElseIf riMode = 1 Then
                sSql += "SELECT bcclscd, bcclsnmd, bcclsnmbp, usdt,"
                sSql += "       CASE WHEN TO_DATE(uedt, 'yyyymmddhh24miss') - SYSDATE < 0 THEN -1 ELSE 0 END diffday,"
                sSql += "       '' modid, '' moddt"
                sSql += "  FROM lf010m"
                sSql += " ORDER BY bcclscd, bcclsnmbp"
                If Serch <> "" Then
                    sSql += " WHERE " + Serch + ""
                End If
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function


    Public Overloads Function GetBcclsInfo(ByVal rsBcclsCd As String, ByVal rsUsDt As String, ByVal rsUeDt As String) As DataTable
        Dim sFn As String = "Public Function GetBcclsInfo(Integer, String, String, String) As DataTable"
        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT bcclscd, bcclsnm, bcclsnms, bcclsnmd, bcclsnmp, bcclsnmbp,"
            sSql += "       fn_ack_date_str(usdt, 'yyyy-mm-dd hh24:mi:ss') usdt,"
            sSql += "       fn_ack_date_str(uedt, 'yyyy-mm-dd hh24:mi:ss') uedt,"
            sSql += "       fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid,"
            sSql += "        fn_ack_get_usr_name(regid) regnm,"
            sSql += "       CASE WHEN colorgbn = '0' THEN '[0] 흰색'   WHEN colorgbn = '1' THEN '[1] 노랑색'"
            sSql += "            WHEN colorgbn = '2' THEN '[2] 보라색' WHEN colorgbn = '3' THEN '[3] 주황색'"
            sSql += "       END colorgbn_01,"
            sSql += "       CASE WHEN bcclsgbn = '0' THEN '[0]'          WHEN bcclsgbn = '1' THEN '[1] 종합검증'"
            sSql += "            WHEN bcclsgbn = '2' THEN '[2] 미생물'   WHEN bcclsgbn = '3' THEN '[3] 혈액은행'"
            sSql += "            WHEN bcclsgbn = '6' THEN '[6] 위탁검체'"
            sSql += "            WHEN bcclsgbn = '7' THEN '[7] 성분제제'"
            sSql += "            WHEN bcclsgbn = '8' THEN '[8] 핵의학'"
            sSql += "            WHEN bcclsgbn = '9' THEN '[9] 병리과'"
            sSql += "       END bcclsgbn_01"
            sSql += "  FROM lf010m"
            sSql += " WHERE bcclscd = :bcclscd"
            sSql += "   AND usdt    = :usdt"

            alParm.Add(New OracleParameter("bcclscd",  OracleDbType.Varchar2, rsBcclsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsBcclsCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            If rsUeDt <> "" Then
                sSql += "   AND uedt   = :usdt"

                alParm.Add(New OracleParameter("uedt",  OracleDbType.Varchar2, rsUeDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUeDt))
            End If
            sSql += " ORDER BY bcclscd"

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try

    End Function

    Public Function TransBcclsInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                   ByVal rsBcclsCd As String, ByVal rsUsDt As String, ByVal rsRegId As String) As Boolean
        Dim sFn As String = "Public Function TransBcclsInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF010M : 계 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        'UPDATE uedt of previous record
                        sSql = ""
                        sSql += "UPDATE lf010m SET uedt = :usdt"
                        sSql += " WHERE (bcclscd, usdt) IN"
                        sSql += "       (SELECT a.bcclscd, a.usdt"
                        sSql += "          FROM (SELECT bcclscd, usdt"
                        sSql += " 			 	   FROM lf010m"
                        sSql += " 				  WHERE bcclscd = :bcclscd"
                        sSql += " 				    AND usdt    < :usdt"
                        sSql += " 				    AND uedt    > :usdt"
                        sSql += "                 ORDER BY usdt DESC"
                        sSql += "              ) a"
                        sSql += "        WHERE ROWNUM = 1"
                        sSql += " 	    )"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("bcclscd",  OracleDbType.Varchar2).Value = rsBcclsCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)

                            sSql = "INSERT INTO lf010m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF010H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf010h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf010m f"
                        sSql += " WHERE (bcclscd, usdt) IN (SELECT a.bcclscd, a.usdt"
                        sSql += "                              FROM (SELECT bcclscd, usdt"
                        sSql += " 							           FROM lf010m"
                        sSql += " 							          WHERE bcclscd = :bcclscd"
                        sSql += " 							          ORDER BY usdt DESC"
                        sSql += "                                   ) a"
                        sSql += " 							  WHERE ROWNUM = 1"
                        sSql += " 							)"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegId
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("bcclscd",  OracleDbType.Varchar2).Value = rsBcclsCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()

                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value

                                Select Case sField.ToUpper
                                    Case "BCCLSCD", "USDT"

                                    Case Else
                                        sFields += sField + " = :" + sField + ","
                                        dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End Select
                            Next

                            'UPDATE record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sSql = ""
                            sSql += "UPDATE lf010m set " + sFields
                            sSql += " WHERE bcclscd = :bcclscd"
                            sSql += "   AND usdt   <= :usdt"
                            sSql += "   AND uedt    > :usdt"

                            dbCmd.Parameters.Add("bcclscd",  OracleDbType.Varchar2).Value = rsBcclsCd
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUsDt

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function


    Public Function TransBcclsInfo_DEL(ByVal rsBcclscd As String, ByVal rsUsDt As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = " Public Function TransBcclsInfo_DEL() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF010M : 검체분류 마스터
            '   LF010H Insert
            sSql = ""
            sSql += "INSERT INTO lf010h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf010m f"
            sSql += " WHERE bcclscd = :bcclscd"
            sSql += "   AND usdt    = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("bcclscd",  OracleDbType.Varchar2).Value = rsBcclscd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF010M Update
            sSql = ""
            sSql += "DELETE lf010m"
            sSql += " WHERE bcclscd = :bcclscd"
            sSql += "   AND usdt    = :usdt"


            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("bcclscd",  OracleDbType.Varchar2).Value = rsBcclscd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransBcclsInfo_UE(ByVal rsBcclsCd As String, ByVal rsUsDt As String, ByVal rsRegId As String, ByVal rsUedt As String) As Boolean
        Dim sFn As String = " Public Function TransBcclsInfo_UE() As Boolean"

        Dim dbCn As New OracleConnection
        Dim dbTran As OracleTransaction
        Dim dbCmd As New OracleCommand

        Try
            Dim sMsg As String = ""

            sMsg = ifExistOtherUsableData("LF011", "BCCLSCD", rsBcclsCd, rsUsDt)

            If IsNothing(sMsg) Then
                MsgBox("쿼리문의 오류가 있습니다!!", MsgBoxStyle.Exclamation)
                Return False
            End If

            If Not sMsg = "" Then
                MsgBox(sMsg, MsgBoxStyle.Critical)
                Return False
            End If

            'LF010M : 검사분류 마스터
            If ifExistMoreSameBccls(rsBcclsCd, rsUsDt) Then Return False

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            dbCn = GetDbConnection()
            dbTran = dbCn.BeginTransaction()

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            '   LF010H Insert
            sSql = ""
            sSql += "INSERT INTO lf010h SELECT fn_ack_sysdate, :modid, :modip,  f.* FROM lf010m f"
            sSql += " WHERE bcclscd = :bcclscd"
            sSql += "   AND usdt    = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("bcclscd",  OracleDbType.Varchar2).Value = rsBcclsCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF010M Update
            sSql = ""
            sSql += "UPDATE lf010m SET uedt = :uedt, regdt = fn_ack_sysdate, regid = :regid"
            sSql += " WHERE bcclscd = :bcclscd"
            sSql += "   AND usdt    = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUedt
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("bcclscd",  OracleDbType.Varchar2).Value = rsBcclsCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()
            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            If dbCn.State = ConnectionState.Open Then
                dbTran.Dispose() : dbTran = Nothing
                dbCn.Close()
            End If
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransBcclsInfo_UPD_UE(ByVal rsBcclsCd As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUeDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransBcclsInfo_UPD_UE() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF010M : 검체분류 마스터
            '   LF010H Insert
            sSql = ""
            sSql += "INSERT INTO lf010h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf010m f"
            sSql += " WHERE bcclscd = :bcclscd"
            sSql += "   AND usdt    = :usdt"
            sSql += "   AND uedt    = ("
            sSql += "                  SELECT uedt FROM lf010m"
            sSql += "                   WHERE bcclscd = :bcclscd"
            sSql += "                    AND usdt     = :usdt"
            sSql += "                 )"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("bcclscd",  OracleDbType.Varchar2).Value = rsBcclsCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
            dbCmd.Parameters.Add("bcclscd",  OracleDbType.Varchar2).Value = rsBcclsCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF010M Update
            sSql = ""
            sSql += "UPDATE lf010m SET"
            sSql += "       uedt  = :uedt,"
            sSql += "       regdt = fn_ack_sysdate,"
            sSql += "       regid = :regid"
            sSql += " WHERE bcclscd = :bcclscd"
            sSql += "   AND usdt    = :usdt"
            sSql += "   AND uedt    = ("
            sSql += "                  SELECT uedt FROM lf010m"
            sSql += "                   WHERE bcclscd = :bcclscd"
            sSql += "                     AND usdt    = :usdt"
            sSql += "                 )"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("bcclscd",  OracleDbType.Varchar2).Value = rsBcclsCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
            dbCmd.Parameters.Add("bcclscd",  OracleDbType.Varchar2).Value = rsBcclsCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransBcclsInfo_UPD_US(ByVal rsBcclsCd As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUsDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransBcclsInfo_UPD_US() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF010M : 검체 마스터 
            '   LF010H Insert 
            sSql = ""
            sSql += "INSERT INTO lf010h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf010m f"
            sSql += " WHERE bcclscd = :bcclscd"
            sSql += "   AND usdt    = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("bcclscd",  OracleDbType.Varchar2).Value = rsBcclsCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF010M Update 
            sSql = ""
            sSql += "UPDATE lf010m SET"
            sSql += "       usdt  = :usdtchg,"
            sSql += "       regdt = fn_ack_sysdate,"
            sSql += "       regid = :regid"
            sSql += " WHERE bcclscd = :bcclscd"
            sSql += "   AND usdt    = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("usdtchg",  OracleDbType.Varchar2).Value = rsUsDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("bcclscd",  OracleDbType.Varchar2).Value = rsBcclsCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

End Class

Public Class APP_F_SLIP
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_SLIP" & vbTab

    Private Function ifExistPart(ByVal rsPartCd As String, ByVal rsUsDt As String, _
                                 ByVal r_DbTrans As oracleTransaction, ByVal r_DbCn As oracleConnection) As Boolean
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT partcd"
            sSql += "  FROM lf020m"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND usdt   = :usdt"
            sSql += "   AND uedt  >  :usdt"
            sSql += "   AND uedt  >= fn_ack_sysdate"

            Dim dbCmd As New oracleCommand
            Dim dbDa As oracleDataAdapter
            Dim dt As New DataTable

            With dbCmd
                .Connection = r_DbCn
                .Transaction = r_DbTrans
                .CommandType = CommandType.Text
                .CommandText = sSql

                .Parameters.Clear()
                .Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
                .Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                .Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
            End With

            dbDa = New oracleDataAdapter(dbCmd)
            dt.Reset()
            dbDa.Fill(dt)

            If dt.Rows.Count > 0 Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Private Function ifExistMoreSameSlip(ByVal rsPartCd As String, ByVal rsSlipCd As String, ByVal rsUsDt As String, _
                                         ByVal r_DbTrans As oracleTransaction, ByVal r_DbCn As oracleConnection) As Boolean
        Dim sFn As String = "Private Function ifExistMoreSameSlip(ByVal asPartCd As String, ByVal asSlipCd As String, ByVal asUSDT As String) As Boolean"

        Try
            Dim dbCmd As New oracleCommand
            Dim dbDa As OracleDataAdapter

            With dbCmd
                .Connection = r_DbCn
                .Transaction = r_DbTrans
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""

            sSql += "SELECT f21.partcd, f21.slipcd"
            sSql += "  FROM vw_ack_tot_partslip_info f20, vw_ack_tot_partslip_info f21"
            sSql += " WHERE f20.partcd = f21.partcd"
            sSql += "   AND f21.partcd = :partcd"
            sSql += "   AND f20.uedt >= fn_ack_sysdate"
            sSql += "   AND f21.uedt >= fn_ack_sysdate"
            sSql += "   AND (f21.partcd, f21.slipcd) NOT IN ("
            sSql += "       (SELECT f21.partcd, f21.slipcd"
            sSql += "          FROM vw_ack_tot_partslip_info f20, vw_ack_tot_partslip_info f21"
            sSql += "         WHERE f20.partcd = f21.partcd"
            sSql += "           AND f21.partcd = :partcd"
            sSql += "           AND f21.slipcd = :slipcd"
            sSql += "           AND f20.uedt  >= :usdt"
            sSql += "           AND f21.usdt   = :usdt"
            sSql += "       )"

            dbCmd.CommandText = sSql

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbDa = New OracleDataAdapter(dbCmd)
            Dim dt As New DataTable
            dt.Reset()
            dbDa.Fill(dt)

            If dt.Rows.Count > 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetOnlyPartInfo(ByVal rsPartCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList


            sSql += "SELECT partnm, partnm, partnms, partnmd, partnmp,"
            sSql += "       take2yn, telno,"
            sSql += "       CASE WHEN partgbn = '0' THEN '[0]'           WHEN partgbn = '1' THEN '[1] 종합검증'"
            sSql += "            WHEN partgbn = '2' THEN '[2] 미생물'    WHEN partgbn = '3' THEN '[3] 혈액은행'"
            sSql += "            WHEN partgbn = '4' THEN '[4] 핵의학체외'"
            sSql += "       END partgbn_01"
            sSql += "  FROM lf020m"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND uedt   > :usdt"
            sSql += "   AND uedt  >= fn_ack_sysdate"

            alParm.Add(New OracleParameter("partcd",  OracleDbType.Varchar2, rsPartCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsPartCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentSlipInfo(ByVal rsPartCd As String, ByVal rsSlipCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetRecentSlipInfo() As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT usdt, partgbn"
            sSql += "  FROM (SELECT usdt, partgbn"
            sSql += "          FROM vw_ack_tot_partslip_info"
            sSql += "         WHERE partcd = :partcd"
            sSql += "           AND slipcd = :slipcd"
            sSql += "           AND ((usdt   >= :usdt AND PARTGBN = '[진단검사실]') OR PARTGBN = '[핵의학검사실]')"
            sSql += "         ORDER BY usdt DESC"
            sSql += "       ) a"
            sSql += " WHERE ROWNUM = 1"

            alParm.Add(New OracleParameter("partcd",  OracleDbType.Varchar2, rsPartCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsPartCd))
            alParm.Add(New OracleParameter("slipcd",  OracleDbType.Varchar2, rsSlipCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSlipCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Overloads Function GetSlipInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Overloads Function GetSlipInfo(ByVal iMode As Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT DISTINCT slipcd, slipnmd, partnmd, usdt, uedt, dispseq"
                sSql += "  FROM ("
                sSql += "        SELECT f21.partcd || f21.slipcd slipcd, f21.slipnmd, f20.partnmd, f21.usdt, f21.uedt, f21.dispseq"
                sSql += "          FROM lf020m f20, lf021m f21"
                sSql += "         WHERE f20.partcd = f21.partcd"
                sSql += "           AND f20.uedt  >= fn_ack_sysdate"
                sSql += "           AND f21.uedt  >= fn_ack_sysdate"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " & rsSerch & ""
                End If
                sSql += " ORDER BY dispseq, slipcd"
            ElseIf riMode = 1 Then
                sSql += "SELECT DISTINCT slipcd, slipnmd, partnmd, usdt, uedt, dispseq, diffday"
                sSql += "  FROM ("
                sSql += "        SELECT f21.partcd || f21.slipcd slipcd, f21.slipnmd, f20.partnmd, f21.usdt, f21.uedt,"
                sSql += "               CASE WHEN TO_DATE(f21.uedt, 'yyyymmddhh24miss') - SYSDATE < 0 THEN -1 ELSE 0 END diffday,"
                sSql += "               f21.dispseq"
                sSql += "          FROM lf020m f20, lf021m f21"
                sSql += "         WHERE f20.partcd = f21.partcd"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " & rsSerch & ""
                End If
                sSql += " ORDER BY dispseq, slipcd"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Overloads Function GetSlipInfo(ByVal rsPartCd As String, ByVal rsSlipCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Overloads Function GetSlipInfo(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT f21.partcd, f21.slipcd, f20.partnm, f20.partnms, f20.partnmd, f20.partnmp,"
            sSql += "       f21.slipnm, f21.slipnms, f21.slipnmd, f21.slipnmp,"
            sSql += "       fn_ack_date_str(f21.usdt, 'yyyy-mm-dd hh24:mi:ss') usdt,"
            sSql += "       fn_ack_date_str(f21.uedt, 'yyyy-mm-dd hh24:mi:ss') uedt,"
            sSql += "       fn_ack_date_str(f21.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt,"
            sSql += "       f21.regid, f21.dispseq, f21.take2yn, fn_ack_get_usr_name(f21.regid) regnm,"
            sSql += "       CASE WHEN f20.partgbn = '0' THEN '[0]'           WHEN f20.partgbn = '1' THEN '[1] 종합검증'"
            sSql += "            WHEN f20.partgbn = '2' THEN '[2] 미생물'    WHEN f20.partgbn = '3' THEN '[3] 혈액은행'"
            sSql += "            WHEN f20.partgbn = '4' THEN '[4] 핵의학체외'"
            sSql += "       END partgbn_01, f20.telno"
            sSql += "  FROM lf020m f20, lf021m f21"
            sSql += " WHERE f20.partcd = f21.partcd"
            sSql += "   AND f21.partcd = :partcd"
            sSql += "   AND f21.slipcd = :slipcd"
            sSql += "   AND f21.usdt   = :usdt"

            alParm.Add(New OracleParameter("partcd",  OracleDbType.Varchar2, rsPartCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsPartCd))
            alParm.Add(New OracleParameter("slipcd",  OracleDbType.Varchar2, rsSlipCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSlipCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransSlipInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                  ByVal ro_Tcol2 As ItemTableCollection, ByVal riType2 As Integer, _
                                  ByVal rsPartCd As String, ByVal rsSlipCd As String, ByVal rsUsDt As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransSlipInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF020M : 분야 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        If Not ifExistPart(rsPartCd, rsUsDt, dbTran, dbCn) Then
                            For i As Integer = 1 To .ItemTableRowCount
                                sField = "" : sFields = "" : sValue = "" : sValues = ""

                                dbCmd.Parameters.Clear()
                                For j As Integer = 1 To .ItemTableColCount
                                    sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                    sFields += sField + ","

                                    sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                    sValues += ":" + sField + ","

                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                Next

                                'insert new record
                                sFields = sFields.Substring(0, sFields.Length - 1)
                                sValues = sValues.Substring(0, sValues.Length - 1)

                                sSql = "INSERT INTO lf020m (" + sFields + ") VALUES (" + sValues + ")"

                                dbCmd.CommandText = sSql
                                iRet += dbCmd.ExecuteNonQuery()

                            Next
                        End If
                    End With
                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF020H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf020h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf020m f"
                        sSql += " WHERE partcd = :partcd"
                        sSql += "   AND usdt   = :usdt"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value

                                Select Case sField.ToUpper
                                    Case "PARTCD", "USDT"

                                    Case Else
                                        sFields += sField + "= :" + sField + ","

                                        dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End Select
                            Next

                            'UPDATE record
                            sFields = sFields.Substring(0, sFields.Length - 1)

                            sSql = ""
                            sSql += "UPDATE lf020m SET " + sFields
                            sSql += " WHERE partcd = :partcd"
                            sSql += "   AND usdt   = :usdt"

                            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt


                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                        Next
                    End With
            End Select

            'LF021M : 슬립 마스터
            Select Case riType2
                Case 0      '----- 신규
                    With ro_Tcol2
                        'UPDATE uedt of previous record
                        sSql = ""
                        sSql += "UPDATE lf021m SET uedt = :usdt"
                        sSql += " WHERE (partcd, slipcd, usdt) IN"
                        sSql += "       (SELECT a.partcd, a.slipcd, a.usdt"
                        sSql += "          FROM (SELECT partcd, slipcd, usdt"
                        sSql += " 				   FROM lf021m"
                        sSql += " 				  WHERE partcd = :partcd"
                        sSql += "                   AND slipcd = :slipcd"
                        sSql += " 				    AND usdt  <= :usdt"
                        sSql += " 				    AND uedt  >  :usdt"
                        sSql += "                 ORDER BY usdt DESC"
                        sSql += "              ) a"
                        sSql += "        WHERE ROWNUM = 1"
                        sSql += " 	    )"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
                        dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)

                            sSql = "INSERT INTO lf021m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol2
                        'LF021H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf021h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf021m f"
                        sSql += " WHERE partcd = :partcd"
                        sSql += "   AND slipcd = :slipcd"
                        sSql += "   AND usdt   = :usdt"


                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
                        dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt


                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value

                                Select Case sField.ToUpper
                                    Case "PARTCD", "SLIPCD", "USDT"

                                    Case Else
                                        sFields += sField + " = :" + sField + ","

                                        dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End Select
                            Next

                            'UPDATE record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sSql = ""
                            sSql += "UPDATE lf021m SET " + sFields
                            sSql += " WHERE partcd = :partcd"
                            sSql += "   AND slipcd = :slipcd"
                            sSql += "   AND usdt   = :usdt"

                            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
                            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransSlipInfo_DEL(ByVal rsPartCd As String, ByVal rsSlipCd As String, ByVal rsUsDt As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = " Public Function TransSlipInfo_DEL() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF021M : 슬립 마스터
            '   LF021H Insert 
            sSql = ""
            sSql += "INSERT INTO lf021h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf021m f"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND slipcd = :slipcd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF021M Delete
            sSql = ""
            sSql += "DELETE lf021m"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND slipcd = :slipcd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            'LF020M : 분야 마스터 
            '   LF020H Insert 
            sSql = ""
            sSql += "INSERT INTO lf020h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf020m f"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND usdt   = :usdt"
            sSql += "   AND partcd NOT IN (SELECT partcd FROM lf021m WHERE partcd = :partcd AND slipcd <> :slipcd AND usdt = :usdt)"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()
            '   LF020M Update
            sSql = ""
            sSql += "DELETE lf020m"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND usdt   = :usdt"
            sSql += "   AND partcd NOT IN (SELECT partcd FROM lf021m WHERE partcd = :partcd AND slipcd <> :slipcd AND usdt = :usdt)"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransSlipInfo_UPD_US(ByVal rsPartCd As String, ByVal rsSlipCd As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUsDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransSlipInfo_UPD_US() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF020M : 분야 마스터 
            '   LF020H Insert 
            sSql = ""
            sSql += "INSERT INTO lf020h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf020m f"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND usdt   = :usdt"
            sSql += "   AND partcd NOT IN (SELECT partcd FROM lf021m WHERE partcd = :partcd AND slipcd <> :slipcd AND usdt = :usdt)"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()


            '   LF020M Update
            sSql = ""
            sSql += "UPDATE lf020m SET"
            sSql += "       usdt   = :usdt,"
            sSql += "       regdt  = fn_ack_sysdate,"
            sSql += "       regid  = :regid"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND usdt   = :usdt"
            sSql += "   AND partcd NOT IN (SELECT partcd FROM lf021m WHERE partcd = :partcd AND slipcd <> :slipcd AND usdt = :usdt)"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            'LF021M : 슬립 마스터 
            '   LF021H Insert 
            sSql = ""
            sSql += "INSERT INTO lf021h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf021m f"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND slipcd = :slipcd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF021M Update 
            sSql = ""
            sSql += "UPDATE lf021m SET"
            sSql += "       usdt   = :usdtchg,"
            sSql += "       regdt  = fn_ack_sysdate,"
            sSql += "       regid  = :regid"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND slipcd = :slipcd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("usdtchg",  OracleDbType.Varchar2).Value = rsUsDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransSlipInfo_UPD_UE(ByVal rsPartCd As String, ByVal rsSlipCd As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUeDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransSlipInfo_UPD_UE() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF020M : 분야 마스터 
            '   LF020H Insert 
            sSql = ""
            sSql += "INSERT INTO lf020h "
            sSql += " SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf020m f"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND usdt   = :usdt"
            sSql += "   AND partcd NOT IN (SELECT partcd FROM lf021m WHERE partcd = :partcd AND slipcd <> :slipcd AND usdt = :usdt)"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
             iRet += dbCmd.ExecuteNonQuery()

            '   LF020M Update
            sSql = ""
            sSql += "UPDATE lf020m SET"
            sSql += "       uedt  = :uedt,"
            sSql += "       regdt = fn_ack_sysdate,"
            sSql += "       regid = :regid"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND usdt   = :usdt"
            sSql += "   AND partcd NOT IN (SELECT partcd FROM lf021m WHERE partcd = :partcd AND slipcd <> :slipcd AND usdt = :usdt)"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            'LF021M : 슬립 마스터
            '   LF021H Insert
            sSql = ""
            sSql += "INSERT INTO lf021h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf021m f"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND slipcd = :slipcd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF021M Update
            sSql = ""
            sSql += "UPDATE lf021m SET"
            sSql += "       uedt  = :uedt,"
            sSql += "       regdt = fn_ack_sysdate,"
            sSql += "       regid = :regid"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND slipcd = :slipcd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransSlipInfo_UE(ByVal rsPartCd As String, ByVal rsSlipCd As String, ByVal rsUsDt As String, ByVal rsRegId As String, ByVal rsUeDt As String) As Boolean
        Dim sFn As String = " Public Function TransSlipInfo_UE() As Boolean"

        Dim dbCn As New OracleConnection
        Dim dbTran As OracleTransaction
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            Dim sMsg As String = ""
            Dim alTest As New ArrayList

            sMsg = ifExistOtherUsableData("LF021M", "PARTCD", "SLIPCD", rsPartCd, rsSlipCd, rsUsDt)

            If IsNothing(sMsg) Then
                MsgBox("쿼리문의 오류가 있습니다!!", MsgBoxStyle.Exclamation)
                Exit Function
            End If

            If Not sMsg = "" Then
                MsgBox(sMsg, MsgBoxStyle.Critical)
                Exit Function
            End If

            dbCn = GetDbConnection()
            dbTran = dbCn.BeginTransaction()

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF021M : 슬립 마스터
            '   LF021H Insert
            sSql = ""
            sSql += "INSERT INTO lf021h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf021m f"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND slipcd = :slipcd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF021M Update
            sSql = ""
            sSql += "UPDATE lf021m SET uedt = :uedt, regid = :regid"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND slipcd = :slipcd"
            sSql += "   AND usdt   = :usdt"
            alTest.Add(sSql)

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDt
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF020H Insert
            sSql = ""
            sSql += "INSERT INTO lf020h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf020m f"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND usdt   = :usdt"
            sSql += "   AND NOT EXISTS (SELECT * FROM lf021m WHERE partcd = :partcd AND slipcd <> :slipcd AND uedt > :uedt)"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF020M Update
            sSql = ""
            sSql += "UPDATE lf020m SET uedt = :uedt, regid = :regid"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND usdt   = :usdt"
            sSql += "   AND NOT EXISTS (SELECT * FROM lf021m WHERE partcd = :partcd AND slipcd <> :slipcd AND uedt > :uedt)"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDt
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsPartCd
            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            If dbCn.State = ConnectionState.Open Then
                dbTran.Dispose() : dbTran = Nothing
                dbCn.Close()
            End If
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function
End Class

Public Class APP_F_SPC
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_SPC" & vbTab

    Public Function GetUsUeCd_Spc(ByVal rsCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeCd_Test() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT spccd  FROM lf031m WHERE spccd = :spccd UNION ALL "
            sSql += "SELECT spccd  FROM lj011m WHERE spccd = :spccd UNION ALL "
            sSql += "SELECT spccd  FROM lr010m WHERE spccd = :spccd UNION ALL "
            sSql += "SELECT spccd  FROM lm010m WHERE spccd = :spccd"

            al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetUsUeDupl_Spc(ByVal rsCd As String, ByVal rsUsDt As String, ByVal rsUseTag As String, ByVal rsCompDt As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeDupl_Spc() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT a.*"
            sSql += "  FROM ("
            sSql += "        SELECT spccd, spcnmd, usdt, uedt"
            sSql += "          FROM lf030m"
            sSql += "         WHERE spccd = :spccd"
            sSql += "           AND usdt <" + IIf(rsUseTag = "USDT", "=", "").ToString + " :compdt"
            sSql += "           AND uedt >" + IIf(rsUseTag = "USDT", "", "=").ToString + " :compdt"
            sSql += "       ) a LEFT OUTER JOIN"
            sSql += "       ("
            sSql += "        SELECT spccd, spcnmd, usdt, uedt"
            sSql += "          FROM lf030m"
            sSql += "         WHERE spccd = :spccd"
            sSql += "           AND usdt  = :usdt"
            sSql += "       ) b ON (a.spccd = b.spccd AND a.usdt = b.usdt)"
            sSql += " WHERE NVL(b.spccd, ' ') = ' '"

            al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("compdt",  OracleDbType.Varchar2, rsCompDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCompDt))
            al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))
            al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Overloads Function GetSpcInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Overloads Function GetSpcInfo(ByVal iMode As Integer, ByVal Serch As string) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT spccd, spcnmd, spcifcd, spcwncd, CASE WHEN reqcmt = '1' THEN 'Y' ELSE '' END reqcmt, usdt, uedt, NULL diffday"
                sSql += "  FROM lf030m"
                sSql += " WHERE uedt >= fn_ack_sysdate"
                If rsSerch <> "" Then
                    sSql += "   AND " & rsSerch & ""
                End If
                sSql += " ORDER BY spccd"
            ElseIf riMode = 1 Then
                sSql += "SELECT spccd, spcnmd, spcifcd, spcwncd, CASE WHEN reqcmt = '1' THEN 'Y' ELSE '' END reqcmt, usdt, uedt,"
                sSql += "       CASE WHEN TO_DATE(uedt, 'yyyymmddhh24miss') - SYSDATE < 0 THEN -1 ELSE 0 END diffday"
                sSql += "  FROM lf030m"
                If rsSerch <> "" Then
                    sSql += " WHERE " & rsSerch & ""
                End If
                sSql += " ORDER BY spccd"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Overloads Function GetSpcInfo(ByVal rsSpcCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Overloads Function GetSpcInfo(ByVal iMode As Integer, ByVal asSpcCd As String, ByVal asUSDT As String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT spccd, spcnm, spcnms, spcnmd, spcnmp, spcnmbp,"
            sSql += "       fn_ack_date_str(usdt, 'yyyy-mm-dd hh24:mi:ss') usdt,"
            sSql += "       fn_ack_date_str(uedt, 'yyyy-mm-dd hh24:mi:ss') uedt,"
            sSql += "       fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid,"
            sSql += "       fn_ack_get_usr_name(regid) regnm,"
            sSql += "       mbspcyn, spcifcd, spcwncd, reqcmt, bldgbn"
            sSql += "  FROM lf030m"
            sSql += " WHERE spccd = :spccd"
            sSql += "   AND usdt  = :usdt"

            alParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetSpcOrdSlipInfo(ByVal rsSpcCd As String) As DataTable
        Dim sFn As String = "Public Function GetSpcOrdSlipInfo(ByVal asSpcCd As String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT CASE WHEN NVL(f33.chk, '') = '' THEN '0' ELSE '1' END chk,"
            sSql += "       '[' || f68.tordslip || '] ' ||  f68.tordslipnm tordslip,"
            sSql += "        f33.dispseq, f33.useflg"
            sSql += "  FROM lf100m f68 LEFT OUTER JOIN"
            sSql += "       (SELECT '1' chk, f68.tordslip, f33.dispseq, f33.useflg"
            sSql += "          FROM lf100m f68, lf033m f33"
            sSql += "         WHERE f68.tordslip = f33.tordslip"
            sSql += "           AND f33.spccd = :spccd"
            sSql += "       ) f33 ON (f68.tordslip = f33.tordslip)"
            sSql += " ORDER BY tordslip"

            alParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentSpcInfo(ByVal rsSpcCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetRecentSpcInfo(ByVal asSpcCd As String, ByVal asUSDT As String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT usdt"
            sSql += "  FROM (SELECT usdt"
            sSql += "          FROM lf030m"
            sSql += "         WHERE spccd = :spccd"
            sSql += "           AND usdt >= :usdt"
            sSql += "         ORDER BY usdt DESC"
            sSql += "       ) a"
            sSql += " WHERE ROWNUM = 1"

            alParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransSpcInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                 ByVal ro_Tcol2 As ItemTableCollection, ByVal riType2 As Integer, _
                                 ByVal rsSpcCd As String, ByVal rsUsDt As String, ByVal rsRegId As String) As Boolean
        Dim sFn As String = "Public Function TransSpcInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""
            Dim bITF_yn As Boolean = False

            'LF030M : 검체마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        'UPDATE uedt of previous record
                        sSql = ""
                        sSql += "UPDATE lf030m SET uedt = :usdt"
                        sSql += " WHERE (spccd, usdt) IN"
                        sSql += "       (SELECT a.spccd, a.usdt"
                        sSql += "          FROM (SELECT spccd, usdt"
                        sSql += " 				   FROM lf030m"
                        sSql += " 				  WHERE spccd = :spccd"
                        sSql += " 				    AND usdt  < :usdt"
                        sSql += " 				    AND uedt  > :usdt"
                        sSql += "                 ORDER BY usdt DESC"
                        sSql += "              ) a"
                        sSql += "        WHERE ROWNUM = 1"
                        sSql += " 	    )"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        If bITF_yn Then
                            sSql = ""
                            sSql += "UPDATE fkitf..itf_lis_lf030m SET uedt = :usdt"
                            sSql += " WHERE (spccd, usdt) IN"
                            sSql += "       (SELECT a.spccd, a.usdt"
                            sSql += "          FROM (SELECT spccd,usdt"
                            sSql += " 				   FROM fkitf..itf_lis_lf030m"
                            sSql += " 				  WHERE spccd = :spccd"
                            sSql += " 				    AND usdt  < :usdt"
                            sSql += " 				    AND uedt  > :usdt"
                            sSql += "                 ORDER BY usdt DESC"
                            sSql += "              ) a"
                            sSql += "        WHERE ROWNUM = 1"
                            sSql += " 	    )"

                            dbCmd.Parameters.Clear()
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                        End If

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)

                            sSql = "INSERT INTO lf030m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                            If bITF_yn Then
                                sSql = "INSERT INTO fkitf..itf_lis_lf030m (" + sFields + ") VALUES (" + sValues + ")"

                                dbCmd.CommandText = sSql
                                iRet += dbCmd.ExecuteNonQuery()
                            End If
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF030H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf030h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf030m f"
                        sSql += " WHERE spccd = :spccd"
                        sSql += "   AND usdt  = :usdt"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegId
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value

                                Select Case sField.ToUpper
                                    Case "SPCCD", "USDT"

                                    Case Else
                                        sFields += sField + " = '" + sValue + "',"

                                        'dbCmd.Parameters.Add(New OracleParameter(sField, sValue))
                                End Select
                            Next

                            'UPDATE record
                            sFields = sFields.Substring(0, sFields.Length - 1)

                            sSql = ""
                            sSql += "UPDATE lf030m SET " + sFields
                            sSql += " WHERE spccd = :spccd"
                            sSql += "   AND usdt  = :usdt"

                            dbCmd.Parameters.Clear()
                            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                        Next
                    End With
            End Select

            'LF033M : 처방슬립별 검체 마스터
            Select Case riType2
                Case 0      '----- 신규
                    With ro_Tcol2
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf033m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    'LF033H Backup
                    sSql = ""
                    sSql += "INSERT INTO lf033h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf033m f"
                    sSql += " WHERE spccd = :spccd"

                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegId
                    dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                    dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

                    dbCmd.CommandText = sSql
                    iRet += dbCmd.ExecuteNonQuery()

                    sSql = ""
                    sSql += "DELETE lf033m"
                    sSql += " WHERE spccd = :spccd"

                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

                    dbCmd.CommandText = sSql
                    iRet += dbCmd.ExecuteNonQuery()

                    With ro_Tcol2
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)

                            sSql = "INSERT INTO lf033m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            '-- OCS 관련 수정
            With dbCmd
                .CommandType = CommandType.StoredProcedure
                .CommandText = "pro_ack_exe_ocs_spc"

                .Parameters.Clear()
                .Parameters.Add(New OracleParameter("rs_iud", "I"))
                .Parameters.Add(New OracleParameter("rs_spccd", rsSpcCd))
                .Parameters.Add(New OracleParameter("rs_editid", USER_INFO.USRID))
                .Parameters.Add(New OracleParameter("rs_editip", USER_INFO.LOCALIP))

                .Parameters.Add("rs_errmsg",  OracleDbType.Varchar2, 4000)
                .Parameters("rs_errmsg").Direction = ParameterDirection.InputOutput
                .Parameters("rs_errmsg").Value = ""

                .ExecuteNonQuery()

                Dim sRetVal As String = .Parameters(4).Value.ToString

                If sRetVal <> "00" Then
                    dbTran.Rollback()
                    Throw (New Exception(sRetVal.Substring(2)))
                End If
            End With

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransSpcInfo_DEL(ByVal rsSpcCd As String, ByVal rsUsDt As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = " Public Function TransSpcInfo_DEL() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            Dim dt As New DataTable

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim bITF_yn As Boolean = False

            'LF020M : 검체 마스터
            '   LF030H Insert
            sSql = ""
            sSql += "INSERT INTO lf030h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf030m f"
            sSql += " WHERE spccd = :spccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF030M Delete
            sSql = ""
            sSql += "DELETE lf030m"
            sSql += " WHERE spccd = :spccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If bITF_yn Then
                sSql = ""
                sSql += "DELETE fkitf..itf_lis_lf030m"
                sSql += " WHERE spccd = :spccd"
                sSql += "   AND usdt  = :usdt"

                dbCmd.Parameters.Clear()
                dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                dbCmd.CommandText = sSql
                iRet += dbCmd.ExecuteNonQuery()

            End If
            'LF020M : 검체 마스터
            '   LF030H Insert
            sSql = ""
            sSql += "INSERT INTO lf033h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf033m f"
            sSql += " WHERE spccd = :spccd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF030M Delete
            sSql = ""
            sSql += "DELETE lf033m"
            sSql += " WHERE spccd = :spccd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function


    Public Function TransSpcInfo_UE(ByVal rsSpcCd As String, ByVal rsUsDt As String, ByVal rsRegId As String, ByVal rsUeDt As String) As Boolean
        Dim sFn As String = " Public Function TransSpcInfo_UE(ByVal asSpcCd As String, ByVal asUSDT As String, byval asUEDT as string, ByVal asRegID As String) As Boolean"

        Dim dbCn As New OracleConnection
        Dim dbTran As OracleTransaction
        Dim dbCmd As New OracleCommand

        Try

            Dim sMsg As String = ifExistOtherUsableData("LF030M", "SPCCD", rsSpcCd, rsUsDt)

            If IsNothing(sMsg) Then
                MsgBox("쿼리문의 오류가 있습니다!!", MsgBoxStyle.Exclamation)
                Exit Function
            End If

            If Not sMsg = "" Then
                MsgBox(sMsg, MsgBoxStyle.Critical)
                Exit Function
            End If

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            dbCn = GetDbConnection()
            dbTran = dbCn.BeginTransaction()

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim bITF_yn As Boolean = False
            Dim dt As New DataTable

            'LF030M : 검체 마스터
            '   LF030H Insert
            sSql = ""
            sSql += "INSERT INTO lf030h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf030m f"
            sSql += " WHERE spccd = :spccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF030M Update
            sSql = ""
            sSql += "UPDATE lf030m SET uedt = :uedt, regid = :regid"
            sSql += " WHERE spccd = :spccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDt
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If bITF_yn Then
                sSql = ""
                sSql += "UPDATE fkitf..itf_lis_lf030m SET uedt = fn_ack_sysdate, regid = :regid"
                sSql += " WHERE spccd = :spccd"
                sSql += "   AND usdt  = :usdt"

                dbCmd.Parameters.Clear()
                dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegId
                dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                dbCmd.CommandText = sSql
                iRet += dbCmd.ExecuteNonQuery()

            End If

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            If dbCn.State = ConnectionState.Open Then
                dbTran.Dispose() : dbTran = Nothing
                dbCn.Close()
            End If
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransSpcInfo_UPD_UE(ByVal rsSpcCd As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUeDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransSpcInfo_UPD_UE() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim bITF_yn As Boolean = False
            Dim dt As New DataTable

            'LF030M : 검체 마스터
            '   LF030H Insert
            sSql = ""
            sSql += "INSERT INTO lf030h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip,  f.* FROM lf030m f"
            sSql += " WHERE spccd = :spccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF030M Update
            sSql = ""
            sSql += "UPDATE lf030m SET"
            sSql += "       uedt  = :uedt,"
            sSql += "       regdt = fn_ack_sysdate,"
            sSql += "       regid = :regid"
            sSql += " WHERE spccd = :spccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If bITF_yn Then
                sSql = ""
                sSql += "UPDATE fkitf..itf_lis_lf030m SET"
                sSql += "       uedt  = :uedt,"
                sSql += "       regdt = fn_ack_sysdate,"
                sSql += "       regid = :regid"
                sSql += " WHERE spccd = :spccd"
                sSql += "   AND usdt  = :usdt"

                dbCmd.Parameters.Clear()
                dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDtNew
                dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
                dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
            End If

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransSpcInfo_UPD_US(ByVal rsSpcCd As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUsDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransSpcInfo_UPD_US() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim bITF_yn As Boolean = False
            Dim dt As New DataTable

            'LF030M : 검체 마스터
            '   LF030H Insert
            sSql = ""
            sSql += "INSERT INTO lf030h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf030m f"
            sSql += " WHERE spccd = :spccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF030M Update
            sSql = ""
            sSql += "UPDATE lf030m SET"
            sSql += "       usdt  = :usdtchg,"
            sSql += "       regdt = fn_ack_sysdate,"
            sSql += "       regid = :regid"
            sSql += " WHERE spccd = :spccd"
            sSql += "   AND usdt  = :usdt"
            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("usdtchg",  OracleDbType.Varchar2).Value = rsUsDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If bITF_yn Then
                sSql = ""
                sSql += "UPDATE fkitf..itf_lis_lf030m SET"
                sSql += "       usdt  = :usdtchg,"
                sSql += "       regdt = fn_ack_sysdate,"
                sSql += "       regid = :regid"
                sSql += " WHERE spccd = :spccd"
                sSql += "   AND usdt  = :usdt"
                dbCmd.Parameters.Clear()
                dbCmd.Parameters.Add("usdtchg",  OracleDbType.Varchar2).Value = rsUsDtNew
                dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
                dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                dbCmd.CommandText = sSql
                iRet += dbCmd.ExecuteNonQuery()
            End If

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function


End Class

Public Class APP_F_SPCGRP
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_SPCGRP" & vbTab

    Public Function GetSpcGrpInfo(ByVal iMode As Integer, ByVal asSerch As String, ByVal asNull As String) As DataTable
        Dim sFn As String = "Public Function GetWkGrpInfo(ByVal iMode As Integer) As DataTable"

        Try
            Dim sSql As String = ""

            If iMode = 0 Then
                sSql += "SELECT DISTINCT spcgrpcd, spcgrpnmd, usdt, uedt"
                sSql += "  FROM lf031m"
                If asSerch <> "" Then
                    sSql += " WHERE '" & asSerch & "'"
                    sSql += "   AND uedt >= fn_ack_sysdate"
                End If
                sSql += " ORDER BY spcgrpcd"
            ElseIf iMode = 1 Then
                sSql += "SELECT DISTINCT spcgrpcd, spcgrpnmd, usdt, uedt,"
                sSql += "       CASE WHEN TO_DATE(uedt, 'yyyymmddhh24miss') - SYSDATE < 0 THEN -1 ELSE 0 END diffday"
                sSql += "  FROM lf031m"
                If asSerch <> "" Then
                    sSql += " WHERE '" & asSerch & "'"
                    sSql += "   AND uedt >= fn_ack_sysdate"
                End If
                sSql += " ORDER BY spcgrpcd"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetSpcGrpInfo(ByVal asSpcGrpCd As String) As DataTable
        Dim sFn As String = "Public Function GetWkGrpInfo(ByVal iMode As Integer, ByVal asWkGrpID As String, ByVal asUSDT As String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT DISTINCT"
            sSql += "       spcgrpcd, spcgrpnm, spcgrpnms, spcgrpnmd, spcgrpnmp,"
            sSql += "       fn_ack_date_str(usdt, 'yyyy-mm-dd hh24:mi:ss') usdt,"
            sSql += "       fn_ack_date_str(uedt, 'yyyy-mm-dd hh24:mi:ss') uedt,"
            sSql += "       fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid"
            sSql += "  FROM lf031m "
            sSql += " WHERE spcgrpcd = '" & asSpcGrpCd & "' "

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetSpcGrpSpcInfo(ByVal asSpcGrpCd As String) As DataTable
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""

            sSql += "SELECT DISTINCT"
            sSql += "       f31.chk, f30.spccd, f30.spcnmd"
            sSql += "  FROM (SELECT spccd, spcnmd"
            sSql += "	      FROM lf030m"
            sSql += "	     WHERE uedt >  fn_ack_sysdate"
            sSql += "       ) f30 LEFT OUTER JOIN"
            sSql += "       (SELECT DISTINCT '1' chk, f31.spccd"
            sSql += "		   FROM lf030m f30, lf031m f31"
            sSql += "	      WHERE f30.spccd = f31.spccd"
            sSql += "		    AND f30.usdt <= fn_ack_sysdate"
            sSql += "	        AND f30.uedt >  fn_ack_sysdate"
            sSql += "		    AND f31.spcgrpcd = '" & asSpcGrpCd & "'"
            sSql += "       ) f31 ON (f30.spccd = f31.spccd)"
            sSql += " ORDER BY f30.spccd"

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetRecentSpcGrpInfo(ByVal asWkGrpCd As String) As DataTable
        Dim sFn As String = "Public Function GetRecentSpcInfo(ByVal asSpcCd As String, ByVal asUSDT As String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT DISTINCT spcgrpcd"
            sSql += "  FROM lf031m"
            sSql += " WHERE spcgrpcd = '" + asWkGrpCd + "'"

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Fn.log(msFile & sFn, Err)
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function TransSpcGrpInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                  ByVal asSpcGrpCd As String, ByVal asRegID As String) As Boolean
        Dim sFn As String = "Public Function TransWkGrpInfo() As Boolean"

        Try
            Dim sSql As String = ""
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""
            Dim alTest As New ArrayList

            'LF032M : 작업그룹 마스터
            SELECT Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = "'" + CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value + "'"
                                sValues += sValue + ","
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf031m (" + sFields + ") VALUES (" + sValues + ")"

                            alTest.Add(sSql)
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF032H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf031h SELECT fn_ack_sysdate, f.* FROM lf031m f"
                        sSql += " WHERE spcgrpcd = '" + asSpcGrpCd + "'"
                     
                        alTest.Add(sSql)

                        sSql = ""
                        sSql += "DELETE lf031m"
                        sSql += " WHERE spcgrpcd = '" + asSpcGrpCd + "'"

                        alTest.Add(sSql)

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = "'" + CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value + "'"
                                sValues += sValue + ","
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf031m (" + sFields + ") VALUES (" + sValues + ")"

                            alTest.Add(sSql)
                        Next
                    End With
            End Select

            If LISAPP.APP_DB.DBSql.ExcuteSql(alTest) = False Then
                Return False
            End If

            Return True
        Catch ex As Exception
            Fn.log(msFile & sFn, Err)
            MsgBox(msFile & sFn & vbCrLf & ex.Message)
            Return False
        End Try
    End Function

    Public Function TransSpcGrpInfo_UE(ByVal asSpcGrpCd As String, ByVal asUSDT As String, ByVal asRegID As String) As Boolean
        Dim sFn As String = " Public Function TransWkGrpInfo_UE(ByVal asWkGrpCd As String, ByVal asUSDT As String, ByVal asRegID As String) As Boolean"

        Try
            Dim sSql As String = ""
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = "", sMsg As String = ""
            Dim alTest As New ArrayList

            'LF031M : 검체그룹 마스터
            '   LF032H Insert
            sSql += "INSERT INTO lf031h SELECT fn_ack_sysdate, f.* FROM lf032m f"
            sSql += " WHERE spcgrpcd = '" + asSpcGrpCd + "'"
            alTest.Add(sSql)

            '   LF031M Delete
            sSql = ""
            sSql += "DELETE lf031m"
            sSql += " WHERE spcgrpcd = '" + asSpcGrpCd + "'"
            alTest.Add(sSql)

            If LISAPP.APP_DB.DBSql.ExcuteSql(alTest) = False Then
                Return False
            End If

            Return True
        Catch ex As Exception
           Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Sub New()

    End Sub
End Class

Public Class APP_F_TEST
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_TEST" & vbTab

    '균 코드
    Public Function fnGetBaccdList() As DataTable
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT baccd , bacnm  "
            sSql += "  FROM LF210m "
            sSql += " WHERE usdt <= fn_ack_sysdate  "
            sSql += "   AND uedt > fn_ack_sysdate  "
            sSql += " ORDER BY baccd "

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    '병원체 코드
    Public Function fnGetTestnm(ByVal rsTestcd As String) As string
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList
            Dim sRet As String = ""

            sSql = ""
            sSql += "SELECT distinct tnm "
            sSql += "  FROM LF060m "
            sSql += " WHERE testcd  = :testcd "

            al.Add(New OracleParameter("testcd", OracleDbType.Varchar2, rsTestcd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestcd))

            DbCommand()
            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            If dt.Rows.Count > 0 Then
                sRet = dt.Rows(0).Item("tnm").ToString
            End If

            Return sRet

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function


    '병원체 코드
    Public Function fnGetHospiRefTestList() As DataTable
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT refcd , refnm , testcd "
            sSql += "  FROM LF510m "
            sSql += " WHERE gbn = 'T' "
            sSql += " ORDER BY refcd  "

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function
    '병원체 코드
    Public Function fnGetHospiRefList() As DataTable
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT refcd , refnm , refnmd , seq , groupcd "
            sSql += "  FROM LF510m "
            sSql += " WHERE gbn = 'H' "
            sSql += " ORDER BY groupcd, refcd ,seq "

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function
    '병원체 검체 
    Public Function fnGetBacRefcdList() As DataTable
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT distinct h.refcd , h.refnm , f.baccd , f.bacnm  " + vbCrLf
            sSql += "  FROM LF510m h, lf210m f" + vbCrLf
            sSql += " WHERE h.gbn = 'H' " + vbCrLf
            sSql += "   AND h.baccd is not null " + vbCrLf
            sSql += "   AND h.baccd = f.baccd " + vbCrLf
            sSql += "   AND f.usdt <= fn_ack_sysdate " + vbCrLf
            sSql += "   AND f.uedt >= fn_ack_sysdate " + vbCrLf
            sSql += " ORDER BY refcd " + vbCrLf

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    '병원체 검체 
    Public Function fnGetTestRefcdList() As DataTable
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT distinct h.refcd , h.refnm , h.testcd , f.tnm  " + vbCrLf
            sSql += "  FROM LF510m h, lf060m f" + vbCrLf
            sSql += " WHERE h.gbn = 'H' " + vbCrLf
            sSql += "   AND h.testcd = f.testcd " + vbCrLf
            sSql += "   AND f.usdt <= fn_ack_sysdate " + vbCrLf
            sSql += "   AND f.uedt >= fn_ack_sysdate " + vbCrLf
            sSql += " ORDER BY refcd " + vbCrLf

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function
    '병원체 검체 
    Public Function fnGetHospiSpcList() As DataTable
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT refcd , refnm , spccd "
            sSql += "  FROM LF510m "
            sSql += " WHERE gbn = 'S' "
            sSql += " ORDER BY refcd "

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    '결과 예문
    Public Function fnGetHospiRstExList() As DataTable
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT refcd rstcd, refnm rstex"
            sSql += "  FROM LF510m "
            sSql += " WHERE gbn = 'R' "
            sSql += " ORDER BY refcd "

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function fnGetSpcnm(ByVal rsSpcnm As String) As String
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT spcnm"
            sSql += "  FROM lf030m "
            sSql += " where spccd = :spccd "

            al.Add(New OracleParameter("spccd", OracleDbType.Varchar2, rsSpcnm.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcnm))


            DbCommand()

            Dim dt As DataTable = DbExecuteQuery(sSql, al)

            Return dt.Rows(0).Item("spcnm").ToString

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function fnGetTnm(ByVal rsTnm As String) As DataTable
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql = ""
            sSql += "SELECT DISTINCT testcd, tnm, uedt"
            sSql += "  FROM ("
            sSql += "        SELECT testcd, tnm, uedt, '1' seq"
            sSql += "          FROM lf060m"
            sSql += "         WHERE UPPER(tnm) LIKE :tnm || '%'"
            sSql += "           AND uedt > fn_ack_sysdate"
            sSql += "         UNION  "
            sSql += "        SELECT testcd, tnm, uedt, '2' seq"
            sSql += "          FROM lf060m"
            sSql += "         WHERE UPPER(tnm) LIKE like '%' || :tnm || '%'"
            sSql += "           AND uedt > fn_ack_sysdate"
            sSql += "       )"
            sSql += " ORDER BY seq, testcd, uedt DESC "

            al.Add(New OracleParameter("tnm",  OracleDbType.Varchar2, rsTnm.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTnm))
            al.Add(New OracleParameter("tnm",  OracleDbType.Varchar2, rsTnm.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTnm))

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function fnGetHelpInfo(ByVal rsTestCd As String, ByVal rsSpcCd As String, _
                                  ByVal rsUsDt As String, ByRef r_dt_Ref As DataTable, _
                                  ByRef r_dt_DTest As DataTable, ByRef r_dt_RTest As DataTable) As DataTable
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList
            Dim dt As New DataTable

            sSql = ""
            sSql += "SELECT f6.tnm, f6.tnms, f6.tnmp, f6.tnmd, f6.tnmbp, f3.spcnm,"
            sSql += "       CASE WHEN f6.tcdgbn = 'P' THEN '[P] Parent' WHEN f6.tcdgbn = 'S' THEN '[S] Single'"
            sSql += "            WHEN f6.tcdgbn = 'C' THEN '[C] Child'  WHEN f6.tcdgbn = 'G' TH'EN [G] Group'"
            sSql += "            WHEN f6.tcdgbn = 'B' THEN '[B] Battery' "
            sSql += "       END tcdgbn,"
            sSql += "       f6.tordcd, f6.sugacd, f6.exlabyn, f6.exlabcd,"
            sSql += "       CASE WHEN SUBSTR(f6.exeday, 1, 1) = 'Y' THEN '1' ELSE '0' END exeday1,"
            sSql += "       CASE WHEN SUBSTR(f6.exeday, 2, 1) = 'Y' THEN '1' ELSE '0' END exeday2,"
            sSql += "       CASE WHEN SUBSTR(f6.exeday, 3, 1) = 'Y' THEN '1' ELSE '0' END exeday3,"
            sSql += "       CASE WHEN SUBSTR(f6.exeday, 4, 1) = 'Y' THEN '1' ELSE '0' END exeday4,"
            sSql += "       CASE WHEN SUBSTR(f6.exeday, 5, 1) = 'Y' THEN '1' ELSE '0' END exeday5,"
            sSql += "       CASE WHEN SUBSTR(f6.exeday, 6, 1) = 'Y' THEN '1' ELSE '0' END exeday6,"
            sSql += "       CASE WHEN SUBSTR(f6.exeday, 7, 1) = 'Y' THEN '1' ELSE '0' END exeday7,"
            sSql += "       f6.titleyn, f6.seqtyn, f6.seqtmi, f6.dispseqo, f6.dispseql, f6.rptyn, f6.tatyn, f6.prptmi, f6.frptmi,"
            sSql += "       '[' || f4.tubecd + '] ' ||  f4.tubenmd tubenm, '[' || f1.bcclscd || '] ' ||  f1.bcclsnmd bcclsnmd,"
            sSql += "       f6.cwarning, f6.owarning, f6.emergbn, f6.ctgbn, f6.poctyn, f6.ptgbn,"
            sSql += "       CASE WHEN NVL(f6.iogbn, '0') = '0' THEN '1'"
            sSql += "            ELSE CASE WHEN NVL(f6.iogbn, '0') = '1' THEN '1' ELSE '0' END"
            sSql += "       END iogbn0,"
            sSql += "       CASE WHEN NVL(f6.iogbn, '0') = '0' THEN '1'"
            sSql += "            ELSE CASE WHEN NVL(f6.iogbn, '0') = '2' THEN '1' ELSE '0' END"
            sSql += "       END iogbn1,"
            sSql += "       '[' || CASE WHEN NVL(f6.bccnt, '0') = 'A' THEN '2' WHEN NVL(f6.bccnt, '0') = 'B' THEN '2'"
            sSql += "                   ELSE f6.bccnt"
            sSql += "              END || ']' bccnt, f6.dspccd1, '[' || f6.dspccd1 || ']' dspcnm1_01,"
            sSql += "       f6.tordslip, '[' || f6.tordslip || ']' tordslip_01, f6.srecvlt, f6.rrptst, f6.fixrptusr, f6.fixrptyn,"
            sSql += "       '[' || f6.partcd || f6.slipcd || ']' slipcd2, f6.rptyn,"
            sSql += "       CASE WHEN NVL(f6.rsttype, '0') = '0' THEN '문자 + 숫자 혼합' ELSE '숫자만 허용' END rsttype,"
            sSql += "       f6.rstunit, CASE WHEN f6.rstllen = '-1' THEN '' ELSE rstllen END rstllen,"
            sSql += "       CASE WHEN f6.rstulen = '-1' THEN '' ELSE rstulen END rstulen,"
            sSql += "       CASE WHEN f6.refgbn = '0' THEN '없음' WHEN f6.refgbn = '1' THEN '문자' WHEN f6.refgbn = '2' THEN '숫자' END refgbn, f6.ordhide,"
            sSql += "       CASE WHEN f6.cutopt = '0' THEN '' WHEN f6.cutopt =  '1' THEN '올림' WHEN f6.cutopt = '2' THEN '반올림' WHEN f6.cutopt = '3' THEN '내림' END cutopt,"
            sSql += "       f6.descref, '[' || f6.panicgbn || ']' panicgbn, f6.panicl, f6.panich, '[' || f6.deltagbn || ']' deltagbn, f6.deltal, f6.deltah,"
            sSql += "       '[' || f6.criticalgbn || ']' criticalgbn, f6.criticall, f6.criticalh, '[' || f6.alertgbn || ']' alertgbn,"
            sSql += "       f6.alertl, f6.alerth, f6.deltaday, CASE WHEN NVL(f6.judgtype, '0') = '0' THEN '1' ELSE '0' END judgtype0,"
            sSql += "       CASE WHEN NVL(f6.judgtype, '0') = '1' THEN '1' ELSE '0' END judgtype1,"
            sSql += "       CASE WHEN LENGTH(NVL(f6.judgtype, '0')) = 6 THEN '1' ELSE '0' END judgtype2,"
            sSql += "       CASE WHEN LENGTH(NVL(f6.judgtype, '0')) = 9 THEN '1' ELSE '0' END judgtype3,"
            sSql += "       f6.ujudglt1, f6.ujudglt2, f6.ujudglt3,"
            sSql += "       CASE WHEN SUBSTR(f6.judgtype, 2, 1) = '1' THEN '[' ||SUBSTR(f6.judgtype, 3, 1) || ']' ELSE '[]' END judgtype11_01,"
            sSql += "       CASE WHEN SUBSTR(f6.judgtype, 5, 1) = '2' THEN '[' ||SUBSTR(f6.judgtype, 6, 1) || ']' ELSE '[]' END judgtype12_01,"
            sSql += " 	    CASE WHEN SUBSTR(f6.judgtype, 8, 1) = '3' THEN '[' ||SUBSTR(f6.judgtype, 9, 1) || ']' ELSE '[]' END judgtype13_01,"
            sSql += "       '[' || f6.alimitgbn || ']' alimitgbn, f6.alimitl, f6.alimith, '[' || f6.alimitls || ']' alimitls , '[' || f6.alimiths || ']' alimiths"
            sSql += "  FROM lf060m f6, lf030m f3, lf040m f4, lf020m f2, lf010m f1"
            sSql += " WHERE f6.testcd = :testcd"
            sSql += "   AND f6.spccd  = :spccd"
            sSql += "   AND f6.usdt   = :usdt"
            sSql += "   AND f6.spccd  = f3.spccd"
            sSql += "   AND f6.usdt  >= f3.usdt"
            sSql += "   AND f6.tubecd = f4.tubecd"
            sSql += "   AND f6.usdt  >= f4.usdt"
            sSql += "   AND f6.bcclscd = f1.bcclscd"
            sSql += "   AND f6.partcd  = f2.partcd"

            al.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
            al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            dt = DbExecuteQuery(sSql, al)

            If dt.Rows.Count > 0 Then
                al = New ArrayList

                sSql = ""
                sSql += "SELECT refseq,"
                sSql += "       CASE WHEN ageymd = 'D' THEN 'day' WHEN ageymd = 'M' THEN 'month' WHEN ageymd = 'Y' THEN 'year' END ageymd, sage,"
                sSql += "       CASE WHEN sages  = '0' THEN '<=' WHEN sages  = '1' THEN '<' END sages, eage,"
                sSql += "       CASE WHEN eages  = '0' THEN '<=' WHEN eages  = '1' THEN '<' END eages, reflm, refhm,"
                sSql += "       CASE WHEN reflms = '0' THEN '<=' WHEN reflms = '1' THEN '<' END reflms,"
                sSql += "       CASE WHEN refhms = '0' THEN '<=' WHEN refhms = '1' THEN '<' END refhms, reflf, refhf,"
                sSql += "       CASE WHEN reflfs = '0' THEN '<=' WHEN reflfs = '1' THEN '<' END reflfs,"
                sSql += "       DECODE(refhfs,'0','<=','1','<') refhfs, reflt"
                sSql += "  FROM lf061m"
                sSql += " WHERE testcd = :testcd"
                sSql += "   AND spccd  = :spccd"
                sSql += "   AND usdt   = :usdt"
                sSql += " ORDER BY refseq"

                al.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
                al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
                al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

                DbCommand()
                r_dt_Ref = DbExecuteQuery(sSql, al)


                al = New ArrayList

                sSql = ""
                sSql += "SELECT f62.testcd, f62.spccd, f60.tnmd, f60.uedt, dispseql"
                sSql += "  FROM lf062m f62, lf060m f60"
                sSql += " WHERE f62.tclscd = :testcd"
                sSql += "   AND f62.spccd  = :spccd"
                sSql += "   AND f62.testcd = f60.testcd"
                sSql += "   AND f62.spccd  = f60.spccd"
                sSql += "   AND f60.usdt   = :usdt"
                sSql += " ORDER BY dispseql"

                al.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
                al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
                al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

                DbCommand()
                r_dt_DTest = DbExecuteQuery(sSql, al)


                al = New ArrayList

                sSql = ""
                sSql += "SELECT f67.reftestcd testcd, f67.refspccd spccd, f60.tnmd, f60.uedt"
                sSql += "  FROM lf063m f67, lf060m f60"
                sSql += " WHERE f67.testcd    = :testcd"
                sSql += "   AND f67.spccd     = :spccd"
                sSql += "   AND f67.reftestcd = f60.testcd"
                sSql += "   AND f67.refspccd  = f60.spccd"
                sSql += "   AND f60.usdt      = :usdt"

                al.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
                al.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
                al.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

                DbCommand()
                r_dt_RTest = DbExecuteQuery(sSql, al)
            End If

            Return dt
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function TransTestInfo_DEL(ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsUsDt As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = " Public Function TransTestInfo_DEL() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim bITF_yn As Boolean = False
            Dim dt As New DataTable

            'LF060M : 검사마스터
            '   LF060H Insert
            sSql = ""
            sSql += "INSERT INTO lf060h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf060m f"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF060M Delete
            sSql = ""
            sSql += "DELETE lf060m"
            sSql += "  WHERE testcd = :testcd"
            sSql += "    AND spccd  = :spccd"
            sSql += "    AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            'LF061M : 참고치 마스터
            '   LF061H Insert
            sSql = ""
            sSql += "INSERT INTO lf061h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf061m f"
            sSql += "  WHERE testcd = :testcd"
            sSql += "    AND spccd  = :spccd"
            sSql += "    AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF061M Delete
            sSql = ""
            sSql += "DELETE lf061m"
            sSql += "  WHERE testcd = :testcd"
            sSql += "    AND spccd  = :spccd"
            sSql += "    AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            'LF062M : 세부검사마스터
            '   LF062H Insert
            sSql = ""
            sSql += "INSERT INTO lf062h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf062m f"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"
            sSql += "   AND (testcd, spccd) NOT IN"
            sSql += "       (SELECT testcd, spccd FROM lf060m"
            sSql += "         WHERE testcd = :testcd"
            sSql += "           AND spccd  = :spccd"
            sSql += "       )"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF062M Delete
            sSql = ""
            sSql += "DELETE lf062m"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"
            sSql += "   AND (testcd, spccd) NOT IN"
            sSql += "       (SELECT testcd, spccd FROM lf060m"
            sSql += "         WHERE testcd = :testcd"
            sSql += "           AND spccd  = :spccd"
            sSql += "       )"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()


            'LF063M : 참조검사마스터
            '   LF063H Insert
            sSql = ""
            sSql += "INSERT INTO lf063h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip,  f.* FROM lf063m f"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"
            sSql += "   AND (testcd, spccd) NOT IN"
            sSql += "       (SELECT testcd, spccd FROM lf060m"
            sSql += "         WHERE testcd = :testcd"
            sSql += "           AND spccd  = :spccd"
            sSql += "       )"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF063M Delete
            sSql = ""
            sSql += "DELETE lf063m"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"
            sSql += "   AND (testcd, spccd) NOT IN"
            sSql += "       (SELECT testcd, spccd FROM lf060m"
            sSql += "         WHERE testcd = :testcd"
            sSql += "           AND spccd  = :spccd"
            sSql += "       )"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransTestInfo_UPD_UE(ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUeDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransTestInfo_UPD_UE() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim bITF_yn As Boolean = False
            Dim dt As New DataTable

            'LF060M : 검사 마스터
            '   LF060H Insert
            sSql = ""
            sSql += "INSERT INTO lf060h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf060m f"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF060M Update
            sSql = ""
            sSql += "UPDATE lf060m SET"
            sSql += "       uedt   = :uedt,"
            sSql += "       regdt  = fn_ack_sysdate,"
            sSql += "       regid  = :regid"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If bITF_yn Then
                sSql = ""
                sSql += "UPDATE fkitf..itf_lis_lf060m SET"
                sSql += "       uedt   = :uedt,"
                sSql += "       regdt  = fn_ack_sysdate,"
                sSql += "       regid  = :regid"
                sSql += " WHERE testcd = :testcd"
                sSql += "   AND spccd  = :spccd"
                sSql += "   AND usdt   = :usdt"

                dbCmd.Parameters.Clear()
                dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDtNew
                dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
                dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                dbCmd.CommandText = sSql
                iRet += dbCmd.ExecuteNonQuery()
            End If

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()

            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransTestInfo_UPD_US(ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUsDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransTestInfo_UPD_US() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim bITF_yn As Boolean = False
            Dim dt As New DataTable

            'LF060M : 검사 마스터
            '   LF060H Insert
            sSql = ""
            sSql += "INSERT INTO lf060h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf060m f"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF060M Update
            sSql = ""
            sSql += "UPDATE lf060m SET"
            sSql += "       usdt   = :usdt,"
            sSql += "       regdt  = fn_ack_sysdate,"
            sSql += "       regid  = :regid"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If bITF_yn Then
                sSql = ""
                sSql += "UPDATE fkitf..itf_lis_lf060m SET"
                sSql += "       usdt   = :usdtchg,"
                sSql += "       regdt  = fn_ack_sysdate,"
                sSql += "       regid  = :regid"
                sSql += " WHERE testcd = :testcd"
                sSql += "   AND spccd  = :spccd"
                sSql += "   AND usdt   = :usdt"

                dbCmd.Parameters.Clear()
                dbCmd.Parameters.Add("usdtchg",  OracleDbType.Varchar2).Value = rsUsDtNew
                dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
                dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                dbCmd.CommandText = sSql
                iRet += dbCmd.ExecuteNonQuery()
            End If

            'LF061M : 참고치 마스터
            '   LF061H Insert
            sSql = ""
            sSql += "INSERT INTO lf061h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf061m f"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF061M Update
            sSql = ""
            sSql += "UPDATE lf061m SET"
            sSql += "       usdt   = :usdtchg,"
            sSql += "       regdt  = fn_ack_sysdate,"
            sSql += "       regid  = :regid"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("usdtchg",  OracleDbType.Varchar2).Value = rsUsDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function GetAgeRefInfo(ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetAgeRefInfo(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT CASE WHEN ageymd = 'D' THEN '0' WHEN ageymd = 'M' THEN '1' WHEN ageymd = 'Y' THEN '2' END ageymd,"
            sSql += "       sage, sages, eages, eage, reflm, reflms, refhms, refhm, reflf, reflfs, refhfs, refhf, reflt"
            sSql += "  FROM lf061m"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"
            sSql += "   AND usdt   = :usdt"
            sSql += " ORDER BY refseq"

            Dim alParm As New ArrayList
            alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            alParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function
    '<참조검사조회
    Public Function GetTestInfo_detail(ByVal rsTestCd As String, ByVal rsSpcCd As String) As DataTable
        Dim sFn As String = "Public Function GetTestInfo_detail(String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT a.testcd, a.spccd, a.tnmd, a.grprstyn, a.sort_key"
            sSql += "  FROM ("
            sSql += "        SELECT t.testcd, t.spccd, t.tnmd tnmd, d.grprstyn, t.usdt, t.uedt, t.dispseql sort_key"
            sSql += "          FROM lf062m d, lf060m t"
            sSql += "         WHERE d.testcd = t.testcd"
            sSql += "           AND d.spccd  = t.spccd"
            sSql += "           AND t.usdt     <= fn_ack_sysdate " '<<<20170414 참조검사 현재것만 조회 추가 
            sSql += "           AND t.uedt     >= fn_ack_sysdate "
            sSql += "           AND d.tclscd = :testcd"
            sSql += "           AND d.tspccd = :spccd"
            sSql += "       ) a,"
            sSql += "       ("
            sSql += "        SELECT t.testcd, t.spccd, MAX(t.usdt) usdt"
            sSql += "          FROM lf062m d, lf060m t"
            sSql += "         WHERE d.testcd = t.testcd"
            sSql += "           AND d.spccd  = t.spccd"
            sSql += "           AND t.usdt     <= fn_ack_sysdate " '<<<20170414 참조검사 현재것만 조회 추가 
            sSql += "           AND t.uedt     >= fn_ack_sysdate "
            sSql += "           AND d.tclscd = :testcd"
            sSql += "           AND d.tspccd = :spccd"
            sSql += "         GROUP BY t.testcd, t.spccd"
            sSql += "       ) b"
            sSql += " WHERE a.testcd = b.testcd"
            sSql += "   AND a.spccd  = b.spccd"
            sSql += "   AND a.usdt   = b.usdt"
            sSql += " ORDER BY sort_key"

            alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            alParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
            alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            alParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function
    '< 세부검사조회 
    Public Function GetTestInfo_ref(ByVal rsTestCd As String, ByVal rsSpcCd As String) As DataTable
        Dim sFn As String = "Public Function GetTestInfo_ref(String, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT DISTINCT reftestcd testcd, refspccd spccd, t.tnmd tnmd"
            sSql += "  FROM lf063m r, lf060m t"
            sSql += " WHERE r.reftestcd = t.testcd"
            sSql += "   AND r.refspccd  = t.spccd"
            sSql += "   AND t.usdt     <= fn_ack_sysdate " '<<<20170414 세부검사 현재것만 조회 추가 
            sSql += "   AND t.uedt     >= fn_ack_sysdate "
            sSql += "   AND r.testcd    = :testcd"
            sSql += "   AND r.spccd     = :spccd"
            sSql += " ORDER BY r.reftestcd, r.refspccd"

            Dim alParm As New ArrayList
            alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            alParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetTestInfo_info(ByVal rsTestCd As String, ByVal rsSpcCd As String) As DataTable
        Dim sFn As String = "Public Function GetTestInfo_ref(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT DISTINCT"
            sSql += "       infogbn, testinfo,"
            sSql += "       CASE WHEN spccd = '----' THEN 1 ELSE 2 END sort1"
            sSql += "  FROM lf064m"
            sSql += " WHERE testcd  = :testcd"
            sSql += "   AND spccd  IN ('----', :spccd)"
            sSql += " ORDER BY infogbn, sort1"

            Dim alParm As New ArrayList
            alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            alParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentTestInfo(ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetRecentTestInfo(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT usdt,partgbn"
            sSql += "  FROM (SELECT usdt,partgbn"
            sSql += "          FROM vw_ack_tot_test_info"
            sSql += "         WHERE testcd = :testcd"
            sSql += "           AND spccd  = :spccd"
            sSql += "           AND ((usdt   >= :usdt AND PARTGBN = '[진단검사실]') OR PARTGBN = '[핵의학검사실]')"
            sSql += "         ORDER BY usdt DESC"
            sSql += "       ) a"
            sSql += " WHERE ROWNUM = 1"

            Dim alParm As New ArrayList
            alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            alParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentTOrdCdInfo(ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsTOrdCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetRecentTOrdCdInfo(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT testspc"
            sSql += "  FROM (SELECT testcd || spccd testspc"
            sSql += "          FROM lf060m"
            sSql += "         WHERE tordcd  = :tordcd"
            sSql += "           AND testcd <> :testcd"
            sSql += "           AND uedt   >= :usdt"
            sSql += "         ORDER BY testspc DESC"
            sSql += "       ) a"
            sSql += " WHERE ROWNUM = 1"

            Dim alParm As New ArrayList
            alParm.Add(New OracleParameter("tordcd",  OracleDbType.Varchar2, rsTOrdCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTOrdCd))
            alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetTestInfo(ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetTestInfo(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT testcd, spccd, '['|| spccd || ']' spcnmd_01, tnm, tnms, tnmd, tnmp, tnmbp,"
            sSql += "       '[' || tcdgbn || ']' tcdgbn_01, titleyn, tordcd, tliscd, insugbn, sugacd, edicd,"
            sSql += "       CASE WHEN NVL(rptyn, '0') = '1' THEN '0' ELSE '1' END rptyn, dispseqo, dispseql, defrst,"
            sSql += "       SUBSTR(exeday, 1, 1) exeday1,"
            sSql += "       SUBSTR(exeday, 2, 1) exeday2,"
            sSql += "       SUBSTR(exeday, 3, 1) exeday3,"
            sSql += "       SUBSTR(exeday, 4, 1) exeday4,"
            sSql += "       SUBSTR(exeday, 5, 1) exeday5,"
            sSql += "       SUBSTR(exeday, 6, 1) exeday6,"
            sSql += "       SUBSTR(exeday, 7, 1) exeday7,"
            sSql += "       tatyn, prptmi, ':M' prptmi_01, frptmi, ':M' frptmi_01, perrptmi, ':M' perrptmi_01, ferrptmi, ':M' ferrptmi_01,"
            sSql += "       rrptst, srecvlt, cwarning,"
            sSql += "       tubecd, '[' || tubecd || ']' tubenmd_01, tubevol, tubeunit, minspcvol, exlabyn, exlabcd,"
            sSql += "       '[' || exlabcd || ']' exlabnmd_01, seqtyn, seqtmi, ctgbn, poctyn,"
            sSql += "       bcclscd, '[' || bcclscd || ']' bcclsnmd_01, slipcd2, '[' || slipcd2 || ']' slipnmd_01,"
            sSql += "       samecd, '[' || mbttype || ']' mbttype_01, '[' || bbttype || ']' bbttype_01, '[' || mgttype || ']' mgttype_01,"
            sSql += "       fn_ack_date_str(usdt, 'yyyy-mm-dd hh24:mi:ss') usdt, fn_ack_date_str(uedt, 'yyyy-mm-dd hh24:mi:ss') uedt,"
            sSql += "       fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid, fn_ack_get_usr_name(regid) regnm,"
            sSql += "       CASE WHEN NVL(rsttype, '0') = '0' THEN '1' ELSE '0' END rsttype0,"
            sSql += "       CASE WHEN NVL(rsttype, '0') = '1' THEN '1' ELSE '0' END rsttype1,"
            sSql += "       CASE WHEN NVL(cutopt, '0')  = '0' THEN '0' ELSE '1' END rstlen,"
            sSql += "       NVL(rstulen, -1) rstulen_01, NVL(rstllen, -1) rstllen_01,"
            sSql += "       CASE WHEN cutopt = '1' THEN '1' ELSE '0' END cutopt1,"
            sSql += "       CASE WHEN cutopt = '2' THEN '1' ELSE '0' END cutopt2,"
            sSql += "       CASE WHEN cutopt = '3' THEN '1' ELSE '0' END cutopt3,"
            sSql += "       CASE WHEN NVL(refgbn, '0') = '0' THEN '1' ELSE '0' END refgbn0,"
            sSql += "       CASE WHEN NVL(refgbn, '0') = '1' THEN '1' ELSE '0' END refgbn1,"
            sSql += "       CASE WHEN NVL(refgbn, '0') = '2' THEN '1' ELSE '0' END refgbn2,"
            sSql += "       rstunit, descref, CASE WHEN NVL(judgtype, '0') = '0' THEN '1' ELSE '0' END judgtype0,"
            sSql += "       CASE WHEN NVL(judgtype, '0') = '1' THEN '1' ELSE '0' END judgtype1,"
            sSql += "       CASE WHEN LENGTH(NVL(judgtype, '0')) = 6 THEN '1' ELSE '0' END judgtype2,"
            sSql += "       CASE WHEN LENGTH(NVL(judgtype, '0')) = 9 THEN '1' ELSE '0' END judgtype3,"
            sSql += "       ujudglt1, ujudglt2, ujudglt3,"
            sSql += "       CASE WHEN SUBSTR(judgtype, 2, 1) = '1' THEN '[' || SUBSTR(judgtype, 3, 1) || ']' ELSE '[]' END judgtype11_01,"
            sSql += "       CASE WHEN SUBSTR(judgtype, 5, 1) = '2' THEN '[' || SUBSTR(judgtype, 6, 1) || ']' ELSE '[]' END judgtype12_01,"
            sSql += " 	    CASE WHEN SUBSTR(judgtype, 8, 1) = '3' THEN '[' || SUBSTR(judgtype, 9, 1) || ']' ELSE '[]' END judgtype13_01,"
            sSql += "       '[' || panicgbn || ']' panicgbn_01, '[' ||criticalgbn || ']' criticalgbn_01,"
            sSql += " 	    '[' || alertgbn || ']' alertgbn_01, '[' ||deltagbn || ']' deltagbn_01,"
            sSql += "       panicl, panich, criticall, criticalh, alertl, alerth, deltaday, deltal, deltah,"
            sSql += "       '[' || alimitgbn || ']' alimitgbn_01, alimitl, '[' || alimitls || ']' alimitls_01, alimith, '[' || alimiths || ']' alimiths_01,"
            sSql += "       reqsub, tordslip, '[' || tordslip || ']' tordslip_01, ptgbn,"
            sSql += "       CASE WHEN NVL(iogbn, '0') = '0' THEN '1' ELSE CASE WHEN NVL(iogbn, '0') = '1' THEN '1' ELSE '0' END END iogbn0,"
            sSql += "       CASE WHEN NVL(iogbn, '0') = '0' THEN '1' ELSE CASE WHEN NVL(iogbn, '0') = '2' THEN '1' ELSE '0' END END iogbn1,"
            sSql += "       CASE WHEN emergbn IN ('1', '3') THEN '1' ELSE '' END ergbn1,"
            sSql += "       CASE WHEN emergbn IN ('2', '3') THEN '1' ELSE '' END ergbn2,"
            sSql += "       fixrptyn, '[' || fixrptusr || ']' fixrptusr_01, dspccd1, '[' || dspccd1 || ']' dspcnm1_01, dspccd2, '[' || dspccd2 || ']' dspcnm2_01,"
            sSql += "       ordhide, '[' || owarninggbn || ']' owarninggbn_01, owarning,"
            sSql += "       SUBSTR(oreqitem, 1, 1) oreqitem1,"
            sSql += "       SUBSTR(oreqitem, 2, 1) oreqitem2,"
            sSql += "       SUBSTR(oreqitem, 3, 1) oreqitem3,"
            sSql += "       SUBSTR(oreqitem, 4, 1) oreqitem4,"
            sSql += "       viwsub, '[' || bccnt || ']' bccnt_01, bconeyn, grprstyn,"
            sSql += "       '['|| cprtgbn ||']' cprtgbn_01,"
            sSql += "       '['|| dbltseq || dbltord ||']' bldgbn_01,"
            sSql += "       signrptyn,"
            sSql += "       cprtcd,fwgbn , cwgbn "
            sSql += "  FROM vw_ack_lis_test_info"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"
            sSql += "   AND usdt   = :usdt"

            Dim alParm As New ArrayList
            alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            alParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetTestInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetTestInfo(Integer, String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT DISTINCT"
                sSql += "       RPAD(testcd, 8, ' ') || spccd tcd, tnmd, spcnmd, '[' || tubecd || '] ' || tubenmd tubenmd,"
                sSql += "       tcdgbn, '[' || tordslip || '] ' || tordslipnm || '(' || LPAD(NVL(dispseqo, '0'), 3, '0') || ')' tordslipnm,"
                sSql += "       CASE WHEN ordhide = '1' THEN 'X' ELSE '' END ordhide, tordcd, sugacd, dspccd1, tliscd,"
                sSql += "       '[' || bcclscd || '] ' || bcclsnmd bcclsnmd, '[' || slipcd2 || '] ' || slipnmd slipnmd,"
                sSql += "       CASE WHEN NVL(exlabyn, '0') = '0' THEN '' ELSE '[' || exlabcd || '] '|| exlabnmd END exlabnmd, titleyn,"
                sSql += "       fn_ack_date_str(usdt, 'yyyy-mm-dd hh24:mi:ss') usdt, uedt, bcclscd, tordslip, slipcd, testcd, spccd,"
                sSql += "       dispseql, dispseqo, 0 diffday"
                sSql += "  FROM vw_ack_lis_test_info"
                sSql += " WHERE uedt >= fn_ack_sysdate"
                If rsSerch <> "" Then
                    sSql += "   AND  " + rsSerch + ""
                End If

                sSql += " ORDER BY testcd, spccd, usdt"
            ElseIf riMode = 1 Then
                sSql += "SELECT DISTINCT"
                sSql += "       RPAD(testcd, 8, ' ') || spccd tcd, tnmd, spcnmd, '[' || tubecd || '] ' ||  tubenmd tubenmd,"
                sSql += "       tcdgbn, '[' || tordslip || '] ' ||  tordslipnm || '(' || LPAD(NVL(dispseqo, '0'), 3, '0') || ')' tordslipnm,"
                sSql += "       CASE WHEN ordhide = '1' THEN 'X' ELSE '' END ordhide, tordcd, sugacd, dspccd1, tliscd,"
                sSql += "       '[' || bcclscd || '] ' ||  bcclsnmd bcclsnmd, '[' || slipcd2 || '] ' ||  slipnmd slipnmd,"
                sSql += "       CASE WHEN NVL(exlabyn, '0') = '0' THEN '' ELSE '[' || exlabcd || '] '|| exlabnmd END exlabnmd, titleyn,"
                sSql += "       fn_ack_date_str(usdt, 'yyyy-mm-dd hh24:mi:ss') usdt, uedt, bcclscd, tordslip, slipcd, testcd, spccd,"
                sSql += "       dispseql, dispseqo,"
                sSql += "       CASE WHEN TO_DATE(uedt, 'yyyymmddhh24miss') - SYSDATE < 0 THEN -1 ELSE 0 END diffday"
                sSql += "  FROM vw_ack_lis_test_info "
                If rsSerch <> "" Then
                    sSql += " WHERE  " + rsSerch + ""
                End If

                sSql += " ORDER BY testcd, spccd, usdt"

            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetTestInfo_NotSpc(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetTestInfo_Exact(ByVal iMode As Integer) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT DISTINCT"
                sSql += "       RPAD(testcd, 8, ' ')  tcd, tnmd, '' spcnmd, '' tubenmd,"
                sSql += "       tcdgbn, '[' || tordslip || '] ' || tordslipnm || '(' || LPAD(NVL(dispseqo, '0'), 3, '0') || ')' tordslipnm,"
                sSql += "       CASE WHEN ordhide = '1' THEN 'X' ELSE '' END ordhide, tordcd, sugacd, '' dspccd1, tliscd,"
                sSql += "       '[' || bcclscd || '] ' || bcclsnmd bcclsnmd, '[' || slipcd2 || '] ' || slipnmd slipnmd,"
                sSql += "       '' exlabnmd, '' titleyn,"
                sSql += "       fn_ack_date_str(usdt, 'yyyy-mm-dd hh24:mi:ss') usdt, uedt, bcclscd, tordslip, slipcd, testcd, '' spccd,"
                sSql += "       dispseql, dispseqo, 0 diffday"
                sSql += "  FROM vw_ack_lis_test_info "
                sSql += " WHERE uedt >= fn_ack_sysdate"
                If rsSerch <> "" Then
                    sSql += "   AND  " + rsSerch + ""
                End If

                sSql += " ORDER BY testcd, usdt"
            ElseIf riMode = 1 Then
                sSql += "SELECT DISTINCT "
                sSql += "       RPAD(testcd, 8, ' ')  tcd, tnmd, '' spcnmd, '' tubenmd,"
                sSql += "       tcdgbn, '[' || tordslip || '] ' ||  tordslipnm || '(' || LPAD(NVL(dispseqo, '0'), 3, '0') || ')' tordslipnm,"
                sSql += "       CASE WHEN ordhide = '1' THEN 'X' ELSE '' END ordhide, tordcd, sugacd, '' dspccd1, tliscd,"
                sSql += "       '['|| bcclscd || '] ' || bcclsnmd bcclsnmd, '[' || slipcd2 || '] ' || slipnmd slipnmd,"
                sSql += "       '' exlabnmd, '' titleyn,"
                sSql += "       fn_ack_date_str(usdt, 'yyyy-mm-dd hh24:mi:ss') usdt, uedt, bcclscd, tordslip, slipcd, testcd, '' spccd,"
                sSql += "       dispseql, dispseqo,"
                sSql += "       CASE WHEN TO_DATE(uedt, 'yyyymmddhh24miss') - SYSDATE < 0 THEN -1 ELSE 0 END diffday"
                sSql += "  FROM vw_ack_lis_test_info "
                If rsSerch <> "" Then
                    sSql += " WHERE  " + rsSerch + ""
                End If

                sSql += " ORDER BY testcd, usdt"

            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    '병원체코드 등록 

    Public Function fnRegList(ByVal rsMode As String, ByVal rsRefcd As String, ByVal rsRefnm As String, ByVal rsRefnmd As String, ByVal rsSeq As String, ByVal rsGroupcd As String) As Boolean

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            Dim iret As Integer = 0

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text

                Dim sSql As String = ""
                '수정
                If rsMode = "0" Then

                    sSql += "UPDATE lf510m "
                    sSql += " SET refnm = :refnm , refnmd = :refnmd , seq  = :seq , groupcd = :groupcd"
                    sSql += " WHERE gbn = 'H' "
                    sSql += "   AND refcd = :refcd"
                    sSql += " "


                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("refnm", OracleDbType.Varchar2).Value = rsRefnm
                    dbCmd.Parameters.Add("refnmd", OracleDbType.Varchar2).Value = rsRefnmd
                    dbCmd.Parameters.Add("seq", OracleDbType.Varchar2).Value = rsSeq
                    dbCmd.Parameters.Add("groupcd", OracleDbType.Varchar2).Value = rsGroupcd
                    dbCmd.Parameters.Add("refcd", OracleDbType.Varchar2).Value = rsRefcd

                    dbCmd.CommandText = sSql
                    iret += dbCmd.ExecuteNonQuery()
                    '신규
                ElseIf rsMode = "1" Then

                    sSql += "INSERT INTO lf510m ( refcd , refnm , refnmd , groupcd , seq ,regdt          , regid,baccd, useyn,gbn, spccd)"
                    sSql += "            values (:refcd ,:refnm ,:refnmd ,:groupcd ,:seq ,fn_ack_sysdate ,:regid,   '',   'Y','H', '')"

                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("refcd", OracleDbType.Varchar2).Value = rsRefcd
                    dbCmd.Parameters.Add("refnm", OracleDbType.Varchar2).Value = rsRefnm
                    dbCmd.Parameters.Add("refnmd", OracleDbType.Varchar2).Value = rsRefnmd
                    dbCmd.Parameters.Add("groupcd", OracleDbType.Varchar2).Value = rsGroupcd
                    dbCmd.Parameters.Add("seq", OracleDbType.Varchar2).Value = rsSeq
                    dbCmd.Parameters.Add("regid", OracleDbType.Varchar2).Value = USER_INFO.USRID


                    dbCmd.CommandText = sSql
                    iret += dbCmd.ExecuteNonQuery()

                End If

                If iret > 0 Then
                    dbTran.Commit()
                End If

                Return True

            End With

        Catch ex As Exception

            dbTran.Rollback()
            Return False
            Throw (New Exception(ex.Message + " @" + msFile + "fnRegSpcList() ", ex))
        End Try

    End Function

    '병원체코드 삭제(종료)

    Public Function fnDelRefCd(ByVal rsRefcd As String) As Boolean

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            Dim iret As Integer = 0

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text

                Dim sSql As String = ""
                '삭제


                sSql += "DELETE lf510m "
                sSql += " WHERE gbn = 'H' "  'H : 병원체코드 
                sSql += "   AND refcd = :refcd"


                dbCmd.Parameters.Clear()
                dbCmd.Parameters.Add("refcd", OracleDbType.Varchar2).Value = rsRefcd

                dbCmd.CommandText = sSql
                iret += dbCmd.ExecuteNonQuery()

                If iret > 0 Then
                    dbTran.Commit()
                End If

                Return True

            End With

        Catch ex As Exception

            dbTran.Rollback()
            Return False
            Throw (New Exception(ex.Message + " @" + msFile + "fnDelRefCd() ", ex))
        End Try

    End Function


    '병원체코드 삭제(종료)

    Public Function fnDelRefCd(ByVal rsRefcd As String, ByVal rsGbn As String) As Boolean

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            Dim iret As Integer = 0

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text

                Dim sSql As String = ""
                '삭제
                If rsGbn = "T" Then

                    sSql += "update lf510m "
                    sSql += "  set testcd = '' "
                    sSql += " WHERE gbn = 'H' "  'H : 병원체코드 ,'S: 검체종류 , 'T :검사별병원체코드 , R :결과예문
                    sSql += "   AND refcd = :refcd"


                    dbCmd.Parameters.Clear()
                    ' dbCmd.Parameters.Add("gbn", OracleDbType.Varchar2).Value = rsGbn
                    dbCmd.Parameters.Add("refcd", OracleDbType.Varchar2).Value = rsRefcd

                ElseIf rsGbn = "B" Then
                    sSql += "update lf510m "
                    sSql += "  set baccd = '' "
                    sSql += " WHERE gbn = 'H' "
                    sSql += "   AND refcd = :refcd"


                    dbCmd.Parameters.Clear()
                    'dbCmd.Parameters.Add("gbn", OracleDbType.Varchar2).Value = rsGbn
                    dbCmd.Parameters.Add("refcd", OracleDbType.Varchar2).Value = rsRefcd
                Else
                    sSql += "DELETE lf510m "
                    sSql += " WHERE gbn = :gbn "  'H : 병원체코드 ,'S: 검체종류 , 'T :검사별병원체코드 , R :결과예문
                    sSql += "   AND refcd = :refcd"


                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("gbn", OracleDbType.Varchar2).Value = rsGbn
                    dbCmd.Parameters.Add("refcd", OracleDbType.Varchar2).Value = rsRefcd
                End If

              

                dbCmd.CommandText = sSql
                iret += dbCmd.ExecuteNonQuery()

                If iret > 0 Then
                    dbTran.Commit()
                End If

                Return True

            End With

        Catch ex As Exception

            dbTran.Rollback()
            Return False
            Throw (New Exception(ex.Message + " @" + msFile + "fnDelRefCd() ", ex))
        End Try

    End Function

    '검사항목별 병원체코드 등록 

    Public Function fnRegBacRefList(ByVal rsRefcd As String, ByVal rsBaccd As String) As Boolean

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            Dim iret As Integer = 0

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text

                Dim sSql As String = ""
                '수정


                sSql += "UPDATE lf510m "
                sSql += " SET baccd = :baccd "
                sSql += " WHERE gbn = 'H' "  'H : 병원체코드 
                sSql += "   AND refcd = :refcd"
                sSql += " "


                dbCmd.Parameters.Clear()
                dbCmd.Parameters.Add("baccd", OracleDbType.Varchar2).Value = rsBaccd
                dbCmd.Parameters.Add("refcd", OracleDbType.Varchar2).Value = rsRefcd

                dbCmd.CommandText = sSql
                iret += dbCmd.ExecuteNonQuery()
                '신규


                If iret > 0 Then
                    dbTran.Commit()
                End If

                Return True

            End With

        Catch ex As Exception

            dbTran.Rollback()
            Return False
            Throw (New Exception(ex.Message + " @" + msFile + "fnRegBacRefList() ", ex))
        End Try

    End Function

    '검사항목별 병원체코드 등록 

    Public Function fnRegTestRefList(ByVal rsMode As String, ByVal rsRefcd As String, ByVal rsRefnm As String, ByVal rsTestcd As String) As Boolean

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            Dim iret As Integer = 0

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text

                Dim sSql As String = ""
                '수정
                If rsMode = "0" Then

                    sSql += "UPDATE lf510m "
                    sSql += " SET testcd = :testcd "
                    sSql += " WHERE gbn = 'H' "  'H : 병원체코드 
                    sSql += "   AND refcd = :refcd"
                    sSql += " "


                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("testcd", OracleDbType.Varchar2).Value = rsTestcd
                    dbCmd.Parameters.Add("refcd", OracleDbType.Varchar2).Value = rsRefcd

                    dbCmd.CommandText = sSql
                    iret += dbCmd.ExecuteNonQuery()
                    '신규
               

                End If

                If iret > 0 Then
                    dbTran.Commit()
                End If

                Return True

            End With

        Catch ex As Exception

            dbTran.Rollback()
            Return False
            Throw (New Exception(ex.Message + " @" + msFile + "fnRegSpcList() ", ex))
        End Try

    End Function

    '검체등록
    Public Function fnRegSpcList(ByVal rsMode As String, ByVal rsSpccd As String, ByVal rsSpcnm As String, ByVal rsSpcList As String) As Boolean

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            Dim iret As Integer = 0

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text

                Dim sSql As String = ""
                '수정
                If rsMode = "0" Then

                    sSql += "UPDATE lf510m "
                    sSql += " SET refnm = :spcnm , spccd = :spclist"
                    sSql += " WHERE gbn = 'S' "
                    sSql += "   AND refcd = :spccd"
                    sSql += " "


                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("spcnm", OracleDbType.Varchar2).Value = rsSpcnm
                    dbCmd.Parameters.Add("spclist", OracleDbType.Varchar2).Value = rsSpcList
                    dbCmd.Parameters.Add("spccd", OracleDbType.Varchar2).Value = rsSpccd

                    dbCmd.CommandText = sSql
                    iret += dbCmd.ExecuteNonQuery()
                    '신규
                ElseIf rsMode = "1" Then

                    sSql += "INSERT INTO lf510m ( refcd , refnm , refnmd , groupcd ,seq ,regdt   , regid,baccd, useyn,gbn, spccd)"
                    sSql += "            values (:spccd ,:spcnm ,'-'     ,'-'      ,'-' ,sysdate ,:regid,   '',   'Y','S',:spclist)"

                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("spccd", OracleDbType.Varchar2).Value = rsSpccd
                    dbCmd.Parameters.Add("spcnm", OracleDbType.Varchar2).Value = rsSpcnm
                    dbCmd.Parameters.Add("regid", OracleDbType.Varchar2).Value = USER_INFO.USRID
                    dbCmd.Parameters.Add("spclist", OracleDbType.Varchar2).Value = rsSpcList


                    dbCmd.CommandText = sSql
                    iret += dbCmd.ExecuteNonQuery()

                End If

                If iret > 0 Then
                    dbTran.Commit()
                End If

                Return True

            End With

        Catch ex As Exception

            dbTran.Rollback()
            Return False
            Throw (New Exception(ex.Message + " @" + msFile + "fnRegSpcList() ", ex))
        End Try

    End Function
    'rj결과 예문 
    Public Function fnRegRefTestList(ByVal rsMode As String, ByVal rsRstcd As String, ByVal rsRstEx As String) As Boolean

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            Dim iret As Integer = 0

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text

                Dim sSql As String = ""
                '수정
                If rsMode = "0" Then

                    sSql += "UPDATE lf510m "
                    sSql += " SET refnm = :rstex "
                    sSql += " WHERE gbn = 'R' "
                    sSql += "   AND refcd = :rstcd"
                    sSql += " "


                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("rstex", OracleDbType.Varchar2).Value = rsRstEx
                    dbCmd.Parameters.Add("rstcd", OracleDbType.Varchar2).Value = rsRstcd


                    dbCmd.CommandText = sSql
                    iret += dbCmd.ExecuteNonQuery()
                    '신규
                ElseIf rsMode = "1" Then

                    sSql += "INSERT INTO lf510m ( refcd , refnm , refnmd , groupcd ,seq ,regdt   , regid,baccd, useyn,gbn, spccd)"
                    sSql += "            values (:rstcd ,:rstex ,'-'     ,'-'      ,'-' ,sysdate ,:regid,   '',   'Y','R','')"

                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("rstcd", OracleDbType.Varchar2).Value = rsRstcd
                    dbCmd.Parameters.Add("rstex", OracleDbType.Varchar2).Value = rsRstEx
                    dbCmd.Parameters.Add("regid", OracleDbType.Varchar2).Value = USER_INFO.USRID

                    dbCmd.CommandText = sSql
                    iret += dbCmd.ExecuteNonQuery()

                End If

                If iret > 0 Then
                    dbTran.Commit()
                End If

                Return True

            End With

        Catch ex As Exception

            dbTran.Rollback()
            Return False
            Throw (New Exception(ex.Message + " @" + msFile + "fnRegSpcList() ", ex))
        End Try

    End Function

    '결과 예문 
    Public Function fnRegRstExList(ByVal rsMode As String, ByVal rsRstcd As String, ByVal rsRstEx As String) As Boolean

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            Dim iret As Integer = 0

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text

                Dim sSql As String = ""
                '수정
                If rsMode = "0" Then

                    sSql += "UPDATE lf510m "
                    sSql += " SET refnm = :rstex "
                    sSql += " WHERE gbn = 'R' "
                    sSql += "   AND refcd = :rstcd"
                    sSql += " "


                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("rstex", OracleDbType.Varchar2).Value = rsRstEx
                    dbCmd.Parameters.Add("rstcd", OracleDbType.Varchar2).Value = rsRstcd


                    dbCmd.CommandText = sSql
                    iret += dbCmd.ExecuteNonQuery()
                    '신규
                ElseIf rsMode = "1" Then

                    sSql += "INSERT INTO lf510m ( refcd , refnm , refnmd , groupcd ,seq ,regdt   , regid,baccd, useyn,gbn, spccd)"
                    sSql += "            values (:rstcd ,:rstex ,'-'     ,'-'      ,'-' ,sysdate ,:regid,   '',   'Y','R','')"

                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("rstcd", OracleDbType.Varchar2).Value = rsRstcd
                    dbCmd.Parameters.Add("rstex", OracleDbType.Varchar2).Value = rsRstEx
                    dbCmd.Parameters.Add("regid", OracleDbType.Varchar2).Value = USER_INFO.USRID

                    dbCmd.CommandText = sSql
                    iret += dbCmd.ExecuteNonQuery()

                End If

                If iret > 0 Then
                    dbTran.Commit()
                End If

                Return True

            End With

        Catch ex As Exception

            dbTran.Rollback()
            Return False
            Throw (New Exception(ex.Message + " @" + msFile + "fnRegSpcList() ", ex))
        End Try

    End Function
    Public Function TransTestInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                  ByVal ro_Tcol2 As ItemTableCollection, ByVal riType2 As Integer, _
                                  ByVal ro_Tcol3 As ItemTableCollection, ByVal riType3 As Integer, _
                                  ByVal ro_Tcol4 As ItemTableCollection, ByVal riType4 As Integer, _
                                  ByVal ro_Tcol5 As ItemTableCollection, _
                                  ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsUsDt As String, _
                                  Optional ByVal rbExcelMode As Boolean = False) As Boolean
        Dim sFn As String = "Public Function TransTestInfo(ByVal ro_Tcol_060m As ItemTableCollection, ByVal ro_Tcol_061m As ItemTableCollection, ByVal ro_Tcol_062m As ItemTableCollection) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""
            Dim dt As New DataTable

            'LF060M : 검사마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        'UPDATE uedt of previous record
                        sSql = ""
                        sSql += "UPDATE lf060m SET uedt = :usdt"
                        sSql += " WHERE (testcd, spccd, usdt) IN"
                        sSql += "       (SELECT a.testcd, a.spccd, a.usdt"
                        sSql += "          FROM (SELECT testcd, spccd, usdt"
                        sSql += " 				   FROM lf060m"
                        sSql += " 				  WHERE testcd = :testcd"
                        sSql += " 					AND spccd  = :spccd"
                        sSql += " 					AND usdt   < :usdt"
                        sSql += " 					AND uedt   > :usdt"
                        sSql += " 		          ORDER BY usdt DESC"
                        sSql += "               ) a"
                        sSql += "         WHERE ROWNUM = 1"
                        sSql += " 		)"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                If sValue = "" Then
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = DBNull.Value
                                Else
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End If
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf060m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF060H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf060h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf060m f"
                        sSql += " WHERE testcd = :testcd"
                        sSql += "   AND spccd  = :spccd"
                        sSql += "   AND usdt   = :usdt"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value

                              
                                Select Case sField.ToUpper
                                    Case "TESTCD", "SPCCD", "USDT"
                                        'Case "CPRTGBN", "CPRTCD"
                                        '    sFields += sField + " =  '" + sValue + "',"
                                    Case Else
                                        sFields += sField + " =  :" + sField + ","

                                        If sValue = "" Then
                                            dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = DBNull.Value
                                        Else
                                            dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                        End If
                                End Select
                            Next

                            'UPDATE record
                            sFields = sFields.Substring(0, sFields.Length - 1)

                            sSql = ""
                            sSql += "UPDATE lf060m SET " + sFields
                            sSql += " WHERE testcd = :testcd"
                            sSql += "   AND spccd  = :spccd"
                            sSql += "   AND usdt   = :usdt"

                            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                        Next
                    End With
            End Select

            'LF061M : 참고치 마스터
            Select Case riType2
                Case 0      '----- 신규
                    With ro_Tcol2
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                If sValue = "" Then
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = DBNull.Value
                                Else
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End If
                            Next

                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf061m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    'LF061H Backup
                    sSql = ""
                    sSql += "INSERT INTO lf061h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf061m f"
                    sSql += " WHERE testcd = :testcd"
                    sSql += "   AND spccd  = :spccd"
                    sSql += "   AND usdt   = :usdt"

                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
                    dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                    dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                    dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                    dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                    dbCmd.CommandText = sSql
                    iRet += dbCmd.ExecuteNonQuery()

                    sSql = ""
                    sSql += "DELETE lf061m"
                    sSql += " WHERE testcd = :testcd"
                    sSql += "   AND spccd  = :spccd"
                    sSql += "   AND usdt   = :usdt"

                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                    dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                    dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                    dbCmd.CommandText = sSql
                    iRet += dbCmd.ExecuteNonQuery()

                    With ro_Tcol2
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""
                            Dim sTmp As String = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                sTmp += "'" + sValue + "',"

                                If sValue = "" Then
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = DBNull.Value
                                Else
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End If
                            Next

                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf061m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                        Next
                    End With
            End Select

            '< add freety 2006/07/26 : 신규시 기존 세부검사 존재할 경우의 오류 방지, 유의할점은 Battery 세부검사는 가장 최근것으로 적용됨
            'LF062M : 세부검사마스터
            Select Case riType3
                Case 0, 1      '----- 0 : 신규, 1 : 수정

                    If rbExcelMode = False Then
                        'LF062H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf062h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf062m f"
                        sSql += " WHERE tclscd = :testcd"
                        sSql += "   AND tspccd = :spccd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        sSql = ""
                        sSql += "DELETE lf062m"
                        sSql += " WHERE tclscd = :testcd"
                        sSql += "   AND tspccd = :spccd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                    End If

                    With ro_Tcol3
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)

                            sSql = "INSERT INTO lf062m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                        Next
                    End With
            End Select
            '>

            '< add freety 2006/07/26 : 신규시 기존 참조검사 존재할 경우의 오류 방지, 유의할점은 Battery 세부검사는 가장 최근것으로 적용됨
            'LF063M : 참조검사마스터
            Select Case riType4
                Case 0, 1     '----- 0 : 신규, 1 : 수정

                    If rbExcelMode = False Then
                        'LF063H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf063h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf063m f"
                        sSql += " WHERE testcd = :testcd"
                        sSql += "   AND spccd  = :spccd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        sSql = ""
                        sSql += "DELETE lf063m"
                        sSql += " WHERE testcd = :testcd"
                        sSql += "   AND spccd  = :spccd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                    End If

                    With ro_Tcol4
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)

                            sSql = "INSERT INTO lf063m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select
            '>

            If ro_Tcol5.ItemTableRowCount > 0 Then
                'LF063H Backup
                sSql = ""
                sSql += "INSERT INTO lf064h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf064m f"
                sSql += " WHERE testcd = :testcd"

                dbCmd.Parameters.Clear()
                dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
                dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd

                dbCmd.CommandText = sSql
                iRet += dbCmd.ExecuteNonQuery()

                sSql = ""
                sSql += "DELETE lf064m"
                sSql += " WHERE testcd = :testcd"
                sSql += "   AND spccd = :spccd" '<20160527 동일검체내용 삭제때문에 추가 

                dbCmd.Parameters.Clear()
                dbCmd.Parameters.Add("testcd", OracleDbType.Varchar2).Value = rsTestCd
                dbCmd.Parameters.Add("spccd", OracleDbType.Varchar2).Value = rsSpcCd

                dbCmd.CommandText = sSql
                iRet += dbCmd.ExecuteNonQuery()

                With ro_Tcol5
                    For i As Integer = 1 To .ItemTableRowCount
                        sField = "" : sFields = "" : sValue = "" : sValues = ""

                        dbCmd.Parameters.Clear()
                        For j As Integer = 1 To .ItemTableColCount
                            sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                            sFields += sField + ","

                            sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                            sValues += ":" + sField + ","

                            dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                        Next

                        sFields = sFields.Substring(0, sFields.Length - 1)
                        sValues = sValues.Substring(0, sValues.Length - 1)
                        sSql = "INSERT INTO lf064m (" + sFields + ") VALUES (" + sValues + ")"

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()
                    Next
                End With

            End If

            If iRet > 0 Then
                dbTran.Commit()

                '-- OCS 관련 수정
                With dbCmd
                    .CommandType = CommandType.StoredProcedure
                    .CommandText = "pro_ack_exe_ocs_test"

                    .Parameters.Clear()
                    .Parameters.Add(New OracleParameter("rs_testcd", rsTestCd))
                    .Parameters.Add(New OracleParameter("rs_spccd", rsSpcCd))
                    .Parameters.Add(New OracleParameter("rs_editid", USER_INFO.USRID))
                    .Parameters.Add(New OracleParameter("rs_editip", USER_INFO.LOCALIP))

                    .Parameters.Add("rs_errmsg",  OracleDbType.Varchar2, 4000)
                    .Parameters("rs_errmsg").Direction = ParameterDirection.InputOutput
                    .Parameters("rs_errmsg").Value = ""

                    .ExecuteNonQuery()

                    Dim sRetVal As String = .Parameters(4).Value.ToString

                    If sRetVal <> "00" Then
                        MsgBox(sRetVal.Substring(2))
                        Return False
                    End If
                End With

                Return True

            Else
                dbTran.Rollback()
                Return False
            End If


           


        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransTestInfo_UE(ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsUsDt As String, ByVal rsUeDt As String, ByVal rsRegId As String) As Boolean
        Dim sFn As String = "Public Function TransTestInfo_UE(ByVal asTClsCd As String, ByVal asSpcCd As String, ByVal asUSDT As String, ByVal asRegID As String) As Boolean"

        Dim dbCn As New OracleConnection
        Dim dbTran As OracleTransaction
        Dim dbCmd As New OracleCommand

        Try
            Dim sMsg As String = ""
            Dim arrRTblNm(0) As String

            arrRTblNm(0) = "LF060"

            sMsg = ifExistOtherUsableData("LF060M", "TESTCD", "SPCCD", rsTestCd, rsSpcCd, rsUsDt)

            If IsNothing(sMsg) Then
                MsgBox("쿼리문의 오류가 있습니다!!", MsgBoxStyle.Exclamation)
                Exit Function
            End If

            If Not sMsg = "" Then
                MsgBox(sMsg, MsgBoxStyle.Critical)
                Exit Function
            End If

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            dbCn = GetDbConnection()
            dbTran = dbCn.BeginTransaction()

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim bITF_yn As Boolean = False
            Dim dt As New DataTable

            'LF060M : 검사마스터
            '   LF060H Insert
            'LF060H Backup
            sSql = ""
            sSql += "INSERT INTO lf060h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf060m f"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF060M Update
            sSql = ""
            sSql += "UPDATE lf060m SET uedt = :uedt, regid = :regid"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND spccd  = :spccd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDt
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegId
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '-- OCS 관련 수정
            With dbCmd
                .CommandType = CommandType.StoredProcedure
                .CommandText = "pro_ack_exe_ocs_slexspct"

                .Parameters.Clear()
                .Parameters.Add(New OracleParameter("rs_testcd", rsTestCd))
                .Parameters.Add(New OracleParameter("rs_editid", USER_INFO.USRID))
                .Parameters.Add(New OracleParameter("rs_editip", USER_INFO.LOCALIP))

                .Parameters.Add("rs_errmsg",  OracleDbType.Varchar2, 4000)
                .Parameters("rs_errmsg").Direction = ParameterDirection.InputOutput
                .Parameters("rs_errmsg").Value = ""

                .ExecuteNonQuery()

                Dim sRetVal As String = .Parameters(3).Value.ToString

                If sRetVal <> "00" Then
                    dbTran.Rollback()
                    Throw (New Exception(sRetVal.Substring(2)))
                End If
            End With

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            If dbCn.State = ConnectionState.Open Then
                dbTran.Dispose() : dbTran = Nothing
                dbCn.Close()
            End If
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransTestInfo_DispseqlL(ByVal rsTestCd As String, ByVal rsDispSeq As String, ByVal rsUsrId As String) As Boolean
        Dim sFn As String = "Public Function TransTestInfo_DispseqlL(ByVal asTClsCd As String, ByVal asSpcCd As String, ByVal asUSDT As String, ByVal asRegID As String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            sSql = ""
            sSql += "UPDATE lf060m SET dispseql = :dispseql"
            sSql += " WHERE testcd = :testcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("dispseql",  OracleDbType.Varchar2).Value = rsDispSeq
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransTestInfo_DispseqlO(ByVal rsTestCd As String, ByVal rsDispSeq As String, ByVal rsUsrId As String) As Boolean
        Dim sFn As String = "Public Function TransTestInfo_DispseqlL(ByVal asTClsCd As String, ByVal asSpcCd As String, ByVal asUSDT As String, ByVal asRegID As String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            sSql = ""
            sSql += "UPDATE lf060m SET dispseqo = :dispseqo"
            sSql += " WHERE testcd = :testcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("dispseqo", OracleDbType.Int32).Value = rsDispSeq
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function
End Class

Public Class APP_F_TGRP
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_TGRP" & vbTab

    Public Function GetTGrpInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetTGrpInfo(Integer, ByVal Serch As String, ByVal asNull As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql = ""
                sSql += "SELECT tgrpcd, tgrpnmd"
                sSql += "  FROM lf065m "
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " GROUP BY tgrpcd, tgrpnmd"

            ElseIf riMode = 1 Then
                sSql = ""
                sSql += "SELECT tgrpcd, tgrpnmd, NULL diffday, NULL moddt, NULL modid"
                sSql += "  FROM lf065m"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " GROUP BY tgrpcd, tgrpnmd"
                sSql += " UNION ALL "
                sSql += "SELECT tgrpcd, tgrpnmd, -1 diffday,"
                sSql += "       fn_ack_date_str(moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, modid"
                sSql += "  FROM lf065h"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " GROUP BY tgrpcd, tgrpnmd, moddt, modid"
                sSql += " ORDER BY tgrpcd, moddt, modid"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetTGrpInfo(ByVal rsTGrpCd As String) As DataTable
        Dim sFn As String = "Public Function GetTGrpInfo(Integer, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql = ""
            sSql += "SELECT DISTINCT"
            sSql += "       tgrpcd, tgrpnm, tgrpnms, tgrpnmd, tgrpnmbp,"
            sSql += "       fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid,"
            sSql += "       fn_ack_get_usr_name(regid) regnm,"
            sSql += "       NULL moddt, NULL modid "
            sSql += "  FROM lf065m"
            sSql += " WHERE tgrpcd = :tgrpcd"

            Dim alParm As New ArrayList
            alParm.Add(New OracleParameter("tgrpcd",  OracleDbType.Varchar2, rsTGrpCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTGrpCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alparm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetTGrpInfo(ByVal rsModDT As String, ByVal rsModID As String, ByVal rsTGrpCd As String) As DataTable
        Dim sFn As String = "Public Function GetTGrpInfo(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql = ""
            sSql += "SELECT DISTINCT"
            sSql += "       tgrpcd, tgrpnm, tgrpnms, tgrpnmd, tgrpnmbp,"
            sSql += "       fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid, fn_ack_get_usr_name(regid) regnm,"
            sSql += "	    fn_ack_date_str(moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, modid, fn_ack_get_usr_name(modid) modnm"
            sSql += "  FROM lf065h"
            sSql += " WHERE tgrpcd = :tgrpcd"
            sSql += "   AND moddt  = :moddt"
            sSql += "   AND modid  = :modid"

            Dim alParm As New ArrayList
            alParm.Add(New OracleParameter("tgrpcd",  OracleDbType.Varchar2, rsTGrpCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTGrpCd))
            alParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDT.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDT))
            alParm.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModID.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModID))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetTGrpInfo_Test(ByVal rsTGrpCd As String) As DataTable
        Dim sFn As String = "Public Function GetTGrpInfo_Test(String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT a.testcd, a.spccd, b.tnmd, b.partcd || b.slipcd partslip"
            sSql += "  FROM lf065m a,"
            sSql += "       ("
            sSql += "        SELECT testcd, spccd, tnmd, partcd, slipcd"
            sSql += "          FROM lf060m"
            sSql += "         WHERE usdt <= fn_ack_sysdate"
            sSql += "           AND uedt >  fn_ack_sysdate"
            sSql += "           AND tcdgbn <> 'G'"
            sSql += "       ) b"
            sSql += " WHERE a.testcd = b.testcd"
            sSql += "   AND a.spccd  = b.spccd"
            sSql += "   AND a.tgrpcd = :tgrpcd"

            Dim alParm As New ArrayList
            alParm.Add(New OracleParameter("tgrpcd",  OracleDbType.Varchar2, rsTGrpCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTGrpCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetTGrpInfo_Test(ByVal rsModDT As String, ByVal rsModID As String, ByVal rsTGrpCd As String) As DataTable
        Dim sFn As String = "Public Function GetTGrpInfo_Test(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT a.testcd, a.spccd, b.tnmd, b.partcd || b.slipcd partslip"
            sSql += "  FROM lf065h a,"
            sSql += "       ("
            sSql += "        SELECT testcd, spccd, tnmd, partcd, slipcd"
            sSql += "          FROM lf060m"
            sSql += "         WHERE usdt <= fn_ack_sysdate"
            sSql += "           AND uedt >  fn_ack_sysdate"
            sSql += "           AND tcdgbn <> 'G'"
            sSql += "       ) b"
            sSql += " WHERE a.testcd = b.testcd"
            sSql += "   AND a.spccd  = b.spccd"
            sSql += "   AND a.tgrpcd = :tgrpcd"
            sSql += "   AND a.moddt  = :moddt"
            sSql += "   AND a.modid  = :modid"

            Dim alParm As New ArrayList
            alParm.Add(New OracleParameter("tgrpcd",  OracleDbType.Varchar2, rsTGrpCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTGrpCd))
            alParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDT.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDT))
            alParm.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModID.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModID))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentTGrpInfo(ByVal rsTGrpCd As String) As DataTable
        Dim sFn As String = "Public Function GetRecentTGrpInfo(String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT tgrpcd"
            sSql += "  FROM lf065m"
            sSql += " WHERE tgrpcd = :tgrpcd"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("tgrpcd",  OracleDbType.Varchar2, rsTGrpCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTGrpCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransTGrpInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                    ByVal rsTGrpCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransTGrpInfo(ItemTableCollection, Integer, String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF065M : 검사그룹 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf065m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF065H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf065h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf065m f"
                        sSql += " WHERE tgrpcd = :tgrpcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("tgrpcd",  OracleDbType.Varchar2).Value = rsTGrpCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        sSql = ""
                        sSql += "DELETE lf065m"
                        sSql += " WHERE tgrpcd = :tgrpcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("tgrpcd",  OracleDbType.Varchar2).Value = rsTGrpCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf065m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransTGrpInfo_UE(ByVal rsTGrpCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransTGrpInfo_UE(String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF065M : 검사그룹 마스터
            '   LF065H Insert
            sSql = ""
            sSql += "INSERT INTO lf065h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf065m f"
            sSql += " WHERE tgrpcd = :tgrpcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("tgrpcd",  OracleDbType.Varchar2).Value = rsTGrpCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF065M Delete
            sSql = ""
            sSql += "DELETE lf065m"
            sSql += " WHERE tgrpcd = :tgrpcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("tgrpcd",  OracleDbType.Varchar2).Value = rsTGrpCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function
End Class

Public Class APP_F_TUBE
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_TUBE" & vbTab

    Public Overloads Function GetTubeInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Overloads Function GetTubeInfo(ByVal iMode As Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT tubecd, tubenmd, tubevol, tubeunit, tubeifcd, usdt, uedt"
                sSql += "  FROM lf040m"
                sSql += " WHERE uedt >= fn_ack_sysdate"
                If rsSerch <> "" Then
                    sSql += "   AND " + rsSerch + ""
                End If
                sSql += " ORDER BY tubecd"
            ElseIf riMode = 1 Then
                sSql += "SELECT tubecd, tubenmd, tubevol, tubeunit, tubeifcd, usdt, uedt,"
                sSql += "       CASE WHEN TO_DATE(uedt, 'yyyymmddhh24miss') - SYSDATE < 0 THEN -1 ELSE 0 END diffday"
                sSql += "  FROM lf040m"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY tubecd"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Overloads Function GetTubeInfo(ByVal rsTubeCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Overloads Function GetTubeInfo(String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT tubecd, tubenm, tubenms, tubenmd, tubenmp, tubenmbp, tubevol, tubeunit, tubeifcd,"
            sSql += "       fn_ack_date_str(usdt, 'yyyy-mm-dd hh24:mi:ss') usdt,"
            sSql += "       fn_ack_date_str(uedt, 'yyyy-mm-dd hh24:mi:ss') uedt,"
            sSql += "       fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid,"
            sSql += "       fn_ack_get_usr_name(regid) regnm"
            sSql += "  FROM lf040m"
            sSql += " WHERE tubecd = :tubecd"
            sSql += "   AND usdt   = :usdt"

            alParm.Add(New OracleParameter("tubecd",  OracleDbType.Varchar2, rsTubeCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTubeCd))
            alParm.Add(New oracleParameter("usdt", rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Overloads Function GetTubeInfo_img(ByVal rsTubeCd As String) As Byte()
        Dim sFn As String = "Public Shared Function GetTubeInfo_img(String) As Byte()"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbCmd As New OracleCommand

        Try
            With dbCmd
                .Connection = dbCn
            End With

            Dim sSql As String = ""

            sSql = ""
            sSql += "SELECT filelen, filebin"
            sSql += "  FROM lf041m"
            sSql += " WHERE tubecd = :tubecd"

            With dbCmd

                .CommandType = CommandType.Text
                .CommandText = sSql

                .Parameters.Clear()

                .Parameters.Clear()
                .Parameters.Add("tubecd",  OracleDbType.Varchar2, rsTubeCd.Length).Value = rsTubeCd

            End With

            Dim a_btReturn() As Byte

            Dim dbDr As oracleDataReader = dbCmd.ExecuteReader(CommandBehavior.SequentialAccess)

            Do While dbDr.Read()

                Dim iStartIndex As Integer = 0
                Dim lngReturn As Long = 0

                Dim iBufferSize As Integer = 0

                iBufferSize = Convert.ToInt32(dbDr.GetValue(0).ToString)

                Dim a_btBuffer(iBufferSize - 1) As Byte
                ReDim a_btBuffer(iBufferSize - 1)

                iStartIndex = 0
                lngReturn = dbDr.GetBytes(1, iStartIndex, a_btBuffer, 0, iBufferSize)

                Do While lngReturn = iBufferSize
                    fnCopyToBytes(a_btBuffer, a_btReturn)


                    ReDim a_btBuffer(iBufferSize - 1)

                    iStartIndex += iBufferSize
                    lngReturn = dbDr.GetBytes(1, iStartIndex, a_btReturn, 0, iBufferSize)
                Loop
            Loop

            dbDr.Close()

            Return a_btReturn

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))


        Finally
            dbCmd.Dispose() : dbCmd = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

        End Try
    End Function

    Private Shared Function fnCopyToBytes(ByVal r_a_btFrom As Byte(), ByRef r_a_btTo As Byte()) As Boolean

        Try
            Dim iIndexDest As Integer = 0
            Dim iLength As Integer = 0

            If r_a_btTo Is Nothing Then
                iIndexDest = 0
            Else
                iIndexDest = r_a_btTo.Length
            End If

            iLength = r_a_btFrom.Length

            ReDim Preserve r_a_btTo(iIndexDest + iLength - 1)

            Array.ConstrainedCopy(r_a_btFrom, 0, r_a_btTo, iIndexDest, iLength)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile, ex))

        End Try

    End Function

    Public Function GetRecentTubeInfo(ByVal rsTubeCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetRecentTubeInfo(String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT usdt"
            sSql += "  FROM (SELECT usdt"
            sSql += "          FROM lf040m"
            sSql += "         WHERE tubecd = :tubecd"
            sSql += "           AND usdt  >= :usdt"
            sSql += "         ORDER BY usdt DESC"
            sSql += "       ) a"
            sSql += " WHERE ROWNUM = 1"

            alParm.Add(New OracleParameter("tubecd",  OracleDbType.Varchar2, rsTubeCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTubeCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransTubeInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                  ByVal rsTubeCd As String, ByVal rsUsDt As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransTubeInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF040M : 용기마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        'UPDATE uedt of previous record
                        sSql = ""
                        sSql += "UPDATE lf040m SET uedt = :usdt"
                        sSql += " WHERE (tubecd, usdt) IN"
                        sSql += "       (SELECT a.tubecd, a.usdt"
                        sSql += "          FROM (SELECT tubecd, usdt"
                        sSql += "				   FROM lf040m"
                        sSql += "				  WHERE tubecd = :tubecd"
                        sSql += "					AND usdt   < :usdt"
                        sSql += "					AND uedt   > :uedt"
                        sSql += "		          ORDER BY usdt DESC"
                        sSql += "               ) a"
                        sSql += "         WHERE ROWNUM = 1"
                        sSql += " 		)"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("tubecd",  OracleDbType.Varchar2).Value = rsTubeCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)

                            sSql = "INSERT INTO lf040m (" + sFields + ") VALUES (" + sValues + ")"
                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF040H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf040h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf040m f"
                        sSql += " WHERE tubecd = :tubecd"
                        sSql += "   AND usdt   = :usdt"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("tubecd",  OracleDbType.Varchar2).Value = rsTubeCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value

                                Select Case sField.ToUpper
                                    Case "TUBECD", "USDT"

                                    Case Else
                                        sFields += sField + " = :" + sField + ","
                                        dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End Select
                            Next

                            'UPDATE record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sSql = ""
                            sSql += "UPDATE lf040m SET " + sFields
                            sSql += " WHERE tubecd = :tubecd"
                            sSql += "   AND usdt   = :usdt"

                            dbCmd.Parameters.Add("tubecd",  OracleDbType.Varchar2).Value = rsTubeCd
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransTubeInfo_DEL(ByVal rsTubeCd As String, ByVal rsUsDt As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = " Public Function TransTestInfo_DEL() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF040M : 용기 마스터
            '   LF040H Insert
            sSql = ""
            sSql += "INSERT INTO lf040h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf040m f"
            sSql += " WHERE tubecd = :tubecd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("tubecd",  OracleDbType.Varchar2).Value = rsTubeCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF040M Delete
            sSql = ""
            sSql += "DELETE lf040m"
            sSql += " WHERE tubecd = :tubecd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("tubecd",  OracleDbType.Varchar2).Value = rsTubeCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransTubeInfo_UE(ByVal rsTubeCd As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUeDt As String) As Boolean
        Dim sFn As String = "Public Function TransTubeInfo_UE(ByVal asTubeCd As String, ByVal asUSDT As String, ByVal asRegID As String) As Boolean"

        Dim dbCn As New OracleConnection
        Dim dbTran As OracleTransaction
        Dim dbCmd As New OracleCommand

        Try
            Dim sMsg As String = ""

            sMsg = ifExistOtherUsableData("LF040", "TUBECD", rsTubeCd, rsUsDt)

            If IsNothing(sMsg) Then
                MsgBox("쿼리문의 오류가 있습니다!!", MsgBoxStyle.Exclamation)
                Exit Function
            End If

            If Not sMsg = "" Then
                MsgBox(sMsg, MsgBoxStyle.Critical)
                Exit Function
            End If

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"
            dbCn = GetDbConnection()
            dbTran = dbCn.BeginTransaction()

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF040M : 용기 마스터
            '   LF040H Insert
            sSql = ""
            sSql += "INSERT INTO lf040h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf040m f"
            sSql += " WHERE tubecd = :tubecd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("tubecd",  OracleDbType.Varchar2).Value = rsTubeCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF040M Update
            sSql = ""
            sSql = "UPDATE lf040m SET uedt = :uedt, regid = :regid"
            sSql += " WHERE tubecd = :tubecd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDt
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("tubecd",  OracleDbType.Varchar2).Value = rsTubeCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            If dbCn.State = ConnectionState.Open Then
                dbTran.Dispose() : dbTran = Nothing
                dbCn.Close()
            End If
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function


    Public Function TransTubeInfo_UPD_UE(ByVal rsTubeCd As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUeDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransTestInfo_UPD_UE() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF040M : 검사 마스터
            '   LF040H Insert
            sSql = ""
            sSql += "INSERT INTO lf040h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf040m f"
            sSql += " WHERE tubecd = :tubecd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("tubecd",  OracleDbType.Varchar2).Value = rsTubeCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF040M Update
            sSql = ""
            sSql += "UPDATE lf040m SET"
            sSql += "       uedt   = :uedt,"
            sSql += "       regdt  = fn_ack_sysdate,"
            sSql += "       regid  = :regid"
            sSql += " WHERE tubecd = :tubecd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("tubecd",  OracleDbType.Varchar2).Value = rsTubeCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransTubeInfo_UPD_US(ByVal rsTubeCd As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUsDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransTestInfo_UPD_US() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF040M : 성분제제 마스터
            '   LF040H Insert
            sSql = ""
            sSql += "INSERT INTO lf040h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf040m f"
            sSql += " WHERE tubecd = :tubecd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("tubecd",  OracleDbType.Varchar2).Value = rsTubeCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF040M Update
            sSql = ""
            sSql += "UPDATE lf040m SET"
            sSql += "       usdt   = :usdtchg,"
            sSql += "       regdt  = fn_ack_sysdate,"
            sSql += "       regid  = :regid"
            sSql += " WHERE tubecd = :tubecd"
            sSql += "   AND usdt   = :usdt"


            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("usdtchg",  OracleDbType.Varchar2).Value = rsUsDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("tubecd",  OracleDbType.Varchar2).Value = rsTubeCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransTubeInfo_Img(ByVal rsTubeCd As String,   ByVal r_btFile As Byte()) As Boolean
        Dim sFn As String = "Public Function TransTubeInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            sSql = ""
            sSql += "UPDATE lf041m SET filelen = :filelen"
            sSql += " WHERE tubecd = :tubecd"


            With dbCmd
                .CommandType = CommandType.Text
                .CommandText = sSql

                .Parameters.Clear()
                .Parameters.Add("filelen", OracleDbType.Int64).Value = r_btFile.Length
                .Parameters.Add("tubecd",  OracleDbType.Varchar2, rsTubeCd.Length).Value = rsTubeCd

                iRet = .ExecuteNonQuery()
            End With

            If iRet < 1 Then
                sSql = ""
                sSql += " INSERT INTO lf041m (tubecd, filelen)"
                sSql += "      VALUES ( :tubecd,    :filelen )"

                With dbCmd
                    .CommandType = CommandType.Text
                    .CommandText = sSql

                    .Parameters.Clear()
                    .Parameters.Add("tubecd",  OracleDbType.Varchar2, rsTubeCd.Length).Value = rsTubeCd
                    .Parameters.Add("filelen", OracleDbType.Int64).Value = r_btFile.Length

                    iRet += .ExecuteNonQuery()
                End With

            End If

            sSql = ""
            sSql += "UPDATE lf041m SET filebin = :filebin"
            sSql += " WHERE tubecd = :tubecd"

            With dbCmd
                .CommandType = CommandType.Text
                .CommandText = sSql

                .Parameters.Clear()
                .Parameters.Add("filebin", OracleDbType.LongRaw, r_btFile.Length).Value = r_btFile
                .Parameters.Add("tubecd",  OracleDbType.Varchar2, rsTubeCd.Length).Value = rsTubeCd

                iRet = .ExecuteNonQuery()
            End With

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

End Class

Public Class APP_F_USR
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_USR" & vbTab

    Public Overloads Function GetUsrInfo(ByVal iMode As Integer, ByVal Serch As String) As DataTable
        Dim sFn As String = "Public Function GetUsrInfo(ByVal iMode As Integer) As DataTable"

        Try
            Dim sSql As String = ""

            If iMode = 0 Then
                sSql += "SELECT DISTINCT usrid, usrnm,"
                sSql += "       CASE WHEN usrlvl = 'S' THEN '관리자' "
                sSql += "            ELSE CASE WHEN drspyn = '1' THEN '전문의'"
                sSql += "                      WHEN drspyn = '0' THEN '일반'"
                sSql += "                 END"
                sSql += "       END usrlvl, CASE WHEN DELFLG='0' THEN 'Y'WHEN DELFLG='1' THEN 'N' END AS USEYN "
                sSql += "  FROM lf090m"
                sSql += " WHERE NVL(delflg, '0') = '0'"

                If Serch <> "" Then
                    sSql += "   AND " + Serch + ""
                End If
                sSql += " ORDER by usrid"

            ElseIf iMode = 1 Then
                sSql += "SELECT DISTINCT usrid, usrnm,"
                sSql += "       CASE WHEN usrlvl = 'S' THEN '관리자' "
                sSql += "            ELSE CASE WHEN drspyn = '1' THEN '전문의'"
                sSql += "                      WHEN drspyn = '0' THEN '일반'"
                sSql += "                 END"
                sSql += "       END usrlvl, CASE WHEN DELFLG='0' THEN 'Y'WHEN DELFLG='1' THEN 'N' END AS USEYN, TO_NUMBER(NVL(DELFLG, '0')) * -1 diffday"
                sSql += "  FROM lf090m"
                If Serch <> "" Then
                    sSql += " WHERE " + Serch + ""
                End If
                sSql += " ORDER by usrid"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Overloads Function GetUsrInfo(ByVal rsUsrID As String) As DataTable
        Dim sFn As String = "Public Function GetUsrInfo(ByVal iMode As Integer, ByVal asUsrID As String, ByVal asUSDT As String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT usrid, usrnm, usrpwd, '********************' usrpwd_vw,"
            sSql += "       '[' || usrlvl || ']' usrlvl_01, medino, drspyn, other, drspyn, medino,"
            sSql += "       fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid,"
            sSql += "       fn_ack_get_usr_name(regid) regnm,"
            sSql += "       fn_ack_get_usr_telno(usrid) telno,"
            sSql += "       delflg"
            sSql += "  FROM lf090m"
            sSql += " WHERE usrid = '" + rsUsrID + "'"

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetUsrMnuInfo(ByVal rsUsrID As String) As DataTable
        Dim sFn As String = "Public Function GetUsrMnuInfo(ByVal asUsrID As String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT NVL(f91.chk, '0') chk, f92.mnuid, f92.isparent, f92.mnulvl, f92.parentid,"
            sSql += "       LPAD('-', f92.mnulvl*4, '-') || mnunm mnunm,"
            sSql += "       CASE WHEN ISPARENT = '1' THEN f92.mnuid ELSE f92.parentid END sort1"
            sSql += "  FROM lf092m f92 LEFT OUTER JOIN"
            sSql += "       (SELECT '1' chk, f92.mnuid "
            sSql += "		   FROM lf092m f92, lf091m f91"
            sSql += "		  WHERE f92.mnuid = f91.mnuid"
            sSql += "		    AND f92.mnugbn in ('1', '9')"
            sSql += " 		    AND f91.usrid = :usrid"
            sSql += "       ) f91 ON (f92.mnuid = f91.mnuid)"
            sSql += " WHERE f92.mnugbn in ('1', '9')"
            sSql += " ORDER BY sort1, f92.vieworder, f92.mnuid"

            alParm.Add(New OracleParameter("usrid",  OracleDbType.Varchar2, rsUsrID.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsrID))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetUsrSkillInfo(ByVal rsUsrID As String) As DataTable
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT NVL(f93.chk, '0') chk, f94.sklgrp, f94.sklcd, f94.skldesc"
            sSql += "  FROM lf094m f94 LEFT OUTER JOIN"
            sSql += "       (SELECT '1' chk, f94.sklgrp, f94.sklcd"
            sSql += "  		   FROM lf094m f94, lf093m f93"
            sSql += "		  WHERE f94.sklgrp = f93.sklgrp"
            sSql += " 		    AND f94.sklcd = f93.sklcd"
            sSql += " 		    AND f93.usrid = :usrid"
            sSql += "       ) f93 ON (f94.sklgrp = f93.sklgrp AND f94.sklcd = f93.sklcd)"
            sSql += " WHERE f94.sklflg = '1'"
            sSql += "   AND f94.sklgrp <> '000'"
            sSql += " ORDER BY dispseq, f94.sklgrp, f94.sklcd"

            alParm.Add(New OracleParameter("usrid",  OracleDbType.Varchar2, rsUsrID.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsrID))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetRecentUsrInfo(ByVal rsUsrID As String) As DataTable
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT usrid"
            sSql += "  FROM lf090m"
            sSql += " WHERE usrid = :usrid"

            alParm.Add(New OracleParameter("usrid",  OracleDbType.Varchar2, rsUsrID.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsrID))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function TransUsrInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                 ByVal ro_Tcol2 As ItemTableCollection, ByVal riType2 As Integer, _
                                 ByVal ro_Tcol3 As ItemTableCollection, ByVal riType3 As Integer, _
                                 ByVal ro_Tcol4 As ItemTableCollection, ByVal riType4 As Integer, _
                                 ByVal rsUsrID As String) As Boolean
        Dim sFn As String = "Public Function TransUsrInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""
            Dim alTest As New ArrayList

            'LF090M : 사용자마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""
                            dbCmd.Parameters.Clear()

                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)

                            sSql = "INSERT INTO lf090m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF090H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf090h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf090m f"
                        sSql += " WHERE usrid = :usrid"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("usrid",  OracleDbType.Varchar2).Value = rsUsrID

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value

                                Select Case sField.ToUpper
                                    Case "USRID"

                                    Case Else
                                        sFields += sField + " = :" + sField + ","

                                        dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End Select
                            Next

                            'UPDATE record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sSql = ""
                            sSql += "UPDATE lf090m SET " + sFields
                            sSql += " WHERE usrid = :usrid"

                            dbCmd.Parameters.Add("usrid",  OracleDbType.Varchar2).Value = rsUsrID
                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            'LF091M : 사용자별 메뉴 마스터
            Select Case riType2
                Case 0      '----- 신규
                    With ro_Tcol2
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            Dim sTmp As String = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                sTmp += sValue + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)

                            sSql = "INSERT INTO lf091m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    'LF091H Backup
                    sSql = ""
                    sSql += "INSERT INTO lf091h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf091m f"
                    sSql += " WHERE usrid = :usrid"

                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
                    dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                    dbCmd.Parameters.Add("usrid",  OracleDbType.Varchar2).Value = rsUsrID

                    dbCmd.CommandText = sSql
                    iRet += dbCmd.ExecuteNonQuery()

                    sSql = ""
                    sSql += "DELETE lf091m"
                    sSql += " WHERE usrid = :usrid"

                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("usrid",  OracleDbType.Varchar2).Value = rsUsrID

                    dbCmd.CommandText = sSql
                    iRet += dbCmd.ExecuteNonQuery()

                    With ro_Tcol2
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)

                            sSql = "INSERT INTO lf091m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            'LF093M : 사용자별 기능 마스터
            Select Case riType3
                Case 0      '----- 신규
                    With ro_Tcol3
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)

                            sSql = "INSERT INTO lf093m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    'LF093H Backup
                    sSql = ""
                    sSql += "INSERT INTO lf093h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf093m f"
                    sSql += " WHERE usrid = :usrid"

                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
                    dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                    dbCmd.Parameters.Add("usrid",  OracleDbType.Varchar2).Value = rsUsrID

                    dbCmd.CommandText = sSql
                    iRet += dbCmd.ExecuteNonQuery()

                    sSql = ""
                    sSql += "DELETE lf093m"
                    sSql += " WHERE usrid = :usrid"

                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("usrid",  OracleDbType.Varchar2).Value = rsUsrID

                    dbCmd.CommandText = sSql
                    iRet += dbCmd.ExecuteNonQuery()

                    With ro_Tcol3
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)

                            sSql = "INSERT INTO lf093m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            'LF097M : 연락처 등록
            Select Case riType4
                Case 0      '----- 신규
                    With ro_Tcol4
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)

                            sSql = "INSERT INTO lf097m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    'LF093H Backup
                    sSql = ""
                    sSql += "INSERT INTO lf097h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf097m f"
                    sSql += " WHERE usrid  = :usrid"
                    sSql += "   AND fldgbn = '1'"

                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
                    dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                    dbCmd.Parameters.Add("usrid",  OracleDbType.Varchar2).Value = rsUsrID

                    dbCmd.CommandText = sSql
                    iRet += dbCmd.ExecuteNonQuery()

                    sSql = ""
                    sSql += "DELETE lf097m"
                    sSql += " WHERE usrid = :usrid"
                    sSql += "   AND fldgbn = '1'"

                    dbCmd.Parameters.Clear()
                    dbCmd.Parameters.Add("usrid",  OracleDbType.Varchar2).Value = rsUsrID

                    dbCmd.CommandText = sSql
                    iRet += dbCmd.ExecuteNonQuery()

                    With ro_Tcol4
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)

                            sSql = "INSERT INTO lf097m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransUsrInfo_DEL(ByVal rsUsrId As String) As Boolean
        Dim sFn As String = " Public Function TransBcclsInfo_DEL() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            sSql = ""
            sSql += "INSERT INTO lf090h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf090m f"
            sSql += " WHERE usrid = :usrid"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("usrid",  OracleDbType.Varchar2).Value = rsUsrId

            dbCmd.CommandText = sSql
            dbCmd.ExecuteNonQuery()

            sSql = ""
            sSql += "DELETE lf090m"
            sSql += " WHERE usrid = :usrid"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("usrid",  OracleDbType.Varchar2).Value = rsUsrId

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            sSql = ""
            sSql += "INSERT INTO lf091h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf091m f"
            sSql += " WHERE usrid = :usrid"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("usrid",  OracleDbType.Varchar2).Value = rsUsrId

            dbCmd.CommandText = sSql
            dbCmd.ExecuteNonQuery()

            sSql = ""
            sSql += "DELETE lf091m"
            sSql += " WHERE usrid = :usrid"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("usrid",  OracleDbType.Varchar2).Value = rsUsrId

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            sSql = ""
            sSql += "INSERT INTO lf093h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf093m f"
            sSql += " WHERE usrid = :usrid"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("usrid",  OracleDbType.Varchar2).Value = rsUsrId

            dbCmd.CommandText = sSql
            dbCmd.ExecuteNonQuery()

            sSql = ""
            sSql += "DELETE lf093m"
            sSql += " WHERE usrid = :usrid"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("usrid",  OracleDbType.Varchar2).Value = rsUsrId

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransUsrInfo_UE(ByVal rsUsrID As String) As Boolean
        Dim sFn As String = "Public Function TransUsrInfo_UE(ByVal asUsrID As String, ByVal asRegID As String) As Boolean"

        Try
            Dim sSql As String = ""
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = "", sMsg As String = ""
            Dim alTest As New ArrayList

            'LF090M : 사용자 마스터
            '   LF090H Insert
            sSql = ""
            sSql += "INSERT INTO lf090h SELECT fn_ack_sysdate, '" + USER_INFO.USRID + "', f.* FROM lf090m f"
            sSql += " WHERE usrid = '" + rsUsrID + "'"
            alTest.Add(sSql)

            '   LF090M Update
            sSql = ""
            sSql += "UPDATE lf090m SET delflg = '1', regdt = fn_ack_sysdate, regid = '" + USER_INFO.USRID + "'"
            sSql += " WHERE usrid = '" + rsUsrID + "'"
            alTest.Add(sSql)

            'LF091M : 사용자별 메뉴 마스터
            '   LF091H Insert
            sSql = ""
            sSql += "INSERT INTO lf091h SELECT fn_ack_sysdate, '" + USER_INFO.USRID + "', f.* FROM lf091m f"
            sSql += " WHERE usrid = '" + rsUsrID + "'"
            alTest.Add(sSql)

            '   LF091M Delete
            sSql = ""
            sSql += "DELETE lf091m"
            sSql += " WHERE usrid = '" + rsUsrID + "'"
            alTest.Add(sSql)

            'LF093M : 사용자별 기능 마스터
            '   LF093H Insert
            sSql = ""
            sSql += "INSERT INTO lf093h SELECT fn_ack_sysdate, '" + USER_INFO.USRID + "', f.* FROM lf093m f"
            sSql += " WHERE usrid = '" + rsUsrID + "'"
            alTest.Add(sSql)

            '   LF093M Delete
            sSql = ""
            sSql += "DELETE lf093m"
            sSql += " WHERE usrid = '" + rsUsrID + "'"
            alTest.Add(sSql)

            If LISAPP.APP_DB.DBSql.ExcuteSql(alTest) = False Then
                Return False
            End If

            Return True
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function
End Class

Public Class APP_F_WKGRP
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_WKGRP" & vbTab


    '-- 검사코드 리스트
    Public Shared Function fnGet_TestInfo(ByVal rsWGrpCD As String) As DataTable
        Dim sFn As String = "Function fnGet_testspc_list(String, String) As DataTable"
        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT DISTINCT"
            sSql += "       '' chk, f6.tnmd, f6.tnmp tnmp, f6.testcd, f6.spccd, RPAD(f6.testcd, 8, ' ') || f6.spccd testspc,"
            sSql += "       f6.tordcd, f6.tordslip, f6.tcdgbn, f6.partcd || f6.slipcd partslip, NVL(f6.titleyn, '0') titleyn,"
            sSql += "       NVL(f6.mbttype, '0') mbttype, NVL(f6.poctyn, '0') poctyn,"
            sSql += "       f3.spcnmd, NVL(f2.dispseq, 999) sort1, NVL(f6.dispseql, 999) sort2"
            sSql += "  FROM lf060m f6, lf021m f2, lf030m f3"
            sSql += " WHERE f6.usdt <= fn_ack_sysdate"
            sSql += "   AND f6.uedt >  fn_ack_sysdate"
            sSql += "   AND (f6.testcd, f6.spccd) NOT IN (SELECT testcd, spccd FROM lf066m WHERE wkgrpcd <> '" + rsWGrpCD + "')"
            sSql += "   AND f6.partcd = f2.partcd"
            sSql += "   AND f6.slipcd = f2.slipcd"
            sSql += "   AND f2.usdt  <= fn_ack_sysdate"
            sSql += "   AND f2.uedt   > fn_ack_sysdate"
            sSql += "   AND f6.spccd  = f3.spccd"
            sSql += "   AND f3.usdt  <= fn_ack_sysdate"
            sSql += "   AND f3.uedt   > fn_ack_sysdate"
            sSql += " ORDER BY sort1, sort2, testspc"

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try

    End Function


    Public Function fnGet_TestInfo_spc(ByVal rsSlipCd As String, ByVal rsSpcCds As String, ByVal rsWGrpCd As String) As DataTable
        Dim sFn As String = "Public Function fnGet_TestInfo_spc(String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT testcd, spccd, tnmd, partcd || slipcd slipcd, dispseql dispseql"
            sSql += "  FROM lf060m"
            sSql += " WHERE usdt   <= fn_ack_sysdate"
            sSql += "   AND uedt   >  fn_ack_sysdate"
            sSql += "   AND partcd  = :partcd"
            sSql += "   AND slipcd  = :slipcd"
            sSql += "   AND spccd  IN ('" + rsSpcCds.Replace(",", "','").ToString + "')"
            sSql += "   AND tcdgbn IN ('S', 'P')"
            sSql += "   AND (testcd, spccd) NOT IN (SELECT testcd, spccd FROM lf066m WHERE wkgrpcd <> '" + rsWGrpCd + "')"
            sSql += " ORDER BY dispseql"

            al.Add(New OracleParameter("partcd", rsSlipCd.Substring(0, 1)))
            al.Add(New OracleParameter("slipcd", rsSlipCd.Substring(1, 1)))

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))


        End Try
    End Function

    Public Function GetWGrpInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetTGrpInfo(Integer, ByVal Serch As String, ByVal asNull As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql = ""
                sSql += "SELECT wkgrpcd, wkgrpnmd"
                sSql += "  FROM lf066m"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " GROUP BY wkgrpcd, wkgrpnmd"

            ElseIf riMode = 1 Then
                sSql = ""
                sSql += "SELECT wkgrpcd, wkgrpnmd, '1' diffday, '' modid, '' moddt"
                sSql += "  FROM lf066m"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " GROUP BY wkgrpcd, wkgrpnmd"
                sSql += " UNION ALL "
                sSql += "SELECT wkgrpcd, wkgrpnmd, '-1' diffday, modid, fn_ack_date_str(moddt, 'yyyy-mm-dd hh24:mi:ss') moddt"
                sSql += "  FROM lf066h"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += "  GROUP BY wkgrpcd, wkgrpnmd, modid, moddt"
                sSql += "  ORDER BY wkgrpcd, moddt, modid"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetWGrpInfo(ByVal rsWGrpCd As String) As DataTable
        Dim sFn As String = "Public Function GetTGrpInfo(Integer, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql = ""
            sSql += "SELECT DISTINCT"
            sSql += "       f64.wkgrpcd, f64.wkgrpnm, f64.wkgrpnms, f64.wkgrpnmd, f64.wkgrpnmbp,"
            sSql += "       '[' || f21.partcd || f21.slipcd || '] ' ||  f21.slipnmd tgrptype_01,"
            sSql += "       CASE WHEN f64.wkgrpgbn = '1' THEN '[1] 일' WHEN f64.wkgrpgbn = '2' THEN '[2] 월' WHEN f64.wkgrpgbn = '3' THEN '[3] 년' END wkgrpgbn_01,"
            sSql += "       fn_ack_date_str(f64.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f64.regid,"
            sSql += "       fn_ack_get_usr_name(f64.regid) regnm,"
            sSql += "       NULL moddt, NULL modid, NULL modnm"
            sSql += "  FROM lf066m f64 LEFT OUTER JOIN"
            sSql += "       lf021m f21 ON (f64.partcd = f21.partcd AND f64.slipcd = f21.slipcd)"
            sSql += " WHERE f64.wkgrpcd = :wgrpcd"

            alParm.Add(New OracleParameter("wgrpcd",  OracleDbType.Varchar2, rsWGrpCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsWGrpCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetWGrpInfo(ByVal rsModDT As String, ByVal rsModID As String, ByVal rsWGrpCd As String) As DataTable
        Dim sFn As String = "Public Function GetTGrpInfo(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql = ""
            sSql += "SELECT DISTINCT"
            sSql += "       f64.wkgrpcd, f64.wkgrpnm, f64.wkgrpnms, f64.wkgrpnmd, f64.wkgrpnmbp,"
            sSql += "       '[' || f21.partcd || f21.slipcd || '] ' ||  f21.slipnmd tgrptype_01,"
            sSql += "       CASE WHEN f64.wkgrpgbn = '1' THEN '[1] 일' WHEN f64.wkgrpgbn = '2' THEN '[2] 월' WHEN f64.wkgrpgbn = '3' THEN '[3] 년' END wkgrpgbn_01,"
            sSql += "       fn_ack_date_str(f64.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f64.regid,"
            sSql += "       fn_ack_get_usr_name(f64.regid) regnm, "
            sSql += "       fn_ack_date_str(f64.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, modid,"
            sSql += "       fn_ack_get_usr_name(modid) modnm"
            sSql += "  FROM lf066h f64 LEFT OUTER JOIN"
            sSql += "       lf021m f21 ON (f64.partcd = f21.partcd AND f64.slipcd = f21.slipcd)"
            sSql += " WHERE f64.wkgrpcd = :wgrpcd"
            sSql += "   AND f64.moddt   = :moddt"
            sSql += "   AND f64.modid   = :modip"

            alParm.Add(New OracleParameter("wgrpcd",  OracleDbType.Varchar2, rsWGrpCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsWGrpCd))
            alParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDT.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDT))
            alParm.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModID.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModID))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetWGrpInfo_Test(ByVal rsWGrpCd As String) As DataTable
        Dim sFn As String = "Public Function GetTGrpInfo_Test(String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT a.testcd, a.spccd, b.tnmd, a.partcd || a.slipcd partslip"
            sSql += "  FROM lf066m a LEFT OUTER JOIN"
            sSql += "       ("
            sSql += "        SELECT testcd, spccd, tnmd"
            sSql += "          FROM lf060m b"
            sSql += "         WHERE b.usdt <= fn_ack_sysdate"
            sSql += "           AND b.uedt >  fn_ack_sysdate"
            sSql += "           AND b.tcdgbn IN ('B', 'S', 'P')"
            sSql += "       ) b ON (a.testcd = b.testcd AND a.spccd = b.spccd)"
            sSql += " WHERE a.wkgrpcd = :wgrpcd"

            alParm.Add(New OracleParameter("wgrpcd",  OracleDbType.Varchar2, rsWGrpCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsWGrpCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetWGrpInfo_Test(ByVal rsModDT As String, ByVal rsModID As String, ByVal rsWGrpCd As String) As DataTable
        Dim sFn As String = "Public Function GetTGrpInfo_Test(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT a.testcd, a.spccd, b.tnmd, a.partcd || a.slipcd partslip"
            sSql += "  FROM lf066h a LEFT OUTER JOIN"
            sSql += "       ("
            sSql += "        SELECT testcd, spccd, tnmd"
            sSql += "          FROM lf060m b"
            sSql += "         WHERE b.usdt <= fn_ack_sysdate"
            sSql += "           AND b.uedt >  fn_ack_sysdate"
            sSql += "           AND b.tcdgbn IN ('B', 'S', 'P')"
            sSql += "       ) b ON (a.testcd = b.testcd AND a.spccd = b.spccd)"
            sSql += " WHERE a.wkgrpcd = :wgrpcd"
            sSql += "   AND a.moddt   = :moddt"
            sSql += "   AND a.modid   = :modid"

            alParm.Add(New OracleParameter("wgrpcd",  OracleDbType.Varchar2, rsWGrpCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsWGrpCd))
            alParm.Add(New OracleParameter("mddip",  OracleDbType.Varchar2, rsModDT.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDT))
            alParm.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModID.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModID))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentWGrpInfo(ByVal rsWGrpCd As String) As DataTable
        Dim sFn As String = "Public Function GetRecentTGrpInfo(String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT wkgrpcd"
            sSql += "  FROM lf066m"
            sSql += " WHERE wkgrpcd = :wgrpcd"

            alParm.Add(New OracleParameter("wgrpcd",  OracleDbType.Varchar2, rsWGrpCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsWGrpCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransWGrpInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                  ByVal rsWGrpCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransTGrpInfo(ItemTableCollection, Integer, String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF065M : 검사그룹 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf066m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF065H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf066h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf066m f"
                        sSql += " WHERE wkgrpcd = :wgrpcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("wgrpcd",  OracleDbType.Varchar2).Value = rsWGrpCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        sSql = ""
                        sSql += "DELETE lf066m"
                        sSql += " WHERE wkgrpcd = :wgrpcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("wkgrp",  OracleDbType.Varchar2).Value = rsWGrpCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf066m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransWGrpInfo_UE(ByVal rsWGrpCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransTGrpInfo_UE(String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
  
            'LF066M : 작업그룹 마스터
            '   LF066H Insert
            sSql = ""
            sSql += "INSERT INTO lf066h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf066m f"
            sSql += " WHERE Wkgrpcd = :wgrpcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("wgrpcd",  OracleDbType.Varchar2).Value = rsWGrpCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF066M Delete
            sSql = ""
            sSql += "DELETE lf066m"
            sSql += " WHERE wkgrpcd = :wgrpcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("wgrpcd",  OracleDbType.Varchar2).Value = rsWGrpCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function
End Class

Public Class APP_F_DCOMCD
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_DCOMCD" & vbTab

    Public Function TransDcomCdInfo_UE(ByVal rsSlipCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = " Public Function TransKSRackInfo_UE(string, string, string, string, string, string) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF430H Backup
            sSql = ""
            sSql += "INSERT INTO lf430h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf430m f"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND slipcd = :slipcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsSlipCd.Substring(0, 1)
            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd.Substring(1, 1)

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            sSql = ""
            sSql += "DELETE lf430m"
            sSql += " WHERE partcd = :partcd"
            sSql += "   AND slipcd = :slipcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsSlipCd.Substring(0, 1)
            dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd.Substring(1, 1)

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransDcomCdInfo(ByVal roTcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                    ByVal rsSlipCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransDcomCdInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF430M : 성분제제 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With roTcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf430m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With roTcol1
                        'LF430H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf430h "
                        sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf430m f"
                        sSql += " WHERE partcd = :partcd"
                        sSql += "   AND slipcd = :slipcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsSlipCd.Substring(0, 1)
                        dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd.Substring(1, 1)

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        sSql = ""
                        sSql += "DELETE lf430m"
                        sSql += " WHERE partcd = :partcd"
                        sSql += "   AND slipcd = :slipcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("partcd",  OracleDbType.Varchar2).Value = rsSlipCd.Substring(0, 1)
                        dbCmd.Parameters.Add("slipcd",  OracleDbType.Varchar2).Value = rsSlipCd.Substring(1, 1)

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf430m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next

                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function GetDcomCdInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetDcomCdInfo(Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT slipcd, slipnmd "
                sSql += "  FROM ("
                sSql += "        SELECT DISTINCT"
                sSql += "               f4.partcd || f4.slipcd slipcd, CASE WHEN NVL(f2.slipnmd, ' ') = ' ' THEN '공통' ELSE f2.slipnmd END slipnmd"
                sSql += "          FROM lf430m f4 LEFT OUTER JOIN"
                sSql += "               lf021m f2 ON (f4.partcd = f2.partcd AND f4.slipcd = f2.slipcd)"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If

            ElseIf riMode = 1 Then
                sSql += "SELECT slipcd, slipnmd, diffday, moddt, modid"
                sSql += "  FROM ( "
                sSql += "        SELECT DISTINCT f4.partcd || f4.slipcd slipcd, CASE WHEN NVL(f2.slipnmd, ' ') = ' ' THEN '공통' ELSE f2.slipnmd END slipnmd,"
                sSql += "               NULL diffday, NULL moddt, NULL modid"
                sSql += "          FROM lf430m f4 LEFT OUTER JOIN"
                sSql += "               lf021M f2 ON (f4.partcd = f2.partcd AND f4.slipcd = f2.slipcd)"
                sSql += "         UNION ALL"
                sSql += "        SELECT DISTINCT f4.partcd || f4.slipcd slipcd, CASE WHEN NVL(f2.slipnmd, ' ') = ' ' THEN '공통' ELSE f2.slipnmd END slipnmd,"
                sSql += "               -1 diffday, fn_ack_date_str(f4.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, f4.modid"
                sSql += "          FROM lf430h f4 LEFT OUTER JOIN"
                sSql += "               lf021m f2 ON (f4.partcd = f2.partcd AND f4.slipcd = f2.slipcd)"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY slipcd, moddt, modid"

            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
             Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function GetDcomCdInfo(ByVal rsSlipCd As String, Optional ByVal rsAdd As String = "") As DataTable
        Dim sFn As String = "Public Function GetDcomCdInfo(String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim sTmp As String = "("

            If rsSlipCd.Length > 0 Then
                sTmp = "'" + rsSlipCd + "'"
            End If

            If rsAdd <> "" Then
                If sTmp.Length > 1 Then sTmp += ","

                sTmp += "'00'"
            End If

            sTmp += ")"


            sSql += "SELECT DISTINCT"
            sSql += "       a.drugcomcd, a.drugcomnm, fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, a.regid,"
            sSql += "       NULL moddt, NULL modid, NULL modnm, fn_ack_get_usr_name(a.regid) regnm,"
            sSql += "       '[' || a.partcd || a.slipcd || '] ' ||  b.slipnmd slipnmd_01"
            sSql += "  FROM lf430m a LEFT OUTER JOIN"
            sSql += "       lf021m b ON (a.partcd = b.partcd AND a.slipcd = b.slipcd)"
            sSql += " WHERE a.partcd || a.slipcd IN " + sTmp

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function GetDcomCdInfo(ByVal rsModDt As String, ByVal rsModId As String, ByVal rsSlipCd As String) As DataTable
        Dim sFn As String = "Public Function GetDcomCdInfo(string, string, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT DISTINCT"
            sSql += "       a.drugcomcd, a.drugcomnm, fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, a.regid,"
            sSql += "       a.moddt, a.modid,"
            sSql += "       '[' || a.partcd || a.slipcd || '] ' ||  CASE WHEN a.partcd + a.slipcd = '00' THEN '공통' ELSE b.slipnmd END slipnmd_01,"
            sSql += "       fn_ack_get_usr_name(a.modid) modnm,"
            sSql += "       fn_ack_get_usr_name(a.regid) regnm"
            sSql += "  FROM lf430h a LEFT OUTER JOIN"
            sSql += "       lf021m b ON (a.partcd = b.partcd AND a.slipcd = b.slipcd)"
            sSql += " WHERE a.moddt  = :moddt"
            sSql += "   AND a.modid  = :modid"
            sSql += "   AND a.partcd = :partcd"
            sSql += "   AND a.slipcd = :slipcd"

            al.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDt))
            al.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModId.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModId))
            al.Add(New OracleParameter("partcd",  OracleDbType.Varchar2, 1, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSlipCd.Substring(0, 1)))
            al.Add(New OracleParameter("slipcd",  OracleDbType.Varchar2, 1, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSlipCd.Substring(1, 1)))


            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
             Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function

    Public Function GetSangBunInfo() As DataTable
        Dim sFn As String = "Public Function GetSangBunInfo() As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT DISTINCT"
            sSql += "       /*ordcd*/''  sungbun_code, igrdname sungbun_name"
            sSql += "  FROM oram1.mdordrct a"
            sSql += " WHERE a.appldate <= SYSDATE"
            sSql += "   AND a.enddate  >= SYSDATE"
            sSql += " ORDER BY a.igrdname"

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
             Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try

    End Function
End Class

Public Class APP_F_COLLTKCD
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_COLLTKCD" & vbTab

    Private Const mc_sCmt0 As String = "병동"
    Private Const mc_sCmt1 As String = "진단검사"
    Private Const mc_sCmt2 As String = "환자특이사항"
    Private Const mc_sCmt3 As String = "미채혈사유"
    Private Const mc_sCmtA As String = "특이결과"
    Private Const mc_sCmtB As String = "결과수정 사유"
    Private Const mc_sCmtC As String = "TAT 사유"
    Private Const mc_sCmtD As String = "혈액은행 환자특이사항"
    Private Const mc_sCmtE As String = "부적합검체 등록 사유"
    Private Const mc_sCmtF As String = "혈액은행 접수취소 사유"
    Private Const mc_sCmtG As String = "특이결과 조치내용"
    Private Const mc_sCmtH As String = "수혈의뢰 사유"

    Public Function GetCmtGbnInfo(Optional ByVal rsGbn As String = "") As DataTable
        Dim sFn As String = "Public Function GetCmtGbnInfo() As DataTable"

        Try
            Dim sSql As String = ""

            If rsGbn = "" Then
                sSql += "SELECT '0' cmtgbncd, '" + mc_sCmt0 + "' cmtgbnnm, 1 cmtgbnsort FROM DUAL"
                sSql += " UNION ALL "
                sSql += "SELECT '1' cmtgbncd, '" + mc_sCmt1 + "' cmtgbnnm, 2 cmtgbnsort FROM DUAL"
                sSql += " UNION ALL "
                sSql += "SELECT 'E' cmtgbncd, '" + mc_sCmtE + "' cmtgbnnm, 3 cmtgbnsort FROM DUAL"
            Else
                sSql += "SELECT '2' cmtgbncd, '" + mc_sCmt2 + "' cmtgbnnm, 1 cmtgbnsort FROM DUAL"
                sSql += " UNION ALL "
                sSql += "SELECT '3' cmtgbncd, '" + mc_sCmt3 + "' cmtgbnnm, 2 cmtgbnsort FROM DUAL"
                sSql += " UNION ALL "
                sSql += "SELECT 'A' cmtgbncd, '" + mc_sCmtA + "' cmtgbnnm, 3 cmtgbnsort FROM DUAL"
                sSql += " UNION ALL "
                sSql += "SELECT 'B' cmtgbncd, '" + mc_sCmtB + "' cmtgbnnm, 4 cmtgbnsort FROM DUAL"
                sSql += " UNION ALL "
                sSql += "SELECT 'C' cmtgbncd, '" + mc_sCmtC + "' cmtgbnnm, 5 cmtgbnsort FROM DUAL"
                sSql += " UNION ALL "
                sSql += "SELECT 'D' cmtgbncd, '" + mc_sCmtD + "' cmtgbnnm, 6 cmtgbnsort FROM DUAL"
                sSql += " UNION ALL "
                sSql += "SELECT 'F' cmtgbncd, '" + mc_sCmtF + "' cmtgbnnm, 7 cmtgbnsort FROM DUAL"
                sSql += " UNION ALL "
                sSql += "SELECT 'G' cmtgbncd, '" + mc_sCmtG + "' cmtgbnnm, 8 cmtgbnsort FROM DUAL"
                sSql += " UNION ALL "
                sSql += "SELECT 'H' cmtgbncd, '" + mc_sCmtH + "' cmtgbnnm, 9 cmtgbnsort FROM DUAL"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetCollTkCdInfo(ByVal riMode As Integer, ByVal rsCmtGbn As String, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetCollTkCdInfo(Integer, ByVal rsGbn As String, ByVal Serch As String, ByVal asNull As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT cmtgbn_01, cmtcd, cmtcont, regdt, regid, diffday, cmtgbnsort, useyn"
                sSql += "  FROM ("
                sSql += "        SELECT '[' || cmtgbn || '] ' ||  b.cmtgbnnm cmtgbn_01, a.cmtcd, a.cmtcont,"
                sSql += "               fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, a.regid, null diffday, null moddt, null modid, b.cmtgbnsort,CASE WHEN a.delflg='0' THEN 'Y'WHEN a.delflg='1' THEN 'N' END AS USEYN"
                sSql += "          FROM lf410m a,"
                sSql += "               ("
                If rsCmtGbn = "" Then
                    sSql += "                SELECT '0' cmtgbncd, '" + mc_sCmt0 + "' cmtgbnnm, 1 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL"
                    sSql += "                SELECT '1' cmtgbncd, '" + mc_sCmt1 + "' cmtgbnnm, 2 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL "
                    sSql += "                SELECT 'E' cmtgbncd, '" + mc_sCmtE + "' cmtgbnnm, 3 cmtgbnsort FROM DUAL"
                Else
                    sSql += "                SELECT '2' cmtgbncd, '" + mc_sCmt2 + "' cmtgbnnm, 1 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL "
                    sSql += "                SELECT '3' cmtgbncd, '" + mc_sCmt3 + "' cmtgbnnm, 2 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL "
                    sSql += "                SELECT 'A' cmtgbncd, '" + mc_sCmtA + "' cmtgbnnm, 3 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL "
                    sSql += "                SELECT 'B' cmtgbncd, '" + mc_sCmtB + "' cmtgbnnm, 4 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL "
                    sSql += "                SELECT 'C' cmtgbncd, '" + mc_sCmtC + "' cmtgbnnm, 5 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL "
                    sSql += "                SELECT 'D' cmtgbncd, '" + mc_sCmtD + "' cmtgbnnm, 6 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL "
                    sSql += "                SELECT 'F' cmtgbncd, '" + mc_sCmtF + "' cmtgbnnm, 7 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL "
                    sSql += "                SELECT 'G' cmtgbncd, '" + mc_sCmtG + "' cmtgbnnm, 8 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL "
                    sSql += "                SELECT 'H' cmtgbncd, '" + mc_sCmtH + "' cmtgbnnm, 9 cmtgbnsort FROM DUAL"
                End If
                sSql += "               ) b"
                sSql += "         WHERE a.cmtgbn = b.cmtgbncd"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY cmtgbnsort, cmtcd"
            ElseIf riMode = 1 Then
                sSql += "SELECT cmtgbn_01, cmtcd, cmtcont, regdt, regid, diffday, cmtgbnsort, useyn"
                sSql += "  FROM ("
                sSql += "        SELECT '[' || cmtgbn || '] ' ||  b.cmtgbnnm cmtgbn_01, a.cmtcd, a.cmtcont,"
                sSql += "               fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, a.regid, TO_NUMBER(NVL(a.delflg, '0')) * -1 diffday, b.cmtgbnsort,CASE WHEN a.delflg='0' THEN 'Y'WHEN a.delflg='1' THEN 'N' END AS USEYN"
                sSql += "          FROM lf410m a,"
                sSql += "               ("
                If rsCmtGbn = "" Then
                    sSql += "                SELECT '0' cmtgbncd, '" + mc_sCmt0 + "' cmtgbnnm, 1 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL"
                    sSql += "                SELECT '1' cmtgbncd, '" + mc_sCmt1 + "' cmtgbnnm, 2 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL "
                    sSql += "                SELECT 'E' cmtgbncd, '" + mc_sCmtE + "' cmtgbnnm, 3 cmtgbnsort FROM DUAL"
                Else
                    sSql += "                SELECT '2' cmtgbncd, '" + mc_sCmt2 + "' cmtgbnnm, 1 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL "
                    sSql += "                SELECT '3' cmtgbncd, '" + mc_sCmt3 + "' cmtgbnnm, 2 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL "
                    sSql += "                SELECT 'A' cmtgbncd, '" + mc_sCmtA + "' cmtgbnnm, 3 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL "
                    sSql += "                SELECT 'B' cmtgbncd, '" + mc_sCmtB + "' cmtgbnnm, 4 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL "
                    sSql += "                SELECT 'C' cmtgbncd, '" + mc_sCmtC + "' cmtgbnnm, 5 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL "
                    sSql += "                SELECT 'D' cmtgbncd, '" + mc_sCmtD + "' cmtgbnnm, 6 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL "
                    sSql += "                SELECT 'F' cmtgbncd, '" + mc_sCmtF + "' cmtgbnnm, 7 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL "
                    sSql += "                SELECT 'G' cmtgbncd, '" + mc_sCmtG + "' cmtgbnnm, 8 cmtgbnsort FROM DUAL"
                    sSql += "                 UNION ALL "
                    sSql += "                SELECT 'H' cmtgbncd, '" + mc_sCmtH + "' cmtgbnnm, 9 cmtgbnsort FROM DUAL"
                End If
                sSql += "               ) b"
                sSql += "         WHERE a.cmtgbn = b.cmtgbncd"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY cmtgbnsort, cmtcd"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetCollTkCdInfo(ByVal rsCmtGbn As String, ByVal rsCmtCd As String) As DataTable
        Dim sFn As String = "Public Function GetCollTkCdInfo(Integer, String, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT '[' || a.cmtgbn || '] ' ||  b.cmtgbnnm cmtgbn_01, a.cmtcd, a.cmtcont, a.delflg,"
            sSql += "       fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, a.regid, NULL moddt, NULL modid, NULL modnm,"
            sSql += "       fn_ack_get_usr_name(a.regid) regnm"
            sSql += "  FROM lf410m a,"
            sSql += "       ("
            sSql += "        SELECT '0' cmtgbncd, '" + mc_sCmt0 + "' cmtgbnnm, 1 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL"
            sSql += "        SELECT '1' cmtgbncd, '" + mc_sCmt1 + "' cmtgbnnm, 2 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT '2' cmtgbncd, '" + mc_sCmt2 + "' cmtgbnnm, 1 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT '3' cmtgbncd, '" + mc_sCmt3 + "' cmtgbnnm, 2 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT 'A' cmtgbncd, '" + mc_sCmtA + "' cmtgbnnm, 3 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT 'B' cmtgbncd, '" + mc_sCmtB + "' cmtgbnnm, 4 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT 'C' cmtgbncd, '" + mc_sCmtC + "' cmtgbnnm, 5 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT 'D' cmtgbncd, '" + mc_sCmtD + "' cmtgbnnm, 6 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT 'E' cmtgbncd, '" + mc_sCmtE + "' cmtgbnnm, 7 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT 'F' cmtgbncd, '" + mc_sCmtF + "' cmtgbnnm, 8 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT 'G' cmtgbncd, '" + mc_sCmtG + "' cmtgbnnm, 8 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT 'H' cmtgbncd, '" + mc_sCmtH + "' cmtgbnnm, 9 cmtgbnsort FROM DUAL"
            sSql += "       ) b"
            sSql += " WHERE a.cmtgbn = b.cmtgbncd"
            sSql += "   AND a.cmtgbn = :cmtgbn"
            sSql += "   AND a.cmtcd  = :cmtcd"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("cmtgbn",  OracleDbType.Varchar2, rsCmtGbn.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCmtGbn))
            alParm.Add(New OracleParameter("cmtcd",  OracleDbType.Varchar2, rsCmtCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCmtCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetCollTkCdInfo(ByVal rsModDT As String, ByVal rsModID As String, ByVal rsCmtGbn As String, ByVal rsCmtCd As String) As DataTable
        Dim sFn As String = "Public Function GetCollTkCdInfo(String, String, String, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT '[' || a.cmtgbn || '] ' ||  b.cmtgbnnm cmtgbn_01, a.cmtcd, a.cmtcont, a.delflg,"
            sSql += "       fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, a.regid,"
            sSql += "       fn_ack_date_str(a.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, a.modid,"
            sSql += "       fn_ack_get_usr_name(a.modid) modnm, fn_ack_get_usr_name(a.regid) regnm"
            sSql += "  FROM lf410h a,"
            sSql += "       ("
            sSql += "        SELECT '0' cmtgbncd, '" + mc_sCmt0 + "' cmtgbnnm, 1 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL"
            sSql += "        SELECT '1' cmtgbncd, '" + mc_sCmt1 + "' cmtgbnnm, 2 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT '2' cmtgbncd, '" + mc_sCmt2 + "' cmtgbnnm, 1 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT '3' cmtgbncd, '" + mc_sCmt3 + "' cmtgbnnm, 2 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT 'A' cmtgbncd, '" + mc_sCmtA + "' cmtgbnnm, 3 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT 'B' cmtgbncd, '" + mc_sCmtB + "' cmtgbnnm, 4 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT 'C' cmtgbncd, '" + mc_sCmtC + "' cmtgbnnm, 5 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT 'D' cmtgbncd, '" + mc_sCmtD + "' cmtgbnnm, 6 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT 'E' cmtgbncd, '" + mc_sCmtE + "' cmtgbnnm, 7 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT 'F' cmtgbncd, '" + mc_sCmtF + "' cmtgbnnm, 8 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT 'G' cmtgbncd, '" + mc_sCmtG + "' cmtgbnnm, 8 cmtgbnsort FROM DUAL"
            sSql += "         UNION ALL "
            sSql += "        SELECT 'H' cmtgbncd, '" + mc_sCmtH + "' cmtgbnnm, 9 cmtgbnsort FROM DUAL"
            sSql += "       ) b"
            sSql += " WHERE a.cmtgbn = b.cmtgbncd"
            sSql += "   AND a.cmtgbn = :cmtgbn"
            sSql += "   AND a.cmtcd  = :cmtcd"
            sSql += "   AND a.moddt  = :moddt"
            sSql += "   AND a.modid  = :modid"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("cmtgbn",  OracleDbType.Varchar2, rsCmtGbn.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCmtGbn))
            alParm.Add(New OracleParameter("mctcd",  OracleDbType.Varchar2, rsCmtCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCmtCd))
            alParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDT.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDT))
            alParm.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModID.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModID))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentCollTkCdInfo(ByVal rsGbnCd As String, ByVal rsCd As String) As DataTable
        Dim sFn As String = "Public Function GetRecentCollTkCdInfo(String, String) As DataTable"

        Dim sSql As String = ""

        Try
            sSql += "SELECT cmtgbn, cmtcd"
            sSql += "  FROM lf410m"
            sSql += " WHERE CMTGBN = :cmtgbn"
            sSql += "   AND CMTCD  = :cmtcd"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("cmtgbn",  OracleDbType.Varchar2, rsGbnCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsGbnCd))
            alParm.Add(New OracleParameter("cmtcd",  OracleDbType.Varchar2, rsCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try

    End Function

    '< yjlee 2009-02-11
    Public Function fnGet_CollTK_Cancel_ContInfo(ByVal rsGbnCd As String) As DataTable
        Dim sFn As String = "Public Function fnGet_CollTK_Cancel_ContInfo(String) As DataTable"

        Dim sSql As String = ""

        Try
            sSql += "SELECT cmtgbn, cmtcd, cmtcont"
            sSql += "  FROM lf410m"
            sSql += " WHERE CMTGBN = :cmtgbn"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("cmtgbn",  OracleDbType.Varchar2, rsGbnCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsGbnCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try

    End Function
    '> yjlee 2009-02-11

    Public Function GetUsUeCd_CollTkCd(ByVal rsCmtGbn As String, ByVal rsCmtCd As String) As DataTable
        Dim sFn As String = "Public Function GetUsUeCd_CollTkCD() As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT cancelcd FROM lj030m"
            sSql += " WHERE cancelcd = :cancelcd"

            al.Add(New OracleParameter("cancelcd",  OracleDbType.Varchar2, (rsCmtGbn + rsCmtCd).Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCmtGbn + rsCmtCd))

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransCollTkCdInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                      ByVal rsCmtGbn As String, ByVal rsCmtCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransCollTkCdInfo(ItemTableCollection, Integer,  String, String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'lf410m : 채혈/접수 취소 사유 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf410m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF410H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf410h "
                        sSql += "SELECT fn_ack_sysdate, :modid, :modip, a.*"
                        sSql += "  FROM lf410m a"
                        sSql += " WHERE cmtgbn = :cmtgbn"
                        sSql += "   AND cmtcd  = :cmtcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("cmtgbn",  OracleDbType.Varchar2).Value = rsCmtGbn
                        dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsCmtCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        sSql = ""
                        sSql += "DELETE lf410m"
                        sSql += " WHERE cmtgbn = :cmtgbn"
                        sSql += "   AND cmtcd  = :cmtcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("cmtgbn",  OracleDbType.Varchar2).Value = rsCmtGbn
                        dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsCmtCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf410m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransCollTkCdInfo_DEL(ByVal rsCmtGbn As String, ByVal rsCmtCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = " Public Function TransCollTkCdInfo_DEL() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            sSql = ""
            sSql += "INSERT INTO lf410h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf410m f"
            sSql += " WHERE cmtgbn = :cmtgbn"
            sSql += "   AND cmtcd  = :cmtcd"

            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("cmtgbn",  OracleDbType.Varchar2).Value = rsCmtGbn
            dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsCmtCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            sSql = ""
            sSql += "DELETE lf410m"
            sSql += " WHERE cmtgbn = :cmtgbn"
            sSql += "   AND cmtcd  = :cmtcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("cmtgbn",  OracleDbType.Varchar2).Value = rsCmtGbn
            dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsCmtCd


            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransCollTkCdInfo_UE(ByVal rsCmtGbn As String, ByVal rsCmtCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransCollTkCdInfo_UE(String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'lf410m : 채혈/접수 취소 사유
            sSql = ""
            sSql += "INSERT INTO lf410h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.*"
            sSql += "  FROM lf410m f"
            sSql += " WHERE cmtgbn = :cmtgbn"
            sSql += "   AND cmtcd  = :cmtcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("cmtgbn",  OracleDbType.Varchar2).Value = rsCmtGbn
            dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsCmtCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   lf410m Delete
            sSql = ""
            sSql += "DELETE FROM lf410m"
            sSql += " WHERE cmtgbn = :cmtgbn"
            sSql += "   AND cmtcd  = :cmtcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("cmtgbn",  OracleDbType.Varchar2).Value = rsCmtGbn
            dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsCmtCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function
End Class

#End Region

#Region " APP_F_% 미생물 "
Public Class APP_F_ANTI
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_ANTI" & vbTab


    Public Function TransTestInfo_DEL(ByVal rsAntiCd As String, ByVal rsUsDt As String) As Boolean
        Dim sFn As String = " Public Function TransTestInfo_DEL() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim dt As New DataTable

            'LF220M : 항생제 마스터
            '   LF230H Insert
            sSql = ""
            sSql += "INSERT INTO lf230h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf230m f"
            sSql += " WHERE anticd = :anticd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("anticd",  OracleDbType.Varchar2).Value = rsAntiCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF230M Delete
            sSql = ""
            sSql += "DELETE lf230m"
            sSql += " WHERE anticd = :anticd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("anticd",  OracleDbType.Varchar2).Value = rsAntiCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransTestInfo_UPD_UE(ByVal rsAntiCd As String, ByVal rsUsDt As String, ByVal rsUeDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransTestInfo_UPD_UE() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim dt As New DataTable

            'LF230M : 항생제 마스터
            '   LF230H Insert
            sSql = ""
            sSql += "INSERT INTO lf230h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf230m f"
            sSql += " WHERE anticd = :anticd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("anticd",  OracleDbType.Varchar2).Value = rsAntiCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF230M Update
            sSql = ""
            sSql += "UPDATE lf230m SET"
            sSql += "       uedt   = :uedt,"
            sSql += "       regdt  = fn_ack_sysdate,"
            sSql += "       regid  = :regid"
            sSql += " WHERE anticd = :anticd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
            dbCmd.Parameters.Add("anticd",  OracleDbType.Varchar2).Value = rsAntiCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransTestInfo_UPD_US(ByVal rsAntiCd As String, ByVal rsUsDt As String, ByVal rsUsDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransTestInfo_UPD_US() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim dt As New DataTable

            'LF230M : 항생제 마스터
            '   LF230H Insert
            sSql = ""
            sSql += "INSERT INTO lf230h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf230m f"
            sSql += " WHERE anticd = :anticd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("anticd",  OracleDbType.Varchar2).Value = rsAntiCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF230M Update
            sSql = ""
            sSql += "UPDATE lf230m set"
            sSql += "       usdt   = :usdtchg,"
            sSql += "       regdt  = fn_ack_sysdate,"
            sSql += "       regid  = :regid"
            sSql += " WHERE anticd = :anticd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("usdtchg",  OracleDbType.Varchar2).Value = rsUsDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
            dbCmd.Parameters.Add("anticd",  OracleDbType.Varchar2).Value = rsAntiCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function


    Public Function GetAntiInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetAntiInfo(ByVal iMode As Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT anticd, antinmd, antiifcd, antiwncd, dispseq, usdt, uedt"
                sSql += "  FROM lf230m"
                sSql += " WHERE uedt >= fn_ack_sysdate"
                If rsSerch <> "" Then
                    sSql += "   AND " + rsSerch + ""
                End If
                sSql += " ORDER BY anticd"
            ElseIf riMode = 1 Then
                sSql += "SELECT anticd, antinmd, antiifcd, antiwncd, dispseq, usdt, uedt,"
                sSql += "       CASE WHEN TO_DATE(uedt, 'yyyymmddhh24miss') - SYSDATE < 0 THEN -1 ELSE 0 END diffday"
                sSql += "  FROM lf230m"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY anticd"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetAntiInfo(ByVal rsAntiCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetAntiInfo(ByVal iMode As Integer, ByVal asAntiCd As String, ByVal asUSDT As String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT anticd, antinm, antinms, antinmd, antinmp, antiifcd, antiwncd, dispseq,"
            sSql += "       fn_ack_date_str(usdt, 'yyyy-mm-dd hh24:mi:ss') usdt, fn_ack_date_str(uedt, 'yyyy-mm-dd hh24:mi:ss') uedt,"
            sSql += "       fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid, fn_ack_get_usr_name(regid) regnm, samecd"
            sSql += "  FROM lf230m"
            sSql += " WHERE anticd = :anticd"
            sSql += "   AND usdt   = :usdt"

            alParm.Add(New OracleParameter("anticd",  OracleDbType.Varchar2, rsAntiCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsAntiCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentAntiInfo(ByVal rsAntiCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetRecentAntiInfo(ByVal asAntiCd As String, ByVal asUSDT As String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT usdt"
            sSql += "  FROM (SELECT usdt"
            sSql += "          FROM lf230m"
            sSql += "         WHERE anticd = :anticd"
            sSql += "           AND usdt  >= :usdt"
            sSql += "         ORDER BY usdt DESC"
            sSql += "       ) a"
            sSql += " WHERE ROWNUM = 1"

            alParm.Add(New OracleParameter("anticd",  OracleDbType.Varchar2, rsAntiCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsAntiCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransAntiInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, ByVal rsAntiCd As String, ByVal rsUsDt As String) As Boolean
        Dim sFn As String = "Public Function TransAntiInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""
            Dim dt As New DataTable

            'LF230M : 항균제 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        'UPDATE uedt of previous record
                        sSql = ""
                        sSql += "UPDATE lf230m SET uedt = :usdt"
                        sSql += " WHERE (anticd, usdt) IN"
                        sSql += "       (SELECT a.anticd, a.usdt"
                        sSql += "          FROM (SELECT anticd, usdt"
                        sSql += " 				   FROM lf230m"
                        sSql += " 			      WHERE anticd = :anticd"
                        sSql += " 					AND usdt   < :usdt"
                        sSql += " 					AND uedt   > :usdt"
                        sSql += " 		          ORDER BY usdt DESC"
                        sSql += "               ) a"
                        sSql += "         WHERE ROWNUM = 1"
                        sSql += " 		)"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("anticd",  OracleDbType.Varchar2).Value = rsAntiCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf230m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF210H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf230h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf230m f"
                        sSql += " WHERE anticd = :anticd"
                        sSql += "   AND usdt   = :usdt"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("anticd",  OracleDbType.Varchar2).Value = rsAntiCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value

                                Select Case sField.ToUpper
                                    Case "ANTICD", "USDT"

                                    Case Else
                                        sFields += sField + " = :" + sField + ","

                                        dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End Select
                            Next

                            'UPDATE record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sSql = ""
                            sSql += "UPDATE lf230m SET " + sFields
                            sSql += " WHERE anticd = :anticd"
                            sSql += "   AND usdt   = :usdt"

                            dbCmd.Parameters.Add("anticd",  OracleDbType.Varchar2).Value = rsAntiCd
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                        Next
                    End With
            End Select

            '-- OCS 관련 수정
            With dbCmd
                .CommandType = CommandType.StoredProcedure
                .CommandText = "pro_ack_exe_ocs_anti"

                .Parameters.Clear()
                .Parameters.Add(New OracleParameter("rs_iud", "I"))
                .Parameters.Add(New OracleParameter("rs_anticd", rsAntiCd))
                .Parameters.Add(New OracleParameter("rs_editid", USER_INFO.USRID))
                .Parameters.Add(New OracleParameter("rs_editip", USER_INFO.LOCALIP))

                .Parameters.Add("rs_errmsg",  OracleDbType.Varchar2, 4000)
                .Parameters("rs_errmsg").Direction = ParameterDirection.InputOutput
                .Parameters("rs_errmsg").Value = ""

                .ExecuteNonQuery()

                Dim sRetVal As String = .Parameters(4).Value.ToString

                If sRetVal <> "00" Then
                    dbTran.Rollback()
                    Throw (New Exception(sRetVal.Substring(2)))
                End If
            End With


            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransAntiInfo_UE(ByVal rsAntiCd As String, ByVal rsUsDt As String, ByVal rsUeDt As String) As Boolean
        Dim sFn As String = "Public Function TransAntiInfo_UE(String, String) As Boolean"

        Dim dbCn As New OracleConnection
        Dim dbTran As OracleTransaction
        Dim dbCmd As New OracleCommand

        Try
            Dim sMsg As String = ""

            sMsg = ifExistOtherUsableData("LF230", "ANTICD", rsAntiCd, rsUsDt)

            If IsNothing(sMsg) Then
                MsgBox("쿼리문의 오류가 있습니다!!", MsgBoxStyle.Exclamation)
                Exit Function
            End If

            If Not sMsg = "" Then
                MsgBox(sMsg, MsgBoxStyle.Critical)
                Exit Function
            End If

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            dbCn = GetDbConnection()
            dbTran = dbCn.BeginTransaction()

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim dt As New DataTable

            'LF230M : 항균제 마스터
            '   LF230H Insert
            sSql = ""
            sSql += "INSERT INTO lf230h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf230m f"
            sSql += " WHERE anticd = :anticd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("anticd",  OracleDbType.Varchar2).Value = rsAntiCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF230M Update
            sSql = ""
            sSql += "UPDATE lf230m SET uedt = :uedt, regid = :regid, regdt = fn_ack_sysdate"
            sSql += " WHERE anticd = :anticd"
            sSql += "   AND usdt   = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDt
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
            dbCmd.Parameters.Add("anticd",  OracleDbType.Varchar2).Value = rsAntiCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            If dbCn.State = ConnectionState.Open Then
                dbTran.Dispose() : dbTran = Nothing
                dbCn.Close()
            End If
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function
End Class

Public Class APP_F_BAC
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_BAC" & vbTab

    '-- 2008/03/07 YEJ add
    Public Function TransTestInfo_DEL(ByVal rsBacCd As String, ByVal rsUsDt As String) As Boolean
        Dim sFn As String = " Public Function TransTestInfo_DEL() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim dt As New DataTable

            'LF210M : 균속마스터
            '   LF210H Insert
            sSql = ""
            sSql += "INSERT INTO lf210h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf210m f"
            sSql += " WHERE baccd = :baccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("baccd",  OracleDbType.Varchar2).Value = rsBacCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF210M Delete
            sSql = ""
            sSql += "DELETE lf210m"
            sSql += " WHERE baccd = :baccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("baccd",  OracleDbType.Varchar2).Value = rsBacCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    '-- 2008/03/07 YEJ add
    Public Function TransTestInfo_UPD_UE(ByVal rsBacCd As String, ByVal rsUsDt As String, ByVal rsUeDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransTestInfo_UPD_UE() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim dt As New DataTable

            'LF210M : 검사 마스터
            '   LF210H Insert
            sSql = ""
            sSql += "INSERT INTO lf210h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf210m f"
            sSql += " WHERE baccd = :baccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("baccd",  OracleDbType.Varchar2).Value = rsBacCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF210M Update
            sSql = ""
            sSql += "UPDATE lf210m SET"
            sSql += "       uedt  = :uedt,"
            sSql += "       regdt = fn_ack_sysdate,"
            sSql += "       regid = :regid"
            sSql += " WHERE baccd = :baccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
            dbCmd.Parameters.Add("baccd",  OracleDbType.Varchar2).Value = rsBacCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    '-- 2008/03/07 YEJ add
    Public Function TransTestInfo_UPD_US(ByVal rsBacCd As String, ByVal rsUsDt As String, ByVal rsUsDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransTestInfo_UPD_US() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim dt As New DataTable

            'LF210M : 검사 마스터
            '   LF210H Insert
            sSql = ""
            sSql += "INSERT INTO lf210h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf210m f"
            sSql += " WHERE baccd = :baccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("baccd",  OracleDbType.Varchar2).Value = rsBacCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF210M Update
            sSql = ""
            sSql += "UPDATE lf210m set"
            sSql += "       usdt  = :usdtchg,"
            sSql += "       regdt = fn_ack_sysdate,"
            sSql += "       regid = :regid"
            sSql += " WHERE baccd = :baccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("usdtchg",  OracleDbType.Varchar2).Value = rsUsDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
            dbCmd.Parameters.Add("baccd",  OracleDbType.Varchar2).Value = rsBacCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function GetBacInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetBacInfo(ByVal iMode As Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT baccd, bacnmd, bacgencd, bacifcd, bacwncd, usdt, uedt"
                sSql += "  FROM lf210m"
                sSql += " WHERE uedt >= fn_ack_sysdate"
                If rsSerch <> "" Then
                    sSql += "   AND " + rsSerch + ""
                End If
                sSql += " ORDER BY baccd"
            ElseIf riMode = 1 Then
                sSql += "SELECT baccd, bacnmd, bacgencd, bacifcd, bacwncd, usdt, uedt,"
                sSql += "       CASE WHEN TO_DATE(uedt, 'yyyymmddhh24miss') - SYSDATE < 0 THEN -1 ELSE 0 END diffday"
                sSql += "  FROM lf210m"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY baccd"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetBacInfo(ByVal rsBacCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetBacInfo(String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT f21.baccd, f21.bacnm, f21.bacnms, f21.bacnmd, f21.bacnmp, f21.bacgencd,"
            sSql += "       '[' || f22.bacgencd || '] ' || f22.bacgennmd bacgennmd_01, f21.bacifcd, f21.bacwncd,"
            sSql += "       fn_ack_date_str(f21.usdt, 'yyyy-mm-dd hh24:mi:ss') usdt, fn_ack_date_str(f21.uedt, 'yyyy-mm-dd hh24:mi:ss') uedt,"
            sSql += "       fn_ack_date_str(f21.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f21.regid,"
            sSql += "       fn_ack_get_usr_name(f21.regid) regnm, f21.samecd"
            sSql += "  FROM lf210m f21 LEFT OUTER JOIN lf220m f22 ON (f21.bacgencd = f22.bacgencd)"
            sSql += " WHERE f21.baccd = :baccd"
            sSql += "   AND f21.usdt  = :usdt"

            alParm.Add(New OracleParameter("baccd",  OracleDbType.Varchar2, rsBacCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsBacCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentBacInfo(ByVal rsBacCd As String, ByVal rsUSDT As String) As DataTable
        Dim sFn As String = "Public Function GetRecentBacInfo(ByVal asBacCd As String, ByVal asUSDT As String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT usdt"
            sSql += "  FROM (SELECT usdt"
            sSql += "          FROM lf210m"
            sSql += "         WHERE baccd = :baccd"
            sSql += "           AND usdt >= :usdt"
            sSql += "         ORDER BY usdt DESC"
            sSql += "       ) a"
            sSql += " WHERE ROWNUM = 1"

            alParm.Add(New OracleParameter("baccd",  OracleDbType.Varchar2, rsBacCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsBacCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUSDT.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUSDT))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function TransBacInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, ByVal rsBacCd As String, ByVal rsUsDt As String) As Boolean
        Dim sFn As String = "Public Function TransBacInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""
            Dim bITF_yn As Boolean = False
            Dim dt As New DataTable

            'LF210M : 배양균 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        'UPDATE uedt of previous record
                        sSql = ""
                        sSql += "UPDATE lf210m SET uedt = :usdt"
                        sSql += " WHERE (baccd, usdt) IN"
                        sSql += "       (SELECT a.baccd, a.usdt"
                        sSql += "          FROM (SELECT baccd, usdt"
                        sSql += "				   FROM lf210m"
                        sSql += "				  WHERE baccd = :baccd"
                        sSql += " 					AND usdt  < :usdt"
                        sSql += " 					AND uedt  > :usdt"
                        sSql += " 	              ORDER BY usdt DESC"
                        sSql += "               ) a"
                        sSql += "         WHERE ROWNUM = 1"
                        sSql += " 		)"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("baccd",  OracleDbType.Varchar2).Value = rsBacCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        If bITF_yn Then
                            sSql = ""
                            sSql += "UPDATE fkitf..itf_lis_lf210m SET uedt = :usdt"
                            sSql += " WHERE (baccd, usdt) IN"
                            sSql += "       (SELECT a.baccd, a.usdt"
                            sSql += "          FROM (SELECT baccd, usdt"
                            sSql += "				   FROM fkitf..itf_lis_lf210m"
                            sSql += "				  WHERE baccd = :baccd"
                            sSql += " 					AND usdt  < :usdt"
                            sSql += " 					AND uedt  > :usdt"
                            sSql += " 	              ORDER BY usdt DESC"
                            sSql += "               ) a"
                            sSql += "         WHERE ROWNUM = 1"
                            sSql += " 		)"

                            dbCmd.Parameters.Clear()
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                            dbCmd.Parameters.Add("baccd",  OracleDbType.Varchar2).Value = rsBacCd
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        End If

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf210m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                            If bITF_yn Then
                                sSql = "INSERT INTO fkitf..itf_lis_lf210m (" + sFields + ") VALUES (" + sValues + ")"

                                dbCmd.CommandText = sSql
                                iRet += dbCmd.ExecuteNonQuery()
                            End If

                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF210H Backup
                        sSql = ""
                        sSql = "INSERT INTO lf210h SELECT fn_ack_sysdate, :modid, :modip,  f.* FROM lf210m f"
                        sSql += " WHERE baccd = :baccd"
                        sSql += "   AND usdt  = :usdt"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("baccd",  OracleDbType.Varchar2).Value = rsBacCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value

                                Select Case sField.ToUpper
                                    Case "BACCD", "USDT"

                                    Case Else
                                        sFields += sField + " = :" + sField + ","

                                        dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End Select
                            Next

                            'UPDATE record
                            sFields = sFields.Substring(0, sFields.Length - 1)

                            sSql = ""
                            sSql += "UPDATE lf210m SET " + sFields
                            sSql += " WHERE baccd = :baccd"
                            sSql += "   AND usdt  = :usdt"

                            dbCmd.Parameters.Add("baccd",  OracleDbType.Varchar2).Value = rsBacCd
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                            If bITF_yn Then
                                sSql = ""
                                sSql += "UPDATE fkitf..itf_lis_lf210m SET " + sFields
                                sSql += " WHERE baccd = :baccd"
                                sSql += "   AND usdt  = :usdt"

                                dbCmd.CommandText = sSql
                                iRet += dbCmd.ExecuteNonQuery()
                            End If
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransBacInfo_UE(ByVal rsBacCd As String, ByVal rsUsDt As String, ByVal rsUeDt As String) As Boolean
        Dim sFn As String = "Public Function TransBacInfo_UE(String, String, String) As Boolean"

        Dim dbCn As New OracleConnection
        Dim dbTran As OracleTransaction
        Dim dbCmd As New OracleCommand

        Try
            Dim sMsg As String = ""

            sMsg = ifExistOtherUsableData("LF210", "BACCD", rsBacCd, rsUsDt)

            If IsNothing(sMsg) Then
                MsgBox("쿼리문의 오류가 있습니다!!", MsgBoxStyle.Exclamation)
                Exit Function
            End If

            If Not sMsg = "" Then
                MsgBox(sMsg, MsgBoxStyle.Critical)
                Exit Function
            End If

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            dbCn = GetDbConnection()
            dbTran = dbCn.BeginTransaction()

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim dt As New DataTable

            'LF210M : 배양균 마스터
            '   LF210H Insert
            sSql = ""
            sSql += "INSERT INTO lf210h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf210m f"
            sSql += " WHERE baccd = :baccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("baccd",  OracleDbType.Varchar2).Value = rsBacCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF210M Update
            sSql = ""
            sSql += "UPDATE lf210m SET uedt = :uedt, regdt = fn_ack_sysdate, regid = :regid"
            sSql += " WHERE baccd = :baccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDt
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
            dbCmd.Parameters.Add("baccd",  OracleDbType.Varchar2).Value = rsBacCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            If dbCn.State = ConnectionState.Open Then
                dbTran.Dispose() : dbTran = Nothing
                dbCn.Close()
            End If
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function
End Class

Public Class APP_F_CULT

    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_CULT" & vbTab

    Public Function TransCultInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                  ByVal rsCultNm As String, ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsUseDays As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function Cult() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'lf250m : 배양균속별 항균제
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf250m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'lf250h Backup
                        sSql = ""
                        sSql += "INSERT INTO lf250h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf250m f"
                        sSql += " WHERE cultnm  = :cultnm"
                        sSql += "   AND testcd  = :testcd"
                        sSql += "   AND spccd   = :spccd"
                        sSql += "   AND usedays = :usedays"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("cultnm",  OracleDbType.Varchar2).Value = rsCultNm
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                        dbCmd.Parameters.Add("usedays",  OracleDbType.Varchar2).Value = rsUseDays

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        'lf250m Delete
                        sSql = ""
                        sSql += "DELETE lf250m"
                        sSql += " WHERE cultnm  = :cultnm"
                        sSql += "   AND testcd  = :testcd"
                        sSql += "   AND spccd   = :spccd"
                        sSql += "   AND usedays = :usedays"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("cultnm",  OracleDbType.Varchar2).Value = rsCultNm
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                        dbCmd.Parameters.Add("usedays",  OracleDbType.Varchar2).Value = rsUseDays

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        'LF240M Insert
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""
                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf250m (" + sFields + ") VALUES (" + sValues + ")"


                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function GetCultiInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetCultiInfo(ByVal iMode As Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then

                sSql += "SELECT fc.cultnm, fc.testcd, fc.spccd, fc.usedays, fc.usedaye, f6.tnmd || '[' || f3.spcnmd || ']' tnmd"
                sSql += "  FROM lf250m fc, lf060m f6, lf030m f3"
                sSql += " WHERE fc.testcd = f6.testcd"
                sSql += "   AND fc.spccd  = f6.spccd"
                sSql += "   AND f6.usdt  <= fn_ack_sysdate"
                sSql += "   AND f6.uedt  >  fn_ack_sysdate"
                sSql += "   AND fc.spccd  = f3.spccd"
                sSql += "   AND f3.usdt  <= fn_ack_sysdate"
                sSql += "   AND f3.uedt  >  fn_ack_sysdate"

                If rsSerch <> "" Then
                    sSql += "   AND " + rsSerch + ""
                End If
                sSql += " ORDER BY fc.cultnm, fc.testcd, fc.spccd"

            ElseIf riMode = 1 Then
                sSql += "SELECT fc.cultnm, fc.testcd, fc.spccd, fc.usedays, fc.usedaye, f6.tnmd || '[' || f3.spcnmd || ']' tnmd,"
                sSql += "       '' modid, '' moddt, 0 diffday"
                sSql += "  FROM lf250m fc, lf060m f6, lf030m f3"
                sSql += " WHERE fc.testcd = f6.testcd"
                sSql += "   AND fc.spccd  = f6.spccd"
                sSql += "   AND f6.usdt  <= fn_ack_sysdate"
                sSql += "   AND f6.uedt  >  fn_ack_sysdate"
                sSql += "   AND fc.spccd  = f3.spccd"
                sSql += "   AND f3.usdt  <= fn_ack_sysdate"
                sSql += "   AND f3.uedt  >  fn_ack_sysdate"

                If rsSerch <> "" Then
                    sSql += "   AND " + rsSerch + ""
                End If
                sSql += " UNION ALL "
                sSql += "SELECT fc.cultnm, fc.testcd, fc.spccd, fc.usedays, fc.usedaye, f6.tnmd || '[' || f3.spcnmd || ']' tnmd,"
                sSql += "      fc.modid, fn_ack_date_str(fc.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, -1 diffday"
                sSql += "  FROM lf250h fc, lf060m f6, lf030m f3"
                sSql += " WHERE fc.testcd = f6.testcd"
                sSql += "   AND fc.spccd  = f6.spccd"
                sSql += "   AND f6.usdt  <= fn_ack_sysdate"
                sSql += "   AND f6.uedt  >  fn_ack_sysdate"
                sSql += "   AND fc.spccd  = f3.spccd"
                sSql += "   AND f3.usdt  <= fn_ack_sysdate"
                sSql += "   AND f3.uedt  >  fn_ack_sysdate"

                If rsSerch <> "" Then
                    sSql += "   AND " + rsSerch + ""
                End If
                sSql += " ORDER BY cultnm, testcd, spccd"

            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetCultInfo(ByVal rsCultNm As String, ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsUseDayS As String) As DataTable
        Dim sFn As String = "Public Function GetBacInfo(ByVal iMode As Integer, ByVal asBacCd As String, ByVal asUSDT As String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT a.cultnm, a.testcd, a.spccd, a.usedays, a.usedaye, a.bccnt, fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt,"
            sSql += "       a.regid, b.tnmd, c.spcnmd, fn_ack_get_usr_name(a.regid) regnm"
            sSql += "  FROM lf250m a, lf060m b, lf030m c"
            sSql += " WHERE a.testcd  = :testcd"
            sSql += "   AND a.spccd   = :spccd"
            sSql += "   AND a.cultnm  = :cultnm"
            sSql += "   AND a.usedays = :usedays"
            sSql += "   AND a.spccd   = b.spccd"
            sSql += "   AND a.testcd  = b.testcd"
            sSql += "   AND b.usdt   <  fn_ack_sysdate"
            sSql += "   AND b.uedt   >= fn_ack_sysdate"
            sSql += "   AND a.spccd  =  c.spccd"
            sSql += "   AND c.usdt   <  fn_ack_sysdate"
            sSql += "   AND c.uedt   >= fn_ack_sysdate"
            sSql += " ORDER BY a.cultnm, a.testcd, a.spccd"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            alParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
            alParm.Add(New OracleParameter("cultnm",  OracleDbType.Varchar2, rsCultNm.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCultNm))
            alParm.Add(New OracleParameter("usedays",  OracleDbType.Varchar2, rsUseDayS.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUseDayS))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function


    Public Function GetCultInfo(ByVal rsCultNm As String, ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsUseDayS As String, ByVal rsModid As String, ByVal rsModdt As String) As DataTable
        Dim sFn As String = "Public Function GetBacInfo(ByVal iMode As Integer, ByVal asBacCd As String, ByVal asUSDT As String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT a.cultnm, a.testcd, a.spccd, a.usedays, a.usedaye, a.bccnt, fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt,"
            sSql += "       a.regid, b.tnmd, c.spcnmd, modid, fn_ack_date_str(a.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt,"
            sSql += "       fn_ack_get_usr_name(a.regid) usernm, fn_ack_get_usr_name(a.modid) modnm"
            sSql += "  FROM lf250h a, lf060m b, lf030m c"
            sSql += " WHERE a.testcd  = :testcd"
            sSql += "   AND a.spccd   = :spccd"
            sSql += "   AND a.cultnm  = :cultnm"
            sSql += "   AND a.usedays = :usedays"
            sSql += "   AND a.moddt   = :moddt"
            sSql += "   AND a.modid   = :modip"
            sSql += "   AND a.spccd   = b.spccd"
            sSql += "   AND a.testcd  = b.testcd"
            sSql += "   AND b.usdt    < fn_ack_sysdate"
            sSql += "   AND b.uedt   >= fn_ack_sysdate"
            sSql += "   AND a.spccd   = c.spccd"
            sSql += "   AND c.usdt    < fn_ack_sysdate"
            sSql += "   AND c.uedt    >= fn_ack_sysdate"
            sSql += " ORDER BY a.cultnm, a.testcd, a.spccd"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            alParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
            alParm.Add(New OracleParameter("cultnm",  OracleDbType.Varchar2, rsCultNm.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCultNm))
            alParm.Add(New OracleParameter("usedays",  OracleDbType.Varchar2, rsUseDayS.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUseDayS))
            alParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModdt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModdt))
            alParm.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModid.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModid))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransCultInfo_UE(ByVal rsCultnm As String, ByVal rsTestcd As String, ByVal rsSpccd As String, ByRef rsUsedays As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = " Public Function CultInfo_DEL() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'lf250m : 배지마스터
            '   lf250h Insert
            sSql = ""
            sSql += "INSERT INTO lf250h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf250m f"
            sSql += " WHERE cultnm  = :cultnm"
            sSql += "   AND testcd  = :testcd"
            sSql += "   AND spccd   = :spccd"
            sSql += "   AND usedays = :usedays"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("cultnm",  OracleDbType.Varchar2).Value = rsCultnm
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestcd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpccd
            dbCmd.Parameters.Add("usedays",  OracleDbType.Varchar2).Value = rsUsedays

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   lf250m Delete
            sSql = ""
            sSql += "DELETE lf250m"
            sSql += " WHERE cultnm  = :cultnm"
            sSql += "   AND testcd  = :testcd"
            sSql += "   AND spccd   = :spccd"
            sSql += "   AND usedays = :usedays"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("cultnm",  OracleDbType.Varchar2).Value = rsCultnm
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestcd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpccd
            dbCmd.Parameters.Add("usedays",  OracleDbType.Varchar2).Value = rsUsedays

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()

            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

End Class

Public Class APP_F_BACGEN
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_BACGEN" & vbTab

    Public Overloads Function GetBacgenInfo(ByVal riMod As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetBacgenInfo(ByVal iMode As Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMod = 0 Then
                sSql += "SELECT bacgencd, bacgennm, bacgennms, bacgennmd, bacgennmp, fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid"
                sSql += "  FROM lf220m"
                If rsSerch <> "" Then
                    sSql += " WHERE " & rsSerch & ""
                End If
                sSql += " ORDER BY bacgencd"
            Else
                sSql += "SELECT bacgencd, bacgennm, bacgennms, bacgennmd, bacgennmp, fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid, "
                sSql += "       1 diffday, '' modid, '' moddt"
                sSql += "  FROM lf220m"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " UNION ALL "
                sSql += "SELECT bacgencd, bacgennm, bacgennms, bacgennmd, bacgennmp, fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid,"
                sSql += "       -1 diffday, modid, fn_ack_date_str(moddt, 'yyyy-mm-dd hh24:mi:ss') moddt"
                sSql += "  FROM lf220h"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY bacgencd"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Overloads Function GetBacgenInfo(ByVal rsBacgenCd As String) As DataTable
        Dim sFn As String = "Public Function GetBacgenInfo(ByVal iMode As Integer, ByVal asBacgenCd As String, ByVal asUSDT As String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT bacgencd, bacgennm, bacgennms, bacgennmd, bacgennmp,"
            sSql += "       fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid,"
            sSql += "       fn_ack_get_usr_name(regid) regnm, dispseq"
            sSql += "  FROM lf220m"
            sSql += " WHERE bacgencd = :bgencd"

            alParm.Add(New OracleParameter("bgencd",  OracleDbType.Varchar2, rsBacgenCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsBacgenCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))


        End Try
    End Function

    Public Overloads Function GetBacgenInfo(ByVal rsBacgenCd As String, ByVal rsModDt As String, ByVal rsModId As String) As DataTable
        Dim sFn As String = "Public Function GetBacgenInfo(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT bacgencd, bacgennm, bacgennms, bacgennmd, bacgennmp,"
            sSql += "       fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid,"
            sSql += "       fn_ack_date_str(moddt, 'yyyy-mm-dd hh24:mi:ss') modt, modid,"
            sSql += "       fn_ack_get_usr_name(regid) regnm, dispseq"
            sSql += "  FROM lf220h"
            sSql += " WHERE bacgencd = :bgencd"
            sSql += "   AND moddt    = :moddt"
            sSql += "   AND modid    = :modid"

            alParm.Add(New OracleParameter("bgencd",  OracleDbType.Varchar2, rsBacgenCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsBacgenCd))
            alParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDt))
            alParm.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModId.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModId))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentBacgenInfo(ByVal rsBacgenCd As String) As DataTable
        Dim sFn As String = "Public Function GetRecentBacgenInfo(String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList


            sSql += "SELECT bacgencd"
            sSql += "  FROM (SELECT bacgencd"
            sSql += "          FROM lf220m"
            sSql += "         WHERE bacgencd = :bgencd"
            sSql += "         ORDER BY bacgencd DESC"
            sSql += "       ) a"
            sSql += " WHERE ROWNUM = 1"

            alParm.Add(New OracleParameter("bgencd",  OracleDbType.Varchar2, rsBacgenCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsBacgenCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransBacgenInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                    ByVal rsBacgenCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransBacgenInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF220M : 배양균속마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf220m (" + sFields + ") VALUES (" + sValues + ")"


                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF220H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf220h SELECT fn_ack_sysdate, :modid, :modip,  f.* FROM lf220m f"
                        sSql += " WHERE bacgencd = :bgencd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("bgencd",  OracleDbType.Varchar2).Value = rsBacgenCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value

                                Select Case sField.ToUpper
                                    Case "BACGENCD"

                                    Case Else
                                        sFields += sField + " = :" + sField + ","
                                        dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End Select
                            Next

                            'UPDATE record
                            sFields = sFields.Substring(0, sFields.Length - 1)

                            sSql = ""
                            sSql += "UPDATE lf220m SET " + sFields
                            sSql += " WHERE bacgencd = :bgencd"

                            dbCmd.Parameters.Add("bgencd",  OracleDbType.Varchar2).Value = rsBacgenCd

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransBacgenInfo_UE(ByVal rsBacgenCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransBacgenInfo_UE(ByVal asBacgenCd As String, ByVal asUSDT As String, ByVal asRegID As String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF220M : 배양균속 마스터
            '   LF220H Insert
            sSql = ""
            sSql += "INSERT INTO lf220h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf220m f"
            sSql += " WHERE bacgencd = :bgencd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("bgencd",  OracleDbType.Varchar2).Value = rsBacgenCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF220M Update
            sSql = ""
            sSql += "DELETE lf220m"
            sSql += " WHERE bacgencd = :bgencd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("bgencd",  OracleDbType.Varchar2).Value = rsBacgenCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function
End Class

Public Class APP_F_BAC_RST
    Inherits APP_F
    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_BAC_RST" & vbTab

    Public Function GetBacRstInfo(ByVal iMode As Integer, ByVal Serch As String, ByVal asNull As String) As DataTable
        Dim sFn As String = "Public Function GetBacRstInfo(ByVal iMode As Integer, ByVal Serch As String, ByVal asNull As String) As DataTable"

        Try
            Dim sSql As String = ""

            If iMode = 0 Then
                sSql += "SELECT f2.testcd, f2.spccd, f2.incrstcd, f2.incrstnm, fn_ack_date_str(f2.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f6.tnmd, f3.spcnmd"
                sSql += "  FROM lf211m f2, lf060m f6, lf030m f3"
                sSql += " WHERE f2.testcd = f6.testcd"
                sSql += "   AND f2.spccd  = f6.spccd"
                sSql += "   AND f6.usdt  <= fn_ack_sysdate"
                sSql += "   AND f6.uedt  >  fn_ack_sysdate"
                sSql += "   AND f2.spccd  = f3.spccd"
                sSql += "   AND f3.usdt  <= fn_ack_sysdate"
                sSql += "   AND f3.uedt  >  fn_ack_sysdate"

                If Serch <> "" Then
                    sSql += "   AND " + Serch + ""
                End If
                sSql += " ORDER BY f2.testcd, f2.spccd, f2.incrstcd"
            ElseIf iMode = 1 Then
                sSql += "SELECT f2.testcd, f2.spccd, f2.incrstcd, f2.incrstnm, fn_ack_date_str(f2.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f6.tnmd, f3.spcnmd,"
                sSql += "       NULL moddt, NULL modid, 1 diffday"
                sSql += "  FROM lf211m f2, lf060m f6, lf030m f3"
                sSql += " WHERE f2.testcd = f6.testcd"
                sSql += "   AND f2.spccd  = f6.spccd"
                sSql += "   AND f6.usdt  <= fn_ack_sysdate"
                sSql += "   AND f6.uedt   > fn_ack_sysdate"
                sSql += "   AND f2.spccd  = f3.spccd"
                sSql += "   AND f3.usdt  <= fn_ack_sysdate"
                sSql += "   AND f3.uedt   > fn_ack_sysdate"
                If Serch <> "" Then
                    sSql += "   AND " + Serch + ""
                End If
                sSql += " UNION "
                sSql += "SELECT f2.testcd, f2.spccd, f2.incrstcd, f2.incrstnm, fn_ack_date_str(f2.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f6.tnmd, f3.spcnmd,"
                sSql += "       fn_ack_date_str(moddt,'yyyy-mm-dd hh24:mi:ss') moddt, modid, -1 diffday"
                sSql += "  FROM lf211h f2, lf060m f6, lf030m f3"
                sSql += " WHERE f2.testcd = f6.testcd"
                sSql += "   AND f2.spccd  = f6.spccd"
                sSql += "   AND f6.usdt  <= fn_ack_sysdate"
                sSql += "   AND f6.uedt   > fn_ack_sysdate"
                sSql += "   AND f2.spccd  = f3.spccd"
                sSql += "   AND f3.usdt  <= fn_ack_sysdate"
                sSql += "   AND f3.uedt   > fn_ack_sysdate"
                If Serch <> "" Then
                    sSql += "   AND " + Serch + ""
                End If
                sSql += " ORDER BY testcd, spccd, incrstcd"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetBacRstInfo(ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsIncCd As String) As DataTable
        Dim sFn As String = "Public Function GetBacRstInfo(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim arlParm As New ArrayList

            sSql += "SELECT f2.testcd, f2.spccd, f2.incrstcd, f2.incrstnm,"
            sSql += "       fn_ack_date_str(f2.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f2.regid,"
            sSql += "       fn_ack_get_usr_name(f2.regid) usernm,"
            sSql += "       f6.tnmd, f3.spcnmd"
            sSql += "  FROM lf211m f2, lf060m f6, lf030m f3"
            sSql += " WHERE f2.testcd = f6.testcd"
            sSql += "   AND f2.spccd  = f6.spccd"
            sSql += "   AND f6.usdt  <= fn_ack_sysdate"
            sSql += "   AND f6.uedt   > fn_ack_sysdate"
            sSql += "   AND f2.spccd  = f3.spccd"
            sSql += "   AND f3.usdt  <= fn_ack_sysdate"
            sSql += "   AND f3.uedt   > fn_ack_sysdate"
            sSql += "   AND f2.testcd = :testcd"
            sSql += "   AND f2.spccd  = :spccd"
            sSql += "   AND f2.incrstcd = :inccd"

            arlParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            arlParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
            arlParm.Add(New OracleParameter("inccd",  OracleDbType.Varchar2, rsIncCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsIncCd))

            DbCommand()
            Return DbExecuteQuery(sSql, arlParm)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))


        End Try
    End Function

    Public Function GetBacRstInfo(ByVal rsModDt As String, ByVal rsModId As String, ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsIncCd As String) As DataTable
        Dim sFn As String = "Public Function GetBacRstInfo(string, string, String, string, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim arlParm As New ArrayList

            sSql += "SELECT f2.testcd, f2.spccd, f2.incrstcd, f2.incrstnm,"
            sSql += "       fn_ack_date_str(f2.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f2.regid, fn_ack_get_usr_name(f2.regid) usernm,"
            sSql += "       fn_ack_date_str(f2.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, f2.modid, fn_ack_get_usr_name(f2.modid) modnm,"
            sSql += "       f6.tnmd, f3.spcnmd"
            sSql += "  FROM lf211h f2, lf060m f6, lf030m f3"
            sSql += " WHERE f2.testcd   = f6.testcd"
            sSql += "   AND f2.spccd    = f6.spccd"
            sSql += "   AND f6.usdt    <= fn_ack_sysdate"
            sSql += "   AND f6.uedt    > fn_ack_sysdate"
            sSql += "   AND f2.spccd    = f3.spccd"
            sSql += "   AND f3.usdt    <= fn_ack_sysdate"
            sSql += "   AND f3.uedt    >  fn_ack_sysdate"
            sSql += "   AND f2.moddt    = :moddt"
            sSql += "   AND f2.modid    = :modid"
            sSql += "   AND f2.testcd   = :testcd"
            sSql += "   AND f2.spccd    = :spccd"
            sSql += "   AND f2.incrstcd = :inccd"

            arlParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDt))
            arlParm.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModId.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModId))
            arlParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            arlParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
            arlParm.Add(New OracleParameter("inccd",  OracleDbType.Varchar2, rsIncCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsIncCd))

            DbCommand()
            Return DbExecuteQuery(sSql, arlParm)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransBacRstInfo(ByVal roITcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                    ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsIncCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransBacRstInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF211M : 균 결과
            Select Case riType1
                Case 0      '----- 신규
                    With roITcol1
                        'UPDATE uedt of previous record
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf211m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With roITcol1
                        'LF211H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf211h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf211m f"
                        sSql += " WHERE testcd   = :testcd"
                        sSql += "   AND spccd    = :spccd"
                        sSql += "   AND incrstcd = :inccd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                        dbCmd.Parameters.Add("inccd",  OracleDbType.Varchar2).Value = rsIncCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        'LF211M Delete
                        sSql = ""
                        sSql += "DELETE lf211m"
                        sSql += " WHERE testcd   = :testcd"
                        sSql += "   AND spccd    = :spccd"
                        sSql += "   AND incrstcd = :inccd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                        dbCmd.Parameters.Add("inccd",  OracleDbType.Varchar2).Value = rsIncCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        'LF211M Insert
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf211m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransBacRstInfo_UE(ByVal rsTestCd As String, ByVal rsSpcCd As String, ByVal rsIncCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransBacRstInfo_UE(string, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF211M : 균 결과 마스터
            '   LF211H Insert
            sSql = ""
            sSql += "INSERT INTO lf211h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf211m f"
            sSql += " WHERE testcd   = :testcd"
            sSql += "   AND spccd    = :spccd"
            sSql += "   AND incrstcd = :inccd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("inccd",  OracleDbType.Varchar2).Value = rsIncCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF211M Update
            sSql = ""
            sSql += "DELETE lf211m"
            sSql += " WHERE testcd   = :testcd"
            sSql += "   AND spccd    = :spccd"
            sSql += "   AND incrstcd = :inccd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("inccd",  OracleDbType.Varchar2).Value = rsIncCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()


            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function
End Class

Public Class APP_F_BACGEN_ANTI
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_BACGEN_ANTI" & vbTab

 
    Public Function GetBacgenAntiInfo(ByVal iMode As Integer, ByVal Serch As String) As DataTable
        Dim sFn As String = "Public Function GetBacgenAntiInfo(ByVal iMode As Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If iMode = 0 Then
                sSql += "SELECT bacgencd, bacgennmd, testmtd"
                sSql += "  FROM ("
                sSql += "        SELECT DISTINCT f24.bacgencd, f22.bacgennmd, f24.testmtd"
                sSql += "          FROM lf220m f22, lf240m f24"
                sSql += "         WHERE f22.bacgencd = f24.bacgencd"
                sSql += "       ) a"
                If Serch <> "" Then
                    sSql += " WHERE " + Serch + ""
                End If
                sSql += " ORDER BY bacgencd, testmtd"
            ElseIf iMode = 1 Then
                sSql += "SELECT bacgencd, bacgennmd, testmtd, diffday, modid, moddt"
                sSql += "  FROM ("
                sSql += "         SELECT DISTINCT f24.bacgencd, f22.bacgennmd, f24.testmtd, '1' diffday, '' modid, '' moddt"
                sSql += "           FROM lf220m f22, lf240m f24"
                sSql += "          WHERE f22.bacgencd = f24.bacgencd"
                sSql += "          UNION ALL "
                sSql += "         SELECT DISTINCT f24.bacgencd, f22.bacgennmd, f24.testmtd, '-1' diffday, f24.modid, fn_ack_date_str(f24.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt"
                sSql += "           FROM lf220m f22, lf240h f24"
                sSql += "          WHERE f22.bacgencd = f24.bacgencd"
                sSql += "        ) a"
                If Serch <> "" Then
                    sSql += " WHERE " + Serch + ""
                End If
                sSql += " ORDER BY bacgencd, testmtd"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function


    Public Function GetBacgenAntiInfo(ByVal rsBacgenCd As String, ByVal rsTestMtd As String) As DataTable
        Dim sFn As String = "Public Function GetBacgenAntiInfo(ByVal iMode As Integer, ByVal asBacgenCd As String, ByVal asTestMtd As String, ByVal asUSDT As String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT NVL(f24.chk, '0') chk, f23.anticd, f23.antinmd, f24.dispseq, f24.refr, f24.refs,"
            sSql += "       fn_ack_date_str(f24.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f24.regid,"
            sSql += "       fn_ack_get_usr_name(f24.regid) regnm, null modid, null moddt, null modnm"
            sSql += "  FROM lf230m f23 LEFT OUTER JOIN"
            sSql += "       ("
            sSql += "        SELECT '1' chk, f24.anticd, f24.dispseq, f24.refr, f24.refs, f24.regdt, f24.regid"
            sSql += "          FROM lf230m f23, lf240m f24"
            sSql += "         WHERE f23.anticd = f24.anticd"
            sSql += "           AND f24.bacgencd = :bgencd"
            sSql += "           AND f24.testmtd  = :testmtd"
            sSql += "           AND f23.uedt >= '30000101000000'"
            sSql += "       ) f24 ON (f23.anticd = f24.anticd)"
            sSql += " WHERE f23.uedt >= '30000101000000'"
            sSql += " ORDER BY f24.chk, f24.dispseq, f23.dispseq, f23.antinmd"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("bgencd",  OracleDbType.Varchar2, rsBacgenCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsBacgenCd))
            alParm.Add(New OracleParameter("testmtd",  OracleDbType.Varchar2, rsTestMtd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestMtd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetBacgenAntiInfo(ByVal rsBacgenCd As String, ByVal rsTestMtd As String, ByVal rsModDt As String, ByVal rsModId As String) As DataTable
        Dim sFn As String = "Public Function GetBacgenAntiInfo(ByVal iMode As Integer, ByVal asBacgenCd As String, ByVal asTestMtd As String, ByVal asUSDT As String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT NVL(f24.chk, '0') chk, f23.anticd, f23.antinmd, f24.dispseq, f24.refr, f24.refs,"
            sSql += "       fn_ack_date_str(f24.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f24.regid,"
            sSql += "       fn_ack_get_usr_name(f24.regid) regnm,  fn_ack_get_usr_name(f24.modid) modnm,"
            sSql += "       fn_ack_date_str(f24.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt"
            sSql += "  FROM lf230m f23 LEFT OUTER JOIN"
            sSql += "       ("
            sSql += "        SELECT '1' chk, f24.anticd, f24.dispseq, f24.refr, f24.refs, f24.regdt, f24.regid, f24.modid, f24.moddt"
            sSql += "          FROM lf230m f23, lf240h f24"
            sSql += "         WHERE f23.anticd = f24.anticd"
            sSql += "           AND f24.bacgencd = :bgencd"
            sSql += "           AND f24.testmtd  = :testmtd"
            sSql += "           AND f24.moddt    = :moddt"
            sSql += "           AND f24.modid    = :modid"
            sSql += "       ) f24 ON (f23.anticd = f24.anticd)"
            sSql += " ORDER BY f24.chk DESC, f24.dispseq, f23.dispseq, f23.antinmd"
  
            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("bgencd",  OracleDbType.Varchar2, rsBacgenCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsBacgenCd))
            alParm.Add(New OracleParameter("testmtd",  OracleDbType.Varchar2, rsTestMtd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestMtd))
            alParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDt))
            alParm.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModId.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModId))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentBacgenAntiInfo(ByVal rsBacgenCd As String, ByVal rsTestMtd As String) As DataTable
        Dim sFn As String = "Public Function GetRecentBacgenAntiInfo(ByVal asBacgenCd As String, ByVal asTestMtd As String, ByVal asUSDT As String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT bacgencd"
            sSql += "  FROM (SELECT bacgencd"
            sSql += "          FROM lf240m"
            sSql += "         WHERE bacgencd = :bgencd"
            sSql += "           AND testmtd  = :testmtd"
            sSql += "         ORDER BY bacgencd desc"
            sSql += "       ) a"
            sSql += " WHERE ROWNUM = 1"

            alParm.Add(New OracleParameter("bgencd",  OracleDbType.Varchar2, rsBacgenCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsBacgenCd))
            alParm.Add(New OracleParameter("testmtd",  OracleDbType.Varchar2, rsTestMtd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestMtd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))


        End Try
    End Function

    Public Function TransBacgenAntiInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                        ByVal rsBacgenCd As String, ByVal rsTestMtd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransBacgenAntiInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF240M : 배양균속별 항균제
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                If sValue = "" Then
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = DBNull.Value
                                Else
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End If
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf240m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF240H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf240h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf240m f"
                        sSql += " WHERE bacgencd = :bgencd"
                        sSql += "   AND testmtd  = :testmtd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("bgencd",  OracleDbType.Varchar2).Value = rsBacgenCd
                        dbCmd.Parameters.Add("testmtd",  OracleDbType.Varchar2).Value = rsTestMtd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        'LF240M Delete
                        sSql = " DELETE FROM lf240m"
                        sSql += " WHERE bacgencd = :bgencd"
                        sSql += "   AND testmtd  = :testmtd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("bgencd",  OracleDbType.Varchar2).Value = rsBacgenCd
                        dbCmd.Parameters.Add("testmtd",  OracleDbType.Varchar2).Value = rsTestMtd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        'LF240M Insert
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                If sValue = "" Then
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = DBNull.Value
                                Else
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End If

                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf240m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransBacgenAntiInfo_DEL(ByVal rsBacGenCd As String, ByVal rsTestMtd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = " Public Function TransTestInfo_DEL() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF240M : 균속마스터
            '   LF220H Insert
            sSql = ""
            sSql += "INSERT INTO lf240h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf240m f"
            sSql += " WHERE bacgencd = :bgencd"
            sSql += "   AND testmtd  = :testmtd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("bgencd",  OracleDbType.Varchar2).Value = rsBacGenCd
            dbCmd.Parameters.Add("testmtd",  OracleDbType.Varchar2).Value = rsTestMtd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF220M Delete
            sSql = ""
            sSql += "DELETE lf240m"
            sSql += " WHERE bacgencd = :bgencd"
            sSql += "   AND testmtd  = :testmtd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("bgencd",  OracleDbType.Varchar2).Value = rsBacGenCd
            dbCmd.Parameters.Add("testmtd",  OracleDbType.Varchar2).Value = rsTestMtd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransBacgenAntiInfo_UE(ByVal rsBacgenCd As String, ByVal rsTestMtd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransBacgenAntiInfo_UE(String, String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF240M : 배양균속별 항균제 마스터
            '   LF240H Insert
            sSql = ""
            sSql += "INSERT INTO lf240h SELECT fn_ack_sysdate, :modid, :modip,  f.* FROM lf240m f"
            sSql += " WHERE bacgencd = :bgencd"
            sSql += "   AND testmtd  = :testmtd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("bgencd",  OracleDbType.Varchar2).Value = rsBacgenCd
            dbCmd.Parameters.Add("testmtd",  OracleDbType.Varchar2).Value = rsTestMtd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF240M Update
            sSql = ""
            sSql += "DELETE lf240m"
            sSql += " WHERE bacgencd = :bgencd"
            sSql += "   AND testmtd  = :testmtd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("bgencd",  OracleDbType.Varchar2).Value = rsBacgenCd
            dbCmd.Parameters.Add("testmtd",  OracleDbType.Varchar2).Value = rsTestMtd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function
End Class
#End Region

#Region " APP_F_% 특수검사"
Public Class APP_F_SPTEST
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_SPTEST" & vbTab

    Public Function GetSpTestInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetSpTestInfo(ByVal iMode As Integer, ByVal Serch As String, ByVal asNull As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT testcd, tnmd tnmd_01 "
                sSql += "  FROM ("
                sSql += "        SELECT f31.testcd, MIN(f60.tnmd) tnmd"
                sSql += "          FROM lf310m f31, lf060m f60"
                sSql += "         WHERE f31.testcd = f60.testcd"
                sSql += "           AND f60.usdt  <= fn_ack_sysdate"
                sSql += "           AND f60.uedt   > fn_ack_sysdate"
                sSql += "         GROUP BY f31.testcd"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY testcd"

            ElseIf riMode = 1 Then
                sSql += "SELECT testcd, tnmd tnmd_01, diffday, moddt, modid"
                sSql += "  FROM ("
                sSql += "        SELECT f31.testcd, MIN(f60.tnmd) tnmd,"
                sSql += "               null diffday, null moddt, null modid"
                sSql += "          FROM lf310m f31, lf060m f60"
                sSql += "         WHERE f31.testcd = f60.testcd"
                sSql += "           AND f60.usdt  <= fn_ack_sysdate"
                sSql += "           AND f60.uedt  >  fn_ack_sysdate"
                sSql += "         GROUP BY f31.testcd"
                sSql += "         UNION ALL "
                sSql += "         SELECT f31.testcd, MIN(f60.tnmd) tnmd,"
                sSql += "                -1 diffday, fn_ack_date_str(f31.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, f31.modid modid"
                sSql += "           FROM lf310h f31, lf060m f60"
                sSql += "          WHERE f31.testcd = f60.testcd"
                sSql += "            AND f60.usdt  <= f31.moddt"
                sSql += "            AND f60.uedt  >  f31.moddt"
                sSql += "          GROUP BY f31.testcd, f31.moddt, f31.modid"
                sSql += "        ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY testcd, moddt, modid"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetSpTestInfo(ByVal rsTestCd As String) As DataTable
        Dim sFn As String = "Public Function GetSpTestInfo(ByVal iMode As Integer, ByVal asTClsCd As String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT f31.testcd, f31.stsubseq, f60.tnmd, f31.strsttxtr, f31.strsttxtm, f31.strsttxtf,"
            sSql += "       f31.stsubcnt, f31.stsubnm, f31.stsubtype, f31.imgtype, f31.imgsizew, f31.imgsizeh,"
            sSql += "       f31.stsubrtf, f31.stsubexprg, f31.stsubfirst,"
            sSql += "       fn_ack_date_str(f31.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f31.regid,"
            sSql += "       fn_ack_get_usr_name(f31.regid) regnm, null modnm "
            sSql += "  FROM (SELECT f31.testcd, MIN(f60.tnmd) tnmd"
            sSql += "          FROM lf310m f31, lf060m f60"
            sSql += " 		  WHERE f31.testcd = f60.testcd"
            sSql += "		    AND f60.usdt  <= fn_ack_sysdate"
            sSql += "		    AND f60.uedt  >  fn_ack_sysdate"
            sSql += " 		    AND f31.testcd = :testcd"
            sSql += " 		  GROUP BY f31.testcd"
            sSql += "       ) f60,"
            sSql += " 	    lf310m f31"
            sSql += " WHERE f31.testcd   = f60.testcd"
            sSql += " ORDER BY f31.testcd, f31.stsubseq"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetSpTestInfo(ByVal rsModDt As String, ByVal rsModId As String, ByVal rsTestCd As String) As DataTable
        Dim sFn As String = "Public Function GetSpTestInfo(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT f31.testcd, f31.stsubseq, f60.tnmd, f31.strsttxtr, f31.strsttxtm, f31.strsttxtf,"
            sSql += "       f31.stsubcnt, f31.stsubnm, f31.stsubtype, f31.imgtype, f31.imgsizew, f31.imgsizeh,"
            sSql += "       f31.stsubrtf, f31.stsubexprg, f31.stsubfirst,"
            sSql += "       fn_ack_date_str(f31.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f31.regid,"
            sSql += "       fn_ack_get_usr_name(f31.regid) regnm, null modnm "
            sSql += "  FROM (SELECT f31.testcd, MIN(f60.tnmd) tnmd"
            sSql += "          FROM lf310h f31, lf060m f60"
            sSql += " 		  WHERE f31.testcd = f60.testcd"
            sSql += "		    AND f60.usdt  <= fn_ack_sysdate"
            sSql += "		    AND f60.uedt  >  fn_ack_sysdate"
            sSql += " 		    AND f31.testcd = :testcd"
            sSql += " 		  GROUP BY f31.testcd"
            sSql += "       ) f60,"
            sSql += " 	    lf310h f31"
            sSql += " WHERE f31.testcd = f60.testcd"
            sSql += "   AND f31.moddt  = :moddt"
            sSql += "   AND f31.modid  = :modid"
            sSql += " ORDER BY f31.testcd, f31.stsubseq"

            alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))
            alParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDt))
            alParm.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModId.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModId))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentSpTestInfo(ByVal rsTestCd As String) As DataTable
        Dim sFn As String = "Public Function GetRecentSpTestInfo(ByVal asTClsCd As String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT testcd"
            sSql += "  FROM lf310m"
            sSql += " WHERE testcd = :testcd"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Overloads Function GetTClsCdInfo(ByVal rsTestCd As String) As DataTable
        Dim sFn As String = "Public Function GetTClsCdInfo(String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT MIN(tnmd) tnmd, MIN(tcdgbn) tcdgbn_min, MAX(tcdgbn) tcdgbn_max"
            sSql += "  FROM lf060m"
            sSql += " WHERE testcd = :testcd"
            sSql += "   AND usdt  <= fn_ack_sysdate"
            sSql += "   AND uedt  >  fn_ack_sysdate"

            alParm.Add(New OracleParameter("testcd",  OracleDbType.Varchar2, rsTestCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsTestCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransSpTestInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                        ByVal rsTestCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransSpTestInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Dim sSql As String = ""
        Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

        Dim iRet As Integer = 0

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        'LF310M Insert
                        For i As Integer = 1 To .ItemTableRowCount
                            sFields = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                If sValue = "" Then
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = DBNull.Value
                                Else
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End If
                            Next

                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)

                            sSql = "INSERT INTO lf310m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF310H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf310h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf310m f"
                        sSql += " WHERE testcd = :testcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        'LF310M Delete
                        sSql = "DELETE lf310m WHERE testcd = :testcd"

                        dbCmd.CommandText = sSql

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd

                        iRet += dbCmd.ExecuteNonQuery()

                        'LF310M Insert
                        For i As Integer = 1 To .ItemTableRowCount
                            sFields = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                If sValue = "" Then
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = DBNull.Value
                                Else
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End If
                            Next

                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)

                            sSql = "INSERT INTO lf310m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
            Else
                dbTran.Rollback()
            End If

            Return True

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransSpTestInfo_UE(ByVal rsTestCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransSpTestInfo_UE(String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Dim sSql As String = ""
        Dim iRet As Integer = 0

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            'LF310H Backup
            sSql = ""
            sSql += "INSERT INTO lf310h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf310m f"
            sSql += " WHERE testcd = :testcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            'LF310M Delete
            sSql = "DELETE lf310m WHERE testcd = :testcd"

            dbCmd.CommandText = sSql

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("testcd",  OracleDbType.Varchar2).Value = rsTestCd

            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
            Else
                dbTran.Rollback()
            End If

            Return True

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function
End Class
#End Region

#Region " APP_F_% 혈액은행 "

Public Class APP_F_BLD_REF
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_BLD_REF" & vbTab

    Public Overloads Function GetBldRefInfo() As DataTable
        Dim sFn As String = "Public Function GetBldRefInfo() As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT a.testcd, a.spccd, b.tnmd, a.bbgbn, a.dispseq,"
            sSql += "       a.tordgbn, a.dordgbn, a.aordgbn, a.trstgbn, a.drstgbn, a.arstgbn,"
            sSql += "       fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, a.regid,"
            sSql += "       fn_ack_get_usr_name(a.regid) regnm"
            sSql += "  FROM lf140m a, lf060m b"
            sSql += " WHERE a.testcd = b.testcd"
            sSql += "   AND a.spccd  = b.spccd"
            sSql += "   AND b.usdt  <= fn_ack_sysdate"
            sSql += "   AND b.uedt  >  fn_ack_sysdate"

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Overloads Function GetBldRefInfo(ByVal rsModDt As String) As DataTable
        Dim sFn As String = "Public Function GetBldRefInfo(ByVal iMode As Integer) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT a.testcd, a.spccd, b.tnmd, a.bbgbn, a.dispseq, a.regdt, a.regid,"
            sSql += "       a.tordgbn, a.dordgbn, a.aordgbn, a.trstgbn, a.drstgbn, a.arstgbn,"
            sSql += "       fn_ack_date_str(a.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, a.regid,"
            sSql += "       fn_ack_get_usr_name(a.regid) regnm,"
            sSql += "       fn_ack_date_str(moddt, yyyy-mm-dd hh24:mi:ss) moddt, modid"
            sSql += "  FROM lf140h a, lf060m b"
            sSql += " WHERE a.testcd = b.testcd"
            sSql += "   AND a.spccd  = b.spccd"
            sSql += "   AND b.usdt  <= fn_ack_sysdate"
            sSql += "   AND b.uedt  >  fn_ack_sysdate"
            sSql += "   AND a.moddt  = :moddt"

            alParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDt))
            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Overloads Function GetBldRefInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetBldRefInfo(ByVal iMode As Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT DISTINCT nmd, NULL diffday, NULL moddt"
                sSql += "  FROM ("
                sSql += "        SELECT '헌혈자검사' nmd FROM DUAL"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If

            ElseIf riMode = 1 Then
                sSql += "SELECT DISTINCT nmd, moddt, diffday"
                sSql += "  FROM ("
                sSql += "        SELECT '헌혈자검사' nmd, NULL diffday, NULL moddt"
                sSql += "          FROM lf140m"
                sSql += "         UNION ALL"
                sSql += "        SELECT '헌혈자검사' nmd, -1 diffday,"
                sSql += "               fn_ack_date_str(moddt, 'yyyy-mm-dd hh24:mi:ss') moddt"
                sSql += "          FROM lf140h"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransBldRefInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                    ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransBldRefInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF120M : 성분제제 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        sSql = "DELETE lf140m"

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()


                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf140m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF120H Backup
                        sSql = "INSERT INTO lf140h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf140m f"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        sSql = "DELETE lf140m"
                        dbCmd.CommandText = sSql
                        dbCmd.Parameters.Clear()
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf140m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function
End Class

Public Class APP_F_FTCD
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_FTCD" & vbTab

    Public Overloads Function GetFTCdInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetFTCdInfo(Integer, String) As DataTable"
        Dim sSql As String = ""

        If riMode = 0 Then
            sSql += "SELECT ftcd, ftnms, fordcd, usdt, uedt"
            sSql += "  FROM lf121m"
            sSql += " WHERE uedt >= fn_ack_sysdate"
            If rsSerch <> "" Then
                sSql += "   AND " + rsSerch + ""
            End If
            sSql += " ORDER BY ftcd, usdt, uedt"
        ElseIf riMode = 1 Then
            sSql += "SELECT ftcd, ftnms, fordcd, usdt, uedt, CASE WHEN TO_DATE(uedt, 'yyyymmddhh24miss') - SYSDATE < 0 THEN -1 ELSE 0 END diffday"
            sSql += "  FROM lf121m"
            If rsSerch <> "" Then
                sSql += " WHERE " + rsSerch + ""
            End If
            sSql += " ORDER BY ftcd, usdt, uedt"
        End If

        Try
            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try

    End Function

    Public Overloads Function GetFTCdInfo(ByVal rsFTCd As String, ByVal rsUSDT As String) As DataTable
        Dim sFn As String = "Function GetFTCdInfo(String, String) As DataTable"
        Dim sSql As String = ""

        sSql = ""
        sSql += "SELECT ftcd, ftnm, ftnms, comcnt, fordcd,"
        sSql += "       fn_ack_date_str(usdt,  'yyyy-mm-dd hh24:mi:ss') usdt,  fn_ack_date_str(uedt, 'yyyy-mm-dd hh24:mi:ss') uedt,"
        sSql += "       fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid, fn_ack_get_usr_name(regid) regnm"
        sSql += "  FROM lf121m"
        sSql += " WHERE ftcd = :ftcd"
        sSql += "   AND usdt = :usdt"

        Try
            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("ftcd",  OracleDbType.Varchar2, rsFTCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsFTCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUSDT.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUSDT))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try

    End Function

    Public Function GetRecentFTCdInfo(ByVal rsFTCd As String, ByVal rsUSDT As String) As DataTable
        Dim sFn As String = "Public Function GetRecentSpcInfo(ByVal asFTCd As String, ByVal asUSDT As String) As DataTable"
        Dim sSql As String = ""

        Try
            sSql += ""
            sSql += "SELECT usdt"
            sSql += "  FROM (SELECT usdt"
            sSql += "          FROM lf121m"
            sSql += "         WHERE ftcd  = :ftcd"
            sSql += "           AND usdt >= :usdt"
            sSql += "         ORDER BY usdt DESC"
            sSql += "       ) a"
            sSql += " WHERE ROWNUM = 1"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("ftcd",  OracleDbType.Varchar2, rsFTCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsFTCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUSDT.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUSDT))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function


    Public Function TransFTCdInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                  ByVal rsFTCd As String, ByVal rsUsDt As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransFTCdInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF121M : 필터 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        'UPDATE uedt of previous record
                        sSql = ""
                        sSql += "UPDATE lf121m SET uedt = :usdt"
                        sSql += " WHERE (ftcd, usdt) IN"
                        sSql += "       (SELECT a.ftcd, a.usdt"
                        sSql += "          FROM (SELECT ftcd, usdt"
                        sSql += "                  FROM lf121m"
                        sSql += "                 WHERE ftcd  = :ftcd"
                        sSql += "                   AND usdt  < :usdt"
                        sSql += "                   AND uedt  > :usdt"
                        sSql += "                 ORDER BY usdt DESC"
                        sSql += "               ) a"
                        sSql += "         WHERE ROWNUM = 1"
                        sSql += "        )"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("ftcd",  OracleDbType.Varchar2).Value = rsFTCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                If sValue = "" Then
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = DBNull.Value
                                Else
                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End If

                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf121m (" + sFields + ") VALUES (" + sValues + ")"


                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF121H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf121h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf121m f"
                        sSql += " WHERE ftcd = :ftcd"
                        sSql += "   AND usdt = :usdt"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("ftcd",  OracleDbType.Varchar2).Value = rsFTCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value

                                Select Case sField.ToUpper
                                    Case "FTCD", "USDT"

                                    Case Else
                                        sFields += sField + " = :" + sField + ","

                                        If sValue = "" Then
                                            dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = DBNull.Value
                                        Else
                                            dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                        End If
                                End Select
                            Next

                            'UPDATE record
                            sFields = sFields.Substring(0, sFields.Length - 1)

                            sSql = ""
                            sSql += "UPDATE lf121m set " + sFields
                            sSql += " WHERE ftcd = :ftcd"
                            sSql += "   AND usdt = :usdt"

                            dbCmd.Parameters.Add("ftcd",  OracleDbType.Varchar2).Value = rsFTCd
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransFTCdInfo_DEL(ByVal rsFtCd As String, ByVal rsUsDt As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = " Public Function TransTestInfo_DEL() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF121M : 필터 마스터
            '   LF121H Insert
            sSql = ""
            sSql += "INSERT INTO lf121h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f12.* FROM lf121m f12"
            sSql += " WHERE ftcd = :ftcd"
            sSql += "   AND usdt = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("ftcd",  OracleDbType.Varchar2).Value = rsFtCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF121M Delete
            sSql = ""
            sSql += "DELETE lf121m"
            sSql += " WHERE ftcd = :ftcd"
            sSql += "   AND usdt = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("ftcd",  OracleDbType.Varchar2).Value = rsFtCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransFTCdInfo_UE(ByVal rsFTCd As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUeDt As String) As Boolean
        Dim sFn As String = "Public Function TransFTCdInfo_UE(String, String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            'LF121M : 필터마스터
            '   LF121H Insert
            'LF121H Backup
            sSql = ""
            sSql += "INSERT INTO lf121h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf121m f"
            sSql += " WHERE ftcd = :ftcd"
            sSql += "   AND usdt = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("ftcd",  OracleDbType.Varchar2).Value = rsFTCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF121M Update
            sSql = ""
            sSql += "UPDATE lf121m set uedt = :uedt, regid = :regid"
            sSql += " WHERE ftcd = :ftcd"
            sSql += "   AND usdt = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDt
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("ftcd",  OracleDbType.Varchar2).Value = rsFTCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransFTCdInfo_UPD_UE(ByVal rsFtcd As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUeDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransTestInfo_UPD_UE() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF121M : 필터 마스터
            '   LF121H Insert
            sSql = ""
            sSql += "INSERT INTO lf121h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf121m f"
            sSql += " WHERE ftcd = :ftcd"
            sSql += "   AND usdt = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("ftcd",  OracleDbType.Varchar2).Value = rsFtcd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF121M Update
            sSql = ""
            sSql += "UPDATE lf121m set"
            sSql += "       uedt  = :uedt,"
            sSql += "       regdt = fn_ack_sysdate,"
            sSql += "       regid = :regid"
            sSql += " WHERE ftcd  = :ftcd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("ftcd",  OracleDbType.Varchar2).Value = rsFtcd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransFTCdInfo_UPD_US(ByVal rsFtCd As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUsDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransTestInfo_UPD_US() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF121M : 필터 마스터
            '   LF121H Insert
            sSql = ""
            sSql += "INSERT INTO lf121h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf121m f"
            sSql += " WHERE ftcd = :ftcd"
            sSql += "   AND usdt = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("ftcd",  OracleDbType.Varchar2).Value = rsFtCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF121M Update
            sSql = ""
            sSql += "UPDATE lf121m set"
            sSql += "       usdt  = :usdtchg,"
            sSql += "       regdt = fn_ack_sysdate,"
            sSql += "       regid = :regid"
            sSql += " WHERE ftcd  = :ftcd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("usdtchg",  OracleDbType.Varchar2).Value = rsUsDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("ftcd",  OracleDbType.Varchar2).Value = rsFtCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

End Class

Public Class APP_F_JOBCD
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_JOBCD" & vbTab

    Public Function GetJobCdInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetJobCdInfo(Integer, String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT jobcd, jobnm"
                sSql += "  FROM lf110m f"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += "  ORDER BY jobcd"
            ElseIf riMode = 1 Then
                sSql += "SELECT jobcd, jobnm, null diffday, null moddt, null modid"
                sSql += "  FROM lf110m f"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " UNION ALL "
                sSql += "SELECT jobcd, jobnm, -1 diffday, fn_ack_date_str(moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, modid"
                sSql += "  FROM lf110h fh"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY jobcd, moddt, modid"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetJobCdInfo(ByVal rsJobCd As String) As DataTable
        Dim sFn As String = "Public Function GetJobCdInfo(String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT jobcd, jobnm, fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid,"
            sSql += "       null moddt, null modid, null modnm,"
            sSql += "       fn_ack_get_usr_name(regid) regnm"
            sSql += "  FROM lf110m"
            sSql += " WHERE jobcd = :jobcd"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("jobcd",  OracleDbType.Varchar2, rsJobCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsJobCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetJobCdInfo(ByVal rsModDt As String, ByVal rsModId As String, ByVal rsJobCd As String) As DataTable
        Dim sFn As String = "Public Function GetJobCdInfo(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT jobcd, jobnm, fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid,"
            sSql += "       fn_ack_date_str(moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, modid,"
            sSql += "       fn_ack_get_usr_name(modid) modnm, fn_ack_get_usr_name(regid) regnm"
            sSql += "  FROM lf110h a"
            sSql += " WHERE a.moddt = :moddt"
            sSql += "   AND a.modid = :modid"
            sSql += "   AND a.jobcd = :jobcd"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDt))
            alParm.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModId.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModId))
            alParm.Add(New OracleParameter("jobcd",  OracleDbType.Varchar2, rsJobCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsJobCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentJobCdInfo(ByVal rsJobCd As String) As DataTable
        Dim sFn As String = "Public Function GetRecentJobCdInfo(String) As DataTable"

        Dim sSql As String = ""

        Try
            sSql += "SELECT jobcd"
            sSql += "  FROM lf110m"
            sSql += " WHERE jobcd = :jobcd"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("jobcd",  OracleDbType.Varchar2, rsJobCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsJobCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try

    End Function

    Public Function TransJobCdInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                     ByVal rsJobCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransJobCdInfo(ItemTableCollection, Integer, String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF110M : 직업 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf110m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF110H Backup
                        sSql = " INSERT INTO lf110h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf110m f"
                        sSql += " WHERE jobcd = :jobcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("jobcd",  OracleDbType.Varchar2).Value = rsJobCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        sSql = " DELETE FROM lf110m"
                        sSql += " WHERE jobcd = :jobcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("jobcd",  OracleDbType.Varchar2).Value = rsJobCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf110m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransJobCdInfo_UE(ByVal rsJobCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransJobCdInfo_UE(String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF110M : 직업 마스터
            '   LF110H Insert
            sSql = " INSERT INTO lf110h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf110m f"
            sSql += " WHERE jobcd = :jobcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("jobcd",  OracleDbType.Varchar2).Value = rsJobCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF110M Delete
            sSql = " DELETE FROM lf110m"
            sSql += " WHERE jobcd = :jobcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("jobcd",  OracleDbType.Varchar2).Value = rsJobCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function
End Class

Public Class APP_F_DISCD
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_DISCD" & vbTab

    Public Function GetDisCdInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetDisCdInfo(Integer,String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += " SELECT discd, disrsn"
                sSql += "   FROM lf111m "
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += "  ORDER BY discd"
            ElseIf riMode = 1 Then
                sSql += " SELECT discd, disrsn, null diffday, null moddt, null modid"
                sSql += "   FROM lf111m "
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += "  union all"
                sSql += " SELECT discd, disrsn, -1 diffday, fn_ack_date_str(moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, modid"
                sSql += "   FROM lf111h "
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += "  ORDER BY discd, moddt, modid"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetDisCdInfo(ByVal rsDisCd As String) As DataTable
        Dim sFn As String = "Public Function GetDisCdInfo(Integer, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT discd, disrsn, fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid,"
            sSql += "       null moddt, null modid, null modnm, fn_ack_get_usr_name (regid) regnm"
            sSql += "  FROM lf111m"
            sSql += " WHERE discd = :discd"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("discd",  OracleDbType.Varchar2, rsDisCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsDisCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))


        End Try
    End Function

    Public Function GetDisCdInfo(ByVal rsModDt As String, ByVal rsModId As String, ByVal rsDisCd As String) As DataTable
        Dim sFn As String = "Public Function GetDisCdInfo(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT discd, disrsn, fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid,"
            sSql += "       fn_ack_date_str(moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, modid, fn_ack_get_usr_name(modid) modnm,"
            sSql += "       fn_ack_get_usr_name(regid) regnm"
            sSql += "  FROM lf111h a"
            sSql += " WHERE a.moddt = :moddt"
            sSql += "   AND a.modid = :modid"
            sSql += "   AND a.discd = :discd"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDt))
            alParm.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModId.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModId))
            alParm.Add(New OracleParameter("discd",  OracleDbType.Varchar2, rsDisCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsDisCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentDisCdInfo(ByVal rsDisCd As String) As DataTable
        Dim sFn As String = "Public Function GetRecentDisCdInfo(String) As DataTable"

        Dim sSql As String = ""

        Try
            sSql += " SELECT discd"
            sSql += "   FROM lf111m"
            sSql += "  WHERE discd = :discd"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("discd",  OracleDbType.Varchar2, rsDisCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsDisCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try

    End Function

    Public Function TransDisCdInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                     ByVal rsDisCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransDisCdInfo(ItemTableCollection, Integer, String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF111M : 부적격사유 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf111m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF111H Backup
                        sSql = " INSERT INTO lf111h SELECT fn_ack_sysdate, :modid, :modip, a.* FROM lf111m a"
                        sSql += " WHERE discd = :discd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("discd",  OracleDbType.Varchar2).Value = rsDisCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        sSql = " DELETE FROM lf111m"
                        sSql += " WHERE discd = :discd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("discd",  OracleDbType.Varchar2).Value = rsDisCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf111m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransDisCdInfo_UE(ByVal rsDisCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransDisCdInfo_UE(String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF111M : 부적격사유 마스터
            '   LF111H Insert
            sSql = ""
            sSql += "INSERT INTO lf111h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf111m f"
            sSql += " WHERE discd = :discd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("discd",  OracleDbType.Varchar2).Value = rsDisCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF111M Delete
            sSql = ""
            sSql += "DELETE lf111m"
            sSql += " WHERE discd = :discd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("discd",  OracleDbType.Varchar2).Value = rsDisCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function
End Class

Public Class APP_F_RTNCD
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_RTNCD" & vbTab

    Private Const mc_sCmt0 As String = "출고후 반납"
    Private Const mc_sCmt1 As String = "출고후 폐기"
    Private Const mc_sCmt2 As String = "출고전 자체폐기"
    Private Const mc_sCmt3 As String = "혈액교환시 폐기"

    Public Function GetCmtGbnInfo() As DataTable
        Dim sFn As String = "Public Function GetCmtGbnInfo() As DataTable"

        Try
            Dim sSql As String = ""

            sSql = ""
            sSql += " SELECT '000' cmtgbncd, '" + mc_sCmt0 + "' cmtgbnnm, 1 cmtgbnsort FROM DUAL"
            sSql += "  union all"
            sSql += " SELECT '110' cmtgbncd, '" + mc_sCmt1 + "' cmtgbnnm, 2 cmtgbnsort FROM DUAL"
            sSql += "  union all"
            sSql += " SELECT '100' cmtgbncd, '" + mc_sCmt2 + "' cmtgbnnm, 3 cmtgbnsort FROM DUAL"
            sSql += "  union all"
            sSql += " SELECT '101' cmtgbncd, '" + mc_sCmt3 + "' cmtgbnnm, 4 cmtgbnsort FROM DUAL"

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function GetRtnCdInfo(ByVal iMode As Integer, ByVal Serch As String) As DataTable
        Dim sFn As String = "Public Function GetRtnCdInfo(Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If iMode = 0 Then
                sSql += "SELECT cmtgbn_01, cmtcd, cmtcont,  stopgbn, regdt, regid, diffday, moddt, modid, cmtgbnsort"
                sSql += "  FROM ("
                sSql += "        SELECT '[' || cmtgbn || realgbn || chggbn || '] ' ||  cmtgbnnm cmtgbn_01, cmtcd, cmtcont, CASE WHEN stopgbn = '1' THEN '1' ELSE '' END stopgbn,"
                sSql += "               fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid, null diffday, null moddt, null modid, cmtgbnsort"
                sSql += "          FROM lf170m a,"
                sSql += "               ("
                sSql += "                SELECT '000' cmtgbncd, '" + mc_sCmt0 + "' cmtgbnnm, 1 cmtgbnsort FROM DUAL"
                sSql += "                 UNION ALL"
                sSql += "                SELECT '110' cmtgbncd, '" + mc_sCmt1 + "' cmtgbnnm, 2 cmtgbnsort FROM DUAL"
                sSql += "                 UNION ALL"
                sSql += "                SELECT '100' cmtgbncd, '" + mc_sCmt2 + "' cmtgbnnm, 3 cmtgbnsort FROM DUAL"
                sSql += "                 UNION ALL"
                sSql += "                SELECT '101' cmtgbncd, '" + mc_sCmt3 + "' cmtgbnnm, 4 cmtgbnsort FROM DUAL"
                sSql += "               ) b"
                sSql += "         WHERE cmtgbn || realgbn || chggbn = cmtgbncd"
                sSql += "       ) a"
                If Serch <> "" Then
                    sSql += " WHERE " + Serch + ""
                End If
                sSql += " ORDER BY cmtgbnsort, cmtcd"
            ElseIf iMode = 1 Then
                sSql += "SELECT cmtgbn_01, cmtcd, cmtcont,  stopgbn, regdt, regid, diffday, moddt, modid, cmtgbnsort"
                sSql += "  FROM ("
                sSql += "        SELECT '[' || cmtgbn || realgbn || chggbn || '] ' ||  cmtgbnnm cmtgbn_01, cmtcd, cmtcont, CASE WHEN stopgbn = '1' THEN '1' ELSE '' END stopgbn,"
                sSql += "                fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid, null diffday, null moddt, null modid, cmtgbnsort"
                sSql += "           FROM lf170m a,"
                sSql += "                ("
                sSql += "                 SELECT '000' cmtgbncd, '" + mc_sCmt0 + "' cmtgbnnm, 1 cmtgbnsort FROM DUAL"
                sSql += "                  UNION ALL"
                sSql += "                 SELECT '110' cmtgbncd, '" + mc_sCmt1 + "' cmtgbnnm, 2 cmtgbnsort FROM DUAL"
                sSql += "                  UNION ALL"
                sSql += "                 SELECT '100' cmtgbncd, '" + mc_sCmt2 + "' cmtgbnnm, 3 cmtgbnsort FROM DUAL"
                sSql += "                  UNION ALL"
                sSql += "                 SELECT '101' cmtgbncd, '" + mc_sCmt3 + "' cmtgbnnm, 4 cmtgbnsort FROM DUAL"
                sSql += "               ) b"
                sSql += "         WHERE cmtgbn || realgbn || chggbn = cmtgbncd"
                sSql += "         UNION ALL"
                sSql += "        SELECT '[' || cmtgbn || realgbn || chggbn || '] ' ||  cmtgbnnm cmtgbnnm, cmtcd, cmtcont, CASE WHEN stopgbn = '1' THEN '1' ELSE '' END stopgbn,"
                sSql += "               fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid,"
                sSql += "               -1 diffday, fn_ack_date_str(moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, modid, cmtgbnsort"
                sSql += "          FROM lf170h a,"
                sSql += "                ("
                sSql += "                 SELECT '000' cmtgbncd, '" + mc_sCmt0 + "' cmtgbnnm, 1 cmtgbnsort FROM DUAL"
                sSql += "                  UNION ALL"
                sSql += "                 SELECT '110' cmtgbncd, '" + mc_sCmt1 + "' cmtgbnnm, 2 cmtgbnsort FROM DUAL"
                sSql += "                  UNION ALL"
                sSql += "                 SELECT '100' cmtgbncd, '" + mc_sCmt2 + "' cmtgbnnm, 3 cmtgbnsort FROM DUAL"
                sSql += "                  UNION ALL"
                sSql += "                 SELECT '101' cmtgbncd, '" + mc_sCmt3 + "' cmtgbnnm, 4 cmtgbnsort FROM DUAL"
                sSql += "               ) b"
                sSql += "         WHERE cmtgbn || realgbn || chggbn = cmtgbncd"
                sSql += "      ) a"
                If Serch <> "" Then
                    sSql += " WHERE " + Serch + ""
                End If
                sSql += " ORDER BY cmtgbnsort, cmtcd, moddt, modid"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRtnCdInfo(ByVal rsCmtGbn As String, ByVal rsRtnCd As String) As DataTable
        Dim sFn As String = "Public Function GetDisCdInfo(String, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += " SELECT '[' || cmtgbn || realgbn || chggbn || '] ' ||  cmtgbnnm cmtgbn_01, cmtcd, cmtcont, CASE WHEN stopgbn = '1' THEN '1' ELSE '' END stopgbn,"
            sSql += "        fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid,"
            sSql += "        null moddt, null modid, null modnm, fn_ack_get_usr_name(regid) usernm, costgbn"
            sSql += "   FROM lf170m a,"
            sSql += "        ("
            sSql += "         SELECT '000' cmtgbncd, '" + mc_sCmt0 + "' cmtgbnnm, 1 cmtgbnsort FROM DUAL"
            sSql += "          UNION ALL"
            sSql += "         SELECT '110' cmtgbncd, '" + mc_sCmt1 + "' cmtgbnnm, 2 cmtgbnsort FROM DUAL"
            sSql += "          UNION ALL"
            sSql += "         SELECT '100' cmtgbncd, '" + mc_sCmt2 + "' cmtgbnnm, 3 cmtgbnsort FROM DUAL"
            sSql += "          UNION ALL"
            sSql += "         SELECT '101' cmtgbncd, '" + mc_sCmt3 + "' cmtgbnnm, 4 cmtgbnsort FROM DUAL"
            sSql += "        ) b"
            sSql += "  WHERE cmtgbn || realgbn || chggbn = cmtgbncd"
            sSql += "    AND cmtgbn || realgbn || chggbn = :cmtgbn"
            sSql += "    AND cmtcd = :cmtcd"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("cmtgbn",  OracleDbType.Varchar2, rsCmtGbn.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCmtGbn))
            alParm.Add(New OracleParameter("cmtcd",  OracleDbType.Varchar2, rsRtnCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsRtnCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRtnCdInfo(ByVal rsModDT As String, ByVal rsModID As String, ByVal rsCmtGbn As String, ByVal rsRtnCd As String) As DataTable
        Dim sFn As String = "Public Function GetRtnCdInfo(String, String, String, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += " SELECT '[' || cmtgbn || realgbn || chggbn || '] ' ||  cmtgbnnm cmtgbn_01, cmtcd, cmtcont, CASE WHEN stopgbn = '1' THEN '1' ELSE '' END stopgbn,"
            sSql += "        fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid, fn_ack_get_usr_name(regid) usrnm,"
            sSql += "        fn_ack_date_str(moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, modid, fn_ack_get_usr_name(modid) modnm,"
            sSql += "        costgbn"
            sSql += "   FROM lf170h,"
            sSql += "        ("
            sSql += "         SELECT '000' cmtgbncd, '" + mc_sCmt0 + "' cmtgbnnm, 1 cmtgbnsort FROM DUAL"
            sSql += "          UNION ALL"
            sSql += "         SELECT '110' cmtgbncd, '" + mc_sCmt1 + "' cmtgbnnm, 2 cmtgbnsort FROM DUAL"
            sSql += "          UNION ALL"
            sSql += "         SELECT '100' cmtgbncd, '" + mc_sCmt2 + "' cmtgbnnm, 3 cmtgbnsort FROM DUAL"
            sSql += "          UNION ALL"
            sSql += "         SELECT '101' cmtgbncd, '" + mc_sCmt3 + "' cmtgbnnm, 4 cmtgbnsort FROM DUAL"
            sSql += "        ) b"
            sSql += "  WHERE cmtgbn || realgbn || chggbn = cmtgbncd"
            sSql += "    AND cmtgbn || realgbn || chggbn = :cmtgbn"
            sSql += "    AND cmtcd  = :cmtcd"
            sSql += "    AND moddt  = :moddt"
            sSql += "    AND modid  = :modid"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("cmtgbn",  OracleDbType.Varchar2, rsCmtGbn.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCmtGbn))
            alParm.Add(New OracleParameter("cmtcd",  OracleDbType.Varchar2, rsRtnCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsRtnCd))
            alParm.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDT.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDT))
            alParm.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModID.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModID))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentRtnCdInfo(ByVal rsCmtGbn As String, ByVal rsRtnCd As String) As DataTable
        Dim sFn As String = "Public Function GetRecentRtnCdInfo(String, String) As DataTable"

        Dim sSql As String = ""

        Try
            sSql += " SELECT cmtgbn, cmtcd"
            sSql += "   FROM lf170m"
            sSql += "  WHERE cmtgbn || realgbn || chggbn = :cmtgbn"
            sSql += "    AND cmtcd  = :cmtcd"

            Dim alParm As New ArrayList

            alParm.Add(New OracleParameter("cmtgbn",  OracleDbType.Varchar2, rsCmtGbn.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsCmtGbn))
            alParm.Add(New OracleParameter("cmtcd",  OracleDbType.Varchar2, rsRtnCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsRtnCd))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try

    End Function

    Public Function TransRtnCdInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                     ByVal rsCmtGbn As String, ByVal rsRtnCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransDisCdInfo(ItemTableCollection, Integer,  String, String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF170M : 반납폐기사유 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf170m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF170H Backup
                        sSql = " INSERT INTO lf170h SELECT fn_ack_sysdate, :modid, :modip, a.* FROM lf170m a"
                        sSql += " WHERE cmtgbn || realgbn || chggbn = :cmtgbn"
                        sSql += "   AND cmtcd  = :cmtcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("cmtgbn",  OracleDbType.Varchar2).Value = rsCmtGbn
                        dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsRtnCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        sSql = " DELETE FROM lf170m"
                        sSql += " WHERE cmtgbn || realgbn || chggbn = :cmtgbn"
                        sSql += "   AND cmtcd  = :cmtcd"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("cmtgbn",  OracleDbType.Varchar2).Value = rsCmtGbn
                        dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsRtnCd

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf170m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransRtnCdInfo_UE(ByVal rsCmtGbn As String, ByVal rsRtnCd As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransDisCdInfo_UE(String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF170M : 반납폐기사유 마스터
            '   LF170H Insert
            sSql = " INSERT INTO lf170h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf170m f"
            sSql += " WHERE cmtgbn || realgbn || chggbn = :cmtgbn"
            sSql += "   AND cmtcd  = :cmtcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("cmtgbn",  OracleDbType.Varchar2).Value = rsCmtGbn
            dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsRtnCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF170M Delete
            sSql = " DELETE FROM lf170m"
            sSql += " WHERE cmtgbn || realgbn || chggbn = :cmtgbn"
            sSql += "   AND cmtcd  = :cmtcd"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("cmtgbn",  OracleDbType.Varchar2).Value = rsCmtGbn
            dbCmd.Parameters.Add("cmtcd",  OracleDbType.Varchar2).Value = rsRtnCd

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function
End Class

'-- 보관검체
Public Class APP_F_KSRACK
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_KSRACK" + vbTab

    Public Function GetKSSpcInfo(ByVal rsBcclscd As String, ByVal rsRackId As String) As DataTable
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT f16.chk, f30.spccd, f30.spcnmd"
            sSql += "  FROM (SELECT spccd, spcnmd"
            sSql += "          FROM lf030m"
            sSql += "		  WHERE uedt > fn_ack_sysdate"
            sSql += "         UNION "
            sSql += "        SELECT '" + "".PadRight(PRG_CONST.Len_SpcCd, "0"c) + "' spccd, '검체구분 없음' spcnmd"
            sSql += " 		   FROM DUAL"
            sSql += "       ) f30 LEFT OUTER JOIN"
            sSql += "       (SELECT DISTINCT '1' chk, f16.spccd"
            sSql += " 		   FROM lf030m f03, lf160m f16"
            sSql += " 		  WHERE f03.spccd   = f16.spccd"
            sSql += " 		    AND f03.usdt   <= fn_ack_sysdate"
            sSql += " 		    AND f03.uedt   >  fn_ack_sysdate"
            sSql += "           AND f16.bcclscd = :bcclscd"
            sSql += " 		    AND f16.rackid  = :rackid"
            sSql += "       ) f16 ON (f30.spccd = f16.spccd)"
            sSql += " ORDER BY f30.spccd"

            al.Add(New OracleParameter("bcclscd",  OracleDbType.Varchar2, rsBcclscd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsBcclscd))
            al.Add(New OracleParameter("rackid",  OracleDbType.Varchar2, rsRackId.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsRackId))

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Overloads Function GetKSRackInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Overloads Function GetKSRackInfo(ByVal iMode As Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += "SELECT bcclscd, rackid, bcclsnmd, alarmterm, maxcol, maxrow, regid, regdt"
                sSql += "  FROM ("
                sSql += "        SELECT DISTINCT"
                sSql += "               f16.bcclscd, f16.rackid, f1.bcclsnmd, f16.alarmterm, f16.maxcol, f16.maxrow,"
                sSql += "               f16.regid, fn_ack_date_str(f16.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt"
                sSql += "          FROM lf160m f16 LEFT OUTER JOIN"
                sSql += "               lf010m f1  ON f16.bcclscd  = f1.bcclscd"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY bcclscd, rackid"

            ElseIf riMode = 1 Then
                sSql += "SELECT bcclscd, rackid, bcclsnmd, alarmterm, maxcol, maxrow, regid, regdt, diffday, moddt, modid"
                sSql += "  FROM ("
                sSql += "        SELECT DISTINCT"
                sSql += "               f16.bcclscd, f16.rackid, f1.bcclsnmd, f16.alarmterm, f16.maxcol, f16.maxrow,"
                sSql += "               f16.regid, fn_ack_date_str(f16.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, NULL diffday, NULL modid, NULL moddt"
                sSql += "          FROM lf160m f16 LEFT OUTER JOIN"
                sSql += "               lf010m f1  ON f16.bcclscd  = f1.bcclscd"
                sSql += "         UNION ALL"
                sSql += "        SELECT DISTINCT"
                sSql += "               f16.bcclscd, f16.rackid, f1.bcclsnmd, f16.alarmterm, f16.maxcol, f16.maxrow,"
                sSql += "               f16.regid, fn_ack_date_str(f16.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, -1 diffday,"
                sSql += "               f16.modid, fn_ack_date_str(f16.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt"
                sSql += "          FROM lf160h f16 LEFT OUTER JOIN"
                sSql += "               lf010m f1  ON f16.bcclscd  = f1.bcclscd"
                sSql += "       ) a"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY bcclscd, rackid"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Overloads Function GetKSRackInfo(ByVal rsBcclscd As String, ByVal rsRackId As String) As DataTable
        Dim sFn As String = "Public Overloads Function GetKSRackInfo(ByVal iMode As Integer, ByVal asSpcCd As String, ByVal asUSDT As String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT DISTINCT"
            sSql += "       f16.bcclscd, f16.rackid, f16.alarmterm, f16.maxcol, f16.maxrow,"
            sSql += "       '[' || f16.bcclscd || ']' bcclsnmd_01,"
            sSql += "       fn_ack_date_str(f16.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f16.regid,"
            sSql += "       NULL modid, NULL modid,"
            sSql += "       fn_ack_get_usr_name(f16.regid) regnm"
            sSql += "  FROM LF160M f16"
            sSql += " WHERE f16.bcclscd = :bcclscd"
            sSql += "   AND f16.rackid  = :rackid"

            al.Add(New OracleParameter("bcclscd",  OracleDbType.Varchar2, rsBcclscd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsBcclscd))
            al.Add(New OracleParameter("rackid",  OracleDbType.Varchar2, rsRackId.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsRackId))
            

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Overloads Function GetKSRackInfo(ByVal rsBcclscd As String, ByVal rsRackId As String, ByVal rsModDt As String, ByVal rsModId As String) As DataTable
        Dim sFn As String = "Public Overloads Function GetKSRackInfo(ByVal iMode As Integer, ByVal asSpcCd As String, ByVal asUSDT As String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim al As New ArrayList

            sSql += "SELECT DISTINCT"
            sSql += "       f16.bcclscd, f16.rackid, f16.alarmterm, f16.maxcol, f16.maxrow,"
            sSql += "       '[' || f16.bcclscd || ']' bcclsnmd_01,"
            sSql += "       fn_ack_date_str(f16.regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, f16.regid,"
            sSql += "       fn_ack_date_str(f16.moddt, 'yyyy-mm-dd hh24:mi:ss') moddt, f16.modid,"
            sSql += "       fn_ack_get_usr_name(f16.regid) regnm"
            sSql += "  FROM LF160h f16"
            sSql += " WHERE f16.bcclscd = :bcclscd"
            sSql += "   AND f16.rackid  = :rackid"
            sSql += "   AND f16.moddt   = :moddt"
            sSql += "   AND f16.modid   = :modid"

            al.Add(New OracleParameter("bcclscd",  OracleDbType.Varchar2, rsBcclscd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsBcclscd))
            al.Add(New OracleParameter("rackid",  OracleDbType.Varchar2, rsRackId.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsRackId))
            al.Add(New OracleParameter("moddt",  OracleDbType.Varchar2, rsModDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModDt))
            al.Add(New OracleParameter("modid",  OracleDbType.Varchar2, rsModId.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsModId))

            DbCommand()
            Return DbExecuteQuery(sSql, al)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransKSRackInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                    ByVal rsBcclscd As String, ByVal rsRackId As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransKSRackInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            'LF160M : 보관검체 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1

                        With ro_Tcol1
                            For i As Integer = 1 To .ItemTableRowCount
                                sField = "" : sFields = "" : sValue = "" : sValues = ""

                                dbCmd.Parameters.Clear()
                                For j As Integer = 1 To .ItemTableColCount
                                    sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                    sFields += sField + ","

                                    sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                    sValues += ":" + sField + ","

                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                Next

                                'insert new record
                                sFields = sFields.Substring(0, sFields.Length - 1)
                                sValues = sValues.Substring(0, sValues.Length - 1)
                                sSql = "INSERT INTO lf160m (" + sFields + ") VALUES (" + sValues + ")"

                                dbCmd.CommandText = sSql
                                iRet += dbCmd.ExecuteNonQuery()
                            Next
                        End With

                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF160H Backup
                        sSql = ""
                        sSql += " INSERT INTO lf160H"
                        sSql += " SELECT fn_ack_sysdate, :modid, :modip, f16.* FROM lf160M f16"
                        sSql += "  WHERE bcclscd = :bcclscd"
                        sSql += "    AND rackid  = :rackid"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("bcclscd",  OracleDbType.Varchar2).Value = rsBcclscd
                        dbCmd.Parameters.Add("rackid",  OracleDbType.Varchar2).Value = rsRackId

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        sSql = ""
                        sSql += " DELETE FROM lf160M"
                        sSql += "  WHERE bcclscd = :bcclscd"
                        sSql += "    AND rackid  = :rackid"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("bcclscd",  OracleDbType.Varchar2).Value = rsBcclscd
                        dbCmd.Parameters.Add("rackid",  OracleDbType.Varchar2).Value = rsRackId

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        With ro_Tcol1
                            For i As Integer = 1 To .ItemTableRowCount
                                sField = "" : sFields = "" : sValue = "" : sValues = ""

                                dbCmd.Parameters.Clear()
                                For j As Integer = 1 To .ItemTableColCount
                                    sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                    sFields += sField + ","

                                    sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                    sValues += ":" + sField + ","

                                    dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                Next

                                'insert new record
                                sFields = sFields.Substring(0, sFields.Length - 1)
                                sValues = sValues.Substring(0, sValues.Length - 1)
                                sSql = "INSERT INTO lf160m (" + sFields + ") VALUES (" + sValues + ")"

                                dbCmd.CommandText = sSql
                                iRet += dbCmd.ExecuteNonQuery()
                            Next
                        End With

                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransKSRackInfo_UE(ByVal rsBcclscd As String, ByVal rsRackId As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransKSRackInfo_UE(String, String, String) As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            'LF160M : 결과코드 마스터 
            '   LF160H Insert 
            sSql = ""
            sSql += "INSERT INTO lf160h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf160m f"
            sSql += "  WHERE bcclscd = :bcclscd"
            sSql += "    AND rackid  = :rackid"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("bcclscd",  OracleDbType.Varchar2).Value = rsBcclscd
            dbCmd.Parameters.Add("rackid",  OracleDbType.Varchar2).Value = rsRackId

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF160M Delete 
            sSql = ""
            sSql += "DELETE lf160m"
            sSql += "  WHERE bcclscd = :bcclscd"
            sSql += "    AND rackid  = :rackid"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("bcclscd",  OracleDbType.Varchar2).Value = rsBcclscd
            dbCmd.Parameters.Add("rackid",  OracleDbType.Varchar2).Value = rsRackId

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

End Class

Public Class APP_F_COMCD
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_COMCD" & vbTab

    Public Function GetGOrdCdInfo(ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetGOrdCdInfo(String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim alParm As New ArrayList

            sSql += "SELECT DISTINCT '[' || RPAD(comordcd, 10, ' ') || spccd || '] ' || comnmd comnmd, comnmd sortnm, dispseql"
            sSql += "  FROM lf120m"
            sSql += " WHERE usdt <= :usdt"
            sSql += "   AND uedt <  :usdt"
            sSql += "   AND (comgbn in ('1', '4') OR NVL(bagordyn, '1') = '1' OR NVL(ftcd, '000') <> '000')"
            sSql += " ORDER BY dispseql, 1"

            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))
            alParm.Add(New OracleParameter("uedt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransComCdInfo_DEL(ByVal rsComCd As String, ByVal rsSpcCd As String, ByVal rsUsDt As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = " Public Function TransComCdInfo_DEL() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim bITF_yn As Boolean = False
            Dim dt As New DataTable

            'LF120M : 성분제제 마스터
            '   LF120H Insert
            sSql = ""
            sSql += "INSERT INTO lf120h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f12.* FROM lf120m f12"
            sSql += " WHERE comcd = :comcd"
            sSql += "   AND spccd = :spccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("comcd",  OracleDbType.Varchar2).Value = rsComCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt


            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF120M Delete
            sSql = ""
            sSql += "DELETE lf120m"
            sSql += " WHERE comcd = :comcd"
            sSql += "   AND spccd = :spccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("comcd",  OracleDbType.Varchar2).Value = rsComCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If bITF_yn Then
                sSql = ""
                sSql += "DELETE fkitf..itf_lis_lf120m"
                sSql += " WHERE comcd = :comcd"
                sSql += "   AND spccd = :spccd"
                sSql += "   AND usdt  = :usdt"

                dbCmd.Parameters.Clear()
                dbCmd.Parameters.Add("comcd",  OracleDbType.Varchar2).Value = rsComCd
                dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                dbCmd.CommandText = sSql
                iRet += dbCmd.ExecuteNonQuery()
            End If

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransComCdInfo_UPD_UE(ByVal rsComCd As String, ByVal rsSpcCd As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUeDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransComCdInfo_UPD_UE() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim bITF_yn As Boolean = False
            Dim dt As New DataTable

            'LF120M : 검사 마스터
            '   LF120H Insert
            sSql = ""
            sSql += "INSERT INTO lf120h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf120m f"
            sSql += " WHERE comcd = :comcd"
            sSql += "   AND spccd = :spccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("comcd",  OracleDbType.Varchar2).Value = rsComCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF120M Update
            sSql = ""
            sSql += "UPDATE lf120m SET"
            sSql += "       uedt  = :uedt,"
            sSql += "       regdt = fn_ack_sysdate,"
            sSql += "       regid = :regid"
            sSql += " WHERE comcd = :comcd"
            sSql += "   AND spccd = :spccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("comcd",  OracleDbType.Varchar2).Value = rsComCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If bITF_yn Then
                sSql = ""
                sSql += "UPDATE fklis..itf_lis_lf120m SET"
                sSql += "       uedt  = :uedt,"
                sSql += "       regdt = fn_ack_sysdate,"
                sSql += "       regid = :regid"
                sSql += " WHERE comcd = :comcd"
                sSql += "   AND spccd = :spccd"
                sSql += "   AND usdt  = :usdt"

                dbCmd.Parameters.Clear()
                dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDtNew
                dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
                dbCmd.Parameters.Add("comcd",  OracleDbType.Varchar2).Value = rsComCd
                dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                dbCmd.CommandText = sSql
                iRet += dbCmd.ExecuteNonQuery()

            End If

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransComCdInfo_UPD_US(ByVal rsComCd As String, ByVal rsSpcCd As String, ByVal rsUsDt As String, ByVal rsRegID As String, ByVal rsUsDtNew As String) As Boolean
        Dim sFn As String = " Public Function TransComCdInfo_UPD_US() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim bITF_yn As Boolean = False
            Dim dt As New DataTable

            'LF120M : 성분제제 마스터
            '   LF120H Insert
            sSql = ""
            sSql += "INSERT INTO lf120h "
            sSql += "SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf120m f"
            sSql += " WHERE comcd = :comcd"
            sSql += "   AND spccd = :spccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("comcd",  OracleDbType.Varchar2).Value = rsComCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF120M Update
            sSql = ""
            sSql += "UPDATE lf120m SET"
            sSql += "       usdt  = :usdtchg,"
            sSql += "       regdt = fn_ack_sysdate,"
            sSql += "       regid = :regid"
            sSql += " WHERE comcd = :comcd"
            sSql += "   AND spccd = :spccd"
            sSql += "   AND usdt  = :usdt"


            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("usdtchg",  OracleDbType.Varchar2).Value = rsUsDtNew
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("comcd",  OracleDbType.Varchar2).Value = rsComCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If bITF_yn Then
                '   LF120M Update
                sSql = ""
                sSql += "UPDATE fkitf..itf_lis_lf120m set"
                sSql += "       usdt  = :usdtchg,"
                sSql += "       regdt = fn_ack_sysdate,"
                sSql += "       regid = :regid"
                sSql += " WHERE comcd = :comcd"
                sSql += "   AND spccd = :spccd"
                sSql += "   AND usdt  = :usdt"


                dbCmd.Parameters.Clear()
                dbCmd.Parameters.Add("usdtchg",  OracleDbType.Varchar2).Value = rsUsDtNew
                dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
                dbCmd.Parameters.Add("comcd",  OracleDbType.Varchar2).Value = rsComCd
                dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                dbCmd.CommandText = sSql
                iRet += dbCmd.ExecuteNonQuery()

            End If

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Overloads Function GetComCdInfo(ByVal riMode As Integer, ByVal rsSerch As String) As DataTable
        Dim sFn As String = "Public Function GetComCdInfo(ByVal iMode As Integer, ByVal Serch As String) As DataTable"

        Try
            Dim sSql As String = ""

            If riMode = 0 Then
                sSql += " SELECT comcd, spccd, comnmd, comordcd, usdt, uedt"
                sSql += "   FROM lf120m"
                sSql += "  WHERE uedt >= fn_ack_sysdate"
                If rsSerch <> "" Then
                    sSql += " AND " + rsSerch + ""
                End If
                sSql += "  ORDER BY comcd, spccd"
            ElseIf riMode = 1 Then
                sSql += " SELECT comcd, spccd, comnmd, comordcd, usdt, uedt,"
                sSql += "        CASE WHEN TO_DATE(uedt, 'yyyymmddhh24miss') - SYSDATE < 0 THEN -1 ELSE 0 END diffday"
                sSql += "   FROM lf120m"
                If rsSerch <> "" Then
                    sSql += " WHERE " + rsSerch + ""
                End If
                sSql += " ORDER BY comcd, spccd"
            End If

            DbCommand()
            Return DbExecuteQuery(sSql)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Overloads Function GetComCdInfo(ByVal rsComCd As String, ByVal rsSpcCd As String, ByVal rsUsDt As String) As DataTable
        Dim sFn As String = "Public Function GetComCdInfo(String, String, String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT comcd, '[' || spccd || ']' spccd_01, comnm, comnms, comnmd, comnmp,"
            sSql += "      '[' || ordslip || ']' ordslip_01, dispseqo, ordhide, comordcd, '[' || dspccd1 || ']' dspccd1_01,"
            sSql += "      '[' || crosslevel || ']' crosslevel_01,"
            sSql += "       CASE WHEN NVL(iogbn, '0') IN ('0', '1') THEN '1' ELSE '0' END iogbn0,"
            sSql += "       CASE WHEN NVL(iogbn, '0') IN ('0', '2') THEN '1' ELSE '0' END iogbn1,"
            sSql += "       sugacd, NVL(emergbn, '0') emergbn, NVL(pedgbn, '0') pedgbn,"
            sSql += "       SUBSTR(exeday, 1, 1) exeday1,"
            sSql += "       SUBSTR(exeday, 2, 1) exeday2,"
            sSql += "       SUBSTR(exeday, 3, 1) exeday3,"
            sSql += "       SUBSTR(exeday, 4, 1) exeday4,"
            sSql += "       SUBSTR(exeday, 5, 1) exeday5,"
            sSql += "       SUBSTR(exeday, 6, 1) exeday6,"
            sSql += "       SUBSTR(exeday, 7, 1) exeday7,"
            sSql += "       SUBSTR(oreqitem, 1, 1) oreqitem1,"
            sSql += "       SUBSTR(oreqitem, 2, 1) oreqitem2,"
            sSql += "       SUBSTR(oreqitem, 3, 1) oreqitem3,"
            sSql += "       CASE WHEN SUBSTR(oreqitem, 4, 1) = '0' THEN '0' ELSE '1' END oreqitem4,"
            sSql += "       CASE WHEN SUBSTR(oreqitem, 4, 1) = 'A' THEN '[A] 적혈구 제제'"
            sSql += "            WHEN SUBSTR(oreqitem, 4, 1) = 'B' THEN '[B] 혈소판 제제'"
            sSql += "            ELSE '[1] 없음'"
            sSql += "       END oreqitem4gbn_01,"
            sSql += "       '[' || owarninggbn || ']' owarninggbn_01, owarning,"
            sSql += "       CASE WHEN donqnt = 400 THEN '1' ELSE '0' END donqnt0, CASE WHEN donqnt = 320 THEN '1' ELSE '0' END donqnt1, NVL(donqnt, '1') donqnt2,"
            sSql += "       ROUND(availmi/60/24, 0) availday, '[' || ftcd || ']' ftcd_01, '[' || pscomcd || ']' pscomcd_01, bldcd, dispseql,"
            sSql += "       fn_ack_date_str(usdt,  'yyyy-mm-dd hh24:mi:ss') usdt, fn_ack_date_str(uedt, 'yyyy-mm-dd hh24:mi:ss') uedt,"
            sSql += "       fn_ack_date_str(regdt, 'yyyy-mm-dd hh24:mi:ss') regdt, regid, '[' || comgbn || ']' COMGBN_01,"
            sSql += "       '[' || gordcd || ']' gordcd_01, bagordyn, fn_ack_get_usr_name(regid) regnm,"
            sSql += "       comliscd"
            sSql += "  FROM lf120m"
            sSql += " WHERE comcd = :comcd"
            sSql += "   AND spccd = :spccd"
            sSql += "   AND usdt  = :usdt"

            Dim alParm As New ArrayList
            alParm.Add(New OracleParameter("comcd",  OracleDbType.Varchar2, rsComCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsComCd))
            alParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUsDt.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsDt))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)
        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function GetRecentComCdInfo(ByVal rsComCd As String, ByVal rsSpcCd As String, ByVal rsUSDT As String) As DataTable
        Dim sFn As String = "Public Function GetRecentComCdInfo(ByVal asComCd As String, ByVal asSpcCd As String, ByVal asUSDT As String) As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT usdt"
            sSql += "  FROM (SELECT usdt"
            sSql += "          FROM lf120m"
            sSql += "         WHERE comcd = :comcd"
            sSql += "           AND spccd = :spccd"
            sSql += "           AND usdt >= :usdt"
            sSql += "         ORDER BY usdt DESC"
            sSql += "       ) a"
            sSql += " WHERE ROWNUM = 1"

            Dim alParm As New ArrayList
            alParm.Add(New OracleParameter("comcd",  OracleDbType.Varchar2, rsComCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsComCd))
            alParm.Add(New OracleParameter("spccd",  OracleDbType.Varchar2, rsSpcCd.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsSpcCd))
            alParm.Add(New OracleParameter("usdt",  OracleDbType.Varchar2, rsUSDT.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUSDT))

            DbCommand()
            Return DbExecuteQuery(sSql, alParm)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function TransComCdInfo(ByVal ro_Tcol1 As ItemTableCollection, ByVal riType1 As Integer, _
                                   ByVal rsComCd As String, ByVal rsSpcCd As String, ByVal rsUsDt As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransComCdInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""
            Dim bITF_yn As Boolean = False
            Dim dt As New DataTable

            'LF120M : 성분제제 마스터
            Select Case riType1
                Case 0      '----- 신규
                    With ro_Tcol1
                        'UPDATE uedt of previous record
                        sSql = ""
                        sSql += "UPDATE lf120m SET uedt = :usdt"
                        sSql += " WHERE (comcd, spccd, usdt) IN"
                        sSql += "       (SELECT a.comcd, a.spccd, a.usdt"
                        sSql += "          FROM (SELECT comcd, spccd, usdt"
                        sSql += " 				   FROM lf120m"
                        sSql += " 				  WHERE comcd = :comcd"
                        sSql += "                   AND spccd = :spccd"
                        sSql += " 					AND usdt  < :usdt"
                        sSql += " 					AND uedt  > :usdt"
                        sSql += " 	             ORDER BY usdt DESC"
                        sSql += "               ) a"
                        sSql += "         WHERE ROWNUM = 1"
                        sSql += " 		)"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("comcd",  OracleDbType.Varchar2).Value = rsComCd
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        If bITF_yn Then
                            sSql = ""
                            sSql += "UPDATE fkitf..itf_lis_lf120m SET uedt = :usdt"
                            sSql += " WHERE (comcd, spccd, usdt) IN"
                            sSql += "       (SELECT a.comcd, a.spccd, a.usdt"
                            sSql += "          FROM (SELECT comcd, spccd, usdt"
                            sSql += " 				   FROM fkitf..itf_lis_lf120m"
                            sSql += " 				  WHERE comcd = :comcd"
                            sSql += "                   AND spccd = :spccd"
                            sSql += " 					AND usdt  < :usdt"
                            sSql += " 					AND uedt  > :usdt"
                            sSql += " 	              ORDER BY usdt DESC"
                            sSql += "               ) a"
                            sSql += "         WHERE ROWNUM = 1"
                            sSql += " 		)"

                            dbCmd.Parameters.Clear()
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                            dbCmd.Parameters.Add("comcd",  OracleDbType.Varchar2).Value = rsComCd
                            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt
                        End If

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sFields += sField + ","

                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value
                                sValues += ":" + sField + ","

                                dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                            Next

                            'insert new record
                            sFields = sFields.Substring(0, sFields.Length - 1)
                            sValues = sValues.Substring(0, sValues.Length - 1)
                            sSql = "INSERT INTO lf120m (" + sFields + ") VALUES (" + sValues + ")"

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                            If bITF_yn Then

                                sSql = "INSERT INTO fkitf..itf_lis_lf120m (" + sFields + ") VALUES (" + sValues + ")"

                                dbCmd.CommandText = sSql
                                iRet += dbCmd.ExecuteNonQuery()
                            End If
                        Next
                    End With

                Case 1      '----- 수정
                    With ro_Tcol1
                        'LF120H Backup
                        sSql = ""
                        sSql += "INSERT INTO lf120h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf120m f"
                        sSql += " WHERE comcd = :comcd"
                        sSql += "   AND spccd = :spccd"
                        sSql += "   AND usdt  = :usdt"

                        dbCmd.Parameters.Clear()
                        dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
                        dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
                        dbCmd.Parameters.Add("comcd",  OracleDbType.Varchar2).Value = rsComCd
                        dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                        dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                        dbCmd.CommandText = sSql
                        iRet += dbCmd.ExecuteNonQuery()

                        For i As Integer = 1 To .ItemTableRowCount
                            sField = "" : sFields = "" : sValue = "" : sValues = ""

                            dbCmd.Parameters.Clear()
                            For j As Integer = 1 To .ItemTableColCount
                                sField = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Field
                                sValue = CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).Value

                                Select Case sField.ToUpper
                                    Case "COMCD", "SPCCD", "USDT"

                                    Case Else
                                        sFields += sField + " = :" + sField + ","

                                        dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * (i - 1) + j), ItemTable).DbType).Value = sValue
                                End Select
                            Next

                            'UPDATE record
                            sFields = sFields.Substring(0, sFields.Length - 1)

                            sSql = ""
                            sSql += "UPDATE lf120m set " + sFields
                            sSql += " WHERE comcd = :comcd"
                            sSql += "   AND spccd = :spccd"
                            sSql += "   AND usdt  = :usdt"

                            dbCmd.Parameters.Add("comcd",  OracleDbType.Varchar2).Value = rsComCd
                            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                            dbCmd.CommandText = sSql
                            iRet += dbCmd.ExecuteNonQuery()

                            If bITF_yn Then
                                sSql = ""
                                sSql += "UPDATE fkitf..itf_lis_lf120m set " + sFields
                                sSql += " WHERE comcd = :comcd"
                                sSql += "   AND spccd = :spccd"
                                sSql += "   AND usdt  = :usdt"

                                dbCmd.CommandText = sSql
                                iRet += dbCmd.ExecuteNonQuery()
                            End If
                        Next
                    End With
            End Select

            If iRet > 0 Then
                dbTran.Commit()
                '-- OCS 관련 수정
                With dbCmd
                    .CommandType = CommandType.StoredProcedure
                    .CommandText = "pro_ack_exe_ocs_test"

                    .Parameters.Clear()
                    .Parameters.Add(New OracleParameter("rs_testcd", rsComCd))
                    .Parameters.Add(New OracleParameter("rs_spccd", rsSpcCd))
                    .Parameters.Add(New OracleParameter("rs_editid", USER_INFO.USRID))
                    .Parameters.Add(New OracleParameter("rs_editip", USER_INFO.LOCALIP))

                    .Parameters.Add("rs_errmsg", OracleDbType.Varchar2, 4000)
                    .Parameters("rs_errmsg").Direction = ParameterDirection.InputOutput
                    .Parameters("rs_errmsg").Value = ""

                    .ExecuteNonQuery()

                    Dim sRetVal As String = .Parameters(4).Value.ToString

                    If sRetVal <> "00" Then
                        Throw (New Exception(sRetVal.Substring(2)))
                    End If
                End With

                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function TransComCdInfo_UE(ByVal rsComCd As String, ByVal rsSpcCd As String, ByVal rsUsDt As String, ByVal rsUeDt As String, ByVal rsRegID As String) As Boolean
        Dim sFn As String = "Public Function TransComCdInfo_UE(ByVal asComCd As String, ByVal asSpcCd As String, ByVal asUSDT As String, ByVal asRegID As String) As Boolean"

        Dim dbCn As OracleConnection
        Dim dbTran As OracleTransaction
        Dim dbCmd As New OracleCommand

        Try

            Dim sMsg As String = ifExistOtherUsableData("LF120", "COMCD", "SPCCD", rsComCd, rsSpcCd, rsUsDt)

            If IsNothing(sMsg) Then
                MsgBox("쿼리문의 오류가 있습니다!!", MsgBoxStyle.Exclamation)
                Exit Function
            End If

            If Not sMsg = "" Then
                MsgBox(sMsg, MsgBoxStyle.Critical)
                Exit Function
            End If

            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            dbCn = GetDbConnection()
            dbTran = dbCn.BeginTransaction()

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0
            Dim bITF_yn As Boolean = False
            Dim dt As New DataTable

            'LF120M : 성분제제마스터
            '   LF120H Insert
            'LF060H Backup
            sSql = ""
            sSql += "INSERT INTO lf120h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf120m f"
            sSql += " WHERE comcd = :comcd"
            sSql += "   AND spccd = :spccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("comcd",  OracleDbType.Varchar2).Value = rsComCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            '   LF120M Update
            sSql = ""
            sSql += "UPDATE lf120m set uedt = :uedt, regid = :regid"
            sSql += " WHERE comcd = :comcd"
            sSql += "   AND spccd = :spccd"
            sSql += "   AND usdt  = :usdt"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDt
            dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
            dbCmd.Parameters.Add("comcd",  OracleDbType.Varchar2).Value = rsComCd
            dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
            dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            If bITF_yn Then
                sSql = ""
                sSql += "UPDATE fkitf..itf_lis_lf120m set uedt = :uedt, regid = :regid"
                sSql += " WHERE comcd = :comcd"
                sSql += "   AND spccd = :spccd"
                sSql += "   AND usdt  = :usdt"

                dbCmd.Parameters.Clear()
                dbCmd.Parameters.Add("uedt",  OracleDbType.Varchar2).Value = rsUeDt
                dbCmd.Parameters.Add("regid",  OracleDbType.Varchar2).Value = rsRegID
                dbCmd.Parameters.Add("comcd",  OracleDbType.Varchar2).Value = rsComCd
                dbCmd.Parameters.Add("spccd",  OracleDbType.Varchar2).Value = rsSpcCd
                dbCmd.Parameters.Add("usdt",  OracleDbType.Varchar2).Value = rsUsDt

                dbCmd.CommandText = sSql
                iRet += dbCmd.ExecuteNonQuery()
            End If

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            If dbCn.State = ConnectionState.Open Then
                dbTran.Dispose() : dbTran = Nothing
                dbCn.Close()
            End If
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function

    Public Function fnGet_SPCList() As DataTable
        Dim sFn As String = "Public Function fnGet_SPCList() As DataTable"

        Try
            Dim sSql As String = ""

            sSql += "SELECT '[' || spccd || ']' || ' ' || spcnmd spcinfo"
            sSql += "  FROM lf030m"
            sSql += " WHERE NVL(bldgbn, '0') = '1'"

            DbCommand()
            Return DbExecuteQuery(sSql)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try

    End Function

End Class

#End Region

Public Class APP_F_USR_HOT
    Inherits APP_F

    Private Const msFile As String = "File : CGAPP_F.vb, Class : DA01.APP_F_USR_HOT" & vbTab

    Public Function fnGet_UsrMenuInfo(ByVal rsUsrID As String) As DataTable
        Dim sFn As String = "Public Function fnGet_UsrMenuInfo(String) As DataTable"

        Try
            Dim sSql As String = ""
            Dim aParam As New ArrayList

            sSql += "SELECT '' chk, f92.mnuid, f92.isparent, f92.mnulvl, f92.parentid,"
            sSql += "       LPAD('-', f92.mnulvl*4, '-') || mnunm mnunm"
            sSql += "  FROM (SELECT '1' chk, f92.mnuid "
            sSql += " 		   FROM lf092m f92, lf091m f91"
            sSql += "         WHERE f92.mnuid   = f91.mnuid"
            sSql += "           AND f92.mnugbn IN ('1', '9')"
            sSql += " 		    AND f91.usrid   = :usrid"
            sSql += "        ) f91 LEFT OUTER JOIN "
            sSql += "        lf092m f92 ON (f92.mnuid = f91.mnuid)"
            sSql += " WHERE f92.mnugbn IN ('1', '9')"
            sSql += "   AND (f92.mnulvl = 0 or f91.chk = '1')"
            sSql += "   AND mnunm  <> '-'"
            sSql += " ORDER BY f92.mnuid"

            aParam.Add(New OracleParameter("usrid",  OracleDbType.Varchar2, rsUsrID.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsrID))

            DbCommand()
            Return DbExecuteQuery(sSql, aParam)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        End Try
    End Function

    Public Function fnGet_UsrHotListInfo(ByVal rsUsrID As String) As DataTable
        Dim sFn As String = ""

        Try
            Dim sSql As String = ""
            Dim aParam As New ArrayList

            sSql += "SELECT f92.mnuid, f92.mnunm, f95.dispseq, f95.icongbn"
            sSql += "  FROM lf092m f92, lf095m f95"
            sSql += " WHERE f95.usrid = :usrid"
            sSql += "   AND f95.mnuid = f92.mnuid"
            sSql += "   AND f92.mnugbn in ('1', '9')"
            sSql += " ORDER BY f95.dispseq"

            aParam.Add(New OracleParameter("usrid",  OracleDbType.Varchar2, rsUsrID.Length, ParameterDirection.Input, Nothing, Nothing, Nothing, Nothing, DataRowVersion.Current, rsUsrID))

            DbCommand()
            Return DbExecuteQuery(sSql, aParam)

        Catch ex As Exception
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))
        End Try
    End Function

    Public Function TransUsrInfo(ByVal ro_Tcol As ItemTableCollection, ByVal rsUsrId As String) As Boolean
        Dim sFn As String = "Public Function TransUsrInfo() As Boolean"

        Dim dbCn As OracleConnection = GetDbConnection()
        Dim dbTran As OracleTransaction = dbCn.BeginTransaction()
        Dim dbCmd As New OracleCommand

        Try
            COMMON.CommFN.MdiMain.DB_Active_YN = "Y"

            With dbCmd
                .Connection = dbCn
                .Transaction = dbTran
                .CommandType = CommandType.Text
            End With

            Dim sSql As String = ""
            Dim iRet As Integer = 0

            Dim sField As String = "", sFields As String = "", sValue As String = "", sValues As String = ""

            sSql = ""
            sSql += "INSERT INTO lf095h SELECT fn_ack_sysdate, :modid, :modip, f.* FROM lf095m f"
            sSql += " WHERE usrid = :usrid"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("modid",  OracleDbType.Varchar2).Value = USER_INFO.USRID
            dbCmd.Parameters.Add("modip",  OracleDbType.Varchar2).Value = USER_INFO.LOCALIP
            dbCmd.Parameters.Add("usrid",  OracleDbType.Varchar2).Value = rsUsrId

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            sSql = ""
            sSql += "DELETE lf095m"
            sSql += " WHERE usrid = :usrid"

            dbCmd.Parameters.Clear()
            dbCmd.Parameters.Add("usrid",  OracleDbType.Varchar2).Value = rsUsrId

            dbCmd.CommandText = sSql
            iRet += dbCmd.ExecuteNonQuery()

            With ro_Tcol
                For ix1 As Integer = 0 To .ItemTableRowCount - 1
                    sField = "" : sFields = "" : sValue = "" : sValues = ""

                    dbCmd.Parameters.Clear()
                    For ix2 As Integer = 1 To .ItemTableColCount
                        sField = CType(.ItemTables.Item(.ItemTableColCount * ix1 + ix2), ItemTable).Field
                        sFields += sField + ","

                        sValue = CType(.ItemTables.Item(.ItemTableColCount * ix1 + ix2), ItemTable).Value
                        sValues += ":" + sField + ","

                        dbCmd.Parameters.Add(sField, CType(.ItemTables.Item(.ItemTableColCount * ix1 + ix2), ItemTable).DbType).Value = sValue
                    Next

                    'insert new record
                    sFields = sFields.Substring(0, sFields.Length - 1)
                    sValues = sValues.Substring(0, sValues.Length - 1)
                    sSql = "INSERT INTO lf095m (" + sFields + ") VALUES (" + sValues + ")"

                    dbCmd.CommandText = sSql
                    iRet += dbCmd.ExecuteNonQuery()
                Next
            End With

            If iRet > 0 Then
                dbTran.Commit()
                Return True
            Else
                dbTran.Rollback()
                Return False
            End If

        Catch ex As Exception
            dbTran.Rollback()
            Throw (New Exception(ex.Message + " @" + msFile + sFn, ex))

        Finally
            dbTran.Dispose() : dbTran = Nothing
            If dbCn.State = ConnectionState.Open Then dbCn.Close()
            dbCn.Dispose() : dbCn = Nothing

            COMMON.CommFN.MdiMain.DB_Active_YN = ""
        End Try
    End Function


End Class

Public Class ItemTable
    Public Field As String
    Public Value As String
    Public DbType As OracleDbType
    Public Col As Integer
    Public Row As Integer
End Class

Public Class ItemTableCollection
    Public ItemTables As Collection
    Private RowCount As Integer = 0
    Private ColCount As Integer = 0

    Public ReadOnly Property ItemTableRowCount() As Integer
        Get
            Return RowCount
        End Get
    End Property

    Public ReadOnly Property ItemTableColCount() As Integer
        Get
            Return ColCount
        End Get
    End Property

    Public Sub New()
        ItemTables = New Collection
    End Sub

    Public Sub SetItemTable(ByVal rsField As String, ByVal riCol As Integer, ByVal riRow As Integer, ByVal rsValue As String, Optional ByVal r_o_DbType As OracleDbType =  OracleDbType.Varchar2)
        Dim it As New ItemTable

        With it
            .Field = rsField
            .Col = riCol
            .Row = riRow
            .Value = rsValue
            .DbType = r_o_DbType
        End With

        ItemTables.Add(it)

        If riRow > RowCount Then
            RowCount = riRow
        End If

        If riCol > ColCount Then
            ColCount = riCol
        End If
    End Sub
End Class



