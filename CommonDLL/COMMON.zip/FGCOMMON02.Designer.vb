﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FGCOMMON02
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DesignerRectTracker1 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FGCOMMON02))
        Dim CBlendItems1 As CButtonLib.cBlendItems = New CButtonLib.cBlendItems
        Dim DesignerRectTracker2 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim DesignerRectTracker3 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim CBlendItems2 As CButtonLib.cBlendItems = New CButtonLib.cBlendItems
        Dim DesignerRectTracker4 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim DesignerRectTracker5 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim CBlendItems3 As CButtonLib.cBlendItems = New CButtonLib.cBlendItems
        Dim DesignerRectTracker6 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim DesignerRectTracker7 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim CBlendItems4 As CButtonLib.cBlendItems = New CButtonLib.cBlendItems
        Dim DesignerRectTracker8 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim DesignerRectTracker9 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim CBlendItems5 As CButtonLib.cBlendItems = New CButtonLib.cBlendItems
        Dim DesignerRectTracker10 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim DesignerRectTracker11 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim CBlendItems6 As CButtonLib.cBlendItems = New CButtonLib.cBlendItems
        Dim DesignerRectTracker12 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim DesignerRectTracker13 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim CBlendItems7 As CButtonLib.cBlendItems = New CButtonLib.cBlendItems
        Dim DesignerRectTracker14 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim DesignerRectTracker15 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim CBlendItems8 As CButtonLib.cBlendItems = New CButtonLib.cBlendItems
        Dim DesignerRectTracker16 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim DesignerRectTracker17 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim CBlendItems9 As CButtonLib.cBlendItems = New CButtonLib.cBlendItems
        Dim DesignerRectTracker18 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim DesignerRectTracker19 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim CBlendItems10 As CButtonLib.cBlendItems = New CButtonLib.cBlendItems
        Dim DesignerRectTracker20 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim DesignerRectTracker21 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim CBlendItems11 As CButtonLib.cBlendItems = New CButtonLib.cBlendItems
        Dim DesignerRectTracker22 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim DesignerRectTracker23 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Dim CBlendItems12 As CButtonLib.cBlendItems = New CButtonLib.cBlendItems
        Dim DesignerRectTracker24 As CButtonLib.DesignerRectTracker = New CButtonLib.DesignerRectTracker
        Me.btnSebu = New CButtonLib.CButton
        Me.btnPatPop = New System.Windows.Forms.Button
        Me.txtRegno = New System.Windows.Forms.TextBox
        Me.cboComCd = New System.Windows.Forms.ComboBox
        Me.dtpDate0 = New System.Windows.Forms.DateTimePicker
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker
        Me.CButton14 = New CButtonLib.CButton
        Me.Label2 = New System.Windows.Forms.Label
        Me.label56 = New System.Windows.Forms.Label
        Me.lblRegNo = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.CheckBox1 = New System.Windows.Forms.CheckBox
        Me.pnlSearchGbn = New System.Windows.Forms.Panel
        Me.rdoNoJub = New System.Windows.Forms.RadioButton
        Me.rdoJubsu = New System.Windows.Forms.RadioButton
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.btnHotList = New CButtonLib.CButton
        Me.CButton1 = New CButtonLib.CButton
        Me.CButton2 = New CButtonLib.CButton
        Me.CButton3 = New CButtonLib.CButton
        Me.CButton4 = New CButtonLib.CButton
        Me.CButton5 = New CButtonLib.CButton
        Me.CButton6 = New CButtonLib.CButton
        Me.CButton7 = New CButtonLib.CButton
        Me.CButton8 = New CButtonLib.CButton
        Me.CButton9 = New CButtonLib.CButton
        Me.pnlSearchGbn.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnSebu
        '
        Me.btnSebu.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btnSebu.CenterPtTracker = DesignerRectTracker1
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(255, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(255, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer)), System.Drawing.Color.Navy}
        CBlendItems1.iPoint = New Single() {0.0!, 0.8723404!, 0.9969605!, 1.0!}
        Me.btnSebu.ColorFillBlend = CBlendItems1
        Me.btnSebu.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btnSebu.Corners.All = CType(6, Short)
        Me.btnSebu.Corners.LowerLeft = CType(6, Short)
        Me.btnSebu.Corners.LowerRight = CType(6, Short)
        Me.btnSebu.Corners.UpperLeft = CType(6, Short)
        Me.btnSebu.Corners.UpperRight = CType(6, Short)
        Me.btnSebu.FillType = CButtonLib.CButton.eFillType.GradientLinear
        Me.btnSebu.FillTypeLinear = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.btnSebu.FocalPoints.CenterPtX = 0.4343434!
        Me.btnSebu.FocalPoints.CenterPtY = 0.44!
        Me.btnSebu.FocalPoints.FocusPtX = 0.0!
        Me.btnSebu.FocalPoints.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btnSebu.FocusPtTracker = DesignerRectTracker2
        Me.btnSebu.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.btnSebu.Image = Nothing
        Me.btnSebu.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnSebu.ImageIndex = 0
        Me.btnSebu.ImageSize = New System.Drawing.Size(16, 16)
        Me.btnSebu.Location = New System.Drawing.Point(149, 327)
        Me.btnSebu.Margin = New System.Windows.Forms.Padding(1)
        Me.btnSebu.Name = "btnSebu"
        Me.btnSebu.Shape = CButtonLib.CButton.eShape.Rectangle
        Me.btnSebu.SideImage = Nothing
        Me.btnSebu.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSebu.SideImageSize = New System.Drawing.Size(48, 48)
        Me.btnSebu.Size = New System.Drawing.Size(99, 25)
        Me.btnSebu.TabIndex = 195
        Me.btnSebu.Text = "상세조회"
        Me.btnSebu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnSebu.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btnSebu.TextMargin = New System.Windows.Forms.Padding(0)
        '
        'btnPatPop
        '
        Me.btnPatPop.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPatPop.Image = CType(resources.GetObject("btnPatPop.Image"), System.Drawing.Image)
        Me.btnPatPop.Location = New System.Drawing.Point(149, 53)
        Me.btnPatPop.Name = "btnPatPop"
        Me.btnPatPop.Size = New System.Drawing.Size(21, 21)
        Me.btnPatPop.TabIndex = 197
        Me.btnPatPop.UseVisualStyleBackColor = True
        '
        'txtRegno
        '
        Me.txtRegno.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.txtRegno.Location = New System.Drawing.Point(149, 102)
        Me.txtRegno.Margin = New System.Windows.Forms.Padding(1)
        Me.txtRegno.MaxLength = 8
        Me.txtRegno.Name = "txtRegno"
        Me.txtRegno.Size = New System.Drawing.Size(126, 21)
        Me.txtRegno.TabIndex = 198
        '
        'cboComCd
        '
        Me.cboComCd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboComCd.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.cboComCd.FormattingEnabled = True
        Me.cboComCd.Items.AddRange(New Object() {"EN", "EM", "GS", "CP", "DEP", ""})
        Me.cboComCd.Location = New System.Drawing.Point(149, 149)
        Me.cboComCd.Name = "cboComCd"
        Me.cboComCd.Size = New System.Drawing.Size(126, 20)
        Me.cboComCd.TabIndex = 199
        '
        'dtpDate0
        '
        Me.dtpDate0.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpDate0.Location = New System.Drawing.Point(149, 190)
        Me.dtpDate0.Margin = New System.Windows.Forms.Padding(1)
        Me.dtpDate0.Name = "dtpDate0"
        Me.dtpDate0.Size = New System.Drawing.Size(88, 21)
        Me.dtpDate0.TabIndex = 200
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.CustomFormat = "HH:mm"
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateTimePicker1.Location = New System.Drawing.Point(254, 190)
        Me.DateTimePicker1.Margin = New System.Windows.Forms.Padding(1)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(57, 21)
        Me.DateTimePicker1.TabIndex = 202
        '
        'CButton14
        '
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton14.CenterPtTracker = DesignerRectTracker3
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.AliceBlue, System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(180, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))}
        CBlendItems2.iPoint = New Single() {0.0!, 0.2960725!, 0.8912387!, 1.0!}
        Me.CButton14.ColorFillBlend = CBlendItems2
        Me.CButton14.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.CButton14.Corners.All = CType(6, Short)
        Me.CButton14.Corners.LowerLeft = CType(6, Short)
        Me.CButton14.Corners.LowerRight = CType(6, Short)
        Me.CButton14.Corners.UpperLeft = CType(6, Short)
        Me.CButton14.Corners.UpperRight = CType(6, Short)
        Me.CButton14.FillType = CButtonLib.CButton.eFillType.GradientLinear
        Me.CButton14.FillTypeLinear = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.CButton14.FocalPoints.CenterPtX = 0.4672897!
        Me.CButton14.FocalPoints.CenterPtY = 0.16!
        Me.CButton14.FocalPoints.FocusPtX = 0.0!
        Me.CButton14.FocalPoints.FocusPtY = 0.0!
        DesignerRectTracker4.IsActive = False
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton14.FocusPtTracker = DesignerRectTracker4
        Me.CButton14.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.CButton14.ForeColor = System.Drawing.Color.White
        Me.CButton14.Image = Nothing
        Me.CButton14.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.CButton14.ImageIndex = 0
        Me.CButton14.ImageSize = New System.Drawing.Size(16, 16)
        Me.CButton14.Location = New System.Drawing.Point(149, 376)
        Me.CButton14.Name = "CButton14"
        Me.CButton14.Shape = CButtonLib.CButton.eShape.Rectangle
        Me.CButton14.SideImage = Nothing
        Me.CButton14.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CButton14.SideImageSize = New System.Drawing.Size(48, 48)
        Me.CButton14.Size = New System.Drawing.Size(107, 25)
        Me.CButton14.TabIndex = 203
        Me.CButton14.Text = "화면정리(F4)"
        Me.CButton14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.CButton14.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.CButton14.TextMargin = New System.Windows.Forms.Padding(0)
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.Label2.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(8, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(79, 21)
        Me.Label2.TabIndex = 204
        Me.Label2.Text = "Lable"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label56
        '
        Me.label56.BackColor = System.Drawing.Color.FromArgb(CType(CType(165, Byte), Integer), CType(CType(186, Byte), Integer), CType(CType(222, Byte), Integer))
        Me.label56.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.label56.ForeColor = System.Drawing.Color.Black
        Me.label56.Location = New System.Drawing.Point(232, 9)
        Me.label56.Name = "label56"
        Me.label56.Size = New System.Drawing.Size(79, 21)
        Me.label56.TabIndex = 205
        Me.label56.Text = "처방일자"
        Me.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRegNo
        '
        Me.lblRegNo.BackColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.lblRegNo.Font = New System.Drawing.Font("굴림", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblRegNo.ForeColor = System.Drawing.Color.White
        Me.lblRegNo.Location = New System.Drawing.Point(423, 9)
        Me.lblRegNo.Name = "lblRegNo"
        Me.lblRegNo.Size = New System.Drawing.Size(100, 40)
        Me.lblRegNo.TabIndex = 206
        Me.lblRegNo.Text = "012345678"
        Me.lblRegNo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.FromArgb(CType(CType(165, Byte), Integer), CType(CType(186, Byte), Integer), CType(CType(222, Byte), Integer))
        Me.Label23.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.White
        Me.Label23.Location = New System.Drawing.Point(317, 9)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(100, 26)
        Me.Label23.TabIndex = 207
        Me.Label23.Text = "특이사항"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.Label1.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(147, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(79, 21)
        Me.Label1.TabIndex = 208
        Me.Label1.Text = "등록번호"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.Label3.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(9, 53)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(79, 21)
        Me.Label3.TabIndex = 209
        Me.Label3.Text = "Popup"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.Label4.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(8, 102)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(79, 21)
        Me.Label4.TabIndex = 210
        Me.Label4.Text = "Text Box"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.Label5.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(8, 148)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(79, 21)
        Me.Label5.TabIndex = 211
        Me.Label5.Text = "Combo"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.Label6.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(8, 190)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(79, 21)
        Me.Label6.TabIndex = 212
        Me.Label6.Text = "Calandar"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.Label7.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(8, 238)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(79, 21)
        Me.Label7.TabIndex = 213
        Me.Label7.Text = "Check Box"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.CheckBox1.Location = New System.Drawing.Point(149, 243)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(87, 16)
        Me.CheckBox1.TabIndex = 214
        Me.CheckBox1.Text = "CheckBox1"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'pnlSearchGbn
        '
        Me.pnlSearchGbn.BackColor = System.Drawing.Color.Transparent
        Me.pnlSearchGbn.Controls.Add(Me.rdoNoJub)
        Me.pnlSearchGbn.Controls.Add(Me.rdoJubsu)
        Me.pnlSearchGbn.ForeColor = System.Drawing.Color.DarkGreen
        Me.pnlSearchGbn.Location = New System.Drawing.Point(149, 282)
        Me.pnlSearchGbn.Name = "pnlSearchGbn"
        Me.pnlSearchGbn.Size = New System.Drawing.Size(204, 22)
        Me.pnlSearchGbn.TabIndex = 215
        '
        'rdoNoJub
        '
        Me.rdoNoJub.Checked = True
        Me.rdoNoJub.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rdoNoJub.ForeColor = System.Drawing.SystemColors.WindowText
        Me.rdoNoJub.Location = New System.Drawing.Point(9, 3)
        Me.rdoNoJub.Name = "rdoNoJub"
        Me.rdoNoJub.Size = New System.Drawing.Size(71, 18)
        Me.rdoNoJub.TabIndex = 5
        Me.rdoNoJub.TabStop = True
        Me.rdoNoJub.Tag = "1"
        Me.rdoNoJub.Text = "미접수"
        Me.rdoNoJub.UseCompatibleTextRendering = True
        '
        'rdoJubsu
        '
        Me.rdoJubsu.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rdoJubsu.ForeColor = System.Drawing.SystemColors.WindowText
        Me.rdoJubsu.Location = New System.Drawing.Point(96, 3)
        Me.rdoJubsu.Name = "rdoJubsu"
        Me.rdoJubsu.Size = New System.Drawing.Size(46, 18)
        Me.rdoJubsu.TabIndex = 6
        Me.rdoJubsu.Tag = "1"
        Me.rdoJubsu.Text = "접수"
        Me.rdoJubsu.UseCompatibleTextRendering = True
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.Label8.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(8, 283)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(79, 21)
        Me.Label8.TabIndex = 216
        Me.Label8.Text = "Radio"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.Label9.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(8, 327)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(119, 21)
        Me.Label9.TabIndex = 217
        Me.Label9.Text = "Link Button"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.Label10.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(8, 380)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(119, 21)
        Me.Label10.TabIndex = 218
        Me.Label10.Text = "Main Button"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.Label11.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(298, 347)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(538, 21)
        Me.Label11.TabIndex = 219
        Me.Label11.Text = "버튼 복사시 화면에 CButton이 한개도 없다면 추가 후 복사해야 버튼이 복사됨"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.Label12.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(8, 424)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(119, 21)
        Me.Label12.TabIndex = 220
        Me.Label12.Text = "Spot"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(149, 426)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(20, 19)
        Me.PictureBox1.TabIndex = 221
        Me.PictureBox1.TabStop = False
        '
        'btnHotList
        '
        Me.btnHotList.AllowDrop = True
        Me.btnHotList.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnHotList.BackgroundImage = CType(resources.GetObject("btnHotList.BackgroundImage"), System.Drawing.Image)
        Me.btnHotList.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker5.IsActive = False
        DesignerRectTracker5.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker5.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btnHotList.CenterPtTracker = DesignerRectTracker5
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.White, System.Drawing.Color.White}
        CBlendItems3.iPoint = New Single() {0.0!, 1.0!}
        Me.btnHotList.ColorFillBlend = CBlendItems3
        Me.btnHotList.ColorFillSolid = System.Drawing.Color.Peru
        Me.btnHotList.Corners.All = CType(2, Short)
        Me.btnHotList.Corners.LowerLeft = CType(2, Short)
        Me.btnHotList.Corners.LowerRight = CType(2, Short)
        Me.btnHotList.Corners.UpperLeft = CType(2, Short)
        Me.btnHotList.Corners.UpperRight = CType(2, Short)
        Me.btnHotList.FillType = CButtonLib.CButton.eFillType.Solid
        Me.btnHotList.FillTypeLinear = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.btnHotList.FocalPoints.CenterPtX = 0.04201681!
        Me.btnHotList.FocalPoints.CenterPtY = 0.4545455!
        Me.btnHotList.FocalPoints.FocusPtX = 0.0!
        Me.btnHotList.FocalPoints.FocusPtY = 0.0!
        DesignerRectTracker6.IsActive = False
        DesignerRectTracker6.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker6.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btnHotList.FocusPtTracker = DesignerRectTracker6
        Me.btnHotList.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.btnHotList.ForeColor = System.Drawing.Color.White
        Me.btnHotList.Image = Nothing
        Me.btnHotList.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnHotList.ImageIndex = 0
        Me.btnHotList.ImageSize = New System.Drawing.Size(16, 16)
        Me.btnHotList.Location = New System.Drawing.Point(272, 376)
        Me.btnHotList.Margin = New System.Windows.Forms.Padding(1)
        Me.btnHotList.Name = "btnHotList"
        Me.btnHotList.Shape = CButtonLib.CButton.eShape.Rectangle
        Me.btnHotList.SideImage = Nothing
        Me.btnHotList.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnHotList.SideImageSize = New System.Drawing.Size(48, 48)
        Me.btnHotList.Size = New System.Drawing.Size(106, 21)
        Me.btnHotList.TabIndex = 222
        Me.btnHotList.Text = "채    혈 "
        Me.btnHotList.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnHotList.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btnHotList.TextMargin = New System.Windows.Forms.Padding(0)
        '
        'CButton1
        '
        Me.CButton1.AllowDrop = True
        Me.CButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CButton1.BackgroundImage = CType(resources.GetObject("CButton1.BackgroundImage"), System.Drawing.Image)
        Me.CButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CButton1.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker7.IsActive = False
        DesignerRectTracker7.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker7.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton1.CenterPtTracker = DesignerRectTracker7
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.White, System.Drawing.Color.White}
        CBlendItems4.iPoint = New Single() {0.0!, 1.0!}
        Me.CButton1.ColorFillBlend = CBlendItems4
        Me.CButton1.ColorFillSolid = System.Drawing.Color.Peru
        Me.CButton1.Corners.All = CType(2, Short)
        Me.CButton1.Corners.LowerLeft = CType(2, Short)
        Me.CButton1.Corners.LowerRight = CType(2, Short)
        Me.CButton1.Corners.UpperLeft = CType(2, Short)
        Me.CButton1.Corners.UpperRight = CType(2, Short)
        Me.CButton1.FillType = CButtonLib.CButton.eFillType.Solid
        Me.CButton1.FillTypeLinear = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.CButton1.FocalPoints.CenterPtX = 0.04716981!
        Me.CButton1.FocalPoints.CenterPtY = 0.5238096!
        Me.CButton1.FocalPoints.FocusPtX = 0.0!
        Me.CButton1.FocalPoints.FocusPtY = 0.0!
        DesignerRectTracker8.IsActive = False
        DesignerRectTracker8.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker8.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton1.FocusPtTracker = DesignerRectTracker8
        Me.CButton1.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.CButton1.ForeColor = System.Drawing.Color.Black
        Me.CButton1.Image = Nothing
        Me.CButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.CButton1.ImageIndex = 0
        Me.CButton1.ImageSize = New System.Drawing.Size(16, 16)
        Me.CButton1.Location = New System.Drawing.Point(401, 376)
        Me.CButton1.Margin = New System.Windows.Forms.Padding(1)
        Me.CButton1.Name = "CButton1"
        Me.CButton1.Shape = CButtonLib.CButton.eShape.Rectangle
        Me.CButton1.SideImage = Nothing
        Me.CButton1.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CButton1.SideImageSize = New System.Drawing.Size(48, 48)
        Me.CButton1.Size = New System.Drawing.Size(90, 21)
        Me.CButton1.TabIndex = 223
        Me.CButton1.Text = "   채  혈 "
        Me.CButton1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.CButton1.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.CButton1.TextMargin = New System.Windows.Forms.Padding(0)
        Me.CButton1.TextShadow = System.Drawing.Color.Black
        '
        'CButton2
        '
        Me.CButton2.AllowDrop = True
        Me.CButton2.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CButton2.BackgroundImage = CType(resources.GetObject("CButton2.BackgroundImage"), System.Drawing.Image)
        Me.CButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CButton2.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker9.IsActive = False
        DesignerRectTracker9.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker9.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton2.CenterPtTracker = DesignerRectTracker9
        CBlendItems5.iColor = New System.Drawing.Color() {System.Drawing.Color.White, System.Drawing.Color.White}
        CBlendItems5.iPoint = New Single() {0.0!, 1.0!}
        Me.CButton2.ColorFillBlend = CBlendItems5
        Me.CButton2.ColorFillSolid = System.Drawing.Color.Peru
        Me.CButton2.Corners.All = CType(2, Short)
        Me.CButton2.Corners.LowerLeft = CType(2, Short)
        Me.CButton2.Corners.LowerRight = CType(2, Short)
        Me.CButton2.Corners.UpperLeft = CType(2, Short)
        Me.CButton2.Corners.UpperRight = CType(2, Short)
        Me.CButton2.FillType = CButtonLib.CButton.eFillType.Solid
        Me.CButton2.FillTypeLinear = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.CButton2.FocalPoints.CenterPtX = 0.04716981!
        Me.CButton2.FocalPoints.CenterPtY = 0.5238096!
        Me.CButton2.FocalPoints.FocusPtX = 0.0!
        Me.CButton2.FocalPoints.FocusPtY = 0.0!
        DesignerRectTracker10.IsActive = False
        DesignerRectTracker10.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker10.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton2.FocusPtTracker = DesignerRectTracker10
        Me.CButton2.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.CButton2.ForeColor = System.Drawing.Color.Black
        Me.CButton2.Image = Nothing
        Me.CButton2.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.CButton2.ImageIndex = 0
        Me.CButton2.ImageSize = New System.Drawing.Size(16, 16)
        Me.CButton2.Location = New System.Drawing.Point(524, 376)
        Me.CButton2.Margin = New System.Windows.Forms.Padding(1)
        Me.CButton2.Name = "CButton2"
        Me.CButton2.Shape = CButtonLib.CButton.eShape.Rectangle
        Me.CButton2.SideImage = Nothing
        Me.CButton2.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CButton2.SideImageSize = New System.Drawing.Size(48, 48)
        Me.CButton2.Size = New System.Drawing.Size(90, 21)
        Me.CButton2.TabIndex = 224
        Me.CButton2.Text = "  접  수"
        Me.CButton2.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.CButton2.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.CButton2.TextMargin = New System.Windows.Forms.Padding(0)
        Me.CButton2.TextShadow = System.Drawing.Color.Black
        '
        'CButton3
        '
        Me.CButton3.AllowDrop = True
        Me.CButton3.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CButton3.BackgroundImage = CType(resources.GetObject("CButton3.BackgroundImage"), System.Drawing.Image)
        Me.CButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CButton3.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker11.IsActive = False
        DesignerRectTracker11.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker11.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton3.CenterPtTracker = DesignerRectTracker11
        CBlendItems6.iColor = New System.Drawing.Color() {System.Drawing.Color.White, System.Drawing.Color.White}
        CBlendItems6.iPoint = New Single() {0.0!, 1.0!}
        Me.CButton3.ColorFillBlend = CBlendItems6
        Me.CButton3.ColorFillSolid = System.Drawing.Color.Peru
        Me.CButton3.Corners.All = CType(2, Short)
        Me.CButton3.Corners.LowerLeft = CType(2, Short)
        Me.CButton3.Corners.LowerRight = CType(2, Short)
        Me.CButton3.Corners.UpperLeft = CType(2, Short)
        Me.CButton3.Corners.UpperRight = CType(2, Short)
        Me.CButton3.FillType = CButtonLib.CButton.eFillType.Solid
        Me.CButton3.FillTypeLinear = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.CButton3.FocalPoints.CenterPtX = 0.04716981!
        Me.CButton3.FocalPoints.CenterPtY = 0.5238096!
        Me.CButton3.FocalPoints.FocusPtX = 0.0!
        Me.CButton3.FocalPoints.FocusPtY = 0.0!
        DesignerRectTracker12.IsActive = False
        DesignerRectTracker12.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker12.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton3.FocusPtTracker = DesignerRectTracker12
        Me.CButton3.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.CButton3.ForeColor = System.Drawing.Color.Black
        Me.CButton3.Image = Nothing
        Me.CButton3.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.CButton3.ImageIndex = 0
        Me.CButton3.ImageSize = New System.Drawing.Size(16, 16)
        Me.CButton3.Location = New System.Drawing.Point(643, 376)
        Me.CButton3.Margin = New System.Windows.Forms.Padding(1)
        Me.CButton3.Name = "CButton3"
        Me.CButton3.Shape = CButtonLib.CButton.eShape.Rectangle
        Me.CButton3.SideImage = Nothing
        Me.CButton3.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CButton3.SideImageSize = New System.Drawing.Size(48, 48)
        Me.CButton3.Size = New System.Drawing.Size(106, 21)
        Me.CButton3.TabIndex = 225
        Me.CButton3.Text = "  검사실인증"
        Me.CButton3.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.CButton3.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.CButton3.TextMargin = New System.Windows.Forms.Padding(0)
        Me.CButton3.TextShadow = System.Drawing.Color.Black
        '
        'CButton4
        '
        Me.CButton4.AllowDrop = True
        Me.CButton4.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CButton4.BackgroundImage = CType(resources.GetObject("CButton4.BackgroundImage"), System.Drawing.Image)
        Me.CButton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CButton4.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker13.IsActive = False
        DesignerRectTracker13.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker13.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton4.CenterPtTracker = DesignerRectTracker13
        CBlendItems7.iColor = New System.Drawing.Color() {System.Drawing.Color.White, System.Drawing.Color.White}
        CBlendItems7.iPoint = New Single() {0.0!, 1.0!}
        Me.CButton4.ColorFillBlend = CBlendItems7
        Me.CButton4.ColorFillSolid = System.Drawing.Color.Peru
        Me.CButton4.Corners.All = CType(2, Short)
        Me.CButton4.Corners.LowerLeft = CType(2, Short)
        Me.CButton4.Corners.LowerRight = CType(2, Short)
        Me.CButton4.Corners.UpperLeft = CType(2, Short)
        Me.CButton4.Corners.UpperRight = CType(2, Short)
        Me.CButton4.FillType = CButtonLib.CButton.eFillType.Solid
        Me.CButton4.FillTypeLinear = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.CButton4.FocalPoints.CenterPtX = 0.04716981!
        Me.CButton4.FocalPoints.CenterPtY = 0.5238096!
        Me.CButton4.FocalPoints.FocusPtX = 0.0!
        Me.CButton4.FocalPoints.FocusPtY = 0.0!
        DesignerRectTracker14.IsActive = False
        DesignerRectTracker14.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker14.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton4.FocusPtTracker = DesignerRectTracker14
        Me.CButton4.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.CButton4.ForeColor = System.Drawing.Color.Black
        Me.CButton4.Image = Nothing
        Me.CButton4.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.CButton4.ImageIndex = 0
        Me.CButton4.ImageSize = New System.Drawing.Size(16, 16)
        Me.CButton4.Location = New System.Drawing.Point(401, 423)
        Me.CButton4.Margin = New System.Windows.Forms.Padding(1)
        Me.CButton4.Name = "CButton4"
        Me.CButton4.Shape = CButtonLib.CButton.eShape.Rectangle
        Me.CButton4.SideImage = Nothing
        Me.CButton4.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CButton4.SideImageSize = New System.Drawing.Size(48, 48)
        Me.CButton4.Size = New System.Drawing.Size(90, 22)
        Me.CButton4.TabIndex = 226
        Me.CButton4.Text = "   결  과"
        Me.CButton4.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.CButton4.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.CButton4.TextMargin = New System.Windows.Forms.Padding(0)
        Me.CButton4.TextShadow = System.Drawing.Color.Black
        '
        'CButton5
        '
        Me.CButton5.AllowDrop = True
        Me.CButton5.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CButton5.BackgroundImage = CType(resources.GetObject("CButton5.BackgroundImage"), System.Drawing.Image)
        Me.CButton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CButton5.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker15.IsActive = False
        DesignerRectTracker15.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker15.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton5.CenterPtTracker = DesignerRectTracker15
        CBlendItems8.iColor = New System.Drawing.Color() {System.Drawing.Color.White, System.Drawing.Color.White}
        CBlendItems8.iPoint = New Single() {0.0!, 1.0!}
        Me.CButton5.ColorFillBlend = CBlendItems8
        Me.CButton5.ColorFillSolid = System.Drawing.Color.Peru
        Me.CButton5.Corners.All = CType(2, Short)
        Me.CButton5.Corners.LowerLeft = CType(2, Short)
        Me.CButton5.Corners.LowerRight = CType(2, Short)
        Me.CButton5.Corners.UpperLeft = CType(2, Short)
        Me.CButton5.Corners.UpperRight = CType(2, Short)
        Me.CButton5.FillType = CButtonLib.CButton.eFillType.Solid
        Me.CButton5.FillTypeLinear = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.CButton5.FocalPoints.CenterPtX = 0.04716981!
        Me.CButton5.FocalPoints.CenterPtY = 0.5238096!
        Me.CButton5.FocalPoints.FocusPtX = 0.0!
        Me.CButton5.FocalPoints.FocusPtY = 0.0!
        DesignerRectTracker16.IsActive = False
        DesignerRectTracker16.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker16.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton5.FocusPtTracker = DesignerRectTracker16
        Me.CButton5.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.CButton5.ForeColor = System.Drawing.Color.Black
        Me.CButton5.Image = Nothing
        Me.CButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.CButton5.ImageIndex = 0
        Me.CButton5.ImageSize = New System.Drawing.Size(16, 16)
        Me.CButton5.Location = New System.Drawing.Point(524, 423)
        Me.CButton5.Margin = New System.Windows.Forms.Padding(1)
        Me.CButton5.Name = "CButton5"
        Me.CButton5.Shape = CButtonLib.CButton.eShape.Rectangle
        Me.CButton5.SideImage = Nothing
        Me.CButton5.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CButton5.SideImageSize = New System.Drawing.Size(48, 48)
        Me.CButton5.Size = New System.Drawing.Size(90, 22)
        Me.CButton5.TabIndex = 227
        Me.CButton5.Text = "  물  품"
        Me.CButton5.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.CButton5.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.CButton5.TextMargin = New System.Windows.Forms.Padding(0)
        Me.CButton5.TextShadow = System.Drawing.Color.Black
        '
        'CButton6
        '
        Me.CButton6.AllowDrop = True
        Me.CButton6.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CButton6.BackgroundImage = CType(resources.GetObject("CButton6.BackgroundImage"), System.Drawing.Image)
        Me.CButton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CButton6.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker17.IsActive = False
        DesignerRectTracker17.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker17.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton6.CenterPtTracker = DesignerRectTracker17
        CBlendItems9.iColor = New System.Drawing.Color() {System.Drawing.Color.White, System.Drawing.Color.White}
        CBlendItems9.iPoint = New Single() {0.0!, 1.0!}
        Me.CButton6.ColorFillBlend = CBlendItems9
        Me.CButton6.ColorFillSolid = System.Drawing.Color.Peru
        Me.CButton6.Corners.All = CType(2, Short)
        Me.CButton6.Corners.LowerLeft = CType(2, Short)
        Me.CButton6.Corners.LowerRight = CType(2, Short)
        Me.CButton6.Corners.UpperLeft = CType(2, Short)
        Me.CButton6.Corners.UpperRight = CType(2, Short)
        Me.CButton6.FillType = CButtonLib.CButton.eFillType.Solid
        Me.CButton6.FillTypeLinear = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.CButton6.FocalPoints.CenterPtX = 0.04716981!
        Me.CButton6.FocalPoints.CenterPtY = 0.5238096!
        Me.CButton6.FocalPoints.FocusPtX = 0.0!
        Me.CButton6.FocalPoints.FocusPtY = 0.0!
        DesignerRectTracker18.IsActive = False
        DesignerRectTracker18.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker18.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton6.FocusPtTracker = DesignerRectTracker18
        Me.CButton6.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.CButton6.ForeColor = System.Drawing.Color.Black
        Me.CButton6.Image = Nothing
        Me.CButton6.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.CButton6.ImageIndex = 0
        Me.CButton6.ImageSize = New System.Drawing.Size(16, 16)
        Me.CButton6.Location = New System.Drawing.Point(401, 472)
        Me.CButton6.Margin = New System.Windows.Forms.Padding(1)
        Me.CButton6.Name = "CButton6"
        Me.CButton6.Shape = CButtonLib.CButton.eShape.Rectangle
        Me.CButton6.SideImage = Nothing
        Me.CButton6.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CButton6.SideImageSize = New System.Drawing.Size(48, 48)
        Me.CButton6.Size = New System.Drawing.Size(90, 22)
        Me.CButton6.TabIndex = 228
        Me.CButton6.Text = "   조  회"
        Me.CButton6.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.CButton6.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.CButton6.TextMargin = New System.Windows.Forms.Padding(0)
        Me.CButton6.TextShadow = System.Drawing.Color.Black
        '
        'CButton7
        '
        Me.CButton7.AllowDrop = True
        Me.CButton7.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CButton7.BackgroundImage = CType(resources.GetObject("CButton7.BackgroundImage"), System.Drawing.Image)
        Me.CButton7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CButton7.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker19.IsActive = False
        DesignerRectTracker19.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker19.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton7.CenterPtTracker = DesignerRectTracker19
        CBlendItems10.iColor = New System.Drawing.Color() {System.Drawing.Color.White, System.Drawing.Color.White}
        CBlendItems10.iPoint = New Single() {0.0!, 1.0!}
        Me.CButton7.ColorFillBlend = CBlendItems10
        Me.CButton7.ColorFillSolid = System.Drawing.Color.Peru
        Me.CButton7.Corners.All = CType(2, Short)
        Me.CButton7.Corners.LowerLeft = CType(2, Short)
        Me.CButton7.Corners.LowerRight = CType(2, Short)
        Me.CButton7.Corners.UpperLeft = CType(2, Short)
        Me.CButton7.Corners.UpperRight = CType(2, Short)
        Me.CButton7.FillType = CButtonLib.CButton.eFillType.Solid
        Me.CButton7.FillTypeLinear = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.CButton7.FocalPoints.CenterPtX = 0.04716981!
        Me.CButton7.FocalPoints.CenterPtY = 0.5238096!
        Me.CButton7.FocalPoints.FocusPtX = 0.0!
        Me.CButton7.FocalPoints.FocusPtY = 0.0!
        DesignerRectTracker20.IsActive = False
        DesignerRectTracker20.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker20.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton7.FocusPtTracker = DesignerRectTracker20
        Me.CButton7.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.CButton7.ForeColor = System.Drawing.Color.Black
        Me.CButton7.Image = Nothing
        Me.CButton7.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.CButton7.ImageIndex = 0
        Me.CButton7.ImageSize = New System.Drawing.Size(16, 16)
        Me.CButton7.Location = New System.Drawing.Point(643, 423)
        Me.CButton7.Margin = New System.Windows.Forms.Padding(1)
        Me.CButton7.Name = "CButton7"
        Me.CButton7.Shape = CButtonLib.CButton.eShape.Rectangle
        Me.CButton7.SideImage = Nothing
        Me.CButton7.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CButton7.SideImageSize = New System.Drawing.Size(48, 48)
        Me.CButton7.Size = New System.Drawing.Size(106, 21)
        Me.CButton7.TabIndex = 229
        Me.CButton7.Text = "  혈액은행"
        Me.CButton7.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.CButton7.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.CButton7.TextMargin = New System.Windows.Forms.Padding(0)
        Me.CButton7.TextShadow = System.Drawing.Color.Black
        '
        'CButton8
        '
        Me.CButton8.AllowDrop = True
        Me.CButton8.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CButton8.BackgroundImage = CType(resources.GetObject("CButton8.BackgroundImage"), System.Drawing.Image)
        Me.CButton8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CButton8.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker21.IsActive = False
        DesignerRectTracker21.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker21.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton8.CenterPtTracker = DesignerRectTracker21
        CBlendItems11.iColor = New System.Drawing.Color() {System.Drawing.Color.White, System.Drawing.Color.White}
        CBlendItems11.iPoint = New Single() {0.0!, 1.0!}
        Me.CButton8.ColorFillBlend = CBlendItems11
        Me.CButton8.ColorFillSolid = System.Drawing.Color.Peru
        Me.CButton8.Corners.All = CType(2, Short)
        Me.CButton8.Corners.LowerLeft = CType(2, Short)
        Me.CButton8.Corners.LowerRight = CType(2, Short)
        Me.CButton8.Corners.UpperLeft = CType(2, Short)
        Me.CButton8.Corners.UpperRight = CType(2, Short)
        Me.CButton8.FillType = CButtonLib.CButton.eFillType.Solid
        Me.CButton8.FillTypeLinear = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.CButton8.FocalPoints.CenterPtX = 0.04716981!
        Me.CButton8.FocalPoints.CenterPtY = 0.5238096!
        Me.CButton8.FocalPoints.FocusPtX = 0.0!
        Me.CButton8.FocalPoints.FocusPtY = 0.0!
        DesignerRectTracker22.IsActive = False
        DesignerRectTracker22.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker22.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton8.FocusPtTracker = DesignerRectTracker22
        Me.CButton8.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.CButton8.ForeColor = System.Drawing.Color.Black
        Me.CButton8.Image = Nothing
        Me.CButton8.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.CButton8.ImageIndex = 0
        Me.CButton8.ImageSize = New System.Drawing.Size(16, 16)
        Me.CButton8.Location = New System.Drawing.Point(524, 472)
        Me.CButton8.Margin = New System.Windows.Forms.Padding(1)
        Me.CButton8.Name = "CButton8"
        Me.CButton8.Shape = CButtonLib.CButton.eShape.Rectangle
        Me.CButton8.SideImage = Nothing
        Me.CButton8.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CButton8.SideImageSize = New System.Drawing.Size(48, 48)
        Me.CButton8.Size = New System.Drawing.Size(90, 22)
        Me.CButton8.TabIndex = 230
        Me.CButton8.Text = "   처  방"
        Me.CButton8.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.CButton8.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.CButton8.TextMargin = New System.Windows.Forms.Padding(0)
        Me.CButton8.TextShadow = System.Drawing.Color.Black
        '
        'CButton9
        '
        Me.CButton9.AllowDrop = True
        Me.CButton9.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CButton9.BackgroundImage = CType(resources.GetObject("CButton9.BackgroundImage"), System.Drawing.Image)
        Me.CButton9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CButton9.BorderColor = System.Drawing.Color.DarkGray
        DesignerRectTracker23.IsActive = False
        DesignerRectTracker23.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker23.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton9.CenterPtTracker = DesignerRectTracker23
        CBlendItems12.iColor = New System.Drawing.Color() {System.Drawing.Color.White, System.Drawing.Color.White}
        CBlendItems12.iPoint = New Single() {0.0!, 1.0!}
        Me.CButton9.ColorFillBlend = CBlendItems12
        Me.CButton9.ColorFillSolid = System.Drawing.Color.Peru
        Me.CButton9.Corners.All = CType(2, Short)
        Me.CButton9.Corners.LowerLeft = CType(2, Short)
        Me.CButton9.Corners.LowerRight = CType(2, Short)
        Me.CButton9.Corners.UpperLeft = CType(2, Short)
        Me.CButton9.Corners.UpperRight = CType(2, Short)
        Me.CButton9.FillType = CButtonLib.CButton.eFillType.Solid
        Me.CButton9.FillTypeLinear = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        Me.CButton9.FocalPoints.CenterPtX = 0.04716981!
        Me.CButton9.FocalPoints.CenterPtY = 0.5238096!
        Me.CButton9.FocalPoints.FocusPtX = 0.0!
        Me.CButton9.FocalPoints.FocusPtY = 0.0!
        DesignerRectTracker24.IsActive = False
        DesignerRectTracker24.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker24.TrackerRectangle"), System.Drawing.RectangleF)
        Me.CButton9.FocusPtTracker = DesignerRectTracker24
        Me.CButton9.Font = New System.Drawing.Font("굴림체", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.CButton9.ForeColor = System.Drawing.Color.Black
        Me.CButton9.Image = Nothing
        Me.CButton9.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.CButton9.ImageIndex = 0
        Me.CButton9.ImageSize = New System.Drawing.Size(16, 16)
        Me.CButton9.Location = New System.Drawing.Point(643, 472)
        Me.CButton9.Margin = New System.Windows.Forms.Padding(1)
        Me.CButton9.Name = "CButton9"
        Me.CButton9.Shape = CButtonLib.CButton.eShape.Rectangle
        Me.CButton9.SideImage = Nothing
        Me.CButton9.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CButton9.SideImageSize = New System.Drawing.Size(48, 48)
        Me.CButton9.Size = New System.Drawing.Size(106, 22)
        Me.CButton9.TabIndex = 231
        Me.CButton9.Text = "   마스터"
        Me.CButton9.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.CButton9.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.CButton9.TextMargin = New System.Windows.Forms.Padding(0)
        Me.CButton9.TextShadow = System.Drawing.Color.Black
        '
        'FGCOMMON02
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1272, 875)
        Me.Controls.Add(Me.CButton9)
        Me.Controls.Add(Me.CButton8)
        Me.Controls.Add(Me.CButton7)
        Me.Controls.Add(Me.CButton6)
        Me.Controls.Add(Me.CButton5)
        Me.Controls.Add(Me.CButton4)
        Me.Controls.Add(Me.CButton3)
        Me.Controls.Add(Me.CButton2)
        Me.Controls.Add(Me.CButton1)
        Me.Controls.Add(Me.btnHotList)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.pnlSearchGbn)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.lblRegNo)
        Me.Controls.Add(Me.label56)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.CButton14)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.dtpDate0)
        Me.Controls.Add(Me.cboComCd)
        Me.Controls.Add(Me.txtRegno)
        Me.Controls.Add(Me.btnPatPop)
        Me.Controls.Add(Me.btnSebu)
        Me.Name = "FGCOMMON02"
        Me.Text = "표준화 컴포넌트"
        Me.pnlSearchGbn.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnSebu As CButtonLib.CButton
    Friend WithEvents btnPatPop As System.Windows.Forms.Button
    Friend WithEvents txtRegno As System.Windows.Forms.TextBox
    Friend WithEvents cboComCd As System.Windows.Forms.ComboBox
    Friend WithEvents dtpDate0 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents CButton14 As CButtonLib.CButton
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents label56 As System.Windows.Forms.Label
    Friend WithEvents lblRegNo As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents pnlSearchGbn As System.Windows.Forms.Panel
    Friend WithEvents rdoNoJub As System.Windows.Forms.RadioButton
    Friend WithEvents rdoJubsu As System.Windows.Forms.RadioButton
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents btnHotList As CButtonLib.CButton
    Friend WithEvents CButton1 As CButtonLib.CButton
    Friend WithEvents CButton2 As CButtonLib.CButton
    Friend WithEvents CButton3 As CButtonLib.CButton
    Friend WithEvents CButton4 As CButtonLib.CButton
    Friend WithEvents CButton5 As CButtonLib.CButton
    Friend WithEvents CButton6 As CButtonLib.CButton
    Friend WithEvents CButton7 As CButtonLib.CButton
    Friend WithEvents CButton8 As CButtonLib.CButton
    Friend WithEvents CButton9 As CButtonLib.CButton
End Class
